
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/trusted-materialized-read-r26/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001006871e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>:
1006871e4:     	stp	x24, x23, [sp, #-0x40]!
1006871e8:     	stp	x22, x21, [sp, #0x10]
1006871ec:     	stp	x20, x19, [sp, #0x20]
1006871f0:     	stp	x29, x30, [sp, #0x30]
1006871f4:     	add	x29, sp, #0x30
1006871f8:     	mov	x20, x0
1006871fc:     	ldr	x23, [x20, #0x20]!
100687200:     	cbz	x23, 0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687204:     	mov	x19, x0
100687208:     	lsr	x8, x23, #51
10068720c:     	mov	x21, x23
100687210:     	cmp	x8, #0xfff
100687214:     	b.lo	0x10068722c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x48>
100687218:     	mov	w8, #0x7ffc             ; =32764
10068721c:     	cmp	x8, x23, lsr #48
100687220:     	b.eq	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687224:     	ands	x21, x23, #0xffffffffffff
100687228:     	b.eq	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068722c:     	and	x8, x21, #0xfffffffffff00000
100687230:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
100687234:     	mov	x10, #0x7ffffffff000    ; =140737488351232
100687238:     	cmp	x9, x10
10068723c:     	ccmp	x8, #0x0, #0x4, lo
100687240:     	b.eq	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687244:     	tst	x21, #0x3
100687248:     	ccmp	x21, #0x7, #0x0, eq
10068724c:     	b.ls	0x1006873d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687250:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687254:     	ldr	x8, [x8, #0x30]
100687258:     	cmn	x8, #0x1
10068725c:     	b.eq	0x100687324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
100687260:     	mrs	x9, TPIDRRO_EL0
100687264:     	and	x9, x9, #0xfffffffffffffff8
100687268:     	ldr	x0, [x9, x8, lsl #3]
10068726c:     	cbz	x0, 0x100687324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
100687270:     	lsr	x1, x21, #20
100687274:     	ldr	x8, [x0, #0x10]
100687278:     	ldrb	w9, [x8]
10068727c:     	cmp	w9, #0x2
100687280:     	b.ne	0x10068733c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x158>
100687284:     	ldrb	w9, [x8, #0x88]
100687288:     	tbz	w9, #0x0, 0x1006872a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
10068728c:     	ldr	x9, [x8, #0x80]
100687290:     	cmp	x9, x1
100687294:     	b.ne	0x1006872a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
100687298:     	ldp	x9, x10, [x8, #0x60]
10068729c:     	cmp	x9, x21
1006872a0:     	ccmp	x10, x21, #0x0, ls
1006872a4:     	b.hi	0x10068731c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x138>
1006872a8:     	ldrb	w9, [x8, #0xb8]
1006872ac:     	cbz	w9, 0x1006872cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
1006872b0:     	ldr	x9, [x8, #0xb0]
1006872b4:     	cmp	x9, x1
1006872b8:     	b.ne	0x1006872cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
1006872bc:     	ldp	x9, x10, [x8, #0x90]
1006872c0:     	cmp	x9, x21
1006872c4:     	ccmp	x10, x21, #0x0, ls
1006872c8:     	b.hi	0x100687648 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x464>
1006872cc:     	ldrb	w9, [x8, #0xe8]
1006872d0:     	cbz	w9, 0x1006872f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
1006872d4:     	ldr	x9, [x8, #0xe0]
1006872d8:     	cmp	x9, x1
1006872dc:     	b.ne	0x1006872f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
1006872e0:     	ldp	x9, x10, [x8, #0xc0]
1006872e4:     	cmp	x9, x21
1006872e8:     	ccmp	x10, x21, #0x0, ls
1006872ec:     	b.hi	0x100687650 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x46c>
1006872f0:     	ldrb	w9, [x8, #0x118]
1006872f4:     	cbz	w9, 0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006872f8:     	ldr	x9, [x8, #0x110]
1006872fc:     	cmp	x9, x1
100687300:     	b.ne	0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
100687304:     	ldp	x9, x10, [x8, #0xf0]
100687308:     	cmp	x9, x21
10068730c:     	ccmp	x10, x21, #0x0, ls
100687310:     	b.ls	0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
100687314:     	add	x9, x8, #0xf0
100687318:     	b	0x100687654 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
10068731c:     	add	x9, x8, #0x60
100687320:     	b	0x100687654 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
100687324:     	bl	0x100b3defc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100687328:     	lsr	x1, x21, #20
10068732c:     	ldr	x8, [x0, #0x10]
100687330:     	ldrb	w9, [x8]
100687334:     	cmp	w9, #0x2
100687338:     	b.eq	0x100687284 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xa0>
10068733c:     	ldr	x9, [x8, #0x8]
100687340:     	ldr	x10, [x8, #0x28]
100687344:     	sub	x9, x1, x9
100687348:     	cmp	x9, x10
10068734c:     	b.hs	0x100687390 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1ac>
100687350:     	ldr	x10, [x8, #0x20]
100687354:     	mov	w11, #0x28              ; =40
100687358:     	madd	x9, x9, x11, x10
10068735c:     	ldr	x10, [x9]
100687360:     	ldr	x11, [x8, #0x10]
100687364:     	cmp	x10, x11
100687368:     	b.ne	0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
10068736c:     	ldp	x10, x11, [x9, #0x8]
100687370:     	cmp	x10, x21
100687374:     	ccmp	x11, x21, #0x0, ls
100687378:     	b.ls	0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
10068737c:     	ldr	x10, [x8, #0x30]
100687380:     	add	x10, x10, #0x1
100687384:     	str	x10, [x8, #0x30]
100687388:     	add	x8, x9, #0x21
10068738c:     	b	0x100687664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x480>
100687390:     	ldr	x9, [x8, #0x58]
100687394:     	add	x9, x9, #0x1
100687398:     	str	x9, [x8, #0x58]
10068739c:     	ldr	x9, [x8, #0x38]
1006873a0:     	add	x9, x9, #0x1
1006873a4:     	str	x9, [x8, #0x38]
1006873a8:     	mov	x0, x21
1006873ac:     	bl	0x10051d1c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1006873b0:     	and	w8, w0, #0xff
1006873b4:     	cbz	w8, 0x1006873d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
1006873b8:     	ldurb	w8, [x21, #-0x8]
1006873bc:     	ldurb	w9, [x21, #-0x7]
1006873c0:     	mov	w10, #0x82              ; =130
1006873c4:     	and	w9, w9, w10
1006873c8:     	cmp	w9, #0x2
1006873cc:     	ccmp	w8, #0x1, #0x0, eq
1006873d0:     	b.eq	0x100687544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x360>
1006873d4:     	mov	x0, x21
1006873d8:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006873dc:     	mov	x22, x0
1006873e0:     	cbz	x0, 0x10068740c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x228>
1006873e4:     	ldrb	w8, [x22]
1006873e8:     	cmp	w8, #0x1
1006873ec:     	b.ne	0x100687420 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x23c>
1006873f0:     	ldrsb	w8, [x22, #0x1]
1006873f4:     	tbnz	w8, #0x1f, 0x1006875b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3cc>
1006873f8:     	mov	x0, x22
1006873fc:     	ldp	w9, w8, [x21]
100687400:     	cmp	w9, w8
100687404:     	b.ls	0x1006874d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
100687408:     	b	0x1006874bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2d8>
10068740c:     	mov	x0, x21
100687410:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100687414:     	tbz	w0, #0x0, 0x10068745c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x278>
100687418:     	mov	x0, #0x0                ; =0
10068741c:     	b	0x1006874ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
100687420:     	mov	x0, x22
100687424:     	cmp	w8, #0x1
100687428:     	b.eq	0x1006874ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
10068742c:     	cmp	w8, #0x9
100687430:     	b.ne	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687434:     	ldr	w8, [x21, #0x4]
100687438:     	mov	w9, #0x5841             ; =22593
10068743c:     	movk	w9, #0x4c5a, lsl #16
100687440:     	cmp	w8, w9
100687444:     	b.ne	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687448:     	mov	x0, x21
10068744c:     	bl	0x100374cd0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100687450:     	mov	x8, x0
100687454:     	cbnz	x0, 0x10068756c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
100687458:     	b	0x100687630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
10068745c:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687460:     	add	x8, x8, #0xe80
100687464:     	ldaprb	w8, [x8]
100687468:     	cbz	w8, 0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068746c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687470:     	add	x8, x8, #0x40
100687474:     	ldapr	x8, [x8]
100687478:     	cmp	x8, x21
10068747c:     	b.hi	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687480:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687484:     	add	x8, x8, #0x48
100687488:     	ldapr	x8, [x8]
10068748c:     	cmp	x8, x21
100687490:     	b.lo	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687494:     	mov	x0, x21
100687498:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
10068749c:     	mov	x9, x0
1006874a0:     	mov	x0, #0x0                ; =0
1006874a4:     	mov	x8, #0x0                ; =0
1006874a8:     	tbz	w9, #0x0, 0x100687630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006874ac:     	ldp	w9, w8, [x21]
1006874b0:     	cmp	w9, w8
1006874b4:     	b.ls	0x1006874d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
1006874b8:     	cbz	x22, 0x1006874ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
1006874bc:     	ldr	w9, [x0, #0x4]
1006874c0:     	ubfiz	x8, x8, #3, #32
1006874c4:     	add	x10, x8, #0x10
1006874c8:     	mov	x8, x21
1006874cc:     	cmp	x10, x9
1006874d0:     	b.ne	0x1006874ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
1006874d4:     	b	0x10068756c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
1006874d8:     	mov	w10, #0xe100            ; =57600
1006874dc:     	movk	w10, #0x5f5, lsl #16
1006874e0:     	mov	x8, x21
1006874e4:     	cmp	w9, w10
1006874e8:     	b.ls	0x10068756c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
1006874ec:     	mov	x0, x21
1006874f0:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1006874f4:     	tbnz	w0, #0x0, 0x100687568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x384>
1006874f8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1006874fc:     	add	x8, x8, #0xe80
100687500:     	ldaprb	w8, [x8]
100687504:     	cbz	w8, 0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687508:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
10068750c:     	add	x8, x8, #0x40
100687510:     	ldapr	x8, [x8]
100687514:     	cmp	x21, x8
100687518:     	b.lo	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068751c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687520:     	add	x8, x8, #0x48
100687524:     	ldapr	x8, [x8]
100687528:     	cmp	x21, x8
10068752c:     	b.hi	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687530:     	mov	x0, x21
100687534:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100687538:     	mov	x8, x21
10068753c:     	tbz	w0, #0x0, 0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687540:     	b	0x10068756c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
100687544:     	ldr	w8, [x21]
100687548:     	mov	w9, #0xe100             ; =57600
10068754c:     	movk	w9, #0x5f5, lsl #16
100687550:     	orr	w9, w9, #0x1
100687554:     	cmp	w8, w9
100687558:     	b.hs	0x1006873d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
10068755c:     	ldr	w9, [x21, #0x4]
100687560:     	cmp	w8, w9
100687564:     	b.hi	0x1006873d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687568:     	mov	x8, x21
10068756c:     	cmp	x8, x23
100687570:     	b.eq	0x1006876d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
100687574:     	str	x8, [x19, #0x20]
100687578:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
10068757c:     	add	x9, x9, #0x260
100687580:     	ldapr	x9, [x9]
100687584:     	cbnz	x9, 0x100687674 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x490>
100687588:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
10068758c:     	ldrb	w9, [x9, #0x268]
100687590:     	tbz	w9, #0x0, 0x10068768c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4a8>
100687594:     	mov	x21, x8
100687598:     	mov	x0, x19
10068759c:     	mov	x1, x20
1006875a0:     	mov	x2, x8
1006875a4:     	mov	w3, #0x0                ; =0
1006875a8:     	bl	0x100473c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier26write_barrier_slot_decoded>
1006875ac:     	b	0x1006876a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c0>
1006875b0:     	ldr	x21, [x22, #0x8]
1006875b4:     	mov	x0, x21
1006875b8:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006875bc:     	cbz	x0, 0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006875c0:     	ldrb	w8, [x0]
1006875c4:     	cmp	w8, #0x1
1006875c8:     	b.ne	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006875cc:     	ldrsb	w8, [x0, #0x1]
1006875d0:     	tbz	w8, #0x1f, 0x1006873fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x218>
1006875d4:     	mov	w24, #0x1               ; =1
1006875d8:     	ldr	x21, [x0, #0x8]
1006875dc:     	mov	x0, x21
1006875e0:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006875e4:     	mov	x8, #0x0                ; =0
1006875e8:     	cbz	x0, 0x100687630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006875ec:     	ldrb	w9, [x0]
1006875f0:     	cmp	w9, #0x1
1006875f4:     	b.ne	0x100687630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006875f8:     	cmp	w24, #0x3f
1006875fc:     	b.hi	0x100687630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687600:     	add	w24, w24, #0x1
100687604:     	ldrsb	w8, [x0, #0x1]
100687608:     	tbnz	w8, #0x1f, 0x1006875d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3f4>
10068760c:     	str	x21, [x22, #0x8]
100687610:     	ldrb	w8, [x22, #0x1]
100687614:     	orr	w8, w8, #0x80
100687618:     	strb	w8, [x22, #0x1]
10068761c:     	ldrb	w8, [x0]
100687620:     	cmp	w8, #0x1
100687624:     	b.ne	0x10068742c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x248>
100687628:     	b	0x1006874ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
10068762c:     	mov	x8, #0x0                ; =0
100687630:     	mov	x0, x8
100687634:     	ldp	x29, x30, [sp, #0x30]
100687638:     	ldp	x20, x19, [sp, #0x20]
10068763c:     	ldp	x22, x21, [sp, #0x10]
100687640:     	ldp	x24, x23, [sp], #0x40
100687644:     	ret
100687648:     	add	x9, x8, #0x90
10068764c:     	b	0x100687654 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
100687650:     	add	x9, x8, #0xc0
100687654:     	ldr	x10, [x8, #0x30]
100687658:     	add	x10, x10, #0x1
10068765c:     	str	x10, [x8, #0x30]
100687660:     	add	x8, x9, #0x19
100687664:     	ldrb	w8, [x8]
100687668:     	cmp	w8, #0xff
10068766c:     	b.ne	0x1006873b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1d0>
100687670:     	b	0x1006873a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1c4>
100687674:     	mov	x21, x8
100687678:     	bl	0x100b18024 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier22write_barriers_enabled0E0zEB1A_>
10068767c:     	mov	x8, x21
100687680:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
100687684:     	ldrb	w9, [x9, #0x268]
100687688:     	tbnz	w9, #0x0, 0x100687594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3b0>
10068768c:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687690:     	ldr	w9, [x9, #0x824]
100687694:     	cbz	w9, 0x1006876a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c4>
100687698:     	mov	x21, x8
10068769c:     	mov	x0, x8
1006876a0:     	bl	0x1004755b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1006876a4:     	mov	x8, x21
1006876a8:     	ldr	x9, [x20]
1006876ac:     	cbz	x9, 0x1006876d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
1006876b0:     	ldr	x9, [x19, #0x10]
1006876b4:     	cbz	x9, 0x1006876d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
1006876b8:     	mov	x20, x8
1006876bc:     	mov	x0, x19
1006876c0:     	bl	0x1002dce7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime15json_tape_store7release>
1006876c4:     	mov	x8, x20
1006876c8:     	str	xzr, [x19, #0x10]
1006876cc:     	str	wzr, [x19, #0xc]
1006876d0:     	ldr	w9, [x8]
1006876d4:     	str	w9, [x19]
1006876d8:     	b	0x100687630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
