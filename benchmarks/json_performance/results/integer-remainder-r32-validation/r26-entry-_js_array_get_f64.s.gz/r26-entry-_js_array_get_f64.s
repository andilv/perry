
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/integer-remainder-r32/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bded0 <_js_array_get_f64>:
1007bded0:     	sub	sp, sp, #0x70
1007bded4:     	stp	x26, x25, [sp, #0x20]
1007bded8:     	stp	x24, x23, [sp, #0x30]
1007bdedc:     	stp	x22, x21, [sp, #0x40]
1007bdee0:     	stp	x20, x19, [sp, #0x50]
1007bdee4:     	stp	x29, x30, [sp, #0x60]
1007bdee8:     	add	x29, sp, #0x60
1007bdeec:     	mov	x19, x1
1007bdef0:     	mov	x22, x0
1007bdef4:     	lsr	x25, x0, #51
1007bdef8:     	mov	x20, x0
1007bdefc:     	cmp	x25, #0xfff
1007bdf00:     	b.lo	0x1007bdf1c <_js_array_get_f64+0x4c>
1007bdf04:     	mov	w8, #0x7ffc             ; =32764
1007bdf08:     	cmp	x8, x22, lsr #48
1007bdf0c:     	b.ne	0x1007bdf18 <_js_array_get_f64+0x48>
1007bdf10:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bdf14:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007bdf18:     	and	x20, x22, #0xffffffffffff
1007bdf1c:     	lsr	x8, x20, #3
1007bdf20:     	cmp	x8, #0x200
1007bdf24:     	b.ls	0x1007bdf5c <_js_array_get_f64+0x8c>
1007bdf28:     	ldurb	w8, [x20, #-0x8]
1007bdf2c:     	cmp	w8, #0x9
1007bdf30:     	b.ne	0x1007bdf5c <_js_array_get_f64+0x8c>
1007bdf34:     	ldr	w8, [x20, #0x4]
1007bdf38:     	mov	w9, #0x5841             ; =22593
1007bdf3c:     	movk	w9, #0x4c5a, lsl #16
1007bdf40:     	cmp	w8, w9
1007bdf44:     	b.ne	0x1007bdf5c <_js_array_get_f64+0x8c>
1007bdf48:     	mov	x0, x20
1007bdf4c:     	mov	x1, x19
1007bdf50:     	bl	0x100687f04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007bdf54:     	fmov	d0, x0
1007bdf58:     	b	0x1007be5cc <_js_array_get_f64+0x6fc>
1007bdf5c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bdf60:     	b.lo	0x1007be010 <_js_array_get_f64+0x140>
1007bdf64:     	tst	x20, #0xffff800000000000
1007bdf68:     	mov	w8, #0x1000             ; =4096
1007bdf6c:     	ccmp	x20, x8, #0x0, eq
1007bdf70:     	b.lo	0x1007be010 <_js_array_get_f64+0x140>
1007bdf74:     	ldurb	w24, [x20, #-0x8]
1007bdf78:     	ldurh	w23, [x20, #-0x6]
1007bdf7c:     	cmp	w24, #0xa
1007bdf80:     	b.gt	0x1007be128 <_js_array_get_f64+0x258>
1007bdf84:     	cmp	w24, #0x2
1007bdf88:     	b.eq	0x1007be1b0 <_js_array_get_f64+0x2e0>
1007bdf8c:     	cmp	w24, #0x8
1007bdf90:     	b.ne	0x1007be018 <_js_array_get_f64+0x148>
1007bdf94:     	mov	x0, x20
1007bdf98:     	bl	0x1003051a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bdf9c:     	cbz	w0, 0x1007be240 <_js_array_get_f64+0x370>
1007bdfa0:     	mov	x22, #0x1               ; =1
1007bdfa4:     	movk	x22, #0x7ffc, lsl #48
1007bdfa8:     	lsr	x8, x20, #51
1007bdfac:     	cmp	x8, #0xfff
1007bdfb0:     	b.lo	0x1007bdfc4 <_js_array_get_f64+0xf4>
1007bdfb4:     	mov	w8, #0x7ffc             ; =32764
1007bdfb8:     	cmp	x8, x20, lsr #48
1007bdfbc:     	b.eq	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007bdfc0:     	and	x20, x20, #0xffffffffffff
1007bdfc4:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bdfc8:     	b.lo	0x1007bdfe8 <_js_array_get_f64+0x118>
1007bdfcc:     	tst	x20, #0xffff800000000000
1007bdfd0:     	mov	w8, #0x1000             ; =4096
1007bdfd4:     	ccmp	x20, x8, #0x0, eq
1007bdfd8:     	b.lo	0x1007bdfe8 <_js_array_get_f64+0x118>
1007bdfdc:     	ldurb	w8, [x20, #-0x8]
1007bdfe0:     	cmp	w8, #0x2
1007bdfe4:     	b.eq	0x1007be8b4 <_js_array_get_f64+0x9e4>
1007bdfe8:     	cbz	x20, 0x1007be5c8 <_js_array_get_f64+0x6f8>
1007bdfec:     	mov	x0, x20
1007bdff0:     	mov	x1, x19
1007bdff4:     	bl	0x100305358 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bdff8:     	cmp	w0, #0x1
1007bdffc:     	b.ne	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be000:     	ldr	x8, [x20, #0x8]
1007be004:     	ubfiz	x9, x1, #4, #32
1007be008:     	ldr	x22, [x8, x9]
1007be00c:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be010:     	mov	w23, #0x0               ; =0
1007be014:     	mov	w24, #0x0               ; =0
1007be018:     	mov	x21, x22
1007be01c:     	cmp	x25, #0xfff
1007be020:     	b.lo	0x1007be038 <_js_array_get_f64+0x168>
1007be024:     	mov	w8, #0x7ffc             ; =32764
1007be028:     	cmp	x8, x22, lsr #48
1007be02c:     	b.eq	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be030:     	ands	x21, x22, #0xffffffffffff
1007be034:     	b.eq	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be038:     	and	x8, x21, #0xfffffffffff00000
1007be03c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007be040:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007be044:     	cmp	x9, x10
1007be048:     	ccmp	x8, #0x0, #0x4, lo
1007be04c:     	b.eq	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be050:     	tst	x21, #0x3
1007be054:     	ccmp	x21, #0x7, #0x0, eq
1007be058:     	b.ls	0x1007be308 <_js_array_get_f64+0x438>
1007be05c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be060:     	ldr	x8, [x8, #0x48]
1007be064:     	cmn	x8, #0x1
1007be068:     	b.eq	0x1007be258 <_js_array_get_f64+0x388>
1007be06c:     	mrs	x9, TPIDRRO_EL0
1007be070:     	and	x9, x9, #0xfffffffffffffff8
1007be074:     	ldr	x0, [x9, x8, lsl #3]
1007be078:     	cbz	x0, 0x1007be258 <_js_array_get_f64+0x388>
1007be07c:     	lsr	x1, x21, #20
1007be080:     	ldr	x8, [x0, #0x10]
1007be084:     	ldrb	w9, [x8]
1007be088:     	cmp	w9, #0x2
1007be08c:     	b.ne	0x1007be270 <_js_array_get_f64+0x3a0>
1007be090:     	ldrb	w9, [x8, #0x88]
1007be094:     	tbz	w9, #0x0, 0x1007be0b4 <_js_array_get_f64+0x1e4>
1007be098:     	ldr	x9, [x8, #0x80]
1007be09c:     	cmp	x9, x1
1007be0a0:     	b.ne	0x1007be0b4 <_js_array_get_f64+0x1e4>
1007be0a4:     	ldp	x9, x10, [x8, #0x60]
1007be0a8:     	cmp	x9, x21
1007be0ac:     	ccmp	x10, x21, #0x0, ls
1007be0b0:     	b.hi	0x1007be250 <_js_array_get_f64+0x380>
1007be0b4:     	ldrb	w9, [x8, #0xb8]
1007be0b8:     	cbz	w9, 0x1007be0d8 <_js_array_get_f64+0x208>
1007be0bc:     	ldr	x9, [x8, #0xb0]
1007be0c0:     	cmp	x9, x1
1007be0c4:     	b.ne	0x1007be0d8 <_js_array_get_f64+0x208>
1007be0c8:     	ldp	x9, x10, [x8, #0x90]
1007be0cc:     	cmp	x9, x21
1007be0d0:     	ccmp	x10, x21, #0x0, ls
1007be0d4:     	b.hi	0x1007be718 <_js_array_get_f64+0x848>
1007be0d8:     	ldrb	w9, [x8, #0xe8]
1007be0dc:     	cbz	w9, 0x1007be0fc <_js_array_get_f64+0x22c>
1007be0e0:     	ldr	x9, [x8, #0xe0]
1007be0e4:     	cmp	x9, x1
1007be0e8:     	b.ne	0x1007be0fc <_js_array_get_f64+0x22c>
1007be0ec:     	ldp	x9, x10, [x8, #0xc0]
1007be0f0:     	cmp	x9, x21
1007be0f4:     	ccmp	x10, x21, #0x0, ls
1007be0f8:     	b.hi	0x1007be800 <_js_array_get_f64+0x930>
1007be0fc:     	ldrb	w9, [x8, #0x118]
1007be100:     	cbz	w9, 0x1007be2d0 <_js_array_get_f64+0x400>
1007be104:     	ldr	x9, [x8, #0x110]
1007be108:     	cmp	x9, x1
1007be10c:     	b.ne	0x1007be2d0 <_js_array_get_f64+0x400>
1007be110:     	ldp	x9, x10, [x8, #0xf0]
1007be114:     	cmp	x9, x21
1007be118:     	ccmp	x10, x21, #0x0, ls
1007be11c:     	b.ls	0x1007be2d0 <_js_array_get_f64+0x400>
1007be120:     	add	x9, x8, #0xf0
1007be124:     	b	0x1007be804 <_js_array_get_f64+0x934>
1007be128:     	cmp	w24, #0xb
1007be12c:     	b.eq	0x1007be1c8 <_js_array_get_f64+0x2f8>
1007be130:     	cmp	w24, #0xc
1007be134:     	b.ne	0x1007be018 <_js_array_get_f64+0x148>
1007be138:     	mov	x0, x20
1007be13c:     	bl	0x10030af38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be140:     	cbz	w0, 0x1007be248 <_js_array_get_f64+0x378>
1007be144:     	mov	x22, #0x1               ; =1
1007be148:     	movk	x22, #0x7ffc, lsl #48
1007be14c:     	lsr	x8, x20, #51
1007be150:     	cmp	x8, #0xfff
1007be154:     	b.lo	0x1007be168 <_js_array_get_f64+0x298>
1007be158:     	mov	w8, #0x7ffc             ; =32764
1007be15c:     	cmp	x8, x20, lsr #48
1007be160:     	b.eq	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be164:     	and	x20, x20, #0xffffffffffff
1007be168:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be16c:     	b.lo	0x1007be18c <_js_array_get_f64+0x2bc>
1007be170:     	tst	x20, #0xffff800000000000
1007be174:     	mov	w8, #0x1000             ; =4096
1007be178:     	ccmp	x20, x8, #0x0, eq
1007be17c:     	b.lo	0x1007be18c <_js_array_get_f64+0x2bc>
1007be180:     	ldurb	w8, [x20, #-0x8]
1007be184:     	cmp	w8, #0x2
1007be188:     	b.eq	0x1007be8cc <_js_array_get_f64+0x9fc>
1007be18c:     	cbz	x20, 0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be190:     	mov	x0, x20
1007be194:     	mov	x1, x19
1007be198:     	bl	0x10030cbb0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be19c:     	cmp	w0, #0x1
1007be1a0:     	b.ne	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be1a4:     	ldr	x8, [x20, #0x8]
1007be1a8:     	ldr	x22, [x8, w1, uxtw #3]
1007be1ac:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be1b0:     	mov	x0, x22
1007be1b4:     	mov	x1, x19
1007be1b8:     	bl	0x10054860c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be1bc:     	tbnz	w0, #0x0, 0x1007be5c4 <_js_array_get_f64+0x6f4>
1007be1c0:     	mov	w24, #0x2               ; =2
1007be1c4:     	b	0x1007be018 <_js_array_get_f64+0x148>
1007be1c8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be1cc:     	add	x8, x8, #0xec0
1007be1d0:     	ldaprb	w8, [x8]
1007be1d4:     	cbz	w8, 0x1007be238 <_js_array_get_f64+0x368>
1007be1d8:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be1dc:     	add	x8, x8, #0x58
1007be1e0:     	ldapr	x8, [x8]
1007be1e4:     	cmp	x20, x8
1007be1e8:     	b.lo	0x1007be238 <_js_array_get_f64+0x368>
1007be1ec:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be1f0:     	add	x8, x8, #0x60
1007be1f4:     	ldapr	x8, [x8]
1007be1f8:     	cmp	x20, x8
1007be1fc:     	b.hi	0x1007be238 <_js_array_get_f64+0x368>
1007be200:     	mov	x0, x20
1007be204:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be208:     	tbz	w0, #0x0, 0x1007be238 <_js_array_get_f64+0x368>
1007be20c:     	add	x0, sp, #0x8
1007be210:     	mov	x1, x20
1007be214:     	bl	0x1002a4aac <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be218:     	ldr	x8, [sp, #0x8]
1007be21c:     	cbz	x8, 0x1007be844 <_js_array_get_f64+0x974>
1007be220:     	cmp	x8, #0x1
1007be224:     	b.ne	0x1007be888 <_js_array_get_f64+0x9b8>
1007be228:     	ldr	d0, [sp, #0x10]
1007be22c:     	scvtf	d1, w19
1007be230:     	bl	0x10081c474 <_js_dyn_index_get>
1007be234:     	b	0x1007be5c4 <_js_array_get_f64+0x6f4>
1007be238:     	mov	w24, #0xb               ; =11
1007be23c:     	b	0x1007be018 <_js_array_get_f64+0x148>
1007be240:     	mov	w24, #0x8               ; =8
1007be244:     	b	0x1007be018 <_js_array_get_f64+0x148>
1007be248:     	mov	w24, #0xc               ; =12
1007be24c:     	b	0x1007be018 <_js_array_get_f64+0x148>
1007be250:     	add	x9, x8, #0x60
1007be254:     	b	0x1007be804 <_js_array_get_f64+0x934>
1007be258:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be25c:     	lsr	x1, x21, #20
1007be260:     	ldr	x8, [x0, #0x10]
1007be264:     	ldrb	w9, [x8]
1007be268:     	cmp	w9, #0x2
1007be26c:     	b.eq	0x1007be090 <_js_array_get_f64+0x1c0>
1007be270:     	ldr	x9, [x8, #0x8]
1007be274:     	ldr	x10, [x8, #0x28]
1007be278:     	sub	x9, x1, x9
1007be27c:     	cmp	x9, x10
1007be280:     	b.hs	0x1007be2c4 <_js_array_get_f64+0x3f4>
1007be284:     	ldr	x10, [x8, #0x20]
1007be288:     	mov	w11, #0x28              ; =40
1007be28c:     	madd	x9, x9, x11, x10
1007be290:     	ldr	x10, [x9]
1007be294:     	ldr	x11, [x8, #0x10]
1007be298:     	cmp	x10, x11
1007be29c:     	b.ne	0x1007be2d0 <_js_array_get_f64+0x400>
1007be2a0:     	ldp	x10, x11, [x9, #0x8]
1007be2a4:     	cmp	x10, x21
1007be2a8:     	ccmp	x11, x21, #0x0, ls
1007be2ac:     	b.ls	0x1007be2d0 <_js_array_get_f64+0x400>
1007be2b0:     	ldr	x10, [x8, #0x30]
1007be2b4:     	add	x10, x10, #0x1
1007be2b8:     	str	x10, [x8, #0x30]
1007be2bc:     	add	x8, x9, #0x21
1007be2c0:     	b	0x1007be814 <_js_array_get_f64+0x944>
1007be2c4:     	ldr	x9, [x8, #0x58]
1007be2c8:     	add	x9, x9, #0x1
1007be2cc:     	str	x9, [x8, #0x58]
1007be2d0:     	ldr	x9, [x8, #0x38]
1007be2d4:     	add	x9, x9, #0x1
1007be2d8:     	str	x9, [x8, #0x38]
1007be2dc:     	mov	x0, x21
1007be2e0:     	bl	0x10051e348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be2e4:     	and	w8, w0, #0xff
1007be2e8:     	cbz	w8, 0x1007be308 <_js_array_get_f64+0x438>
1007be2ec:     	ldurb	w8, [x21, #-0x8]
1007be2f0:     	ldurb	w9, [x21, #-0x7]
1007be2f4:     	mov	w10, #0x82              ; =130
1007be2f8:     	and	w9, w9, w10
1007be2fc:     	cmp	w9, #0x2
1007be300:     	ccmp	w8, #0x1, #0x0, eq
1007be304:     	b.eq	0x1007be3d8 <_js_array_get_f64+0x508>
1007be308:     	mov	x0, x21
1007be30c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be310:     	cbz	x0, 0x1007be338 <_js_array_get_f64+0x468>
1007be314:     	ldrb	w9, [x0]
1007be318:     	cmp	w9, #0x1
1007be31c:     	b.ne	0x1007be354 <_js_array_get_f64+0x484>
1007be320:     	ldrsb	w8, [x0, #0x1]
1007be324:     	tbnz	w8, #0x1f, 0x1007be400 <_js_array_get_f64+0x530>
1007be328:     	ldp	w10, w9, [x21]
1007be32c:     	cmp	w10, w9
1007be330:     	b.hi	0x1007be48c <_js_array_get_f64+0x5bc>
1007be334:     	b	0x1007be4a4 <_js_array_get_f64+0x5d4>
1007be338:     	mov	x25, x0
1007be33c:     	mov	x0, x21
1007be340:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be344:     	tbz	w0, #0x0, 0x1007be390 <_js_array_get_f64+0x4c0>
1007be348:     	mov	x0, #0x0                ; =0
1007be34c:     	mov	x8, x25
1007be350:     	b	0x1007be47c <_js_array_get_f64+0x5ac>
1007be354:     	mov	x8, x0
1007be358:     	cmp	w9, #0x1
1007be35c:     	b.eq	0x1007be47c <_js_array_get_f64+0x5ac>
1007be360:     	cmp	w9, #0x9
1007be364:     	b.ne	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be368:     	ldr	w8, [x21, #0x4]
1007be36c:     	mov	w9, #0x5841             ; =22593
1007be370:     	movk	w9, #0x4c5a, lsl #16
1007be374:     	cmp	w8, w9
1007be378:     	b.ne	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be37c:     	mov	x0, x21
1007be380:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be384:     	cbz	x0, 0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be388:     	mov	x21, x0
1007be38c:     	b	0x1007be4c0 <_js_array_get_f64+0x5f0>
1007be390:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be394:     	add	x8, x8, #0xec0
1007be398:     	ldaprb	w8, [x8]
1007be39c:     	cbz	w8, 0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be3a0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be3a4:     	add	x8, x8, #0x58
1007be3a8:     	ldapr	x8, [x8]
1007be3ac:     	cmp	x8, x21
1007be3b0:     	b.hi	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be3b4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be3b8:     	add	x8, x8, #0x60
1007be3bc:     	ldapr	x8, [x8]
1007be3c0:     	cmp	x8, x21
1007be3c4:     	b.lo	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be3c8:     	mov	x0, x21
1007be3cc:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be3d0:     	tbnz	w0, #0x0, 0x1007be348 <_js_array_get_f64+0x478>
1007be3d4:     	b	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be3d8:     	ldr	w8, [x21]
1007be3dc:     	mov	w9, #0xe100             ; =57600
1007be3e0:     	movk	w9, #0x5f5, lsl #16
1007be3e4:     	orr	w9, w9, #0x1
1007be3e8:     	cmp	w8, w9
1007be3ec:     	b.hs	0x1007be308 <_js_array_get_f64+0x438>
1007be3f0:     	ldr	w9, [x21, #0x4]
1007be3f4:     	cmp	w8, w9
1007be3f8:     	b.ls	0x1007be4c0 <_js_array_get_f64+0x5f0>
1007be3fc:     	b	0x1007be308 <_js_array_get_f64+0x438>
1007be400:     	mov	x25, x0
1007be404:     	ldr	x21, [x0, #0x8]
1007be408:     	mov	x0, x21
1007be40c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be410:     	cbz	x0, 0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be414:     	ldrb	w8, [x0]
1007be418:     	cmp	w8, #0x1
1007be41c:     	b.ne	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be420:     	ldrsb	w8, [x0, #0x1]
1007be424:     	tbz	w8, #0x1f, 0x1007be328 <_js_array_get_f64+0x458>
1007be428:     	mov	w26, #0x1               ; =1
1007be42c:     	ldr	x21, [x0, #0x8]
1007be430:     	mov	x0, x21
1007be434:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be438:     	cbz	x0, 0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be43c:     	ldrb	w8, [x0]
1007be440:     	cmp	w8, #0x1
1007be444:     	b.ne	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be448:     	cmp	w26, #0x3f
1007be44c:     	b.hi	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be450:     	add	w26, w26, #0x1
1007be454:     	ldrsb	w8, [x0, #0x1]
1007be458:     	tbnz	w8, #0x1f, 0x1007be42c <_js_array_get_f64+0x55c>
1007be45c:     	str	x21, [x25, #0x8]
1007be460:     	ldrb	w8, [x25, #0x1]
1007be464:     	orr	w9, w8, #0x80
1007be468:     	mov	x8, x25
1007be46c:     	strb	w9, [x25, #0x1]
1007be470:     	ldrb	w9, [x0]
1007be474:     	cmp	w9, #0x1
1007be478:     	b.ne	0x1007be360 <_js_array_get_f64+0x490>
1007be47c:     	ldp	w10, w9, [x21]
1007be480:     	cmp	w10, w9
1007be484:     	b.ls	0x1007be4a4 <_js_array_get_f64+0x5d4>
1007be488:     	cbz	x8, 0x1007be4b4 <_js_array_get_f64+0x5e4>
1007be48c:     	ldr	w8, [x0, #0x4]
1007be490:     	ubfiz	x9, x9, #3, #32
1007be494:     	add	x9, x9, #0x10
1007be498:     	cmp	x9, x8
1007be49c:     	b.eq	0x1007be4c0 <_js_array_get_f64+0x5f0>
1007be4a0:     	b	0x1007be4b4 <_js_array_get_f64+0x5e4>
1007be4a4:     	mov	w8, #0xe100             ; =57600
1007be4a8:     	movk	w8, #0x5f5, lsl #16
1007be4ac:     	cmp	w10, w8
1007be4b0:     	b.ls	0x1007be4c0 <_js_array_get_f64+0x5f0>
1007be4b4:     	mov	x0, x21
1007be4b8:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be4bc:     	tbz	w0, #0x0, 0x1007be570 <_js_array_get_f64+0x6a0>
1007be4c0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be4c4:     	add	x8, x8, #0xec0
1007be4c8:     	ldaprb	w8, [x8]
1007be4cc:     	cbz	w8, 0x1007be514 <_js_array_get_f64+0x644>
1007be4d0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be4d4:     	add	x8, x8, #0x58
1007be4d8:     	ldapr	x8, [x8]
1007be4dc:     	cmp	x21, x8
1007be4e0:     	b.lo	0x1007be514 <_js_array_get_f64+0x644>
1007be4e4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be4e8:     	add	x8, x8, #0x60
1007be4ec:     	ldapr	x8, [x8]
1007be4f0:     	cmp	x21, x8
1007be4f4:     	b.hi	0x1007be514 <_js_array_get_f64+0x644>
1007be4f8:     	mov	x0, x21
1007be4fc:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be500:     	tbz	w0, #0x0, 0x1007be514 <_js_array_get_f64+0x644>
1007be504:     	mov	x0, x21
1007be508:     	mov	x1, x19
1007be50c:     	bl	0x1008fc188 <_js_typed_array_get>
1007be510:     	b	0x1007be5c4 <_js_array_get_f64+0x6f4>
1007be514:     	mov	x0, x21
1007be518:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be51c:     	tbz	w0, #0x0, 0x1007be544 <_js_array_get_f64+0x674>
1007be520:     	mov	x0, x21
1007be524:     	mov	x1, x19
1007be528:     	bl	0x10058651c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007be52c:     	and	w8, w1, #0xff
1007be530:     	ucvtf	d0, w8
1007be534:     	fmov	x8, d0
1007be538:     	tst	w0, #0x1
1007be53c:     	csel	x22, x8, xzr, ne
1007be540:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be544:     	cmp	x21, x20
1007be548:     	b.eq	0x1007be5f0 <_js_array_get_f64+0x720>
1007be54c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007be550:     	b.lo	0x1007be5e8 <_js_array_get_f64+0x718>
1007be554:     	tst	x21, #0xffff800000000000
1007be558:     	mov	w8, #0x1000             ; =4096
1007be55c:     	ccmp	x21, x8, #0x0, eq
1007be560:     	b.lo	0x1007be5e8 <_js_array_get_f64+0x718>
1007be564:     	ldurb	w24, [x21, #-0x8]
1007be568:     	ldurh	w23, [x21, #-0x6]
1007be56c:     	b	0x1007be5f0 <_js_array_get_f64+0x720>
1007be570:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be574:     	add	x8, x8, #0xec0
1007be578:     	ldaprb	w8, [x8]
1007be57c:     	cbz	w8, 0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be580:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be584:     	add	x8, x8, #0x58
1007be588:     	ldapr	x8, [x8]
1007be58c:     	cmp	x21, x8
1007be590:     	b.lo	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be594:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be598:     	add	x8, x8, #0x60
1007be59c:     	ldapr	x8, [x8]
1007be5a0:     	cmp	x21, x8
1007be5a4:     	b.hi	0x1007be5b4 <_js_array_get_f64+0x6e4>
1007be5a8:     	mov	x0, x21
1007be5ac:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be5b0:     	tbnz	w0, #0x0, 0x1007be4c0 <_js_array_get_f64+0x5f0>
1007be5b4:     	mov	x0, x22
1007be5b8:     	mov	x1, x19
1007be5bc:     	bl	0x10054860c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be5c0:     	tbz	w0, #0x0, 0x1007be898 <_js_array_get_f64+0x9c8>
1007be5c4:     	fmov	x22, d0
1007be5c8:     	fmov	d0, x22
1007be5cc:     	ldp	x29, x30, [sp, #0x60]
1007be5d0:     	ldp	x20, x19, [sp, #0x50]
1007be5d4:     	ldp	x22, x21, [sp, #0x40]
1007be5d8:     	ldp	x24, x23, [sp, #0x30]
1007be5dc:     	ldp	x26, x25, [sp, #0x20]
1007be5e0:     	add	sp, sp, #0x70
1007be5e4:     	ret
1007be5e8:     	mov	w23, #0x0               ; =0
1007be5ec:     	mov	w24, #0x0               ; =0
1007be5f0:     	cmp	w24, #0x1
1007be5f4:     	b.ne	0x1007be7a8 <_js_array_get_f64+0x8d8>
1007be5f8:     	tbz	w23, #0xa, 0x1007be7a8 <_js_array_get_f64+0x8d8>
1007be5fc:     	adrp	x8, 0x100b64000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data14case_ignorable7OFFSETS+0x2bc>
1007be600:     	add	x8, x8, #0xd8c
1007be604:     	cmp	w19, #0x3e8
1007be608:     	b.lo	0x1007be680 <_js_array_get_f64+0x7b0>
1007be60c:     	mov	x9, #0x0                ; =0
1007be610:     	mov	w11, #0x1759            ; =5977
1007be614:     	movk	w11, #0xd1b7, lsl #16
1007be618:     	mov	w12, #0x2710            ; =10000
1007be61c:     	mov	w13, #0x147b            ; =5243
1007be620:     	mov	w14, #0x64              ; =100
1007be624:     	add	x15, sp, #0x8
1007be628:     	mov	w16, #0x967f            ; =38527
1007be62c:     	movk	w16, #0x98, lsl #16
1007be630:     	mov	x10, x19
1007be634:     	mov	x17, x10
1007be638:     	umull	x10, w10, w11
1007be63c:     	lsr	x10, x10, #45
1007be640:     	msub	w0, w10, w12, w17
1007be644:     	ubfx	w1, w0, #2, #14
1007be648:     	mul	w1, w1, w13
1007be64c:     	lsr	w1, w1, #17
1007be650:     	msub	w0, w1, w14, w0
1007be654:     	add	x2, x15, x9
1007be658:     	ldrh	w1, [x8, w1, uxtw #1]
1007be65c:     	strh	w1, [x2, #0x6]
1007be660:     	and	x0, x0, #0xffff
1007be664:     	ldrh	w0, [x8, x0, lsl #1]
1007be668:     	strh	w0, [x2, #0x8]
1007be66c:     	sub	x9, x9, #0x4
1007be670:     	cmp	w17, w16
1007be674:     	b.hi	0x1007be634 <_js_array_get_f64+0x764>
1007be678:     	add	x9, x9, #0xa
1007be67c:     	b	0x1007be688 <_js_array_get_f64+0x7b8>
1007be680:     	mov	w9, #0xa                ; =10
1007be684:     	mov	x10, x19
1007be688:     	cmp	w10, #0x9
1007be68c:     	b.ls	0x1007be6c0 <_js_array_get_f64+0x7f0>
1007be690:     	sub	x9, x9, #0x2
1007be694:     	ubfx	w11, w10, #2, #14
1007be698:     	mov	w12, #0x147b            ; =5243
1007be69c:     	mul	w11, w11, w12
1007be6a0:     	lsr	w11, w11, #17
1007be6a4:     	mov	w12, #0x64              ; =100
1007be6a8:     	msub	w10, w11, w12, w10
1007be6ac:     	and	x10, x10, #0xffff
1007be6b0:     	ldrh	w10, [x8, x10, lsl #1]
1007be6b4:     	add	x12, sp, #0x8
1007be6b8:     	strh	w10, [x12, x9]
1007be6bc:     	mov	x10, x11
1007be6c0:     	cbz	w19, 0x1007be6f8 <_js_array_get_f64+0x828>
1007be6c4:     	cbnz	w10, 0x1007be6f8 <_js_array_get_f64+0x828>
1007be6c8:     	cmp	x9, #0xa
1007be6cc:     	b.ne	0x1007be720 <_js_array_get_f64+0x850>
1007be6d0:     	mov	w23, #0x1               ; =1
1007be6d4:     	add	x0, sp, #0x8
1007be6d8:     	mov	x1, x21
1007be6dc:     	mov	w2, #0x1                ; =1
1007be6e0:     	mov	x3, #0x0                ; =0
1007be6e4:     	bl	0x1005b28fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be6e8:     	ldr	x8, [sp, #0x8]
1007be6ec:     	mov	w20, #0x1               ; =1
1007be6f0:     	cbnz	x8, 0x1007be770 <_js_array_get_f64+0x8a0>
1007be6f4:     	b	0x1007be7a8 <_js_array_get_f64+0x8d8>
1007be6f8:     	sub	x23, x9, #0x1
1007be6fc:     	ubfiz	w10, w10, #1, #4
1007be700:     	add	x8, x8, x10
1007be704:     	ldrb	w8, [x8, #0x1]
1007be708:     	add	x10, sp, #0x8
1007be70c:     	strb	w8, [x10, x23]
1007be710:     	mov	w8, #0xb                ; =11
1007be714:     	b	0x1007be728 <_js_array_get_f64+0x858>
1007be718:     	add	x9, x8, #0x90
1007be71c:     	b	0x1007be804 <_js_array_get_f64+0x934>
1007be720:     	mov	w8, #0xa                ; =10
1007be724:     	mov	x23, x9
1007be728:     	sub	x22, x8, x9
1007be72c:     	mov	x0, x22
1007be730:     	mov	w1, #0x1                ; =1
1007be734:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
1007be738:     	cbz	x0, 0x1007be8e4 <_js_array_get_f64+0xa14>
1007be73c:     	mov	x20, x0
1007be740:     	add	x8, sp, #0x8
1007be744:     	add	x1, x8, x23
1007be748:     	mov	x2, x22
1007be74c:     	bl	0x100b61dec <_writev+0x100b61dec>
1007be750:     	add	x0, sp, #0x8
1007be754:     	mov	x1, x21
1007be758:     	mov	x2, x20
1007be75c:     	mov	x3, x22
1007be760:     	bl	0x1005b28fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be764:     	ldr	w8, [sp, #0x8]
1007be768:     	tbz	w8, #0x0, 0x1007be7a0 <_js_array_get_f64+0x8d0>
1007be76c:     	mov	w23, #0x0               ; =0
1007be770:     	mov	x22, #0x1               ; =1
1007be774:     	movk	x22, #0x7ffc, lsl #48
1007be778:     	ldr	x0, [sp, #0x10]
1007be77c:     	cbz	x0, 0x1007be834 <_js_array_get_f64+0x964>
1007be780:     	cbz	x21, 0x1007be824 <_js_array_get_f64+0x954>
1007be784:     	lsr	x8, x21, #52
1007be788:     	cmp	x8, #0x7fe
1007be78c:     	b.hi	0x1007be828 <_js_array_get_f64+0x958>
1007be790:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007be794:     	bfxil	x8, x21, #0, #48
1007be798:     	mov	x21, x8
1007be79c:     	b	0x1007be828 <_js_array_get_f64+0x958>
1007be7a0:     	mov	x0, x20
1007be7a4:     	bl	0x100b5ef40 <_mi_free>
1007be7a8:     	ldr	w8, [x21]
1007be7ac:     	cmp	w19, w8
1007be7b0:     	b.hs	0x1007be7f0 <_js_array_get_f64+0x920>
1007be7b4:     	ldr	w8, [x21, #0x4]
1007be7b8:     	cmp	w19, w8
1007be7bc:     	b.hs	0x1007be7e0 <_js_array_get_f64+0x910>
1007be7c0:     	add	x8, x21, w19, uxtw #3
1007be7c4:     	ldr	x22, [x8, #0x8]
1007be7c8:     	mov	x8, #0x1                ; =1
1007be7cc:     	movk	x8, #0x7ffc, lsl #48
1007be7d0:     	add	x8, x8, #0xf
1007be7d4:     	cmp	x22, x8
1007be7d8:     	b.ne	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be7dc:     	b	0x1007be7f0 <_js_array_get_f64+0x920>
1007be7e0:     	mov	x0, x21
1007be7e4:     	mov	x1, x19
1007be7e8:     	bl	0x10052aa04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007be7ec:     	tbnz	w0, #0x0, 0x1007be5c4 <_js_array_get_f64+0x6f4>
1007be7f0:     	mov	x0, x21
1007be7f4:     	mov	x1, x19
1007be7f8:     	bl	0x1006c7318 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007be7fc:     	b	0x1007be5c4 <_js_array_get_f64+0x6f4>
1007be800:     	add	x9, x8, #0xc0
1007be804:     	ldr	x10, [x8, #0x30]
1007be808:     	add	x10, x10, #0x1
1007be80c:     	str	x10, [x8, #0x30]
1007be810:     	add	x8, x9, #0x19
1007be814:     	ldrb	w8, [x8]
1007be818:     	cmp	w8, #0xff
1007be81c:     	b.ne	0x1007be2e8 <_js_array_get_f64+0x418>
1007be820:     	b	0x1007be2dc <_js_array_get_f64+0x40c>
1007be824:     	add	x21, x22, #0x1
1007be828:     	fmov	d0, x21
1007be82c:     	bl	0x1006fd13c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007be830:     	mov	x22, x0
1007be834:     	tbnz	w23, #0x0, 0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be838:     	mov	x0, x20
1007be83c:     	bl	0x100b5ef40 <_mi_free>
1007be840:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be844:     	ldr	x20, [sp, #0x10]
1007be848:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be84c:     	ldr	x8, [x8, #0xed8]
1007be850:     	cbz	x8, 0x1007be868 <_js_array_get_f64+0x998>
1007be854:     	mov	x0, x20
1007be858:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007be85c:     	tbz	w0, #0x0, 0x1007be868 <_js_array_get_f64+0x998>
1007be860:     	mov	x0, x20
1007be864:     	bl	0x1002bee80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007be868:     	tbnz	w19, #0x1f, 0x1007be888 <_js_array_get_f64+0x9b8>
1007be86c:     	ldr	w8, [x20]
1007be870:     	cmp	w19, w8
1007be874:     	b.hs	0x1007be888 <_js_array_get_f64+0x9b8>
1007be878:     	mov	w1, w19
1007be87c:     	mov	x0, x20
1007be880:     	bl	0x1002a510c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007be884:     	b	0x1007be5c4 <_js_array_get_f64+0x6f4>
1007be888:     	mov	x8, #0x1                ; =1
1007be88c:     	movk	x8, #0x7ffc, lsl #48
1007be890:     	mov	x22, x8
1007be894:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be898:     	mov	x0, x22
1007be89c:     	bl	0x100b478b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007be8a0:     	cmp	x0, #0x1
1007be8a4:     	b.ne	0x1007bdf10 <_js_array_get_f64+0x40>
1007be8a8:     	mov	x0, x19
1007be8ac:     	bl	0x100b478d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007be8b0:     	b	0x1007be5c4 <_js_array_get_f64+0x6f4>
1007be8b4:     	mov	x0, x20
1007be8b8:     	mov	w1, #0x0                ; =0
1007be8bc:     	bl	0x100b49e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be8c0:     	mov	x20, x0
1007be8c4:     	cbnz	x0, 0x1007bdfec <_js_array_get_f64+0x11c>
1007be8c8:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be8cc:     	mov	x0, x20
1007be8d0:     	mov	w1, #0x1                ; =1
1007be8d4:     	bl	0x100b49e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be8d8:     	mov	x20, x0
1007be8dc:     	cbnz	x0, 0x1007be190 <_js_array_get_f64+0x2c0>
1007be8e0:     	b	0x1007be5c8 <_js_array_get_f64+0x6f8>
1007be8e4:     	mov	w0, #0x1                ; =1
1007be8e8:     	mov	x1, x22
1007be8ec:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
