; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/integer-remainder-r32/candidate-remainder-ir-native/.perry-trace/llvm/test_json_index_remainder_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_index_remainder_ts_.str.0 = private unnamed_addr constant [88 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/test-files/test_json_index_remainder.ts\00"
@test_json_index_remainder_ts_.str.0.bytes = private unnamed_addr constant [3 x i8] c"-0\00"
@test_json_index_remainder_ts_.str.1.bytes = private unnamed_addr constant [4 x i8] c"NaN\00"
@test_json_index_remainder_ts_.str.2.bytes = private unnamed_addr constant [2 x i8] c":\00"
@test_json_index_remainder_ts_.str.3.bytes = private unnamed_addr constant [11 x i8] c"4294967295\00"
@test_json_index_remainder_ts_.str.4.bytes = private unnamed_addr constant [7 x i8] c"number\00"
@test_json_index_remainder_ts_.str.5.bytes = private unnamed_addr constant [10 x i8] c"TypeError\00"
@test_json_index_remainder_ts_.str.6.bytes = private unnamed_addr constant [11 x i8] c"unexpected\00"
@test_json_index_remainder_ts_.str.7.bytes = private unnamed_addr constant [7 x i8] c"bigint\00"
@test_json_index_remainder_ts_.str.1 = private unnamed_addr constant [10 x i8] c"remainder\00"
@test_json_index_remainder_ts_.str.2 = private unnamed_addr constant [9 x i8] c"describe\00"
@test_json_index_remainder_ts_.str.3 = private unnamed_addr constant [58 x i8] c"function remainder(a: any, b: any): any { return a % b; }\00"
@test_json_index_remainder_ts_.str.4 = private unnamed_addr constant [202 x i8] c"function describe(v: any): string {\0A    if (typeof v === 'number') {\0A        if (Object.is(v, -0)) return '-0';\0A        if (Number.isNaN(v)) return 'NaN';\0A    }\0A    return typeof v + ':' + String(v);\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_index_remainder_ts = internal global i32 0
@perry_ic_test_json_index_remainder_ts__0 = private global ptr null
@perry_ic_test_json_index_remainder_ts__1 = private global ptr null
@perry_ic_test_json_index_remainder_ts__4 = private global ptr null
@test_json_index_remainder_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_index_remainder_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_index_remainder_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_index_remainder_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_index_remainder_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_index_remainder_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_index_remainder_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_index_remainder_ts_.str.7.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_test_json_index_remainder_ts__remainder$spec_b_i32"(double %arg2, i32 %arg3) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg2 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #8
  %r3 = bitcast i64 %r3.rs4o to double
  %r5 = sitofp i32 %arg3 to double
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r3, double %r5, i32 0, i32 0)
  %r61 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  ret double %r61
}

; Function Attrs: inlinehint optsize
define double @perry_fn_test_json_index_remainder_ts__remainder(double %arg2, double %arg3) #7 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg2 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg3 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #8
  %r3 = bitcast i64 %r3.rs4o to double
  %r4.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r4.rs4o = call i64 asm "", "=r,0"(i64 %r4.rs4i) #8
  %r4 = bitcast i64 %r4.rs4o to double
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r3, double %r4, i32 0, i32 0)
  %r51 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  ret double %r51
}

; Function Attrs: inlinehint optsize
define double @perry_fn_test_json_index_remainder_ts__describe(double %arg4) #7 gc "statepoint-example" {
entry.0:
  %r66 = alloca [32 x double], align 8
  %rs4gc.b1 = bitcast double %arg4 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %r2.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r2.rs4o = call i64 asm "", "=r,0"(i64 %r2.rs4i) #8
  %r2 = bitcast i64 %r2.rs4o to double
  %r3 = bitcast double %r2 to i64
  %r4 = lshr i64 %r3, 48
  %r5 = sub nsw i64 %r4, 32761
  %r6 = icmp ugt i64 %r5, 6
  %r7 = icmp ne i64 %r4, 0
  %r8 = icmp ult i64 %r3, 65536
  %r9 = or i1 %r7, %r8
  %r10 = fcmp olt double %r2, 0x4130000000000000
  %r11 = fcmp oge double %r2, 0x4140000000000000
  %r12 = or i1 %r10, %r11
  %r13 = fcmp uno double %r2, %r2
  %r14 = or i1 %r12, %r13
  %r15 = and i1 %r6, %r9
  %r16 = and i1 %r15, %r14
  br i1 %r16, label %typeof.num.fast.1, label %typeof.num.slow.2

typeof.num.fast.1:                                ; preds = %entry.0
  br label %typeof.num.merge.3

typeof.num.slow.2:                                ; preds = %entry.0
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double)) @js_value_typeof_tag, i32 1, i32 0, double %r2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s1) ]
  %r171 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s1, %rs4gc.s1)
  %r18 = icmp eq i32 %r171, 3
  br label %typeof.num.merge.3

typeof.num.merge.3:                               ; preds = %typeof.num.slow.2, %typeof.num.fast.1
  %.0 = phi ptr addrspace(1) [ %rs4gc.s1, %typeof.num.fast.1 ], [ %rs4gc.s1.relocated, %typeof.num.slow.2 ]
  %r19 = phi i1 [ true, %typeof.num.fast.1 ], [ %r18, %typeof.num.slow.2 ]
  %r20 = select i1 %r19, i64 9222246136947933188, i64 9222246136947933187
  %r21 = bitcast i64 %r20 to double
  %r22 = icmp eq i64 %r20, 9222246136947933188
  br i1 %r22, label %if.then.4, label %if.else.5

if.then.4:                                        ; preds = %typeof.num.merge.3
  %r23.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r23.rs4o = call i64 asm "", "=r,0"(i64 %r23.rs4i) #8
  %r23 = bitcast i64 %r23.rs4o to double
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_object_is, i32 2, i32 0, double %r23, double -0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r243 = call double @llvm.experimental.gc.result.f64(token %statepoint_token2)
  %rs4gc.s1.relocated4 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 0, i32 0) ; (%.0, %.0)
  %r25 = bitcast double %r243 to i64
  %r26 = and i64 %r25, 9221120237041090560
  %r27 = icmp ne i64 %r26, 9221120237041090560
  br i1 %r27, label %truthy.num.7, label %truthy.tag.8

if.else.5:                                        ; preds = %typeof.num.merge.3
  br label %if.merge.6

if.merge.6:                                       ; preds = %if.merge.17, %if.else.5
  %.1 = phi ptr addrspace(1) [ %rs4gc.s1.relocated10, %if.merge.17 ], [ %.0, %if.else.5 ]
  %r50.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r50.rs4o = call i64 asm "", "=r,0"(i64 %r50.rs4i) #8
  %r50 = bitcast i64 %r50.rs4o to double
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_value_typeof, i32 1, i32 0, double %r50, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r516 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token5)
  %rs4gc.s1.relocated7 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 0, i32 0) ; (%.1, %.1)
  %r52 = or i64 %r516, 9223090561878065152
  %r53 = bitcast i64 %r52 to double
  %rs4gc.s2 = inttoptr i64 %r52 to ptr addrspace(1)
  %r55.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r55 = call i64 asm "", "=r,0"(i64 %r55.rs4i) #8
  %r56 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r57 = icmp ne i32 %r56, 0
  br i1 %r57, label %shadow.root.barrier.18, label %shadow.root.barrier.done.19

truthy.num.7:                                     ; preds = %if.then.4
  %r28 = fcmp one double %r243, 0.000000e+00
  br label %truthy.merge.10

truthy.tag.8:                                     ; preds = %if.then.4
  %r29 = icmp eq i64 %r25, 9222246136947933188
  %r30 = icmp eq i64 %r25, 9222246136947933187
  %r31 = icmp eq i64 %r25, 9222246136947933185
  %r32 = icmp eq i64 %r25, 9222246136947933186
  %r33 = or i1 %r30, %r31
  %r34 = or i1 %r33, %r32
  %r35 = or i1 %r29, %r34
  br i1 %r35, label %truthy.merge.10, label %truthy.obj.11

truthy.slow.9:                                    ; preds = %truthy.obj.11
  %r41 = call i32 @js_is_truthy(double %r243) #8
  %r42 = icmp ne i32 %r41, 0
  br label %truthy.merge.10

truthy.merge.10:                                  ; preds = %truthy.obj.11, %truthy.slow.9, %truthy.tag.8, %truthy.num.7
  %r43 = phi i1 [ %r28, %truthy.num.7 ], [ %r29, %truthy.tag.8 ], [ true, %truthy.obj.11 ], [ %r42, %truthy.slow.9 ]
  br i1 %r43, label %if.then.12, label %if.else.13

truthy.obj.11:                                    ; preds = %truthy.tag.8
  %r36 = lshr i64 %r25, 48
  %r37 = icmp eq i64 %r36, 32765
  %r38 = and i64 %r25, 281474976710655
  %r39 = icmp ne i64 %r38, 0
  %r40 = and i1 %r37, %r39
  br i1 %r40, label %truthy.merge.10, label %truthy.slow.9

if.then.12:                                       ; preds = %truthy.merge.10
  %r44 = load double, ptr @test_json_index_remainder_ts_.str.0.handle, align 8
  ret double %r44

if.else.13:                                       ; preds = %truthy.merge.10
  br label %if.merge.14

if.merge.14:                                      ; preds = %if.else.13
  %r45.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1.relocated4 to i64
  %r45.rs4o = call i64 asm "", "=r,0"(i64 %r45.rs4i) #8
  %r45 = bitcast i64 %r45.rs4o to double
  %statepoint_token8 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_is_nan, i32 1, i32 0, double %r45, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s1.relocated4) ]
  %r469 = call double @llvm.experimental.gc.result.f64(token %statepoint_token8)
  %rs4gc.s1.relocated10 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token8, i32 0, i32 0) ; (%rs4gc.s1.relocated4, %rs4gc.s1.relocated4)
  %r47 = bitcast double %r469 to i64
  %r48 = icmp eq i64 %r47, 9222246136947933188
  br i1 %r48, label %if.then.15, label %if.else.16

if.then.15:                                       ; preds = %if.merge.14
  %r49 = load double, ptr @test_json_index_remainder_ts_.str.1.handle, align 8
  ret double %r49

if.else.16:                                       ; preds = %if.merge.14
  br label %if.merge.17

if.merge.17:                                      ; preds = %if.else.16
  br label %if.merge.6

shadow.root.barrier.18:                           ; preds = %if.merge.6
  call void @js_write_barrier_root_nanbox(i64 %r55) #8
  br label %shadow.root.barrier.done.19

shadow.root.barrier.done.19:                      ; preds = %shadow.root.barrier.18, %if.merge.6
  %r58 = load double, ptr @test_json_index_remainder_ts_.str.2.handle, align 8
  %r59.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1.relocated7 to i64
  %r59.rs4o = call i64 asm "", "=r,0"(i64 %r59.rs4i) #8
  %r59 = bitcast i64 %r59.rs4o to double
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_string_coerce, i32 1, i32 0, double %r59, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2) ]
  %r6012 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token11)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%rs4gc.s2, %rs4gc.s2)
  %r61 = or i64 %r6012, 9223090561878065152
  %r62 = bitcast i64 %r61 to double
  %r63.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated to i64
  %r63 = call i64 asm "", "=r,0"(i64 %r63.rs4i) #8
  %r64 = bitcast i64 %r63 to double
  %r65 = load double, ptr @test_json_index_remainder_ts_.str.2.handle, align 8
  %r67 = getelementptr double, ptr %r66, i64 0
  store double %r64, ptr %r67, align 8
  %r68 = getelementptr double, ptr %r66, i64 1
  store double %r65, ptr %r68, align 8
  %r69 = getelementptr double, ptr %r66, i64 2
  store double %r62, ptr %r69, align 8
  %r70 = ptrtoint ptr %r66 to i64
  %statepoint_token13 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r70, i32 3, i32 0, i32 0)
  %r7114 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token13)
  %r72 = or i64 %r7114, 9223090561878065152
  %r73 = bitcast i64 %r72 to double
  ret double %r73
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_index_remainder_ts__remainder(i64 %this_closure, double %a0, double %a1) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_index_remainder_ts__remainder(double %a0, double %a1)
  ret double %r1
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_index_remainder_ts__describe(i64 %this_closure, double %a0) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_index_remainder_ts__describe(double %a0)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_index_remainder_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_index_remainder_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" personality ptr @perry_eh_personality {
entry.0:
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_index_remainder_ts_.str.0, i32 87, i32 0, i32 0)
  %statepoint_token66 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token67 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token68 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token69 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_index_remainder_ts, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token70 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc_literal, i32 1, i32 0, i32 17, i32 0, i32 0)
  %r2100 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token70)
  %r3 = inttoptr i64 %r2100 to ptr
  %r4 = getelementptr inbounds nuw i8, ptr %r3, i64 8
  store double 0xFFF0000000000000, ptr %r4, align 8
  %r5 = getelementptr inbounds nuw i8, ptr %r3, i64 16
  store double 0xC1F0000000000000, ptr %r5, align 8
  %r6 = getelementptr inbounds nuw i8, ptr %r3, i64 24
  store double -1.500000e+00, ptr %r6, align 8
  %r7 = getelementptr inbounds nuw i8, ptr %r3, i64 32
  store double -1.000000e+00, ptr %r7, align 8
  %r8 = getelementptr inbounds nuw i8, ptr %r3, i64 40
  store double -0.000000e+00, ptr %r8, align 8
  %r9 = getelementptr inbounds nuw i8, ptr %r3, i64 48
  store double 0.000000e+00, ptr %r9, align 8
  %r10 = getelementptr inbounds nuw i8, ptr %r3, i64 56
  store double 5.000000e-01, ptr %r10, align 8
  %r11 = getelementptr inbounds nuw i8, ptr %r3, i64 64
  store double 1.000000e+00, ptr %r11, align 8
  %r12 = getelementptr inbounds nuw i8, ptr %r3, i64 72
  store double 1.700000e+01, ptr %r12, align 8
  %r13 = getelementptr inbounds nuw i8, ptr %r3, i64 80
  store double 6.553700e+04, ptr %r13, align 8
  %r14 = getelementptr inbounds nuw i8, ptr %r3, i64 88
  store double 0x41E0000000000000, ptr %r14, align 8
  %r15 = getelementptr inbounds nuw i8, ptr %r3, i64 96
  store double 0x41EFFFFFFFE00000, ptr %r15, align 8
  %r16 = getelementptr inbounds nuw i8, ptr %r3, i64 104
  store double 0x41EFFFFFFFF00000, ptr %r16, align 8
  %r17 = getelementptr inbounds nuw i8, ptr %r3, i64 112
  store double 0x41F0000000000000, ptr %r17, align 8
  %r18 = getelementptr inbounds nuw i8, ptr %r3, i64 120
  store double 0x433FFFFFFFFFFFFF, ptr %r18, align 8
  %r19 = getelementptr inbounds nuw i8, ptr %r3, i64 128
  store double 0x7FF0000000000000, ptr %r19, align 8
  %r20 = getelementptr inbounds nuw i8, ptr %r3, i64 136
  store double 0x7FF8000000000000, ptr %r20, align 8
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64)) @js_array_mark_numeric_f64_layout, i32 1, i32 0, i64 %r2100, i32 0, i32 0)
  %r22 = or i64 %r2100, 9222527611924643840
  %r23 = bitcast i64 %r22 to double
  %rs4gc.b3 = bitcast double %r23 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r24.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r24 = call i64 asm "", "=r,0"(i64 %r24.rs4i) #8
  %r25 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r26 = icmp ne i32 %r25, 0
  br i1 %r26, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r24) #8
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  br label %for.cond.3

for.cond.3:                                       ; preds = %for.update.5, %shadow.root.barrier.done.2
  %r27.0 = phi i32 [ 0, %shadow.root.barrier.done.2 ], [ %r457, %for.update.5 ]
  %r1.0.base = phi ptr addrspace(1) [ %rs4gc.s3, %shadow.root.barrier.done.2 ], [ %.0424, %for.update.5 ], !is_base_value !0
  %r1.0 = phi ptr addrspace(1) [ %rs4gc.s3, %shadow.root.barrier.done.2 ], [ %.0427, %for.update.5 ]
  %r29 = sitofp i32 %r27.0 to double
  %r30.rs4i = ptrtoint ptr addrspace(1) %r1.0 to i64
  %r30.rs4o = call i64 asm "", "=r,0"(i64 %r30.rs4i) #8
  %r30 = bitcast i64 %r30.rs4o to double
  %r31 = bitcast double %r30 to i64
  %r32 = and i64 %r31, 281474976710655
  %r33 = lshr i64 %r31, 48
  %r34 = and i64 %r33, 65533
  %r35 = icmp eq i64 %r34, 32765
  %r36 = icmp ugt i64 %r32, 1048575
  %r37 = and i1 %r35, %r36
  br i1 %r37, label %plen.check_gc.7, label %plen.slow.9

for.body.4:                                       ; preds = %gcpoll.done.29
  br label %for.cond.30

for.update.5:                                     ; preds = %gcpoll.done.86
  %r457 = add i32 %r27.0, 1
  %r458 = sitofp i32 %r27.0 to double
  %r459 = sitofp i32 %r457 to double
  br label %for.cond.3

for.exit.6:                                       ; preds = %gcpoll.done.29
  %r461 = load double, ptr @test_json_index_remainder_ts_.str.3.handle, align 8
  %statepoint_token102 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_bigint_from_i128_parts, i32 2, i32 0, i64 43, i64 0, i32 0, i32 0)
  %r469103 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token102)
  %r470 = or i64 %r469103, 9221683186994511872
  %r471 = bitcast i64 %r470 to double
  %rs4gc.s4 = inttoptr i64 %r470 to ptr addrspace(1)
  %r472.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r472 = call i64 asm "", "=r,0"(i64 %r472.rs4i) #8
  %r473 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r474 = icmp ne i32 %r473, 0
  br i1 %r474, label %shadow.root.barrier.87, label %shadow.root.barrier.done.88

plen.check_gc.7:                                  ; preds = %for.cond.3
  %r38 = sub nuw nsw i64 %r32, 8
  %r39 = inttoptr i64 %r38 to ptr
  %r40 = load i8, ptr %r39, align 1
  %r41 = icmp eq i8 %r40, 1
  %r42 = icmp eq i8 %r40, 3
  %r43 = or i1 %r41, %r42
  %r44 = sub nuw nsw i64 %r32, 7
  %r45 = inttoptr i64 %r44 to ptr
  %r46 = load i8, ptr %r45, align 1
  %r47 = and i8 %r46, -128
  %r48 = icmp eq i8 %r47, 0
  %r49 = and i1 %r43, %r48
  br i1 %r49, label %plen.fast.8, label %plen.slow.9

plen.fast.8:                                      ; preds = %plen.check_gc.7
  %r51 = inttoptr i64 %r32 to ptr
  %r52 = select i1 false, ptr @perry_null_guard_zero_test_json_index_remainder_ts, ptr %r51
  %r53 = load i32, ptr %r52, align 4
  %r54 = uitofp i32 %r53 to double
  br label %plen.merge.10

plen.slow.9:                                      ; preds = %plen.check_gc.7, %for.cond.3
  %r55 = lshr i64 %r31, 48
  %r56 = icmp eq i64 %r55, 32765
  %r57 = icmp uge i64 %r32, 2199023255552
  %r58 = icmp ult i64 %r32, 140737488355328
  %r59 = and i1 %r56, %r57
  %r60 = and i1 %r59, %r58
  %r61 = load ptr, ptr @perry_ic_test_json_index_remainder_ts__0, align 8
  br i1 %r60, label %plen.ic.header.11, label %plen.ic.miss.23

plen.merge.10:                                    ; preds = %plen.ic.merge.24, %plen.fast.8
  %.0421 = phi ptr addrspace(1) [ %r1.0, %plen.fast.8 ], [ %.1422, %plen.ic.merge.24 ]
  %.0 = phi ptr addrspace(1) [ %r1.0.base, %plen.fast.8 ], [ %.1, %plen.ic.merge.24 ]
  %r136 = phi double [ %r54, %plen.fast.8 ], [ %r135, %plen.ic.merge.24 ]
  %r137 = fcmp olt double %r29, %r136
  %r138 = select i1 %r137, i64 9222246136947933188, i64 9222246136947933187
  %r139 = bitcast i64 %r138 to double
  %r141 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r142 = icmp ne i32 %r141, 0
  br i1 %r142, label %gcpoll.28, label %gcpoll.done.29

plen.ic.header.11:                                ; preds = %plen.slow.9
  %r63 = sub nuw nsw i64 %r32, 8
  %r64 = inttoptr i64 %r63 to ptr
  %r65 = load i8, ptr %r64, align 1
  %r66 = icmp eq i8 %r65, 2
  %r67 = sub nuw nsw i64 %r32, 7
  %r68 = inttoptr i64 %r67 to ptr
  %r69 = load i8, ptr %r68, align 1
  %r70 = and i8 %r69, -128
  %r71 = icmp eq i8 %r70, 0
  %r72 = and i1 %r66, %r71
  br i1 %r72, label %plen.elem.meta.25, label %plen.ic.miss.23

plen.ic.shape.12:                                 ; preds = %plen.elem.store.26, %plen.elem.meta.25
  %r62 = icmp ne ptr %r61, null
  br i1 %r62, label %plen.ic.shape.probe.13, label %plen.ic.miss.23

plen.ic.shape.probe.13:                           ; preds = %plen.ic.shape.12
  %r84 = inttoptr i64 %r32 to ptr
  %r85 = load i32, ptr %r84, align 4
  %r86 = add nuw nsw i64 %r32, 4
  %r87 = inttoptr i64 %r86 to ptr
  %r88 = load i32, ptr %r87, align 4
  %r89 = zext i32 %r85 to i64
  %r90 = zext i32 %r88 to i64
  %r91 = shl nuw i64 %r89, 32
  %r92 = or i64 %r91, %r90
  %r93 = getelementptr i64, ptr %r61, i64 0
  %r94 = load i64, ptr %r93, align 8
  %r95 = icmp ne i64 %r94, 0
  br i1 %r95, label %plen.ic.identity.14, label %plen.ic.miss.23

plen.ic.identity.14:                              ; preds = %plen.ic.shape.probe.13
  %r96 = and i64 %r94, -9223372036854775808
  %0 = icmp slt i64 %r94, 0
  br i1 %0, label %plen.ic.family_meta.16, label %plen.ic.exact.15

plen.ic.exact.15:                                 ; preds = %plen.ic.identity.14
  %r98 = icmp eq i64 %r92, %r94
  br i1 %r98, label %plen.ic.slot.18, label %plen.ic.miss.23

plen.ic.family_meta.16:                           ; preds = %plen.ic.identity.14
  %r99 = add nuw nsw i64 %r32, 8
  %r100 = inttoptr i64 %r99 to ptr
  %r101 = load i64, ptr %r100, align 8
  %r102 = icmp ne i64 %r101, 0
  br i1 %r102, label %plen.ic.family_token.17, label %plen.ic.miss.23

plen.ic.family_token.17:                          ; preds = %plen.ic.family_meta.16
  %r103 = inttoptr i64 %r101 to ptr
  %r104 = getelementptr i64, ptr %r103, i64 6
  %r105 = load i64, ptr %r104, align 8
  %r106 = icmp eq i64 %r105, %r94
  br i1 %r106, label %plen.ic.slot.18, label %plen.ic.miss.23

plen.ic.slot.18:                                  ; preds = %plen.ic.family_token.17, %plen.ic.exact.15
  %r107 = getelementptr i64, ptr %r61, i64 1
  %r108 = load i64, ptr %r107, align 8
  %r109 = getelementptr i64, ptr %r61, i64 2
  %r110 = load i64, ptr %r109, align 8
  %r111 = icmp ult i64 %r108, %r110
  br i1 %r111, label %plen.ic.inline.19, label %plen.ic.spill_meta.20

plen.ic.inline.19:                                ; preds = %plen.ic.slot.18
  %r112 = shl i64 %r108, 3
  %r113 = add i64 %r112, 16
  %r114 = add i64 %r32, %r113
  %r115 = inttoptr i64 %r114 to ptr
  %r116 = load double, ptr %r115, align 8
  br label %plen.ic.merge.24

plen.ic.spill_meta.20:                            ; preds = %plen.ic.slot.18
  %r117 = add nuw nsw i64 %r32, 8
  %r118 = inttoptr i64 %r117 to ptr
  %r119 = load i64, ptr %r118, align 8
  %r120 = icmp ne i64 %r119, 0
  br i1 %r120, label %plen.ic.spill_ptr.21, label %plen.ic.miss.23

plen.ic.spill_ptr.21:                             ; preds = %plen.ic.spill_meta.20
  %r121 = inttoptr i64 %r119 to ptr
  %r122 = getelementptr i64, ptr %r121, i64 4
  %r123 = load i64, ptr %r122, align 8
  %r124 = icmp ne i64 %r123, 0
  %r125 = select i1 %r124, i64 %r123, i64 %r119
  %r126 = inttoptr i64 %r125 to ptr
  %r127 = load i32, ptr %r126, align 4
  %r128 = zext i32 %r127 to i64
  %r129 = icmp ult i64 %r108, %r128
  %r130 = and i1 %r124, %r129
  br i1 %r130, label %plen.ic.spill_load.22, label %plen.ic.miss.23

plen.ic.spill_load.22:                            ; preds = %plen.ic.spill_ptr.21
  %r131 = add nuw nsw i64 %r108, 1
  %r132 = getelementptr inbounds nuw i64, ptr %r126, i64 %r131
  %r133 = load double, ptr %r132, align 8
  br label %plen.ic.merge.24

plen.ic.miss.23:                                  ; preds = %plen.ic.spill_ptr.21, %plen.ic.spill_meta.20, %plen.ic.family_token.17, %plen.ic.family_meta.16, %plen.ic.exact.15, %plen.ic.shape.probe.13, %plen.ic.shape.12, %plen.ic.header.11, %plen.slow.9
  %statepoint_token104 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r30, ptr @perry_ic_test_json_index_remainder_ts__0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.0.base, ptr addrspace(1) %r1.0) ]
  %r134105 = call double @llvm.experimental.gc.result.f64(token %statepoint_token104)
  %r1.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token104, i32 0, i32 0) ; (%r1.0.base, %r1.0.base)
  %r1.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token104, i32 0, i32 1) ; (%r1.0.base, %r1.0)
  br label %plen.ic.merge.24

plen.ic.merge.24:                                 ; preds = %plen.elem.length.27, %plen.ic.miss.23, %plen.ic.spill_load.22, %plen.ic.inline.19
  %.1422 = phi ptr addrspace(1) [ %r1.0, %plen.elem.length.27 ], [ %r1.0, %plen.ic.inline.19 ], [ %r1.0, %plen.ic.spill_load.22 ], [ %r1.0.relocated, %plen.ic.miss.23 ]
  %.1 = phi ptr addrspace(1) [ %r1.0.base, %plen.elem.length.27 ], [ %r1.0.base, %plen.ic.inline.19 ], [ %r1.0.base, %plen.ic.spill_load.22 ], [ %r1.0.base.relocated, %plen.ic.miss.23 ]
  %r135 = phi double [ %r83, %plen.elem.length.27 ], [ %r116, %plen.ic.inline.19 ], [ %r133, %plen.ic.spill_load.22 ], [ %r134105, %plen.ic.miss.23 ]
  br label %plen.merge.10

plen.elem.meta.25:                                ; preds = %plen.ic.header.11
  %r73 = add nuw nsw i64 %r32, 8
  %r74 = inttoptr i64 %r73 to ptr
  %r75 = load i64, ptr %r74, align 8
  %r76 = icmp ne i64 %r75, 0
  br i1 %r76, label %plen.elem.store.26, label %plen.ic.shape.12

plen.elem.store.26:                               ; preds = %plen.elem.meta.25
  %r77 = inttoptr i64 %r75 to ptr
  %r78 = getelementptr i64, ptr %r77, i64 12
  %r79 = load i64, ptr %r78, align 8
  %r80 = icmp ne i64 %r79, 0
  br i1 %r80, label %plen.elem.length.27, label %plen.ic.shape.12

plen.elem.length.27:                              ; preds = %plen.elem.store.26
  %r81 = inttoptr i64 %r79 to ptr
  %r82 = load i32, ptr %r81, align 4
  %r83 = uitofp i32 %r82 to double
  br label %plen.ic.merge.24

gcpoll.28:                                        ; preds = %plen.merge.10
  %statepoint_token106 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.0421) ]
  %r1.0.base.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 0, i32 0) ; (%.0, %.0)
  %r1.0.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 0, i32 1) ; (%.0, %.0421)
  br label %gcpoll.done.29

gcpoll.done.29:                                   ; preds = %gcpoll.28, %plen.merge.10
  %.2423 = phi ptr addrspace(1) [ %r1.0.relocated108, %gcpoll.28 ], [ %.0421, %plen.merge.10 ]
  %.2 = phi ptr addrspace(1) [ %r1.0.base.relocated107, %gcpoll.28 ], [ %.0, %plen.merge.10 ]
  %r140 = icmp eq i64 %r138, 9222246136947933188
  br i1 %r140, label %for.body.4, label %for.exit.6

for.cond.30:                                      ; preds = %for.update.32, %for.body.4
  %r143.0 = phi i32 [ 0, %for.body.4 ], [ %r451, %for.update.32 ]
  %r1.1.base = phi ptr addrspace(1) [ %.2, %for.body.4 ], [ %.0433, %for.update.32 ], !is_base_value !0
  %r1.1 = phi ptr addrspace(1) [ %.2423, %for.body.4 ], [ %.0434, %for.update.32 ]
  %r145 = sitofp i32 %r143.0 to double
  %r146.rs4i = ptrtoint ptr addrspace(1) %r1.1 to i64
  %r146.rs4o = call i64 asm "", "=r,0"(i64 %r146.rs4i) #8
  %r146 = bitcast i64 %r146.rs4o to double
  %r147 = bitcast double %r146 to i64
  %r148 = and i64 %r147, 281474976710655
  %r149 = lshr i64 %r147, 48
  %r150 = and i64 %r149, 65533
  %r151 = icmp eq i64 %r150, 32765
  %r152 = icmp ugt i64 %r148, 1048575
  %r153 = and i1 %r151, %r152
  br i1 %r153, label %plen.check_gc.34, label %plen.slow.36

for.body.31:                                      ; preds = %gcpoll.done.56
  %r260.rs4i = ptrtoint ptr addrspace(1) %.3430 to i64
  %r260.rs4o = call i64 asm "", "=r,0"(i64 %r260.rs4i) #8
  %r260 = bitcast i64 %r260.rs4o to double
  %r262 = bitcast double %r260 to i64
  %r263 = and i64 %r262, 281474976710655
  %r264 = lshr i64 %r262, 48
  %r265 = icmp eq i64 %r264, 32765
  %r266 = icmp ugt i64 %r263, 1048575
  %r267 = and i1 %r265, %r266
  br i1 %r267, label %arr.guard.deref.61, label %arr.guard.cold.63

for.update.32:                                    ; preds = %gcpoll.done.84
  %r451 = add i32 %r143.0, 1
  %r452 = sitofp i32 %r143.0 to double
  %r453 = sitofp i32 %r451 to double
  br label %for.cond.30

for.exit.33:                                      ; preds = %gcpoll.done.56
  %r454 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r455 = icmp ne i32 %r454, 0
  br i1 %r455, label %gcpoll.85, label %gcpoll.done.86

plen.check_gc.34:                                 ; preds = %for.cond.30
  %r154 = sub nuw nsw i64 %r148, 8
  %r155 = inttoptr i64 %r154 to ptr
  %r156 = load i8, ptr %r155, align 1
  %r157 = icmp eq i8 %r156, 1
  %r158 = icmp eq i8 %r156, 3
  %r159 = or i1 %r157, %r158
  %r160 = sub nuw nsw i64 %r148, 7
  %r161 = inttoptr i64 %r160 to ptr
  %r162 = load i8, ptr %r161, align 1
  %r163 = and i8 %r162, -128
  %r164 = icmp eq i8 %r163, 0
  %r165 = and i1 %r159, %r164
  br i1 %r165, label %plen.fast.35, label %plen.slow.36

plen.fast.35:                                     ; preds = %plen.check_gc.34
  %r167 = inttoptr i64 %r148 to ptr
  %r168 = select i1 false, ptr @perry_null_guard_zero_test_json_index_remainder_ts, ptr %r167
  %r169 = load i32, ptr %r168, align 4
  %r170 = uitofp i32 %r169 to double
  br label %plen.merge.37

plen.slow.36:                                     ; preds = %plen.check_gc.34, %for.cond.30
  %r171 = lshr i64 %r147, 48
  %r172 = icmp eq i64 %r171, 32765
  %r173 = icmp uge i64 %r148, 2199023255552
  %r174 = icmp ult i64 %r148, 140737488355328
  %r175 = and i1 %r172, %r173
  %r176 = and i1 %r175, %r174
  %r177 = load ptr, ptr @perry_ic_test_json_index_remainder_ts__1, align 8
  br i1 %r176, label %plen.ic.header.38, label %plen.ic.miss.50

plen.merge.37:                                    ; preds = %plen.ic.merge.51, %plen.fast.35
  %.1428 = phi ptr addrspace(1) [ %r1.1, %plen.fast.35 ], [ %.2429, %plen.ic.merge.51 ]
  %.1425 = phi ptr addrspace(1) [ %r1.1.base, %plen.fast.35 ], [ %.2426, %plen.ic.merge.51 ]
  %r252 = phi double [ %r170, %plen.fast.35 ], [ %r251, %plen.ic.merge.51 ]
  %r253 = fcmp olt double %r145, %r252
  %r254 = select i1 %r253, i64 9222246136947933188, i64 9222246136947933187
  %r255 = bitcast i64 %r254 to double
  %r257 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r258 = icmp ne i32 %r257, 0
  br i1 %r258, label %gcpoll.55, label %gcpoll.done.56

plen.ic.header.38:                                ; preds = %plen.slow.36
  %r179 = sub nuw nsw i64 %r148, 8
  %r180 = inttoptr i64 %r179 to ptr
  %r181 = load i8, ptr %r180, align 1
  %r182 = icmp eq i8 %r181, 2
  %r183 = sub nuw nsw i64 %r148, 7
  %r184 = inttoptr i64 %r183 to ptr
  %r185 = load i8, ptr %r184, align 1
  %r186 = and i8 %r185, -128
  %r187 = icmp eq i8 %r186, 0
  %r188 = and i1 %r182, %r187
  br i1 %r188, label %plen.elem.meta.52, label %plen.ic.miss.50

plen.ic.shape.39:                                 ; preds = %plen.elem.store.53, %plen.elem.meta.52
  %r178 = icmp ne ptr %r177, null
  br i1 %r178, label %plen.ic.shape.probe.40, label %plen.ic.miss.50

plen.ic.shape.probe.40:                           ; preds = %plen.ic.shape.39
  %r200 = inttoptr i64 %r148 to ptr
  %r201 = load i32, ptr %r200, align 4
  %r202 = add nuw nsw i64 %r148, 4
  %r203 = inttoptr i64 %r202 to ptr
  %r204 = load i32, ptr %r203, align 4
  %r205 = zext i32 %r201 to i64
  %r206 = zext i32 %r204 to i64
  %r207 = shl nuw i64 %r205, 32
  %r208 = or i64 %r207, %r206
  %r209 = getelementptr i64, ptr %r177, i64 0
  %r210 = load i64, ptr %r209, align 8
  %r211 = icmp ne i64 %r210, 0
  br i1 %r211, label %plen.ic.identity.41, label %plen.ic.miss.50

plen.ic.identity.41:                              ; preds = %plen.ic.shape.probe.40
  %r212 = and i64 %r210, -9223372036854775808
  %1 = icmp slt i64 %r210, 0
  br i1 %1, label %plen.ic.family_meta.43, label %plen.ic.exact.42

plen.ic.exact.42:                                 ; preds = %plen.ic.identity.41
  %r214 = icmp eq i64 %r208, %r210
  br i1 %r214, label %plen.ic.slot.45, label %plen.ic.miss.50

plen.ic.family_meta.43:                           ; preds = %plen.ic.identity.41
  %r215 = add nuw nsw i64 %r148, 8
  %r216 = inttoptr i64 %r215 to ptr
  %r217 = load i64, ptr %r216, align 8
  %r218 = icmp ne i64 %r217, 0
  br i1 %r218, label %plen.ic.family_token.44, label %plen.ic.miss.50

plen.ic.family_token.44:                          ; preds = %plen.ic.family_meta.43
  %r219 = inttoptr i64 %r217 to ptr
  %r220 = getelementptr i64, ptr %r219, i64 6
  %r221 = load i64, ptr %r220, align 8
  %r222 = icmp eq i64 %r221, %r210
  br i1 %r222, label %plen.ic.slot.45, label %plen.ic.miss.50

plen.ic.slot.45:                                  ; preds = %plen.ic.family_token.44, %plen.ic.exact.42
  %r223 = getelementptr i64, ptr %r177, i64 1
  %r224 = load i64, ptr %r223, align 8
  %r225 = getelementptr i64, ptr %r177, i64 2
  %r226 = load i64, ptr %r225, align 8
  %r227 = icmp ult i64 %r224, %r226
  br i1 %r227, label %plen.ic.inline.46, label %plen.ic.spill_meta.47

plen.ic.inline.46:                                ; preds = %plen.ic.slot.45
  %r228 = shl i64 %r224, 3
  %r229 = add i64 %r228, 16
  %r230 = add i64 %r148, %r229
  %r231 = inttoptr i64 %r230 to ptr
  %r232 = load double, ptr %r231, align 8
  br label %plen.ic.merge.51

plen.ic.spill_meta.47:                            ; preds = %plen.ic.slot.45
  %r233 = add nuw nsw i64 %r148, 8
  %r234 = inttoptr i64 %r233 to ptr
  %r235 = load i64, ptr %r234, align 8
  %r236 = icmp ne i64 %r235, 0
  br i1 %r236, label %plen.ic.spill_ptr.48, label %plen.ic.miss.50

plen.ic.spill_ptr.48:                             ; preds = %plen.ic.spill_meta.47
  %r237 = inttoptr i64 %r235 to ptr
  %r238 = getelementptr i64, ptr %r237, i64 4
  %r239 = load i64, ptr %r238, align 8
  %r240 = icmp ne i64 %r239, 0
  %r241 = select i1 %r240, i64 %r239, i64 %r235
  %r242 = inttoptr i64 %r241 to ptr
  %r243 = load i32, ptr %r242, align 4
  %r244 = zext i32 %r243 to i64
  %r245 = icmp ult i64 %r224, %r244
  %r246 = and i1 %r240, %r245
  br i1 %r246, label %plen.ic.spill_load.49, label %plen.ic.miss.50

plen.ic.spill_load.49:                            ; preds = %plen.ic.spill_ptr.48
  %r247 = add nuw nsw i64 %r224, 1
  %r248 = getelementptr inbounds nuw i64, ptr %r242, i64 %r247
  %r249 = load double, ptr %r248, align 8
  br label %plen.ic.merge.51

plen.ic.miss.50:                                  ; preds = %plen.ic.spill_ptr.48, %plen.ic.spill_meta.47, %plen.ic.family_token.44, %plen.ic.family_meta.43, %plen.ic.exact.42, %plen.ic.shape.probe.40, %plen.ic.shape.39, %plen.ic.header.38, %plen.slow.36
  %statepoint_token109 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r146, ptr @perry_ic_test_json_index_remainder_ts__1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.1.base, ptr addrspace(1) %r1.1) ]
  %r250110 = call double @llvm.experimental.gc.result.f64(token %statepoint_token109)
  %r1.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 0, i32 0) ; (%r1.1.base, %r1.1.base)
  %r1.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 0, i32 1) ; (%r1.1.base, %r1.1)
  br label %plen.ic.merge.51

plen.ic.merge.51:                                 ; preds = %plen.elem.length.54, %plen.ic.miss.50, %plen.ic.spill_load.49, %plen.ic.inline.46
  %.2429 = phi ptr addrspace(1) [ %r1.1, %plen.elem.length.54 ], [ %r1.1, %plen.ic.inline.46 ], [ %r1.1, %plen.ic.spill_load.49 ], [ %r1.1.relocated, %plen.ic.miss.50 ]
  %.2426 = phi ptr addrspace(1) [ %r1.1.base, %plen.elem.length.54 ], [ %r1.1.base, %plen.ic.inline.46 ], [ %r1.1.base, %plen.ic.spill_load.49 ], [ %r1.1.base.relocated, %plen.ic.miss.50 ]
  %r251 = phi double [ %r199, %plen.elem.length.54 ], [ %r232, %plen.ic.inline.46 ], [ %r249, %plen.ic.spill_load.49 ], [ %r250110, %plen.ic.miss.50 ]
  br label %plen.merge.37

plen.elem.meta.52:                                ; preds = %plen.ic.header.38
  %r189 = add nuw nsw i64 %r148, 8
  %r190 = inttoptr i64 %r189 to ptr
  %r191 = load i64, ptr %r190, align 8
  %r192 = icmp ne i64 %r191, 0
  br i1 %r192, label %plen.elem.store.53, label %plen.ic.shape.39

plen.elem.store.53:                               ; preds = %plen.elem.meta.52
  %r193 = inttoptr i64 %r191 to ptr
  %r194 = getelementptr i64, ptr %r193, i64 12
  %r195 = load i64, ptr %r194, align 8
  %r196 = icmp ne i64 %r195, 0
  br i1 %r196, label %plen.elem.length.54, label %plen.ic.shape.39

plen.elem.length.54:                              ; preds = %plen.elem.store.53
  %r197 = inttoptr i64 %r195 to ptr
  %r198 = load i32, ptr %r197, align 4
  %r199 = uitofp i32 %r198 to double
  br label %plen.ic.merge.51

gcpoll.55:                                        ; preds = %plen.merge.37
  %statepoint_token111 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1425, ptr addrspace(1) %.1428) ]
  %r1.1.base.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token111, i32 0, i32 0) ; (%.1425, %.1425)
  %r1.1.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token111, i32 0, i32 1) ; (%.1425, %.1428)
  br label %gcpoll.done.56

gcpoll.done.56:                                   ; preds = %gcpoll.55, %plen.merge.37
  %.3430 = phi ptr addrspace(1) [ %r1.1.relocated113, %gcpoll.55 ], [ %.1428, %plen.merge.37 ]
  %.3 = phi ptr addrspace(1) [ %r1.1.base.relocated112, %gcpoll.55 ], [ %.1425, %plen.merge.37 ]
  %r256 = icmp eq i64 %r254, 9222246136947933188
  br i1 %r256, label %for.body.31, label %for.exit.33

arr.fast.57:                                      ; preds = %arr.guard.numeric_in_bounds.65, %arr.guard.cold.63
  %r1.2.base = phi ptr addrspace(1) [ %.3, %arr.guard.numeric_in_bounds.65 ], [ %rs4gc.s5, %arr.guard.cold.63 ], !is_base_value !0
  %r1.2 = phi ptr addrspace(1) [ %.3430, %arr.guard.numeric_in_bounds.65 ], [ %rs4gc.s5, %arr.guard.cold.63 ]
  %r331 = phi i64 [ %r282, %arr.guard.numeric_in_bounds.65 ], [ %r325, %arr.guard.cold.63 ]
  %r332 = zext i32 %r27.0 to i64
  %r333 = shl nuw nsw i64 %r332, 3
  %r334 = add nuw nsw i64 %r333, 8
  %r335 = add i64 %r331, %r334
  %r336 = inttoptr i64 %r335 to ptr
  %r337 = load double, ptr %r336, align 8
  br label %arr.merge.60

arr.fallback.58:                                  ; preds = %arr.guard.cold.63, %arr.guard.deref.61
  %r1.4.base = phi ptr addrspace(1) [ %rs4gc.s5, %arr.guard.cold.63 ], [ %.3, %arr.guard.deref.61 ], !is_base_value !0
  %r1.4 = phi ptr addrspace(1) [ %rs4gc.s5, %arr.guard.cold.63 ], [ %.3430, %arr.guard.deref.61 ]
  %r329 = sitofp i32 %r27.0 to double
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5190247735588028418, double %r260, double %r329, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.4.base, ptr addrspace(1) %r1.4) ]
  %r330115 = call double @llvm.experimental.gc.result.f64(token %statepoint_token114)
  %r1.4.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 0) ; (%r1.4.base, %r1.4.base)
  %r1.4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 1) ; (%r1.4.base, %r1.4)
  br label %arr.merge.60

arr.guard.oob.59:                                 ; preds = %arr.guard.range.64
  br label %arr.merge.60

arr.merge.60:                                     ; preds = %arr.guard.oob.59, %arr.fallback.58, %arr.fast.57
  %r1.3.base = phi ptr addrspace(1) [ %r1.2.base, %arr.fast.57 ], [ %r1.4.base.relocated, %arr.fallback.58 ], [ %.3, %arr.guard.oob.59 ], !is_base_value !0
  %r1.3 = phi ptr addrspace(1) [ %r1.2, %arr.fast.57 ], [ %r1.4.relocated, %arr.fallback.58 ], [ %.3430, %arr.guard.oob.59 ]
  %r338 = phi double [ %r337, %arr.fast.57 ], [ %r330115, %arr.fallback.58 ], [ 0x7FFC000000000001, %arr.guard.oob.59 ]
  %r340.rs4i = ptrtoint ptr addrspace(1) %r1.3 to i64
  %r340.rs4o = call i64 asm "", "=r,0"(i64 %r340.rs4i) #8
  %r340 = bitcast i64 %r340.rs4o to double
  %r342 = bitcast double %r340 to i64
  %r343 = and i64 %r342, 281474976710655
  %r344 = lshr i64 %r342, 48
  %r345 = icmp eq i64 %r344, 32765
  %r346 = icmp ugt i64 %r343, 1048575
  %r347 = and i1 %r345, %r346
  br i1 %r347, label %arr.guard.deref.70, label %arr.guard.cold.72

arr.guard.deref.61:                               ; preds = %for.body.31
  %r268 = bitcast double %r260 to i64
  %r269 = and i64 %r268, 281474976710655
  %r270 = sub nsw i64 %r269, 8
  %r271 = inttoptr i64 %r270 to ptr
  %r272 = load i8, ptr %r271, align 1
  %r273 = icmp eq i8 %r272, 1
  %r274 = sub nsw i64 %r269, 7
  %r275 = inttoptr i64 %r274 to ptr
  %r276 = load i8, ptr %r275, align 1
  %r277 = and i8 %r276, -128
  %r278 = icmp ne i8 %r277, 0
  %r279 = inttoptr i64 %r269 to ptr
  %r280 = load i64, ptr %r279, align 8
  %r281 = and i1 %r273, %r278
  %r282 = select i1 %r281, i64 %r280, i64 %r269
  %r283 = lshr i64 %r282, 48
  %r284 = icmp eq i64 %r283, 0
  %r285 = icmp ugt i64 %r282, 1048575
  %r286 = and i1 %r284, %r285
  br i1 %r286, label %arr.guard.live.62, label %arr.fallback.58

arr.guard.live.62:                                ; preds = %arr.guard.deref.61
  %r287 = sub nuw i64 %r282, 8
  %r288 = inttoptr i64 %r287 to ptr
  %r289 = load i8, ptr %r288, align 1
  %r290 = icmp eq i8 %r289, 1
  %r291 = sub nuw i64 %r282, 7
  %r292 = inttoptr i64 %r291 to ptr
  %r293 = load i8, ptr %r292, align 1
  %r294 = and i8 %r293, -128
  %r295 = icmp eq i8 %r294, 0
  %r296 = sub nuw i64 %r282, 6
  %r297 = inttoptr i64 %r296 to ptr
  %r298 = load i16, ptr %r297, align 2
  %r299 = and i16 %r298, 1024
  %r300 = icmp eq i16 %r299, 0
  %r301 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r302 = icmp eq i8 %r301, 0
  %r303 = inttoptr i64 %r282 to ptr
  %r304 = load i32, ptr %r303, align 4
  %r305 = getelementptr i8, ptr %r303, i64 4
  %r306 = load i32, ptr %r305, align 4
  %r307 = icmp slt i32 %r27.0, 0
  %r308 = icmp eq i1 %r307, false
  %r309 = icmp ult i32 %r27.0, %r304
  %r310 = icmp ule i32 %r304, 16000000
  %r311 = icmp ule i32 %r306, 16000000
  %r312 = icmp ule i32 %r304, %r306
  %r313 = and i1 %r290, %r295
  %r314 = and i1 %r313, %r300
  %r315 = and i1 %r314, %r302
  %r316 = and i1 %r315, %r308
  %r317 = and i1 %r316, %r310
  %r318 = and i1 %r317, %r311
  %r319 = and i1 %r318, %r312
  br i1 %r319, label %arr.guard.range.64, label %arr.guard.cold.63

arr.guard.cold.63:                                ; preds = %arr.guard.numeric_in_bounds.65, %arr.guard.live.62, %for.body.31
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_array_refresh_local_head, i32 1, i32 0, double %r260, i32 0, i32 0)
  %r323117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token116)
  %rs4gc.b5 = bitcast double %r323117 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r324 = bitcast double %r260 to i64
  %r325 = and i64 %r324, 281474976710655
  %r326 = call i32 @js_typed_feedback_numeric_array_index_get_guard(i64 5190247735588028418, double %r260, i32 %r27.0, i32 1) #8
  %r327 = icmp ne i32 %r326, 0
  br i1 %r327, label %arr.fast.57, label %arr.fallback.58

arr.guard.range.64:                               ; preds = %arr.guard.live.62
  %r320 = and i16 %r298, 128
  %r321 = icmp ne i16 %r320, 0
  %r322 = and i1 %r309, %r321
  br i1 %r309, label %arr.guard.numeric_in_bounds.65, label %arr.guard.oob.59

arr.guard.numeric_in_bounds.65:                   ; preds = %arr.guard.range.64
  br i1 %r322, label %arr.fast.57, label %arr.guard.cold.63

arr.fast.66:                                      ; preds = %arr.guard.numeric_in_bounds.74, %arr.guard.cold.72
  %r1.5.base = phi ptr addrspace(1) [ %r1.3.base, %arr.guard.numeric_in_bounds.74 ], [ %rs4gc.s7, %arr.guard.cold.72 ], !is_base_value !0
  %r1.5 = phi ptr addrspace(1) [ %r1.3, %arr.guard.numeric_in_bounds.74 ], [ %rs4gc.s7, %arr.guard.cold.72 ]
  %r411 = phi i64 [ %r362, %arr.guard.numeric_in_bounds.74 ], [ %r405, %arr.guard.cold.72 ]
  %r412 = zext i32 %r143.0 to i64
  %r413 = shl nuw nsw i64 %r412, 3
  %r414 = add nuw nsw i64 %r413, 8
  %r415 = add i64 %r411, %r414
  %r416 = inttoptr i64 %r415 to ptr
  %r417 = load double, ptr %r416, align 8
  br label %arr.merge.69

arr.fallback.67:                                  ; preds = %arr.guard.cold.72, %arr.guard.deref.70
  %r1.7.base = phi ptr addrspace(1) [ %rs4gc.s7, %arr.guard.cold.72 ], [ %r1.3.base, %arr.guard.deref.70 ], !is_base_value !0
  %r1.7 = phi ptr addrspace(1) [ %rs4gc.s7, %arr.guard.cold.72 ], [ %r1.3, %arr.guard.deref.70 ]
  %r409 = sitofp i32 %r143.0 to double
  %statepoint_token118 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5190247735588028419, double %r340, double %r409, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.7.base, ptr addrspace(1) %r1.7) ]
  %r410119 = call double @llvm.experimental.gc.result.f64(token %statepoint_token118)
  %r1.7.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token118, i32 0, i32 0) ; (%r1.7.base, %r1.7.base)
  %r1.7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token118, i32 0, i32 1) ; (%r1.7.base, %r1.7)
  br label %arr.merge.69

arr.guard.oob.68:                                 ; preds = %arr.guard.range.73
  br label %arr.merge.69

arr.merge.69:                                     ; preds = %arr.guard.oob.68, %arr.fallback.67, %arr.fast.66
  %r1.6.base = phi ptr addrspace(1) [ %r1.5.base, %arr.fast.66 ], [ %r1.7.base.relocated, %arr.fallback.67 ], [ %r1.3.base, %arr.guard.oob.68 ], !is_base_value !0
  %r1.6 = phi ptr addrspace(1) [ %r1.5, %arr.fast.66 ], [ %r1.7.relocated, %arr.fallback.67 ], [ %r1.3, %arr.guard.oob.68 ]
  %r418 = phi double [ %r417, %arr.fast.66 ], [ %r410119, %arr.fallback.67 ], [ 0x7FFC000000000001, %arr.guard.oob.68 ]
  %statepoint_token120 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base, ptr addrspace(1) %r1.6) ]
  %r419121 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token120)
  %r1.6.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 0, i32 0) ; (%r1.6.base, %r1.6.base)
  %r1.6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 0, i32 1) ; (%r1.6.base, %r1.6)
  %rs4gc.s6 = inttoptr i64 %r419121 to ptr addrspace(1)
  %r421.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r421 = call i64 asm "", "=r,0"(i64 %r421.rs4i) #8
  %r422 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r423 = icmp ne i32 %r422, 0
  br i1 %r423, label %shadow.root.barrier.75, label %shadow.root.barrier.done.76

arr.guard.deref.70:                               ; preds = %arr.merge.60
  %r348 = bitcast double %r340 to i64
  %r349 = and i64 %r348, 281474976710655
  %r350 = sub nsw i64 %r349, 8
  %r351 = inttoptr i64 %r350 to ptr
  %r352 = load i8, ptr %r351, align 1
  %r353 = icmp eq i8 %r352, 1
  %r354 = sub nsw i64 %r349, 7
  %r355 = inttoptr i64 %r354 to ptr
  %r356 = load i8, ptr %r355, align 1
  %r357 = and i8 %r356, -128
  %r358 = icmp ne i8 %r357, 0
  %r359 = inttoptr i64 %r349 to ptr
  %r360 = load i64, ptr %r359, align 8
  %r361 = and i1 %r353, %r358
  %r362 = select i1 %r361, i64 %r360, i64 %r349
  %r363 = lshr i64 %r362, 48
  %r364 = icmp eq i64 %r363, 0
  %r365 = icmp ugt i64 %r362, 1048575
  %r366 = and i1 %r364, %r365
  br i1 %r366, label %arr.guard.live.71, label %arr.fallback.67

arr.guard.live.71:                                ; preds = %arr.guard.deref.70
  %r367 = sub nuw i64 %r362, 8
  %r368 = inttoptr i64 %r367 to ptr
  %r369 = load i8, ptr %r368, align 1
  %r370 = icmp eq i8 %r369, 1
  %r371 = sub nuw i64 %r362, 7
  %r372 = inttoptr i64 %r371 to ptr
  %r373 = load i8, ptr %r372, align 1
  %r374 = and i8 %r373, -128
  %r375 = icmp eq i8 %r374, 0
  %r376 = sub nuw i64 %r362, 6
  %r377 = inttoptr i64 %r376 to ptr
  %r378 = load i16, ptr %r377, align 2
  %r379 = and i16 %r378, 1024
  %r380 = icmp eq i16 %r379, 0
  %r381 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r382 = icmp eq i8 %r381, 0
  %r383 = inttoptr i64 %r362 to ptr
  %r384 = load i32, ptr %r383, align 4
  %r385 = getelementptr i8, ptr %r383, i64 4
  %r386 = load i32, ptr %r385, align 4
  %r387 = icmp slt i32 %r143.0, 0
  %r388 = icmp eq i1 %r387, false
  %r389 = icmp ult i32 %r143.0, %r384
  %r390 = icmp ule i32 %r384, 16000000
  %r391 = icmp ule i32 %r386, 16000000
  %r392 = icmp ule i32 %r384, %r386
  %r393 = and i1 %r370, %r375
  %r394 = and i1 %r393, %r380
  %r395 = and i1 %r394, %r382
  %r396 = and i1 %r395, %r388
  %r397 = and i1 %r396, %r390
  %r398 = and i1 %r397, %r391
  %r399 = and i1 %r398, %r392
  br i1 %r399, label %arr.guard.range.73, label %arr.guard.cold.72

arr.guard.cold.72:                                ; preds = %arr.guard.numeric_in_bounds.74, %arr.guard.live.71, %arr.merge.60
  %statepoint_token122 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_array_refresh_local_head, i32 1, i32 0, double %r340, i32 0, i32 0)
  %r403123 = call double @llvm.experimental.gc.result.f64(token %statepoint_token122)
  %rs4gc.b7 = bitcast double %r403123 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r404 = bitcast double %r340 to i64
  %r405 = and i64 %r404, 281474976710655
  %r406 = call i32 @js_typed_feedback_numeric_array_index_get_guard(i64 5190247735588028419, double %r340, i32 %r143.0, i32 1) #8
  %r407 = icmp ne i32 %r406, 0
  br i1 %r407, label %arr.fast.66, label %arr.fallback.67

arr.guard.range.73:                               ; preds = %arr.guard.live.71
  %r400 = and i16 %r378, 128
  %r401 = icmp ne i16 %r400, 0
  %r402 = and i1 %r389, %r401
  br i1 %r389, label %arr.guard.numeric_in_bounds.74, label %arr.guard.oob.68

arr.guard.numeric_in_bounds.74:                   ; preds = %arr.guard.range.73
  br i1 %r402, label %arr.fast.66, label %arr.guard.cold.72

shadow.root.barrier.75:                           ; preds = %arr.merge.69
  call void @js_write_barrier_root_nanbox(i64 %r421) #8
  br label %shadow.root.barrier.done.76

shadow.root.barrier.done.76:                      ; preds = %shadow.root.barrier.75, %arr.merge.69
  %r425 = sitofp i32 %r27.0 to double
  %r426.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r426 = call i64 asm "", "=r,0"(i64 %r426.rs4i) #8
  %statepoint_token124 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r426, double %r425, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base.relocated, ptr addrspace(1) %r1.6.relocated) ]
  %r427125 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token124)
  %r1.6.base.relocated126 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 0, i32 0) ; (%r1.6.base.relocated, %r1.6.base.relocated)
  %r1.6.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 0, i32 1) ; (%r1.6.base.relocated, %r1.6.relocated)
  %rs4gc.s8 = inttoptr i64 %r427125 to ptr addrspace(1)
  %r428.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r428 = call i64 asm "", "=r,0"(i64 %r428.rs4i) #8
  %r429 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r430 = icmp ne i32 %r429, 0
  br i1 %r430, label %shadow.root.barrier.77, label %shadow.root.barrier.done.78

shadow.root.barrier.77:                           ; preds = %shadow.root.barrier.done.76
  call void @js_write_barrier_root_nanbox(i64 %r428) #8
  br label %shadow.root.barrier.done.78

shadow.root.barrier.done.78:                      ; preds = %shadow.root.barrier.77, %shadow.root.barrier.done.76
  %r432 = sitofp i32 %r143.0 to double
  %r433.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r433 = call i64 asm "", "=r,0"(i64 %r433.rs4i) #8
  %statepoint_token128 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r433, double %r432, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base.relocated126, ptr addrspace(1) %r1.6.relocated127) ]
  %r434129 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token128)
  %r1.6.base.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 0, i32 0) ; (%r1.6.base.relocated126, %r1.6.base.relocated126)
  %r1.6.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 0, i32 1) ; (%r1.6.base.relocated126, %r1.6.relocated127)
  %rs4gc.s9 = inttoptr i64 %r434129 to ptr addrspace(1)
  %r435.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r435 = call i64 asm "", "=r,0"(i64 %r435.rs4i) #8
  %r436 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r437 = icmp ne i32 %r436, 0
  br i1 %r437, label %shadow.root.barrier.79, label %shadow.root.barrier.done.80

shadow.root.barrier.79:                           ; preds = %shadow.root.barrier.done.78
  call void @js_write_barrier_root_nanbox(i64 %r435) #8
  br label %shadow.root.barrier.done.80

shadow.root.barrier.done.80:                      ; preds = %shadow.root.barrier.79, %shadow.root.barrier.done.78
  %statepoint_token132 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r338, double %r418, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base.relocated130, ptr addrspace(1) %r1.6.relocated131, ptr addrspace(1) %rs4gc.s9) ]
  %r440133 = call double @llvm.experimental.gc.result.f64(token %statepoint_token132)
  %r1.6.base.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 0, i32 0) ; (%r1.6.base.relocated130, %r1.6.base.relocated130)
  %r1.6.relocated135 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 0, i32 1) ; (%r1.6.base.relocated130, %r1.6.relocated131)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  %statepoint_token136 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_index_remainder_ts__describe, i32 1, i32 0, double %r440133, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base.relocated134, ptr addrspace(1) %r1.6.relocated135, ptr addrspace(1) %rs4gc.s9.relocated) ]
  %r441137 = call double @llvm.experimental.gc.result.f64(token %statepoint_token136)
  %r1.6.base.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token136, i32 0, i32 0) ; (%r1.6.base.relocated134, %r1.6.base.relocated134)
  %r1.6.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token136, i32 0, i32 1) ; (%r1.6.base.relocated134, %r1.6.relocated135)
  %rs4gc.s9.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token136, i32 2, i32 2) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  %r442.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated140 to i64
  %r442 = call i64 asm "", "=r,0"(i64 %r442.rs4i) #8
  %statepoint_token141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r442, double %r441137, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base.relocated138, ptr addrspace(1) %r1.6.relocated139) ]
  %r443142 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token141)
  %r1.6.base.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 0, i32 0) ; (%r1.6.base.relocated138, %r1.6.base.relocated138)
  %r1.6.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 0, i32 1) ; (%r1.6.base.relocated138, %r1.6.relocated139)
  %rs4gc.s10 = inttoptr i64 %r443142 to ptr addrspace(1)
  %r444.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r444 = call i64 asm "", "=r,0"(i64 %r444.rs4i) #8
  %r445 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r446 = icmp ne i32 %r445, 0
  br i1 %r446, label %shadow.root.barrier.81, label %shadow.root.barrier.done.82

shadow.root.barrier.81:                           ; preds = %shadow.root.barrier.done.80
  call void @js_write_barrier_root_nanbox(i64 %r444) #8
  br label %shadow.root.barrier.done.82

shadow.root.barrier.done.82:                      ; preds = %shadow.root.barrier.81, %shadow.root.barrier.done.80
  %r447.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r447 = call i64 asm "", "=r,0"(i64 %r447.rs4i) #8
  %statepoint_token145 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r447, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base.relocated143, ptr addrspace(1) %r1.6.relocated144) ]
  %r1.6.base.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token145, i32 0, i32 0) ; (%r1.6.base.relocated143, %r1.6.base.relocated143)
  %r1.6.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token145, i32 0, i32 1) ; (%r1.6.base.relocated143, %r1.6.relocated144)
  %r448 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r449 = icmp ne i32 %r448, 0
  br i1 %r449, label %gcpoll.83, label %gcpoll.done.84

gcpoll.83:                                        ; preds = %shadow.root.barrier.done.82
  %statepoint_token148 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.6.base.relocated146, ptr addrspace(1) %r1.6.relocated147) ]
  %r1.6.base.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 0, i32 0) ; (%r1.6.base.relocated146, %r1.6.base.relocated146)
  %r1.6.relocated150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 0, i32 1) ; (%r1.6.base.relocated146, %r1.6.relocated147)
  br label %gcpoll.done.84

gcpoll.done.84:                                   ; preds = %gcpoll.83, %shadow.root.barrier.done.82
  %.0434 = phi ptr addrspace(1) [ %r1.6.relocated150, %gcpoll.83 ], [ %r1.6.relocated147, %shadow.root.barrier.done.82 ]
  %.0433 = phi ptr addrspace(1) [ %r1.6.base.relocated149, %gcpoll.83 ], [ %r1.6.base.relocated146, %shadow.root.barrier.done.82 ]
  br label %for.update.32

gcpoll.85:                                        ; preds = %for.exit.33
  %statepoint_token151 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.3430) ]
  %r1.1.base.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 0, i32 0) ; (%.3, %.3)
  %r1.1.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 0, i32 1) ; (%.3, %.3430)
  br label %gcpoll.done.86

gcpoll.done.86:                                   ; preds = %gcpoll.85, %for.exit.33
  %.0427 = phi ptr addrspace(1) [ %r1.1.relocated153, %gcpoll.85 ], [ %.3430, %for.exit.33 ]
  %.0424 = phi ptr addrspace(1) [ %r1.1.base.relocated152, %gcpoll.85 ], [ %.3, %for.exit.33 ]
  br label %for.update.5

shadow.root.barrier.87:                           ; preds = %for.exit.6
  call void @js_write_barrier_root_nanbox(i64 %r472) #8
  br label %shadow.root.barrier.done.88

shadow.root.barrier.done.88:                      ; preds = %shadow.root.barrier.87, %for.exit.6
  %statepoint_token154 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_bigint_from_i128_parts, i32 2, i32 0, i64 43, i64 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4) ]
  %r478155 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token154)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token154, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  %r479 = or i64 %r478155, 9221683186994511872
  %r480 = bitcast i64 %r479 to double
  %statepoint_token156 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_dynamic_neg, i32 1, i32 0, double %r480, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated) ]
  %r481157 = call double @llvm.experimental.gc.result.f64(token %statepoint_token156)
  %rs4gc.s4.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token156, i32 0, i32 0) ; (%rs4gc.s4.relocated, %rs4gc.s4.relocated)
  %r482 = load double, ptr @test_json_index_remainder_ts_.str.3.handle, align 8
  %r483.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4.relocated158 to i64
  %r483 = call i64 asm "", "=r,0"(i64 %r483.rs4i) #8
  %r484 = bitcast i64 %r483 to double
  br label %arena_state.init.89

arena_state.init.89:                              ; preds = %shadow.root.barrier.done.88
  %r488 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r489 = icmp ne i64 %r488, -1
  br i1 %r489, label %arena_state.hot_tls.tsd.91, label %arena_state.hot_tls.slow.93

arena_state.ready.90:                             ; preds = %arena_state.hot_tls.resolved.95
  %r504 = getelementptr i8, ptr %r502, i64 8
  %r505 = load i64, ptr %r504, align 8
  %r506 = add i64 %r505, 72
  %r507 = getelementptr i8, ptr %r502, i64 16
  %r508 = load i64, ptr %r507, align 8
  %r509 = icmp ule i64 %r506, %r508
  br i1 %r509, label %arrlit.fast.96, label %arrlit.slow.97

arena_state.hot_tls.tsd.91:                       ; preds = %arena_state.init.89
  %r490 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #8
  %r491 = and i64 %r490, -8
  %r492 = shl i64 %r488, 3
  %r493 = add i64 %r491, %r492
  %r494 = inttoptr i64 %r493 to ptr
  %r495 = load ptr, ptr %r494, align 8
  %r496 = icmp ne ptr %r495, null
  br i1 %r496, label %arena_state.hot_tls.fast.92, label %arena_state.hot_tls.slow.93

arena_state.hot_tls.fast.92:                      ; preds = %arena_state.hot_tls.tsd.91
  %r497 = getelementptr i8, ptr %r495, i64 8
  %r498 = load ptr, ptr %r497, align 8
  %r499 = load ptr, ptr %r498, align 8
  %r500 = icmp ne ptr %r499, null
  br i1 %r500, label %arena_state.hot_tls.ready.94, label %arena_state.hot_tls.slow.93

arena_state.hot_tls.slow.93:                      ; preds = %arena_state.hot_tls.fast.92, %arena_state.hot_tls.tsd.91, %arena_state.init.89
  %statepoint_token159 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated158) ]
  %r501160 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token159)
  %rs4gc.s4.relocated161 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 0, i32 0) ; (%rs4gc.s4.relocated158, %rs4gc.s4.relocated158)
  br label %arena_state.hot_tls.resolved.95

arena_state.hot_tls.ready.94:                     ; preds = %arena_state.hot_tls.fast.92
  br label %arena_state.hot_tls.resolved.95

arena_state.hot_tls.resolved.95:                  ; preds = %arena_state.hot_tls.ready.94, %arena_state.hot_tls.slow.93
  %.0435 = phi ptr addrspace(1) [ %rs4gc.s4.relocated158, %arena_state.hot_tls.ready.94 ], [ %rs4gc.s4.relocated161, %arena_state.hot_tls.slow.93 ]
  %r502 = phi ptr [ %r498, %arena_state.hot_tls.ready.94 ], [ %r501160, %arena_state.hot_tls.slow.93 ]
  br label %arena_state.ready.90

arrlit.fast.96:                                   ; preds = %arena_state.ready.90
  store i64 %r506, ptr %r504, align 8
  %r510 = load ptr, ptr %r502, align 8
  %r511 = getelementptr i8, ptr %r510, i64 %r505
  br label %arrlit.merge.98

arrlit.slow.97:                                   ; preds = %arena_state.ready.90
  %statepoint_token162 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r502, i64 72, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0435) ]
  %r512163 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token162)
  %rs4gc.s4.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 0, i32 0) ; (%.0435, %.0435)
  br label %arrlit.merge.98

arrlit.merge.98:                                  ; preds = %arrlit.slow.97, %arrlit.fast.96
  %.1436 = phi ptr addrspace(1) [ %.0435, %arrlit.fast.96 ], [ %rs4gc.s4.relocated164, %arrlit.slow.97 ]
  %r513 = phi ptr [ %r511, %arrlit.fast.96 ], [ %r512163, %arrlit.slow.97 ]
  store i64 310311387649, ptr %r513, align 8
  %r514 = getelementptr i8, ptr %r513, i64 8
  store i64 30064771079, ptr %r514, align 8
  %r515 = getelementptr i8, ptr %r513, i64 8
  %r516 = ptrtoint ptr %r515 to i64
  %r517 = getelementptr inbounds nuw i8, ptr %r513, i64 16
  %r1046 = load double, ptr @test_json_index_remainder_ts_.str.3.handle, align 8
  store double %r1046, ptr %r517, align 8
  %r1045 = load double, ptr @test_json_index_remainder_ts_.str.3.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1045) #8
  %r1044 = load double, ptr @test_json_index_remainder_ts_.str.3.handle, align 8
  %r518 = bitcast double %r1044 to i64
  %r1042 = load double, ptr @test_json_index_remainder_ts_.str.3.handle, align 8
  %r1043 = bitcast double %r1042 to i64
  call void @js_gc_note_slot_layout(i64 %r516, i32 0, i64 %r1043) #8
  %r519 = getelementptr inbounds nuw i8, ptr %r513, i64 24
  store double 0x7FFC000000000004, ptr %r519, align 8
  %r520 = getelementptr inbounds nuw i8, ptr %r513, i64 32
  store double 0x7FFC000000000003, ptr %r520, align 8
  %r521 = getelementptr inbounds nuw i8, ptr %r513, i64 40
  store double 0x7FFC000000000002, ptr %r521, align 8
  %r522 = getelementptr inbounds nuw i8, ptr %r513, i64 48
  store double 0x7FFC000000000001, ptr %r522, align 8
  %r523 = getelementptr inbounds nuw i8, ptr %r513, i64 56
  %r1040.rs4i = ptrtoint ptr addrspace(1) %.1436 to i64
  %r1040 = call i64 asm "", "=r,0"(i64 %r1040.rs4i) #8
  %r1041 = bitcast i64 %r1040 to double
  store double %r1041, ptr %r523, align 8
  %r1038.rs4i = ptrtoint ptr addrspace(1) %.1436 to i64
  %r1038 = call i64 asm "", "=r,0"(i64 %r1038.rs4i) #8
  %r1039 = bitcast i64 %r1038 to double
  call void @js_string_addref_if_heap_string(double %r1039) #8
  %r1036.rs4i = ptrtoint ptr addrspace(1) %.1436 to i64
  %r1036 = call i64 asm "", "=r,0"(i64 %r1036.rs4i) #8
  %r1037 = bitcast i64 %r1036 to double
  %r524 = bitcast double %r1037 to i64
  %r1033.rs4i = ptrtoint ptr addrspace(1) %.1436 to i64
  %r1033 = call i64 asm "", "=r,0"(i64 %r1033.rs4i) #8
  %r1034 = bitcast i64 %r1033 to double
  %r1035 = bitcast double %r1034 to i64
  call void @js_gc_note_slot_layout(i64 %r516, i32 5, i64 %r1035) #8
  %r525 = getelementptr inbounds nuw i8, ptr %r513, i64 64
  store double %r481157, ptr %r525, align 8
  call void @js_string_addref_if_heap_string(double %r481157) #8
  %r526 = bitcast double %r481157 to i64
  call void @js_gc_note_slot_layout(i64 %r516, i32 6, i64 %r526) #8
  %r527 = or i64 %r516, 9222527611924643840
  %r528 = bitcast i64 %r527 to double
  %rs4gc.b11 = bitcast double %r528 to i64
  %rs4gc.s11 = inttoptr i64 %rs4gc.b11 to ptr addrspace(1)
  %r529.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r529 = call i64 asm "", "=r,0"(i64 %r529.rs4i) #8
  %r530 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r531 = icmp ne i32 %r530, 0
  br i1 %r531, label %shadow.root.barrier.99, label %shadow.root.barrier.done.100

shadow.root.barrier.99:                           ; preds = %arrlit.merge.98
  call void @js_write_barrier_root_nanbox(i64 %r529) #8
  br label %shadow.root.barrier.done.100

shadow.root.barrier.done.100:                     ; preds = %shadow.root.barrier.99, %arrlit.merge.98
  br label %for.cond.101

for.cond.101:                                     ; preds = %for.update.103, %shadow.root.barrier.done.100
  %.0437 = phi ptr addrspace(1) [ %rs4gc.s11, %shadow.root.barrier.done.100 ], [ %.14, %for.update.103 ]
  %r532.0 = phi i32 [ 0, %shadow.root.barrier.done.100 ], [ %r994, %for.update.103 ]
  %r534 = sitofp i32 %r532.0 to double
  %r535.rs4i = ptrtoint ptr addrspace(1) %.0437 to i64
  %r535.rs4o = call i64 asm "", "=r,0"(i64 %r535.rs4i) #8
  %r535 = bitcast i64 %r535.rs4o to double
  %r536 = bitcast double %r535 to i64
  %r537 = and i64 %r536, 281474976710655
  %r538 = lshr i64 %r536, 48
  %r539 = and i64 %r538, 65533
  %r540 = icmp eq i64 %r539, 32765
  %r541 = icmp ugt i64 %r537, 1048575
  %r542 = and i1 %r540, %r541
  br i1 %r542, label %plen.check_gc.105, label %plen.slow.107

for.body.102:                                     ; preds = %gcpoll.done.127
  %statepoint_token165 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_eh_try_push, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3440) ]
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 0, i32 0) ; (%.3440, %.3440)
  br label %try.body.128

for.update.103:                                   ; preds = %gcpoll.done.205
  %r994 = add i32 %r532.0, 1
  %r995 = sitofp i32 %r532.0 to double
  %r996 = sitofp i32 %r994 to double
  br label %for.cond.101

for.exit.104:                                     ; preds = %gcpoll.done.127
  %statepoint_token166 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token167 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token168 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token169 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token170 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.206

plen.check_gc.105:                                ; preds = %for.cond.101
  %r543 = sub nuw nsw i64 %r537, 8
  %r544 = inttoptr i64 %r543 to ptr
  %r545 = load i8, ptr %r544, align 1
  %r546 = icmp eq i8 %r545, 1
  %r547 = icmp eq i8 %r545, 3
  %r548 = or i1 %r546, %r547
  %r549 = sub nuw nsw i64 %r537, 7
  %r550 = inttoptr i64 %r549 to ptr
  %r551 = load i8, ptr %r550, align 1
  %r552 = and i8 %r551, -128
  %r553 = icmp eq i8 %r552, 0
  %r554 = and i1 %r548, %r553
  br i1 %r554, label %plen.fast.106, label %plen.slow.107

plen.fast.106:                                    ; preds = %plen.check_gc.105
  %r556 = inttoptr i64 %r537 to ptr
  %r557 = select i1 false, ptr @perry_null_guard_zero_test_json_index_remainder_ts, ptr %r556
  %r558 = load i32, ptr %r557, align 4
  %r559 = uitofp i32 %r558 to double
  br label %plen.merge.108

plen.slow.107:                                    ; preds = %plen.check_gc.105, %for.cond.101
  %r560 = lshr i64 %r536, 48
  %r561 = icmp eq i64 %r560, 32765
  %r562 = icmp uge i64 %r537, 2199023255552
  %r563 = icmp ult i64 %r537, 140737488355328
  %r564 = and i1 %r561, %r562
  %r565 = and i1 %r564, %r563
  %r566 = load ptr, ptr @perry_ic_test_json_index_remainder_ts__4, align 8
  br i1 %r565, label %plen.ic.header.109, label %plen.ic.miss.121

plen.merge.108:                                   ; preds = %plen.ic.merge.122, %plen.fast.106
  %.1438 = phi ptr addrspace(1) [ %.0437, %plen.fast.106 ], [ %.2439, %plen.ic.merge.122 ]
  %r641 = phi double [ %r559, %plen.fast.106 ], [ %r640, %plen.ic.merge.122 ]
  %r642 = fcmp olt double %r534, %r641
  %r643 = select i1 %r642, i64 9222246136947933188, i64 9222246136947933187
  %r644 = bitcast i64 %r643 to double
  %r646 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r647 = icmp ne i32 %r646, 0
  br i1 %r647, label %gcpoll.126, label %gcpoll.done.127

plen.ic.header.109:                               ; preds = %plen.slow.107
  %r568 = sub nuw nsw i64 %r537, 8
  %r569 = inttoptr i64 %r568 to ptr
  %r570 = load i8, ptr %r569, align 1
  %r571 = icmp eq i8 %r570, 2
  %r572 = sub nuw nsw i64 %r537, 7
  %r573 = inttoptr i64 %r572 to ptr
  %r574 = load i8, ptr %r573, align 1
  %r575 = and i8 %r574, -128
  %r576 = icmp eq i8 %r575, 0
  %r577 = and i1 %r571, %r576
  br i1 %r577, label %plen.elem.meta.123, label %plen.ic.miss.121

plen.ic.shape.110:                                ; preds = %plen.elem.store.124, %plen.elem.meta.123
  %r567 = icmp ne ptr %r566, null
  br i1 %r567, label %plen.ic.shape.probe.111, label %plen.ic.miss.121

plen.ic.shape.probe.111:                          ; preds = %plen.ic.shape.110
  %r589 = inttoptr i64 %r537 to ptr
  %r590 = load i32, ptr %r589, align 4
  %r591 = add nuw nsw i64 %r537, 4
  %r592 = inttoptr i64 %r591 to ptr
  %r593 = load i32, ptr %r592, align 4
  %r594 = zext i32 %r590 to i64
  %r595 = zext i32 %r593 to i64
  %r596 = shl nuw i64 %r594, 32
  %r597 = or i64 %r596, %r595
  %r598 = getelementptr i64, ptr %r566, i64 0
  %r599 = load i64, ptr %r598, align 8
  %r600 = icmp ne i64 %r599, 0
  br i1 %r600, label %plen.ic.identity.112, label %plen.ic.miss.121

plen.ic.identity.112:                             ; preds = %plen.ic.shape.probe.111
  %r601 = and i64 %r599, -9223372036854775808
  %2 = icmp slt i64 %r599, 0
  br i1 %2, label %plen.ic.family_meta.114, label %plen.ic.exact.113

plen.ic.exact.113:                                ; preds = %plen.ic.identity.112
  %r603 = icmp eq i64 %r597, %r599
  br i1 %r603, label %plen.ic.slot.116, label %plen.ic.miss.121

plen.ic.family_meta.114:                          ; preds = %plen.ic.identity.112
  %r604 = add nuw nsw i64 %r537, 8
  %r605 = inttoptr i64 %r604 to ptr
  %r606 = load i64, ptr %r605, align 8
  %r607 = icmp ne i64 %r606, 0
  br i1 %r607, label %plen.ic.family_token.115, label %plen.ic.miss.121

plen.ic.family_token.115:                         ; preds = %plen.ic.family_meta.114
  %r608 = inttoptr i64 %r606 to ptr
  %r609 = getelementptr i64, ptr %r608, i64 6
  %r610 = load i64, ptr %r609, align 8
  %r611 = icmp eq i64 %r610, %r599
  br i1 %r611, label %plen.ic.slot.116, label %plen.ic.miss.121

plen.ic.slot.116:                                 ; preds = %plen.ic.family_token.115, %plen.ic.exact.113
  %r612 = getelementptr i64, ptr %r566, i64 1
  %r613 = load i64, ptr %r612, align 8
  %r614 = getelementptr i64, ptr %r566, i64 2
  %r615 = load i64, ptr %r614, align 8
  %r616 = icmp ult i64 %r613, %r615
  br i1 %r616, label %plen.ic.inline.117, label %plen.ic.spill_meta.118

plen.ic.inline.117:                               ; preds = %plen.ic.slot.116
  %r617 = shl i64 %r613, 3
  %r618 = add i64 %r617, 16
  %r619 = add i64 %r537, %r618
  %r620 = inttoptr i64 %r619 to ptr
  %r621 = load double, ptr %r620, align 8
  br label %plen.ic.merge.122

plen.ic.spill_meta.118:                           ; preds = %plen.ic.slot.116
  %r622 = add nuw nsw i64 %r537, 8
  %r623 = inttoptr i64 %r622 to ptr
  %r624 = load i64, ptr %r623, align 8
  %r625 = icmp ne i64 %r624, 0
  br i1 %r625, label %plen.ic.spill_ptr.119, label %plen.ic.miss.121

plen.ic.spill_ptr.119:                            ; preds = %plen.ic.spill_meta.118
  %r626 = inttoptr i64 %r624 to ptr
  %r627 = getelementptr i64, ptr %r626, i64 4
  %r628 = load i64, ptr %r627, align 8
  %r629 = icmp ne i64 %r628, 0
  %r630 = select i1 %r629, i64 %r628, i64 %r624
  %r631 = inttoptr i64 %r630 to ptr
  %r632 = load i32, ptr %r631, align 4
  %r633 = zext i32 %r632 to i64
  %r634 = icmp ult i64 %r613, %r633
  %r635 = and i1 %r629, %r634
  br i1 %r635, label %plen.ic.spill_load.120, label %plen.ic.miss.121

plen.ic.spill_load.120:                           ; preds = %plen.ic.spill_ptr.119
  %r636 = add nuw nsw i64 %r613, 1
  %r637 = getelementptr inbounds nuw i64, ptr %r631, i64 %r636
  %r638 = load double, ptr %r637, align 8
  br label %plen.ic.merge.122

plen.ic.miss.121:                                 ; preds = %plen.ic.spill_ptr.119, %plen.ic.spill_meta.118, %plen.ic.family_token.115, %plen.ic.family_meta.114, %plen.ic.exact.113, %plen.ic.shape.probe.111, %plen.ic.shape.110, %plen.ic.header.109, %plen.slow.107
  %statepoint_token171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r535, ptr @perry_ic_test_json_index_remainder_ts__4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0437) ]
  %r639172 = call double @llvm.experimental.gc.result.f64(token %statepoint_token171)
  %rs4gc.s11.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 0, i32 0) ; (%.0437, %.0437)
  br label %plen.ic.merge.122

plen.ic.merge.122:                                ; preds = %plen.elem.length.125, %plen.ic.miss.121, %plen.ic.spill_load.120, %plen.ic.inline.117
  %.2439 = phi ptr addrspace(1) [ %.0437, %plen.elem.length.125 ], [ %.0437, %plen.ic.inline.117 ], [ %.0437, %plen.ic.spill_load.120 ], [ %rs4gc.s11.relocated173, %plen.ic.miss.121 ]
  %r640 = phi double [ %r588, %plen.elem.length.125 ], [ %r621, %plen.ic.inline.117 ], [ %r638, %plen.ic.spill_load.120 ], [ %r639172, %plen.ic.miss.121 ]
  br label %plen.merge.108

plen.elem.meta.123:                               ; preds = %plen.ic.header.109
  %r578 = add nuw nsw i64 %r537, 8
  %r579 = inttoptr i64 %r578 to ptr
  %r580 = load i64, ptr %r579, align 8
  %r581 = icmp ne i64 %r580, 0
  br i1 %r581, label %plen.elem.store.124, label %plen.ic.shape.110

plen.elem.store.124:                              ; preds = %plen.elem.meta.123
  %r582 = inttoptr i64 %r580 to ptr
  %r583 = getelementptr i64, ptr %r582, i64 12
  %r584 = load i64, ptr %r583, align 8
  %r585 = icmp ne i64 %r584, 0
  br i1 %r585, label %plen.elem.length.125, label %plen.ic.shape.110

plen.elem.length.125:                             ; preds = %plen.elem.store.124
  %r586 = inttoptr i64 %r584 to ptr
  %r587 = load i32, ptr %r586, align 4
  %r588 = uitofp i32 %r587 to double
  br label %plen.ic.merge.122

gcpoll.126:                                       ; preds = %plen.merge.108
  %statepoint_token174 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1438) ]
  %rs4gc.s11.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 0, i32 0) ; (%.1438, %.1438)
  br label %gcpoll.done.127

gcpoll.done.127:                                  ; preds = %gcpoll.126, %plen.merge.108
  %.3440 = phi ptr addrspace(1) [ %rs4gc.s11.relocated175, %gcpoll.126 ], [ %.1438, %plen.merge.108 ]
  %r645 = icmp eq i64 %r643, 9222246136947933188
  br i1 %r645, label %for.body.102, label %for.exit.104

try.body.128:                                     ; preds = %for.body.102
  %statepoint_token178 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated) ]
          to label %eh.cont650 unwind label %eh.lpad.1311

eh.cont650:                                       ; preds = %try.body.128
  %r649179 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token178)
  %rs4gc.s11.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 0, i32 0) ; (%rs4gc.s11.relocated, %rs4gc.s11.relocated)
  %rs4gc.s12 = inttoptr i64 %r649179 to ptr addrspace(1)
  %r651.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r651 = call i64 asm "", "=r,0"(i64 %r651.rs4i) #8
  %r652 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r653 = icmp ne i32 %r652, 0
  br i1 %r653, label %shadow.root.barrier.132, label %shadow.root.barrier.done.133

try.catch.129:                                    ; preds = %eh.lpad.131
  %statepoint_token181 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4) ]
  %rs4gc.s11.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token181, i32 0, i32 0) ; (%.4, %.4)
  %statepoint_token183 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_get_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated182) ]
  %r760184 = call double @llvm.experimental.gc.result.f64(token %statepoint_token183)
  %rs4gc.s11.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 0, i32 0) ; (%rs4gc.s11.relocated182, %rs4gc.s11.relocated182)
  %statepoint_token186 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_clear_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated185) ]
  %rs4gc.s11.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 0, i32 0) ; (%rs4gc.s11.relocated185, %rs4gc.s11.relocated185)
  %rs4gc.b13 = bitcast double %r760184 to i64
  %rs4gc.s13 = inttoptr i64 %rs4gc.b13 to ptr addrspace(1)
  %r762.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r762 = call i64 asm "", "=r,0"(i64 %r762.rs4i) #8
  %r763 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r764 = icmp ne i32 %r763, 0
  br i1 %r764, label %shadow.root.barrier.147, label %shadow.root.barrier.done.148

try.finally.130:                                  ; preds = %shadow.root.barrier.done.164, %eh.cont759
  %.6 = phi ptr addrspace(1) [ %rs4gc.s11.relocated251, %eh.cont759 ], [ %rs4gc.s11.relocated270, %shadow.root.barrier.done.164 ]
  %statepoint_token188 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_eh_try_push, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6) ]
  %rs4gc.s11.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 0, i32 0) ; (%.6, %.6)
  br label %try.body.165

eh.lpad.1311:                                     ; preds = %try.body.128
  %lpad = landingpad token
          cleanup
  %rs4gc.s11.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad, i32 0, i32 0) ; (%rs4gc.s11.relocated, %rs4gc.s11.relocated)
  br label %eh.lpad.131

eh.lpad.131.split-lp2:                            ; preds = %shadow.root.barrier.132
  %lpad3 = landingpad token
          cleanup
  %rs4gc.s11.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 0, i32 0) ; (%rs4gc.s11.relocated180, %rs4gc.s11.relocated180)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  br label %eh.lpad.131.split-lp

eh.lpad.131.split-lp.split-lp5:                   ; preds = %shadow.root.barrier.done.133
  %lpad6 = landingpad token
          cleanup
  %rs4gc.s11.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad6, i32 0, i32 0) ; (%.5, %.5)
  br label %eh.lpad.131.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp7:          ; preds = %shadow.root.barrier.134
  %lpad8 = landingpad token
          cleanup
  %rs4gc.s11.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 0, i32 0) ; (%rs4gc.s11.relocated199, %rs4gc.s11.relocated199)
  %rs4gc.s14.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  br label %eh.lpad.131.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp10: ; preds = %shadow.root.barrier.done.135
  %lpad11 = landingpad token
          cleanup
  %rs4gc.s11.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad11, i32 0, i32 0) ; (%.7, %.7)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp12: ; preds = %shadow.root.barrier.136
  %lpad13 = landingpad token
          cleanup
  %rs4gc.s11.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad13, i32 0, i32 0) ; (%rs4gc.s11.relocated209, %rs4gc.s11.relocated209)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad13, i32 1, i32 1) ; (%rs4gc.s15, %rs4gc.s15)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15: ; preds = %arr.fallback.139
  %lpad16 = landingpad token
          cleanup
  %rs4gc.s11.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad16, i32 0, i32 0) ; (%.8, %.8)
  %rs4gc.s15.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad16, i32 1, i32 1) ; (%.0443, %.0443)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp17: ; preds = %arr.merge.141
  %lpad18 = landingpad token
          cleanup
  %rs4gc.s11.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad18, i32 0, i32 0) ; (%.9, %.9)
  %rs4gc.s15.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad18, i32 1, i32 1) ; (%.1444, %.1444)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp20: ; preds = %eh.cont748
  %lpad21 = landingpad token
          cleanup
  %rs4gc.s15.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad21, i32 0, i32 0) ; (%rs4gc.s15.relocated228, %rs4gc.s15.relocated228)
  %rs4gc.s11.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad21, i32 1, i32 1) ; (%rs4gc.s11.relocated227, %rs4gc.s11.relocated227)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp22: ; preds = %eh.cont750
  %lpad23 = landingpad token
          cleanup
  %rs4gc.s11.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad23, i32 0, i32 0) ; (%rs4gc.s11.relocated235, %rs4gc.s11.relocated235)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp25: ; preds = %shadow.root.barrier.145
  %lpad26 = landingpad token
          cleanup
  %rs4gc.s11.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad26, i32 0, i32 0) ; (%rs4gc.s11.relocated240, %rs4gc.s11.relocated240)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad26, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %shadow.root.barrier.done.146
  %lpad.split-lp = landingpad token
          cleanup
  %rs4gc.s11.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad.split-lp, i32 0, i32 0) ; (%.10, %.10)
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp25
  %.29 = phi ptr addrspace(1) [ %rs4gc.s11.relocated247, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated242, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp25 ]
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp22
  %.28 = phi ptr addrspace(1) [ %.29, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated237, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp22 ]
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp20
  %.27 = phi ptr addrspace(1) [ %.28, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated231, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp20 ]
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp17
  %.26 = phi ptr addrspace(1) [ %.27, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated223, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp17 ]
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15
  %.25 = phi ptr addrspace(1) [ %.26, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated216, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15 ]
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp12
  %.24 = phi ptr addrspace(1) [ %.25, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated211, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp12 ]
  br label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp.split-lp:  ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp10
  %.23 = phi ptr addrspace(1) [ %.24, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated206, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp10 ]
  br label %eh.lpad.131.split-lp.split-lp.split-lp

eh.lpad.131.split-lp.split-lp.split-lp:           ; preds = %eh.lpad.131.split-lp.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp.split-lp7
  %.22 = phi ptr addrspace(1) [ %.23, %eh.lpad.131.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated201, %eh.lpad.131.split-lp.split-lp.split-lp7 ]
  br label %eh.lpad.131.split-lp.split-lp

eh.lpad.131.split-lp.split-lp:                    ; preds = %eh.lpad.131.split-lp.split-lp.split-lp, %eh.lpad.131.split-lp.split-lp5
  %.21 = phi ptr addrspace(1) [ %.22, %eh.lpad.131.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated196, %eh.lpad.131.split-lp.split-lp5 ]
  br label %eh.lpad.131.split-lp

eh.lpad.131.split-lp:                             ; preds = %eh.lpad.131.split-lp.split-lp, %eh.lpad.131.split-lp2
  %.20 = phi ptr addrspace(1) [ %.21, %eh.lpad.131.split-lp.split-lp ], [ %rs4gc.s11.relocated191, %eh.lpad.131.split-lp2 ]
  br label %eh.lpad.131

eh.lpad.131:                                      ; preds = %eh.lpad.131.split-lp, %eh.lpad.1311
  %.4 = phi ptr addrspace(1) [ %.20, %eh.lpad.131.split-lp ], [ %rs4gc.s11.relocated177, %eh.lpad.1311 ]
  br label %try.catch.129

shadow.root.barrier.132:                          ; preds = %eh.cont650
  %statepoint_token192 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r651, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated180, ptr addrspace(1) %rs4gc.s12) ]
          to label %eh.cont654 unwind label %eh.lpad.131.split-lp2

eh.cont654:                                       ; preds = %shadow.root.barrier.132
  %rs4gc.s11.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 0, i32 0) ; (%rs4gc.s11.relocated180, %rs4gc.s11.relocated180)
  %rs4gc.s12.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  br label %shadow.root.barrier.done.133

shadow.root.barrier.done.133:                     ; preds = %eh.cont654, %eh.cont650
  %.0441 = phi ptr addrspace(1) [ %rs4gc.s12.relocated194, %eh.cont654 ], [ %rs4gc.s12, %eh.cont650 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s11.relocated193, %eh.cont654 ], [ %rs4gc.s11.relocated180, %eh.cont650 ]
  %r655 = load double, ptr @test_json_index_remainder_ts_.str.4.handle, align 8
  %r656.rs4i = ptrtoint ptr addrspace(1) %.0441 to i64
  %r656 = call i64 asm "", "=r,0"(i64 %r656.rs4i) #8
  %statepoint_token197 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r656, double %r655, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5) ]
          to label %eh.cont658 unwind label %eh.lpad.131.split-lp.split-lp5

eh.cont658:                                       ; preds = %shadow.root.barrier.done.133
  %r657198 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token197)
  %rs4gc.s11.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 0, i32 0) ; (%.5, %.5)
  %rs4gc.s14 = inttoptr i64 %r657198 to ptr addrspace(1)
  %r659.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r659 = call i64 asm "", "=r,0"(i64 %r659.rs4i) #8
  %r660 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r661 = icmp ne i32 %r660, 0
  br i1 %r661, label %shadow.root.barrier.134, label %shadow.root.barrier.done.135

shadow.root.barrier.134:                          ; preds = %eh.cont658
  %statepoint_token202 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r659, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated199, ptr addrspace(1) %rs4gc.s14) ]
          to label %eh.cont662 unwind label %eh.lpad.131.split-lp.split-lp.split-lp7

eh.cont662:                                       ; preds = %shadow.root.barrier.134
  %rs4gc.s11.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 0, i32 0) ; (%rs4gc.s11.relocated199, %rs4gc.s11.relocated199)
  %rs4gc.s14.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  br label %shadow.root.barrier.done.135

shadow.root.barrier.done.135:                     ; preds = %eh.cont662, %eh.cont658
  %.0442 = phi ptr addrspace(1) [ %rs4gc.s14.relocated204, %eh.cont662 ], [ %rs4gc.s14, %eh.cont658 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s11.relocated203, %eh.cont662 ], [ %rs4gc.s11.relocated199, %eh.cont658 ]
  %r664 = sitofp i32 %r532.0 to double
  %r665.rs4i = ptrtoint ptr addrspace(1) %.0442 to i64
  %r665 = call i64 asm "", "=r,0"(i64 %r665.rs4i) #8
  %statepoint_token207 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r665, double %r664, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7) ]
          to label %eh.cont667 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp10

eh.cont667:                                       ; preds = %shadow.root.barrier.done.135
  %r666208 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token207)
  %rs4gc.s11.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 0, i32 0) ; (%.7, %.7)
  %rs4gc.s15 = inttoptr i64 %r666208 to ptr addrspace(1)
  %r668.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r668 = call i64 asm "", "=r,0"(i64 %r668.rs4i) #8
  %r669 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r670 = icmp ne i32 %r669, 0
  br i1 %r670, label %shadow.root.barrier.136, label %shadow.root.barrier.done.137

shadow.root.barrier.136:                          ; preds = %eh.cont667
  %statepoint_token212 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r668, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated209, ptr addrspace(1) %rs4gc.s15) ]
          to label %eh.cont671 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp12

eh.cont671:                                       ; preds = %shadow.root.barrier.136
  %rs4gc.s11.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 0, i32 0) ; (%rs4gc.s11.relocated209, %rs4gc.s11.relocated209)
  %rs4gc.s15.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 1, i32 1) ; (%rs4gc.s15, %rs4gc.s15)
  br label %shadow.root.barrier.done.137

shadow.root.barrier.done.137:                     ; preds = %eh.cont671, %eh.cont667
  %.0443 = phi ptr addrspace(1) [ %rs4gc.s15.relocated214, %eh.cont671 ], [ %rs4gc.s15, %eh.cont667 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s11.relocated213, %eh.cont671 ], [ %rs4gc.s11.relocated209, %eh.cont667 ]
  %r672.rs4i = ptrtoint ptr addrspace(1) %.8 to i64
  %r672.rs4o = call i64 asm "", "=r,0"(i64 %r672.rs4i) #8
  %r672 = bitcast i64 %r672.rs4o to double
  %r674 = bitcast double %r672 to i64
  %r675 = and i64 %r674, 281474976710655
  %r676 = lshr i64 %r674, 48
  %r677 = icmp eq i64 %r676, 32765
  %r678 = icmp ugt i64 %r675, 1048575
  %r679 = and i1 %r677, %r678
  br i1 %r679, label %arr.guard.deref.142, label %arr.fallback.139

arr.fast.138:                                     ; preds = %arr.guard.range.144
  %r736 = zext i32 %r532.0 to i64
  %r737 = shl nuw nsw i64 %r736, 3
  %r738 = add nuw nsw i64 %r737, 8
  %r739 = add i64 %r694, %r738
  %r740 = inttoptr i64 %r739 to ptr
  %r741 = load double, ptr %r740, align 8
  %r742 = bitcast double %r741 to i64
  %r743 = icmp eq i64 %r742, 9222246136947933200
  %r745 = select i1 %r743, double 0x7FFC000000000001, double %r741
  br label %arr.merge.141

arr.fallback.139:                                 ; preds = %arr.guard.live.143, %arr.guard.deref.142, %shadow.root.barrier.done.137
  %r733 = sitofp i32 %r532.0 to double
  %statepoint_token218 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5190247735588028421, double %r672, double %r733, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8, ptr addrspace(1) %.0443) ]
          to label %eh.cont735 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15

eh.cont735:                                       ; preds = %arr.fallback.139
  %r734219 = call double @llvm.experimental.gc.result.f64(token %statepoint_token218)
  %rs4gc.s11.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 0, i32 0) ; (%.8, %.8)
  %rs4gc.s15.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 1, i32 1) ; (%.0443, %.0443)
  br label %arr.merge.141

arr.guard.oob.140:                                ; preds = %arr.guard.range.144
  br label %arr.merge.141

arr.merge.141:                                    ; preds = %arr.guard.oob.140, %eh.cont735, %arr.fast.138
  %.1444 = phi ptr addrspace(1) [ %.0443, %arr.fast.138 ], [ %.0443, %arr.guard.oob.140 ], [ %rs4gc.s15.relocated221, %eh.cont735 ]
  %.9 = phi ptr addrspace(1) [ %.8, %arr.fast.138 ], [ %.8, %arr.guard.oob.140 ], [ %rs4gc.s11.relocated220, %eh.cont735 ]
  %r746 = phi double [ %r745, %arr.fast.138 ], [ %r734219, %eh.cont735 ], [ 0x7FFC000000000001, %arr.guard.oob.140 ]
  %statepoint_token225 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i32)) @"perry_fn_test_json_index_remainder_ts__remainder$spec_b_i32", i32 2, i32 0, double %r746, i32 7, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9, ptr addrspace(1) %.1444) ]
          to label %eh.cont748 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp17

eh.cont748:                                       ; preds = %arr.merge.141
  %r747226 = call double @llvm.experimental.gc.result.f64(token %statepoint_token225)
  %rs4gc.s11.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 0, i32 0) ; (%.9, %.9)
  %rs4gc.s15.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 1, i32 1) ; (%.1444, %.1444)
  %statepoint_token232 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_index_remainder_ts__describe, i32 1, i32 0, double %r747226, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s15.relocated228, ptr addrspace(1) %rs4gc.s11.relocated227) ]
          to label %eh.cont750 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp20

eh.cont750:                                       ; preds = %eh.cont748
  %r749233 = call double @llvm.experimental.gc.result.f64(token %statepoint_token232)
  %rs4gc.s15.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 0, i32 0) ; (%rs4gc.s15.relocated228, %rs4gc.s15.relocated228)
  %rs4gc.s11.relocated235 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 1, i32 1) ; (%rs4gc.s11.relocated227, %rs4gc.s11.relocated227)
  %r751.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated234 to i64
  %r751 = call i64 asm "", "=r,0"(i64 %r751.rs4i) #8
  %statepoint_token238 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r751, double %r749233, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated235) ]
          to label %eh.cont753 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp22

eh.cont753:                                       ; preds = %eh.cont750
  %r752239 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token238)
  %rs4gc.s11.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 0, i32 0) ; (%rs4gc.s11.relocated235, %rs4gc.s11.relocated235)
  %rs4gc.s16 = inttoptr i64 %r752239 to ptr addrspace(1)
  %r754.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r754 = call i64 asm "", "=r,0"(i64 %r754.rs4i) #8
  %r755 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r756 = icmp ne i32 %r755, 0
  br i1 %r756, label %shadow.root.barrier.145, label %shadow.root.barrier.done.146

arr.guard.deref.142:                              ; preds = %shadow.root.barrier.done.137
  %r680 = bitcast double %r672 to i64
  %r681 = and i64 %r680, 281474976710655
  %r682 = sub nsw i64 %r681, 8
  %r683 = inttoptr i64 %r682 to ptr
  %r684 = load i8, ptr %r683, align 1
  %r685 = icmp eq i8 %r684, 1
  %r686 = sub nsw i64 %r681, 7
  %r687 = inttoptr i64 %r686 to ptr
  %r688 = load i8, ptr %r687, align 1
  %r689 = and i8 %r688, -128
  %r690 = icmp ne i8 %r689, 0
  %r691 = inttoptr i64 %r681 to ptr
  %r692 = load i64, ptr %r691, align 8
  %r693 = and i1 %r685, %r690
  %r694 = select i1 %r693, i64 %r692, i64 %r681
  %r695 = lshr i64 %r694, 48
  %r696 = icmp eq i64 %r695, 0
  %r697 = icmp ugt i64 %r694, 1048575
  %r698 = and i1 %r696, %r697
  br i1 %r698, label %arr.guard.live.143, label %arr.fallback.139

arr.guard.live.143:                               ; preds = %arr.guard.deref.142
  %r699 = sub nuw i64 %r694, 8
  %r700 = inttoptr i64 %r699 to ptr
  %r701 = load i8, ptr %r700, align 1
  %r702 = icmp eq i8 %r701, 1
  %r703 = sub nuw i64 %r694, 7
  %r704 = inttoptr i64 %r703 to ptr
  %r705 = load i8, ptr %r704, align 1
  %r706 = and i8 %r705, -128
  %r707 = icmp eq i8 %r706, 0
  %r708 = sub nuw i64 %r694, 6
  %r709 = inttoptr i64 %r708 to ptr
  %r710 = load i16, ptr %r709, align 2
  %r711 = and i16 %r710, 1024
  %r712 = icmp eq i16 %r711, 0
  %r713 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r714 = icmp eq i8 %r713, 0
  %r715 = inttoptr i64 %r694 to ptr
  %r716 = load i32, ptr %r715, align 4
  %r717 = getelementptr i8, ptr %r715, i64 4
  %r718 = load i32, ptr %r717, align 4
  %r719 = icmp slt i32 %r532.0, 0
  %r720 = icmp eq i1 %r719, false
  %r722 = icmp ule i32 %r716, 16000000
  %r723 = icmp ule i32 %r718, 16000000
  %r724 = icmp ule i32 %r716, %r718
  %r725 = and i1 %r702, %r707
  %r726 = and i1 %r725, %r712
  %r727 = and i1 %r726, %r714
  %r728 = and i1 %r727, %r720
  %r729 = and i1 %r728, %r722
  %r730 = and i1 %r729, %r723
  %r731 = and i1 %r730, %r724
  br i1 %r731, label %arr.guard.range.144, label %arr.fallback.139

arr.guard.range.144:                              ; preds = %arr.guard.live.143
  %r721 = icmp ult i32 %r532.0, %r716
  br i1 %r721, label %arr.fast.138, label %arr.guard.oob.140

shadow.root.barrier.145:                          ; preds = %eh.cont753
  %statepoint_token243 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r754, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated240, ptr addrspace(1) %rs4gc.s16) ]
          to label %eh.cont757 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp25

eh.cont757:                                       ; preds = %shadow.root.barrier.145
  %rs4gc.s11.relocated244 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 0, i32 0) ; (%rs4gc.s11.relocated240, %rs4gc.s11.relocated240)
  %rs4gc.s16.relocated245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  br label %shadow.root.barrier.done.146

shadow.root.barrier.done.146:                     ; preds = %eh.cont757, %eh.cont753
  %.0445 = phi ptr addrspace(1) [ %rs4gc.s16.relocated245, %eh.cont757 ], [ %rs4gc.s16, %eh.cont753 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s11.relocated244, %eh.cont757 ], [ %rs4gc.s11.relocated240, %eh.cont753 ]
  %r758.rs4i = ptrtoint ptr addrspace(1) %.0445 to i64
  %r758 = call i64 asm "", "=r,0"(i64 %r758.rs4i) #8
  %statepoint_token248 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r758, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
          to label %eh.cont759 unwind label %eh.lpad.131.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.cont759:                                       ; preds = %shadow.root.barrier.done.146
  %rs4gc.s11.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token248, i32 0, i32 0) ; (%.10, %.10)
  %statepoint_token250 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated249) ]
  %rs4gc.s11.relocated251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 0, i32 0) ; (%rs4gc.s11.relocated249, %rs4gc.s11.relocated249)
  br label %try.finally.130

shadow.root.barrier.147:                          ; preds = %try.catch.129
  call void @js_write_barrier_root_nanbox(i64 %r762) #8
  br label %shadow.root.barrier.done.148

shadow.root.barrier.done.148:                     ; preds = %shadow.root.barrier.147, %try.catch.129
  %statepoint_token252 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated187, ptr addrspace(1) %rs4gc.s13) ]
  %r765253 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token252)
  %rs4gc.s11.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 0, i32 0) ; (%rs4gc.s11.relocated187, %rs4gc.s11.relocated187)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 1, i32 1) ; (%rs4gc.s13, %rs4gc.s13)
  %rs4gc.s17 = inttoptr i64 %r765253 to ptr addrspace(1)
  %r766.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r766 = call i64 asm "", "=r,0"(i64 %r766.rs4i) #8
  %r767 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r768 = icmp ne i32 %r767, 0
  br i1 %r768, label %shadow.root.barrier.149, label %shadow.root.barrier.done.150

shadow.root.barrier.149:                          ; preds = %shadow.root.barrier.done.148
  call void @js_write_barrier_root_nanbox(i64 %r766) #8
  br label %shadow.root.barrier.done.150

shadow.root.barrier.done.150:                     ; preds = %shadow.root.barrier.149, %shadow.root.barrier.done.148
  %r769 = load double, ptr @test_json_index_remainder_ts_.str.4.handle, align 8
  %r770.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r770 = call i64 asm "", "=r,0"(i64 %r770.rs4i) #8
  %statepoint_token255 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r770, double %r769, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated254, ptr addrspace(1) %rs4gc.s13.relocated) ]
  %r771256 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token255)
  %rs4gc.s11.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token255, i32 0, i32 0) ; (%rs4gc.s11.relocated254, %rs4gc.s11.relocated254)
  %rs4gc.s13.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token255, i32 1, i32 1) ; (%rs4gc.s13.relocated, %rs4gc.s13.relocated)
  %rs4gc.s18 = inttoptr i64 %r771256 to ptr addrspace(1)
  %r772.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r772 = call i64 asm "", "=r,0"(i64 %r772.rs4i) #8
  %r773 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r774 = icmp ne i32 %r773, 0
  br i1 %r774, label %shadow.root.barrier.151, label %shadow.root.barrier.done.152

shadow.root.barrier.151:                          ; preds = %shadow.root.barrier.done.150
  call void @js_write_barrier_root_nanbox(i64 %r772) #8
  br label %shadow.root.barrier.done.152

shadow.root.barrier.done.152:                     ; preds = %shadow.root.barrier.151, %shadow.root.barrier.done.150
  %r776 = sitofp i32 %r532.0 to double
  %r777.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r777 = call i64 asm "", "=r,0"(i64 %r777.rs4i) #8
  %statepoint_token259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r777, double %r776, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated257, ptr addrspace(1) %rs4gc.s13.relocated258) ]
  %r778260 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token259)
  %rs4gc.s11.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 0, i32 0) ; (%rs4gc.s11.relocated257, %rs4gc.s11.relocated257)
  %rs4gc.s13.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 1) ; (%rs4gc.s13.relocated258, %rs4gc.s13.relocated258)
  %rs4gc.s19 = inttoptr i64 %r778260 to ptr addrspace(1)
  %r779.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r779 = call i64 asm "", "=r,0"(i64 %r779.rs4i) #8
  %r780 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r781 = icmp ne i32 %r780, 0
  br i1 %r781, label %shadow.root.barrier.153, label %shadow.root.barrier.done.154

shadow.root.barrier.153:                          ; preds = %shadow.root.barrier.done.152
  call void @js_write_barrier_root_nanbox(i64 %r779) #8
  br label %shadow.root.barrier.done.154

shadow.root.barrier.done.154:                     ; preds = %shadow.root.barrier.153, %shadow.root.barrier.done.152
  %r782.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated262 to i64
  %r782.rs4o = call i64 asm "", "=r,0"(i64 %r782.rs4i) #8
  %r782 = bitcast i64 %r782.rs4o to double
  %statepoint_token263 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i32)) @js_instanceof, i32 2, i32 0, double %r782, i32 -65520, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated261, ptr addrspace(1) %rs4gc.s19) ]
  %r783264 = call double @llvm.experimental.gc.result.f64(token %statepoint_token263)
  %rs4gc.s11.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 0, i32 0) ; (%rs4gc.s11.relocated261, %rs4gc.s11.relocated261)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 1, i32 1) ; (%rs4gc.s19, %rs4gc.s19)
  %r784 = bitcast double %r783264 to i64
  %r785 = and i64 %r784, 9221120237041090560
  %r786 = icmp ne i64 %r785, 9221120237041090560
  br i1 %r786, label %truthy.num.155, label %truthy.tag.156

truthy.num.155:                                   ; preds = %shadow.root.barrier.done.154
  %r787 = fcmp one double %r783264, 0.000000e+00
  br label %truthy.merge.158

truthy.tag.156:                                   ; preds = %shadow.root.barrier.done.154
  %r788 = icmp eq i64 %r784, 9222246136947933188
  %r789 = icmp eq i64 %r784, 9222246136947933187
  %r790 = icmp eq i64 %r784, 9222246136947933185
  %r791 = icmp eq i64 %r784, 9222246136947933186
  %r792 = or i1 %r789, %r790
  %r793 = or i1 %r792, %r791
  %r794 = or i1 %r788, %r793
  br i1 %r794, label %truthy.merge.158, label %truthy.obj.159

truthy.slow.157:                                  ; preds = %truthy.obj.159
  %r800 = call i32 @js_is_truthy(double %r783264) #8
  %r801 = icmp ne i32 %r800, 0
  br label %truthy.merge.158

truthy.merge.158:                                 ; preds = %truthy.obj.159, %truthy.slow.157, %truthy.tag.156, %truthy.num.155
  %r802 = phi i1 [ %r787, %truthy.num.155 ], [ %r788, %truthy.tag.156 ], [ true, %truthy.obj.159 ], [ %r801, %truthy.slow.157 ]
  br i1 %r802, label %ternary.then.160, label %ternary.else.161

truthy.obj.159:                                   ; preds = %truthy.tag.156
  %r795 = lshr i64 %r784, 48
  %r796 = icmp eq i64 %r795, 32765
  %r797 = and i64 %r784, 281474976710655
  %r798 = icmp ne i64 %r797, 0
  %r799 = and i1 %r796, %r798
  br i1 %r799, label %truthy.merge.158, label %truthy.slow.157

ternary.then.160:                                 ; preds = %truthy.merge.158
  %r803 = load double, ptr @test_json_index_remainder_ts_.str.5.handle, align 8
  br label %ternary.merge.162

ternary.else.161:                                 ; preds = %truthy.merge.158
  %r804 = load double, ptr @test_json_index_remainder_ts_.str.6.handle, align 8
  br label %ternary.merge.162

ternary.merge.162:                                ; preds = %ternary.else.161, %ternary.then.160
  %r805 = phi double [ %r803, %ternary.then.160 ], [ %r804, %ternary.else.161 ]
  %r806.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19.relocated to i64
  %r806 = call i64 asm "", "=r,0"(i64 %r806.rs4i) #8
  %statepoint_token266 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r806, double %r805, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated265) ]
  %r807267 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token266)
  %rs4gc.s11.relocated268 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 0, i32 0) ; (%rs4gc.s11.relocated265, %rs4gc.s11.relocated265)
  %rs4gc.s20 = inttoptr i64 %r807267 to ptr addrspace(1)
  %r808.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r808 = call i64 asm "", "=r,0"(i64 %r808.rs4i) #8
  %r809 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r810 = icmp ne i32 %r809, 0
  br i1 %r810, label %shadow.root.barrier.163, label %shadow.root.barrier.done.164

shadow.root.barrier.163:                          ; preds = %ternary.merge.162
  call void @js_write_barrier_root_nanbox(i64 %r808) #8
  br label %shadow.root.barrier.done.164

shadow.root.barrier.done.164:                     ; preds = %shadow.root.barrier.163, %ternary.merge.162
  %r811.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r811 = call i64 asm "", "=r,0"(i64 %r811.rs4i) #8
  %statepoint_token269 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r811, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated268) ]
  %rs4gc.s11.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token269, i32 0, i32 0) ; (%rs4gc.s11.relocated268, %rs4gc.s11.relocated268)
  br label %try.finally.130

try.body.165:                                     ; preds = %try.finally.130
  %statepoint_token273 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated189) ]
          to label %eh.cont814 unwind label %eh.lpad.16827

eh.cont814:                                       ; preds = %try.body.165
  %r813274 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token273)
  %rs4gc.s11.relocated275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 0, i32 0) ; (%rs4gc.s11.relocated189, %rs4gc.s11.relocated189)
  %rs4gc.s21 = inttoptr i64 %r813274 to ptr addrspace(1)
  %r815.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r815 = call i64 asm "", "=r,0"(i64 %r815.rs4i) #8
  %r816 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r817 = icmp ne i32 %r816, 0
  br i1 %r817, label %shadow.root.barrier.169, label %shadow.root.barrier.done.170

try.catch.166:                                    ; preds = %eh.lpad.168
  %statepoint_token276 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11) ]
  %rs4gc.s11.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 0, i32 0) ; (%.11, %.11)
  %statepoint_token278 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_get_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated277) ]
  %r939279 = call double @llvm.experimental.gc.result.f64(token %statepoint_token278)
  %rs4gc.s11.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token278, i32 0, i32 0) ; (%rs4gc.s11.relocated277, %rs4gc.s11.relocated277)
  %statepoint_token281 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_clear_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated280) ]
  %rs4gc.s11.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 0, i32 0) ; (%rs4gc.s11.relocated280, %rs4gc.s11.relocated280)
  %rs4gc.b22 = bitcast double %r939279 to i64
  %rs4gc.s22 = inttoptr i64 %rs4gc.b22 to ptr addrspace(1)
  %r941.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r941 = call i64 asm "", "=r,0"(i64 %r941.rs4i) #8
  %r942 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r943 = icmp ne i32 %r942, 0
  br i1 %r943, label %shadow.root.barrier.186, label %shadow.root.barrier.done.187

try.finally.167:                                  ; preds = %shadow.root.barrier.done.203, %eh.cont938
  %.13 = phi ptr addrspace(1) [ %rs4gc.s11.relocated360, %eh.cont938 ], [ %rs4gc.s11.relocated379, %shadow.root.barrier.done.203 ]
  %r991 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r992 = icmp ne i32 %r991, 0
  br i1 %r992, label %gcpoll.204, label %gcpoll.done.205

eh.lpad.16827:                                    ; preds = %try.body.165
  %lpad28 = landingpad token
          cleanup
  %rs4gc.s11.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad28, i32 0, i32 0) ; (%rs4gc.s11.relocated189, %rs4gc.s11.relocated189)
  br label %eh.lpad.168

eh.lpad.168.split-lp30:                           ; preds = %shadow.root.barrier.169
  %lpad31 = landingpad token
          cleanup
  %rs4gc.s11.relocated284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad31, i32 0, i32 0) ; (%rs4gc.s11.relocated275, %rs4gc.s11.relocated275)
  %rs4gc.s21.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad31, i32 1, i32 1) ; (%rs4gc.s21, %rs4gc.s21)
  br label %eh.lpad.168.split-lp

eh.lpad.168.split-lp.split-lp33:                  ; preds = %shadow.root.barrier.done.170
  %lpad34 = landingpad token
          cleanup
  %rs4gc.s11.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad34, i32 0, i32 0) ; (%.12, %.12)
  br label %eh.lpad.168.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp36:         ; preds = %shadow.root.barrier.171
  %lpad37 = landingpad token
          cleanup
  %rs4gc.s11.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad37, i32 0, i32 0) ; (%rs4gc.s11.relocated292, %rs4gc.s11.relocated292)
  %rs4gc.s23.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad37, i32 1, i32 1) ; (%rs4gc.s23, %rs4gc.s23)
  br label %eh.lpad.168.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp39: ; preds = %shadow.root.barrier.done.172
  %lpad40 = landingpad token
          cleanup
  %rs4gc.s11.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad40, i32 0, i32 0) ; (%.15, %.15)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp42: ; preds = %shadow.root.barrier.173
  %lpad43 = landingpad token
          cleanup
  %rs4gc.s24.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad43, i32 0, i32 0) ; (%rs4gc.s24, %rs4gc.s24)
  %rs4gc.s11.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad43, i32 1, i32 1) ; (%rs4gc.s11.relocated302, %rs4gc.s11.relocated302)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp45: ; preds = %arr.fallback.176
  %lpad46 = landingpad token
          cleanup
  %rs4gc.s24.relocated309 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad46, i32 0, i32 0) ; (%.0448, %.0448)
  %rs4gc.s11.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad46, i32 1, i32 1) ; (%.16, %.16)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp48: ; preds = %shadow.root.barrier.182
  %lpad49 = landingpad token
          cleanup
  %rs4gc.s24.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad49, i32 0, i32 0) ; (%.1449, %.1449)
  %rs4gc.s25.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad49, i32 1, i32 1) ; (%rs4gc.s25, %rs4gc.s25)
  %rs4gc.s11.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad49, i32 2, i32 2) ; (%.17, %.17)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp51: ; preds = %shadow.root.barrier.done.183
  %lpad52 = landingpad token
          cleanup
  %rs4gc.s25.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad52, i32 0, i32 0) ; (%.0432, %.0432)
  %rs4gc.s24.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad52, i32 1, i32 1) ; (%.2450, %.2450)
  %rs4gc.s11.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad52, i32 2, i32 2) ; (%.18, %.18)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp54: ; preds = %eh.cont921
  %lpad55 = landingpad token
          cleanup
  %rs4gc.s24.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad55, i32 0, i32 0) ; (%rs4gc.s24.relocated329, %rs4gc.s24.relocated329)
  %rs4gc.s11.relocated333 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad55, i32 1, i32 1) ; (%rs4gc.s11.relocated330, %rs4gc.s11.relocated330)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp57: ; preds = %eh.cont927
  %lpad58 = landingpad token
          cleanup
  %rs4gc.s24.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad58, i32 0, i32 0) ; (%rs4gc.s24.relocated336, %rs4gc.s24.relocated336)
  %rs4gc.s11.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad58, i32 1, i32 1) ; (%rs4gc.s11.relocated337, %rs4gc.s11.relocated337)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp60: ; preds = %eh.cont929
  %lpad61 = landingpad token
          cleanup
  %rs4gc.s11.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad61, i32 0, i32 0) ; (%rs4gc.s11.relocated344, %rs4gc.s11.relocated344)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp63: ; preds = %shadow.root.barrier.184
  %lpad64 = landingpad token
          cleanup
  %rs4gc.s26.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad64, i32 0, i32 0) ; (%rs4gc.s26, %rs4gc.s26)
  %rs4gc.s11.relocated351 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad64, i32 1, i32 1) ; (%rs4gc.s11.relocated349, %rs4gc.s11.relocated349)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %shadow.root.barrier.done.185
  %lpad.split-lp65 = landingpad token
          cleanup
  %rs4gc.s11.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad.split-lp65, i32 0, i32 0) ; (%.19, %.19)
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp63
  %.41 = phi ptr addrspace(1) [ %rs4gc.s11.relocated356, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated351, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp63 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp60
  %.40 = phi ptr addrspace(1) [ %.41, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated346, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp60 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp57
  %.39 = phi ptr addrspace(1) [ %.40, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated340, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp57 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp54
  %.38 = phi ptr addrspace(1) [ %.39, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated333, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp54 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp51
  %.37 = phi ptr addrspace(1) [ %.38, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated325, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp51 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp48
  %.36 = phi ptr addrspace(1) [ %.37, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated317, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp48 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp45
  %.35 = phi ptr addrspace(1) [ %.36, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated310, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp45 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp42
  %.34 = phi ptr addrspace(1) [ %.35, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated304, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp42 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp.split-lp:  ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp39
  %.33 = phi ptr addrspace(1) [ %.34, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated299, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp39 ]
  br label %eh.lpad.168.split-lp.split-lp.split-lp

eh.lpad.168.split-lp.split-lp.split-lp:           ; preds = %eh.lpad.168.split-lp.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp.split-lp36
  %.32 = phi ptr addrspace(1) [ %.33, %eh.lpad.168.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated294, %eh.lpad.168.split-lp.split-lp.split-lp36 ]
  br label %eh.lpad.168.split-lp.split-lp

eh.lpad.168.split-lp.split-lp:                    ; preds = %eh.lpad.168.split-lp.split-lp.split-lp, %eh.lpad.168.split-lp.split-lp33
  %.31 = phi ptr addrspace(1) [ %.32, %eh.lpad.168.split-lp.split-lp.split-lp ], [ %rs4gc.s11.relocated289, %eh.lpad.168.split-lp.split-lp33 ]
  br label %eh.lpad.168.split-lp

eh.lpad.168.split-lp:                             ; preds = %eh.lpad.168.split-lp.split-lp, %eh.lpad.168.split-lp30
  %.30 = phi ptr addrspace(1) [ %.31, %eh.lpad.168.split-lp.split-lp ], [ %rs4gc.s11.relocated284, %eh.lpad.168.split-lp30 ]
  br label %eh.lpad.168

eh.lpad.168:                                      ; preds = %eh.lpad.168.split-lp, %eh.lpad.16827
  %.11 = phi ptr addrspace(1) [ %.30, %eh.lpad.168.split-lp ], [ %rs4gc.s11.relocated272, %eh.lpad.16827 ]
  br label %try.catch.166

shadow.root.barrier.169:                          ; preds = %eh.cont814
  %statepoint_token285 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r815, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated275, ptr addrspace(1) %rs4gc.s21) ]
          to label %eh.cont818 unwind label %eh.lpad.168.split-lp30

eh.cont818:                                       ; preds = %shadow.root.barrier.169
  %rs4gc.s11.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 0, i32 0) ; (%rs4gc.s11.relocated275, %rs4gc.s11.relocated275)
  %rs4gc.s21.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 1, i32 1) ; (%rs4gc.s21, %rs4gc.s21)
  br label %shadow.root.barrier.done.170

shadow.root.barrier.done.170:                     ; preds = %eh.cont818, %eh.cont814
  %.0446 = phi ptr addrspace(1) [ %rs4gc.s21.relocated287, %eh.cont818 ], [ %rs4gc.s21, %eh.cont814 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s11.relocated286, %eh.cont818 ], [ %rs4gc.s11.relocated275, %eh.cont814 ]
  %r819 = load double, ptr @test_json_index_remainder_ts_.str.7.handle, align 8
  %r820.rs4i = ptrtoint ptr addrspace(1) %.0446 to i64
  %r820 = call i64 asm "", "=r,0"(i64 %r820.rs4i) #8
  %statepoint_token290 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r820, double %r819, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
          to label %eh.cont822 unwind label %eh.lpad.168.split-lp.split-lp33

eh.cont822:                                       ; preds = %shadow.root.barrier.done.170
  %r821291 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token290)
  %rs4gc.s11.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 0, i32 0) ; (%.12, %.12)
  %rs4gc.s23 = inttoptr i64 %r821291 to ptr addrspace(1)
  %r823.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r823 = call i64 asm "", "=r,0"(i64 %r823.rs4i) #8
  %r824 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r825 = icmp ne i32 %r824, 0
  br i1 %r825, label %shadow.root.barrier.171, label %shadow.root.barrier.done.172

shadow.root.barrier.171:                          ; preds = %eh.cont822
  %statepoint_token295 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r823, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated292, ptr addrspace(1) %rs4gc.s23) ]
          to label %eh.cont826 unwind label %eh.lpad.168.split-lp.split-lp.split-lp36

eh.cont826:                                       ; preds = %shadow.root.barrier.171
  %rs4gc.s11.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 0, i32 0) ; (%rs4gc.s11.relocated292, %rs4gc.s11.relocated292)
  %rs4gc.s23.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 1, i32 1) ; (%rs4gc.s23, %rs4gc.s23)
  br label %shadow.root.barrier.done.172

shadow.root.barrier.done.172:                     ; preds = %eh.cont826, %eh.cont822
  %.0447 = phi ptr addrspace(1) [ %rs4gc.s23.relocated297, %eh.cont826 ], [ %rs4gc.s23, %eh.cont822 ]
  %.15 = phi ptr addrspace(1) [ %rs4gc.s11.relocated296, %eh.cont826 ], [ %rs4gc.s11.relocated292, %eh.cont822 ]
  %r828 = sitofp i32 %r532.0 to double
  %r829.rs4i = ptrtoint ptr addrspace(1) %.0447 to i64
  %r829 = call i64 asm "", "=r,0"(i64 %r829.rs4i) #8
  %statepoint_token300 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r829, double %r828, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15) ]
          to label %eh.cont831 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp39

eh.cont831:                                       ; preds = %shadow.root.barrier.done.172
  %r830301 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token300)
  %rs4gc.s11.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token300, i32 0, i32 0) ; (%.15, %.15)
  %rs4gc.s24 = inttoptr i64 %r830301 to ptr addrspace(1)
  %r832.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r832 = call i64 asm "", "=r,0"(i64 %r832.rs4i) #8
  %r833 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r834 = icmp ne i32 %r833, 0
  br i1 %r834, label %shadow.root.barrier.173, label %shadow.root.barrier.done.174

shadow.root.barrier.173:                          ; preds = %eh.cont831
  %statepoint_token305 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r832, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s24, ptr addrspace(1) %rs4gc.s11.relocated302) ]
          to label %eh.cont835 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp42

eh.cont835:                                       ; preds = %shadow.root.barrier.173
  %rs4gc.s24.relocated306 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 0, i32 0) ; (%rs4gc.s24, %rs4gc.s24)
  %rs4gc.s11.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 1, i32 1) ; (%rs4gc.s11.relocated302, %rs4gc.s11.relocated302)
  br label %shadow.root.barrier.done.174

shadow.root.barrier.done.174:                     ; preds = %eh.cont835, %eh.cont831
  %.0448 = phi ptr addrspace(1) [ %rs4gc.s24.relocated306, %eh.cont835 ], [ %rs4gc.s24, %eh.cont831 ]
  %.16 = phi ptr addrspace(1) [ %rs4gc.s11.relocated307, %eh.cont835 ], [ %rs4gc.s11.relocated302, %eh.cont831 ]
  %r836.rs4i = ptrtoint ptr addrspace(1) %.16 to i64
  %r836.rs4o = call i64 asm "", "=r,0"(i64 %r836.rs4i) #8
  %r836 = bitcast i64 %r836.rs4o to double
  %r838 = bitcast double %r836 to i64
  %r839 = and i64 %r838, 281474976710655
  %r840 = lshr i64 %r838, 48
  %r841 = icmp eq i64 %r840, 32765
  %r842 = icmp ugt i64 %r839, 1048575
  %r843 = and i1 %r841, %r842
  br i1 %r843, label %arr.guard.deref.179, label %arr.fallback.176

arr.fast.175:                                     ; preds = %arr.guard.range.181
  %r900 = zext i32 %r532.0 to i64
  %r901 = shl nuw nsw i64 %r900, 3
  %r902 = add nuw nsw i64 %r901, 8
  %r903 = add i64 %r858, %r902
  %r904 = inttoptr i64 %r903 to ptr
  %r905 = load double, ptr %r904, align 8
  %r906 = bitcast double %r905 to i64
  %r907 = icmp eq i64 %r906, 9222246136947933200
  %r909 = select i1 %r907, double 0x7FFC000000000001, double %r905
  br label %arr.merge.178

arr.fallback.176:                                 ; preds = %arr.guard.live.180, %arr.guard.deref.179, %shadow.root.barrier.done.174
  %r897 = sitofp i32 %r532.0 to double
  %statepoint_token311 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5190247735588028422, double %r836, double %r897, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0448, ptr addrspace(1) %.16) ]
          to label %eh.cont899 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp45

eh.cont899:                                       ; preds = %arr.fallback.176
  %r898312 = call double @llvm.experimental.gc.result.f64(token %statepoint_token311)
  %rs4gc.s24.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token311, i32 0, i32 0) ; (%.0448, %.0448)
  %rs4gc.s11.relocated314 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token311, i32 1, i32 1) ; (%.16, %.16)
  br label %arr.merge.178

arr.guard.oob.177:                                ; preds = %arr.guard.range.181
  br label %arr.merge.178

arr.merge.178:                                    ; preds = %arr.guard.oob.177, %eh.cont899, %arr.fast.175
  %.1449 = phi ptr addrspace(1) [ %.0448, %arr.fast.175 ], [ %.0448, %arr.guard.oob.177 ], [ %rs4gc.s24.relocated313, %eh.cont899 ]
  %.17 = phi ptr addrspace(1) [ %.16, %arr.fast.175 ], [ %.16, %arr.guard.oob.177 ], [ %rs4gc.s11.relocated314, %eh.cont899 ]
  %r910 = phi double [ %r909, %arr.fast.175 ], [ %r898312, %eh.cont899 ], [ 0x7FFC000000000001, %arr.guard.oob.177 ]
  %r911 = bitcast double %r910 to i64
  %rs4gc.s25 = inttoptr i64 %r911 to ptr addrspace(1)
  %r913.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r913 = call i64 asm "", "=r,0"(i64 %r913.rs4i) #8
  %r914 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r915 = icmp ne i32 %r914, 0
  br i1 %r915, label %shadow.root.barrier.182, label %shadow.root.barrier.done.183

arr.guard.deref.179:                              ; preds = %shadow.root.barrier.done.174
  %r844 = bitcast double %r836 to i64
  %r845 = and i64 %r844, 281474976710655
  %r846 = sub nsw i64 %r845, 8
  %r847 = inttoptr i64 %r846 to ptr
  %r848 = load i8, ptr %r847, align 1
  %r849 = icmp eq i8 %r848, 1
  %r850 = sub nsw i64 %r845, 7
  %r851 = inttoptr i64 %r850 to ptr
  %r852 = load i8, ptr %r851, align 1
  %r853 = and i8 %r852, -128
  %r854 = icmp ne i8 %r853, 0
  %r855 = inttoptr i64 %r845 to ptr
  %r856 = load i64, ptr %r855, align 8
  %r857 = and i1 %r849, %r854
  %r858 = select i1 %r857, i64 %r856, i64 %r845
  %r859 = lshr i64 %r858, 48
  %r860 = icmp eq i64 %r859, 0
  %r861 = icmp ugt i64 %r858, 1048575
  %r862 = and i1 %r860, %r861
  br i1 %r862, label %arr.guard.live.180, label %arr.fallback.176

arr.guard.live.180:                               ; preds = %arr.guard.deref.179
  %r863 = sub nuw i64 %r858, 8
  %r864 = inttoptr i64 %r863 to ptr
  %r865 = load i8, ptr %r864, align 1
  %r866 = icmp eq i8 %r865, 1
  %r867 = sub nuw i64 %r858, 7
  %r868 = inttoptr i64 %r867 to ptr
  %r869 = load i8, ptr %r868, align 1
  %r870 = and i8 %r869, -128
  %r871 = icmp eq i8 %r870, 0
  %r872 = sub nuw i64 %r858, 6
  %r873 = inttoptr i64 %r872 to ptr
  %r874 = load i16, ptr %r873, align 2
  %r875 = and i16 %r874, 1024
  %r876 = icmp eq i16 %r875, 0
  %r877 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r878 = icmp eq i8 %r877, 0
  %r879 = inttoptr i64 %r858 to ptr
  %r880 = load i32, ptr %r879, align 4
  %r881 = getelementptr i8, ptr %r879, i64 4
  %r882 = load i32, ptr %r881, align 4
  %r883 = icmp slt i32 %r532.0, 0
  %r884 = icmp eq i1 %r883, false
  %r886 = icmp ule i32 %r880, 16000000
  %r887 = icmp ule i32 %r882, 16000000
  %r888 = icmp ule i32 %r880, %r882
  %r889 = and i1 %r866, %r871
  %r890 = and i1 %r889, %r876
  %r891 = and i1 %r890, %r878
  %r892 = and i1 %r891, %r884
  %r893 = and i1 %r892, %r886
  %r894 = and i1 %r893, %r887
  %r895 = and i1 %r894, %r888
  br i1 %r895, label %arr.guard.range.181, label %arr.fallback.176

arr.guard.range.181:                              ; preds = %arr.guard.live.180
  %r885 = icmp ult i32 %r532.0, %r880
  br i1 %r885, label %arr.fast.175, label %arr.guard.oob.177

shadow.root.barrier.182:                          ; preds = %arr.merge.178
  %statepoint_token318 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r913, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1449, ptr addrspace(1) %rs4gc.s25, ptr addrspace(1) %.17) ]
          to label %eh.cont916 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp48

eh.cont916:                                       ; preds = %shadow.root.barrier.182
  %rs4gc.s24.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 0, i32 0) ; (%.1449, %.1449)
  %rs4gc.s25.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 1, i32 1) ; (%rs4gc.s25, %rs4gc.s25)
  %rs4gc.s11.relocated321 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 2, i32 2) ; (%.17, %.17)
  br label %shadow.root.barrier.done.183

shadow.root.barrier.done.183:                     ; preds = %eh.cont916, %arr.merge.178
  %.2450 = phi ptr addrspace(1) [ %rs4gc.s24.relocated319, %eh.cont916 ], [ %.1449, %arr.merge.178 ]
  %.18 = phi ptr addrspace(1) [ %rs4gc.s11.relocated321, %eh.cont916 ], [ %.17, %arr.merge.178 ]
  %.0432 = phi ptr addrspace(1) [ %rs4gc.s25.relocated320, %eh.cont916 ], [ %rs4gc.s25, %arr.merge.178 ]
  %statepoint_token326 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_bigint_from_i128_parts, i32 2, i32 0, i64 7, i64 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0432, ptr addrspace(1) %.2450, ptr addrspace(1) %.18) ]
          to label %eh.cont921 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp51

eh.cont921:                                       ; preds = %shadow.root.barrier.done.183
  %r920327 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token326)
  %rs4gc.s25.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 0, i32 0) ; (%.0432, %.0432)
  %rs4gc.s24.relocated329 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 1, i32 1) ; (%.2450, %.2450)
  %rs4gc.s11.relocated330 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 2, i32 2) ; (%.18, %.18)
  %r922 = or i64 %r920327, 9221683186994511872
  %r923 = bitcast i64 %r922 to double
  %r924.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25.relocated328 to i64
  %r924 = call i64 asm "", "=r,0"(i64 %r924.rs4i) #8
  %r925 = bitcast i64 %r924 to double
  %statepoint_token334 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @perry_fn_test_json_index_remainder_ts__remainder, i32 2, i32 0, double %r925, double %r923, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s24.relocated329, ptr addrspace(1) %rs4gc.s11.relocated330) ]
          to label %eh.cont927 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp54

eh.cont927:                                       ; preds = %eh.cont921
  %r926335 = call double @llvm.experimental.gc.result.f64(token %statepoint_token334)
  %rs4gc.s24.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 0, i32 0) ; (%rs4gc.s24.relocated329, %rs4gc.s24.relocated329)
  %rs4gc.s11.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 1, i32 1) ; (%rs4gc.s11.relocated330, %rs4gc.s11.relocated330)
  %statepoint_token341 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_index_remainder_ts__describe, i32 1, i32 0, double %r926335, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s24.relocated336, ptr addrspace(1) %rs4gc.s11.relocated337) ]
          to label %eh.cont929 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp57

eh.cont929:                                       ; preds = %eh.cont927
  %r928342 = call double @llvm.experimental.gc.result.f64(token %statepoint_token341)
  %rs4gc.s24.relocated343 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 0, i32 0) ; (%rs4gc.s24.relocated336, %rs4gc.s24.relocated336)
  %rs4gc.s11.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 1, i32 1) ; (%rs4gc.s11.relocated337, %rs4gc.s11.relocated337)
  %r930.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24.relocated343 to i64
  %r930 = call i64 asm "", "=r,0"(i64 %r930.rs4i) #8
  %statepoint_token347 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r930, double %r928342, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated344) ]
          to label %eh.cont932 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp60

eh.cont932:                                       ; preds = %eh.cont929
  %r931348 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token347)
  %rs4gc.s11.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token347, i32 0, i32 0) ; (%rs4gc.s11.relocated344, %rs4gc.s11.relocated344)
  %rs4gc.s26 = inttoptr i64 %r931348 to ptr addrspace(1)
  %r933.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r933 = call i64 asm "", "=r,0"(i64 %r933.rs4i) #8
  %r934 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r935 = icmp ne i32 %r934, 0
  br i1 %r935, label %shadow.root.barrier.184, label %shadow.root.barrier.done.185

shadow.root.barrier.184:                          ; preds = %eh.cont932
  %statepoint_token352 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r933, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s26, ptr addrspace(1) %rs4gc.s11.relocated349) ]
          to label %eh.cont936 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp63

eh.cont936:                                       ; preds = %shadow.root.barrier.184
  %rs4gc.s26.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 0, i32 0) ; (%rs4gc.s26, %rs4gc.s26)
  %rs4gc.s11.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 1, i32 1) ; (%rs4gc.s11.relocated349, %rs4gc.s11.relocated349)
  br label %shadow.root.barrier.done.185

shadow.root.barrier.done.185:                     ; preds = %eh.cont936, %eh.cont932
  %.19 = phi ptr addrspace(1) [ %rs4gc.s11.relocated354, %eh.cont936 ], [ %rs4gc.s11.relocated349, %eh.cont932 ]
  %.0431 = phi ptr addrspace(1) [ %rs4gc.s26.relocated353, %eh.cont936 ], [ %rs4gc.s26, %eh.cont932 ]
  %r937.rs4i = ptrtoint ptr addrspace(1) %.0431 to i64
  %r937 = call i64 asm "", "=r,0"(i64 %r937.rs4i) #8
  %statepoint_token357 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r937, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.19) ]
          to label %eh.cont938 unwind label %eh.lpad.168.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.cont938:                                       ; preds = %shadow.root.barrier.done.185
  %rs4gc.s11.relocated358 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token357, i32 0, i32 0) ; (%.19, %.19)
  %statepoint_token359 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated358) ]
  %rs4gc.s11.relocated360 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 0, i32 0) ; (%rs4gc.s11.relocated358, %rs4gc.s11.relocated358)
  br label %try.finally.167

shadow.root.barrier.186:                          ; preds = %try.catch.166
  call void @js_write_barrier_root_nanbox(i64 %r941) #8
  br label %shadow.root.barrier.done.187

shadow.root.barrier.done.187:                     ; preds = %shadow.root.barrier.186, %try.catch.166
  %statepoint_token361 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s22, ptr addrspace(1) %rs4gc.s11.relocated282) ]
  %r944362 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token361)
  %rs4gc.s22.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 0, i32 0) ; (%rs4gc.s22, %rs4gc.s22)
  %rs4gc.s11.relocated363 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 1, i32 1) ; (%rs4gc.s11.relocated282, %rs4gc.s11.relocated282)
  %rs4gc.s27 = inttoptr i64 %r944362 to ptr addrspace(1)
  %r945.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r945 = call i64 asm "", "=r,0"(i64 %r945.rs4i) #8
  %r946 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r947 = icmp ne i32 %r946, 0
  br i1 %r947, label %shadow.root.barrier.188, label %shadow.root.barrier.done.189

shadow.root.barrier.188:                          ; preds = %shadow.root.barrier.done.187
  call void @js_write_barrier_root_nanbox(i64 %r945) #8
  br label %shadow.root.barrier.done.189

shadow.root.barrier.done.189:                     ; preds = %shadow.root.barrier.188, %shadow.root.barrier.done.187
  %r948 = load double, ptr @test_json_index_remainder_ts_.str.7.handle, align 8
  %r949.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r949 = call i64 asm "", "=r,0"(i64 %r949.rs4i) #8
  %statepoint_token364 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r949, double %r948, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s22.relocated, ptr addrspace(1) %rs4gc.s11.relocated363) ]
  %r950365 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token364)
  %rs4gc.s22.relocated366 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token364, i32 0, i32 0) ; (%rs4gc.s22.relocated, %rs4gc.s22.relocated)
  %rs4gc.s11.relocated367 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token364, i32 1, i32 1) ; (%rs4gc.s11.relocated363, %rs4gc.s11.relocated363)
  %rs4gc.s28 = inttoptr i64 %r950365 to ptr addrspace(1)
  %r951.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r951 = call i64 asm "", "=r,0"(i64 %r951.rs4i) #8
  %r952 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r953 = icmp ne i32 %r952, 0
  br i1 %r953, label %shadow.root.barrier.190, label %shadow.root.barrier.done.191

shadow.root.barrier.190:                          ; preds = %shadow.root.barrier.done.189
  call void @js_write_barrier_root_nanbox(i64 %r951) #8
  br label %shadow.root.barrier.done.191

shadow.root.barrier.done.191:                     ; preds = %shadow.root.barrier.190, %shadow.root.barrier.done.189
  %r955 = sitofp i32 %r532.0 to double
  %r956.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r956 = call i64 asm "", "=r,0"(i64 %r956.rs4i) #8
  %statepoint_token368 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r956, double %r955, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated367, ptr addrspace(1) %rs4gc.s22.relocated366) ]
  %r957369 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token368)
  %rs4gc.s11.relocated370 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token368, i32 0, i32 0) ; (%rs4gc.s11.relocated367, %rs4gc.s11.relocated367)
  %rs4gc.s22.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token368, i32 1, i32 1) ; (%rs4gc.s22.relocated366, %rs4gc.s22.relocated366)
  %rs4gc.s29 = inttoptr i64 %r957369 to ptr addrspace(1)
  %r958.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r958 = call i64 asm "", "=r,0"(i64 %r958.rs4i) #8
  %r959 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r960 = icmp ne i32 %r959, 0
  br i1 %r960, label %shadow.root.barrier.192, label %shadow.root.barrier.done.193

shadow.root.barrier.192:                          ; preds = %shadow.root.barrier.done.191
  call void @js_write_barrier_root_nanbox(i64 %r958) #8
  br label %shadow.root.barrier.done.193

shadow.root.barrier.done.193:                     ; preds = %shadow.root.barrier.192, %shadow.root.barrier.done.191
  %r961.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22.relocated371 to i64
  %r961.rs4o = call i64 asm "", "=r,0"(i64 %r961.rs4i) #8
  %r961 = bitcast i64 %r961.rs4o to double
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i32)) @js_instanceof, i32 2, i32 0, double %r961, i32 -65520, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated370, ptr addrspace(1) %rs4gc.s29) ]
  %r962373 = call double @llvm.experimental.gc.result.f64(token %statepoint_token372)
  %rs4gc.s11.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 0, i32 0) ; (%rs4gc.s11.relocated370, %rs4gc.s11.relocated370)
  %rs4gc.s29.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 1, i32 1) ; (%rs4gc.s29, %rs4gc.s29)
  %r963 = bitcast double %r962373 to i64
  %r964 = and i64 %r963, 9221120237041090560
  %r965 = icmp ne i64 %r964, 9221120237041090560
  br i1 %r965, label %truthy.num.194, label %truthy.tag.195

truthy.num.194:                                   ; preds = %shadow.root.barrier.done.193
  %r966 = fcmp one double %r962373, 0.000000e+00
  br label %truthy.merge.197

truthy.tag.195:                                   ; preds = %shadow.root.barrier.done.193
  %r967 = icmp eq i64 %r963, 9222246136947933188
  %r968 = icmp eq i64 %r963, 9222246136947933187
  %r969 = icmp eq i64 %r963, 9222246136947933185
  %r970 = icmp eq i64 %r963, 9222246136947933186
  %r971 = or i1 %r968, %r969
  %r972 = or i1 %r971, %r970
  %r973 = or i1 %r967, %r972
  br i1 %r973, label %truthy.merge.197, label %truthy.obj.198

truthy.slow.196:                                  ; preds = %truthy.obj.198
  %r979 = call i32 @js_is_truthy(double %r962373) #8
  %r980 = icmp ne i32 %r979, 0
  br label %truthy.merge.197

truthy.merge.197:                                 ; preds = %truthy.obj.198, %truthy.slow.196, %truthy.tag.195, %truthy.num.194
  %r981 = phi i1 [ %r966, %truthy.num.194 ], [ %r967, %truthy.tag.195 ], [ true, %truthy.obj.198 ], [ %r980, %truthy.slow.196 ]
  br i1 %r981, label %ternary.then.199, label %ternary.else.200

truthy.obj.198:                                   ; preds = %truthy.tag.195
  %r974 = lshr i64 %r963, 48
  %r975 = icmp eq i64 %r974, 32765
  %r976 = and i64 %r963, 281474976710655
  %r977 = icmp ne i64 %r976, 0
  %r978 = and i1 %r975, %r977
  br i1 %r978, label %truthy.merge.197, label %truthy.slow.196

ternary.then.199:                                 ; preds = %truthy.merge.197
  %r982 = load double, ptr @test_json_index_remainder_ts_.str.5.handle, align 8
  br label %ternary.merge.201

ternary.else.200:                                 ; preds = %truthy.merge.197
  %r983 = load double, ptr @test_json_index_remainder_ts_.str.6.handle, align 8
  br label %ternary.merge.201

ternary.merge.201:                                ; preds = %ternary.else.200, %ternary.then.199
  %r984 = phi double [ %r982, %ternary.then.199 ], [ %r983, %ternary.else.200 ]
  %r985.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29.relocated to i64
  %r985 = call i64 asm "", "=r,0"(i64 %r985.rs4i) #8
  %statepoint_token375 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r985, double %r984, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated374) ]
  %r986376 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token375)
  %rs4gc.s11.relocated377 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token375, i32 0, i32 0) ; (%rs4gc.s11.relocated374, %rs4gc.s11.relocated374)
  %rs4gc.s30 = inttoptr i64 %r986376 to ptr addrspace(1)
  %r987.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r987 = call i64 asm "", "=r,0"(i64 %r987.rs4i) #8
  %r988 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r989 = icmp ne i32 %r988, 0
  br i1 %r989, label %shadow.root.barrier.202, label %shadow.root.barrier.done.203

shadow.root.barrier.202:                          ; preds = %ternary.merge.201
  call void @js_write_barrier_root_nanbox(i64 %r987) #8
  br label %shadow.root.barrier.done.203

shadow.root.barrier.done.203:                     ; preds = %shadow.root.barrier.202, %ternary.merge.201
  %r990.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r990 = call i64 asm "", "=r,0"(i64 %r990.rs4i) #8
  %statepoint_token378 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r990, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated377) ]
  %rs4gc.s11.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 0, i32 0) ; (%rs4gc.s11.relocated377, %rs4gc.s11.relocated377)
  br label %try.finally.167

gcpoll.204:                                       ; preds = %try.finally.167
  %statepoint_token380 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %rs4gc.s11.relocated381 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 0, i32 0) ; (%.13, %.13)
  br label %gcpoll.done.205

gcpoll.done.205:                                  ; preds = %gcpoll.204, %try.finally.167
  %.14 = phi ptr addrspace(1) [ %rs4gc.s11.relocated381, %gcpoll.204 ], [ %.13, %try.finally.167 ]
  br label %for.update.103

event_loop.header.206:                            ; preds = %event_loop.body_wait.211, %event_loop.body_check.210, %for.exit.104
  %statepoint_token382 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r1001383 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token382)
  %r1002 = icmp ne i32 %r1001383, 0
  br i1 %r1002, label %event_loop.host_return.208, label %event_loop.check_pending.207

event_loop.check_pending.207:                     ; preds = %event_loop.header.206
  %statepoint_token384 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1003385 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token384)
  %statepoint_token386 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1004387 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token386)
  %statepoint_token388 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1005389 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token388)
  %statepoint_token390 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1006391 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token390)
  %statepoint_token392 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1007393 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token392)
  %statepoint_token394 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1008395 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token394)
  %r1009 = or i32 %r1003385, %r1004387
  %r1010 = or i32 %r1005389, %r1006391
  %r1011 = or i32 %r1010, %r1007393
  %r1012 = or i32 %r1009, %r1011
  %r1013 = or i32 %r1012, 0
  %r1014 = or i32 %r1013, %r1008395
  %r1015 = icmp ne i32 %r1014, 0
  br i1 %r1015, label %event_loop.body.209, label %event_loop.exit.212

event_loop.host_return.208:                       ; preds = %event_loop.header.206
  call void @js_typed_feedback_maybe_dump_trace() #8
  ret i32 0

event_loop.body.209:                              ; preds = %event_loop.check_pending.207
  %statepoint_token396 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token397 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.210

event_loop.body_check.210:                        ; preds = %event_loop.body.209
  %statepoint_token398 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1017399 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token398)
  %statepoint_token400 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1018401 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token400)
  %statepoint_token402 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1019403 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token402)
  %statepoint_token404 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1020405 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token404)
  %statepoint_token406 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1021407 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token406)
  %statepoint_token408 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1022409 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token408)
  %r1023 = or i32 %r1017399, %r1018401
  %r1024 = or i32 %r1019403, %r1020405
  %r1025 = or i32 %r1024, %r1021407
  %r1026 = or i32 %r1023, %r1025
  %r1027 = or i32 %r1026, 0
  %r1028 = or i32 %r1027, %r1022409
  %r1029 = icmp ne i32 %r1028, 0
  br i1 %r1029, label %event_loop.body_wait.211, label %event_loop.header.206

event_loop.body_wait.211:                         ; preds = %event_loop.body_check.210
  %statepoint_token410 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.206

event_loop.exit.212:                              ; preds = %event_loop.check_pending.207
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token412 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token413 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token414 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token415 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token416 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token417 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token418 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token419 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r1032420 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token419)
  call void @js_typed_feedback_maybe_dump_trace() #8
  ret i32 %r1032420
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_index_remainder_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.0.bytes, i32 2)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_index_remainder_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.1.bytes, i32 3)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_index_remainder_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.2.bytes, i32 1)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_index_remainder_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.3.bytes, i32 10)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_index_remainder_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.4.bytes, i32 6)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_index_remainder_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.5.bytes, i32 9)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_index_remainder_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.6.bytes, i32 10)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_index_remainder_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_index_remainder_ts_.str.7.bytes, i32 6)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_index_remainder_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_index_remainder_ts_.str.7.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__remainder, ptr @test_json_index_remainder_ts_.str.1, i32 9)
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__describe, ptr @test_json_index_remainder_ts_.str.2, i32 8)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_index_remainder_ts__remainder, ptr @test_json_index_remainder_ts_.str.1, i32 9)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_index_remainder_ts__describe, ptr @test_json_index_remainder_ts_.str.2, i32 8)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__remainder, ptr @test_json_index_remainder_ts_.str.3, i32 57, i32 0)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__describe, ptr @test_json_index_remainder_ts_.str.4, i32 201, i32 0)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__describe, i32 1)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__remainder, i32 2)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__describe, i32 1)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__remainder, i32 2)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__describe)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_index_remainder_ts__remainder)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_index_remainder_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_index_remainder_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { inlinehint optsize "frame-pointer"="non-leaf" }
attributes #8 = { "gc-leaf-function" }

!0 = !{}
