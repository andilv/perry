
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/integer-remainder-r32/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844694 <_js_json_parse>:
100844694:     	stp	x29, x30, [sp, #-0x10]!
100844698:     	mov	x29, sp
10084469c:     	cbz	x0, 0x1008446f4 <_js_json_parse+0x60>
1008446a0:     	ldr	w1, [x0, #0x4]
1008446a4:     	cmp	w1, #0x2
1008446a8:     	b.eq	0x1008446b8 <_js_json_parse+0x24>
1008446ac:     	cbz	w1, 0x1008446f4 <_js_json_parse+0x60>
1008446b0:     	ldrb	w8, [x0, #0x14]
1008446b4:     	b	0x1008446d8 <_js_json_parse+0x44>
1008446b8:     	ldrb	w8, [x0, #0x14]
1008446bc:     	cmp	w8, #0x7b
1008446c0:     	b.ne	0x1008446d8 <_js_json_parse+0x44>
1008446c4:     	ldrb	w8, [x0, #0x15]
1008446c8:     	cmp	w8, #0x7d
1008446cc:     	b.ne	0x1008446e4 <_js_json_parse+0x50>
1008446d0:     	ldp	x29, x30, [sp], #0x10
1008446d4:     	b	0x1004ec900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
1008446d8:     	orr	w8, w8, #0x20
1008446dc:     	cmp	w8, #0x7b
1008446e0:     	b.ne	0x1008446ec <_js_json_parse+0x58>
1008446e4:     	ldp	x29, x30, [sp], #0x10
1008446e8:     	b	0x100505d78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008446ec:     	ldp	x29, x30, [sp], #0x10
1008446f0:     	b	0x1005083f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008446f4:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6f1c>
1008446f8:     	add	x0, x0, #0x5c1
1008446fc:     	mov	w1, #0x1c               ; =28
100844700:     	bl	0x100508828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
