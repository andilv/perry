
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/integer-remainder-r32/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008453ac <_js_json_stringify>:
1008453ac:     	sub	sp, sp, #0x80
1008453b0:     	stp	d9, d8, [sp, #0x20]
1008453b4:     	stp	x26, x25, [sp, #0x30]
1008453b8:     	stp	x24, x23, [sp, #0x40]
1008453bc:     	stp	x22, x21, [sp, #0x50]
1008453c0:     	stp	x20, x19, [sp, #0x60]
1008453c4:     	stp	x29, x30, [sp, #0x70]
1008453c8:     	add	x29, sp, #0x70
1008453cc:     	mov	x21, x0
1008453d0:     	mov.16b	v8, v0
1008453d4:     	fmov	x19, d8
1008453d8:     	and	x20, x19, #0xffff000000000000
1008453dc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008453e0:     	cmp	x20, x8
1008453e4:     	b.ne	0x10084540c <_js_json_stringify+0x60>
1008453e8:     	and	x0, x19, #0xffffffffffff
1008453ec:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1008453f0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1008453f4:     	movk	x9, #0xffef, lsl #16
1008453f8:     	cmp	x8, x9
1008453fc:     	b.hi	0x10084540c <_js_json_stringify+0x60>
100845400:     	ldr	w8, [x0, #0x4]
100845404:     	cmp	w8, #0x40
100845408:     	b.hs	0x10084547c <_js_json_stringify+0xd0>
10084540c:     	mov.16b	v0, v8
100845410:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100845414:     	tbz	w0, #0x0, 0x100845420 <_js_json_stringify+0x74>
100845418:     	mov	x23, x1
10084541c:     	b	0x100845990 <_js_json_stringify+0x5e4>
100845420:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845424:     	cmp	x20, x8
100845428:     	b.ne	0x100845490 <_js_json_stringify+0xe4>
10084542c:     	ands	x19, x19, #0xffffffffffff
100845430:     	b.eq	0x100845490 <_js_json_stringify+0xe4>
100845434:     	mov	x0, x19
100845438:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084543c:     	cbz	w0, 0x100845490 <_js_json_stringify+0xe4>
100845440:     	ldurb	w8, [x19, #-0x8]
100845444:     	cmp	w8, #0x9
100845448:     	b.ne	0x100845490 <_js_json_stringify+0xe4>
10084544c:     	ldr	w8, [x19, #0x4]
100845450:     	mov	w9, #0x5841             ; =22593
100845454:     	movk	w9, #0x4c5a, lsl #16
100845458:     	cmp	w8, w9
10084545c:     	b.ne	0x100845490 <_js_json_stringify+0xe4>
100845460:     	mov	x0, x19
100845464:     	bl	0x100688364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100845468:     	cbz	x0, 0x100845490 <_js_json_stringify+0xe4>
10084546c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845470:     	bfxil	x8, x0, #0, #48
100845474:     	fmov	d8, x8
100845478:     	b	0x100845490 <_js_json_stringify+0xe4>
10084547c:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845480:     	tbnz	w0, #0x0, 0x100845418 <_js_json_stringify+0x6c>
100845484:     	mov.16b	v0, v8
100845488:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084548c:     	tbnz	w0, #0x0, 0x100845418 <_js_json_stringify+0x6c>
100845490:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845494:     	add	x0, x0, #0xd78
100845498:     	ldr	x8, [x0]
10084549c:     	blr	x8
1008454a0:     	mov	x19, x0
1008454a4:     	ldr	w26, [x0]
1008454a8:     	add	w8, w26, #0x1
1008454ac:     	str	w8, [x0]
1008454b0:     	cbz	w26, 0x100845520 <_js_json_stringify+0x174>
1008454b4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008454b8:     	add	x0, x0, #0xd00
1008454bc:     	ldr	x8, [x0]
1008454c0:     	blr	x8
1008454c4:     	ldrb	w8, [x0, #0x20]
1008454c8:     	cmp	w8, #0x1
1008454cc:     	b.ne	0x100845a84 <_js_json_stringify+0x6d8>
1008454d0:     	ldr	x8, [x0]
1008454d4:     	cbnz	x8, 0x100845a90 <_js_json_stringify+0x6e4>
1008454d8:     	mov	x8, #-0x1               ; =-1
1008454dc:     	str	x8, [x0]
1008454e0:     	ldr	x20, [x0, #0x18]
1008454e4:     	ldr	x8, [x0, #0x8]
1008454e8:     	cmp	x20, x8
1008454ec:     	b.eq	0x1008459b4 <_js_json_stringify+0x608>
1008454f0:     	ldr	x8, [x0, #0x10]
1008454f4:     	mov	w9, #0x18               ; =24
1008454f8:     	madd	x8, x20, x9, x8
1008454fc:     	mov	w9, #0x8                ; =8
100845500:     	stp	xzr, x9, [x8]
100845504:     	str	xzr, [x8, #0x10]
100845508:     	add	x8, x20, #0x1
10084550c:     	str	x8, [x0, #0x18]
100845510:     	ldr	x8, [x0]
100845514:     	add	x8, x8, #0x1
100845518:     	str	x8, [x0]
10084551c:     	b	0x1008455ac <_js_json_stringify+0x200>
100845520:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845524:     	add	x0, x0, #0xdc0
100845528:     	ldr	x8, [x0]
10084552c:     	blr	x8
100845530:     	strb	wzr, [x0]
100845534:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845538:     	add	x0, x0, #0xdf0
10084553c:     	ldr	x8, [x0]
100845540:     	blr	x8
100845544:     	strb	wzr, [x0]
100845548:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10084554c:     	ldr	w20, [x8, #0x5a8]
100845550:     	cmp	w20, #0x300
100845554:     	b.hs	0x100845a10 <_js_json_stringify+0x664>
100845558:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084555c:     	ldr	x8, [x8, #0x48]
100845560:     	cmn	x8, #0x1
100845564:     	b.eq	0x100845a00 <_js_json_stringify+0x654>
100845568:     	mrs	x9, TPIDRRO_EL0
10084556c:     	and	x9, x9, #0xfffffffffffffff8
100845570:     	ldr	x0, [x9, x8, lsl #3]
100845574:     	cbz	x0, 0x100845a00 <_js_json_stringify+0x654>
100845578:     	add	x8, x0, x20, lsl #3
10084557c:     	ldr	x0, [x8, #0x1e8]
100845580:     	cbz	x0, 0x100845a10 <_js_json_stringify+0x664>
100845584:     	str	xzr, [x0]
100845588:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084558c:     	add	x0, x0, #0xd90
100845590:     	ldr	x8, [x0]
100845594:     	blr	x8
100845598:     	ldrb	w8, [x0, #0x20]
10084559c:     	cbnz	w8, 0x100845a9c <_js_json_stringify+0x6f0>
1008455a0:     	ldr	x8, [x0]
1008455a4:     	cbnz	x8, 0x100845ac4 <_js_json_stringify+0x718>
1008455a8:     	str	xzr, [x0, #0x18]
1008455ac:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008455b0:     	add	x0, x0, #0xd30
1008455b4:     	ldr	x8, [x0]
1008455b8:     	blr	x8
1008455bc:     	mov	x20, x0
1008455c0:     	ldrb	w8, [x0, #0x18]
1008455c4:     	cmp	w8, #0x1
1008455c8:     	b.ne	0x100845a20 <_js_json_stringify+0x674>
1008455cc:     	ldr	x8, [x0]
1008455d0:     	mov	x9, #-0x1               ; =-1
1008455d4:     	str	x9, [x0]
1008455d8:     	cmn	x8, #0x2
1008455dc:     	b.eq	0x100845ad0 <_js_json_stringify+0x724>
1008455e0:     	cmn	x8, #0x1
1008455e4:     	b.eq	0x1008455f8 <_js_json_stringify+0x24c>
1008455e8:     	add	x9, sp, #0x8
1008455ec:     	ldur	q0, [x0, #0x8]
1008455f0:     	stur	q0, [x9, #0x8]
1008455f4:     	b	0x100845604 <_js_json_stringify+0x258>
1008455f8:     	mov	x8, #0x0                ; =0
1008455fc:     	mov	w9, #0x1                ; =1
100845600:     	stp	x9, xzr, [sp, #0x10]
100845604:     	str	x8, [sp, #0x8]
100845608:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084560c:     	add	x0, x0, #0xd18
100845610:     	ldr	x8, [x0]
100845614:     	blr	x8
100845618:     	ldrb	w8, [x0, #0x20]
10084561c:     	cbnz	w8, 0x100845a50 <_js_json_stringify+0x6a4>
100845620:     	ldr	x8, [x0]
100845624:     	cbnz	x8, 0x100845a78 <_js_json_stringify+0x6cc>
100845628:     	str	xzr, [x0, #0x18]
10084562c:     	add	x1, sp, #0x8
100845630:     	mov.16b	v0, v8
100845634:     	mov	x0, x21
100845638:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084563c:     	ldp	x21, x22, [sp, #0x10]
100845640:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100845644:     	b.hs	0x100845704 <_js_json_stringify+0x358>
100845648:     	cmp	x22, #0x40
10084564c:     	b.hs	0x1008457c8 <_js_json_stringify+0x41c>
100845650:     	ands	x9, x22, #0x38
100845654:     	b.eq	0x100845678 <_js_json_stringify+0x2cc>
100845658:     	and	x8, x22, #0x38
10084565c:     	neg	x8, x8
100845660:     	mov	x10, x21
100845664:     	ldr	x11, [x10], #0x8
100845668:     	tst	x11, #0x8080808080808080
10084566c:     	b.ne	0x1008456ec <_js_json_stringify+0x340>
100845670:     	adds	x8, x8, #0x8
100845674:     	b.ne	0x100845664 <_js_json_stringify+0x2b8>
100845678:     	and	x8, x22, #0x7
10084567c:     	cbz	x8, 0x10084584c <_js_json_stringify+0x4a0>
100845680:     	add	x9, x21, x9
100845684:     	ldrsb	w10, [x9]
100845688:     	tbnz	w10, #0x1f, 0x1008456ec <_js_json_stringify+0x340>
10084568c:     	cmp	x8, #0x1
100845690:     	b.eq	0x10084584c <_js_json_stringify+0x4a0>
100845694:     	ldrsb	w10, [x9, #0x1]
100845698:     	tbnz	w10, #0x1f, 0x1008456ec <_js_json_stringify+0x340>
10084569c:     	cmp	x8, #0x2
1008456a0:     	b.eq	0x10084584c <_js_json_stringify+0x4a0>
1008456a4:     	ldrsb	w10, [x9, #0x2]
1008456a8:     	tbnz	w10, #0x1f, 0x1008456ec <_js_json_stringify+0x340>
1008456ac:     	cmp	x8, #0x3
1008456b0:     	b.eq	0x10084584c <_js_json_stringify+0x4a0>
1008456b4:     	ldrsb	w10, [x9, #0x3]
1008456b8:     	tbnz	w10, #0x1f, 0x1008456ec <_js_json_stringify+0x340>
1008456bc:     	cmp	x8, #0x4
1008456c0:     	b.eq	0x10084584c <_js_json_stringify+0x4a0>
1008456c4:     	ldrsb	w10, [x9, #0x4]
1008456c8:     	tbnz	w10, #0x1f, 0x1008456ec <_js_json_stringify+0x340>
1008456cc:     	cmp	x8, #0x5
1008456d0:     	b.eq	0x10084584c <_js_json_stringify+0x4a0>
1008456d4:     	ldrsb	w10, [x9, #0x5]
1008456d8:     	tbnz	w10, #0x1f, 0x1008456ec <_js_json_stringify+0x340>
1008456dc:     	cmp	x8, #0x6
1008456e0:     	b.eq	0x10084584c <_js_json_stringify+0x4a0>
1008456e4:     	ldrsb	w8, [x9, #0x6]
1008456e8:     	tbz	w8, #0x1f, 0x10084584c <_js_json_stringify+0x4a0>
1008456ec:     	mov	x0, x21
1008456f0:     	mov	x1, x22
1008456f4:     	mov	x2, x22
1008456f8:     	bl	0x1008dcd80 <_js_string_from_bytes_with_capacity>
1008456fc:     	mov	x23, x0
100845700:     	b	0x100845948 <_js_json_stringify+0x59c>
100845704:     	and	x8, x22, #0x7fffffffffffffc0
100845708:     	add	x8, x21, x8
10084570c:     	mov	x9, x21
100845710:     	ldp	q0, q1, [x9]
100845714:     	ldp	q2, q3, [x9, #0x20]
100845718:     	orr.16b	v0, v1, v0
10084571c:     	orr.16b	v1, v2, v3
100845720:     	orr.16b	v0, v0, v1
100845724:     	umaxv.16b	b0, v0
100845728:     	fmov	w10, s0
10084572c:     	tbnz	w10, #0x7, 0x10084578c <_js_json_stringify+0x3e0>
100845730:     	add	x9, x9, #0x40
100845734:     	cmp	x9, x8
100845738:     	b.ne	0x100845710 <_js_json_stringify+0x364>
10084573c:     	ands	x9, x22, #0x30
100845740:     	b.eq	0x100845764 <_js_json_stringify+0x3b8>
100845744:     	mov	x10, x9
100845748:     	mov	x11, x8
10084574c:     	ldr	q0, [x11], #0x10
100845750:     	umaxv.16b	b0, v0
100845754:     	fmov	w12, s0
100845758:     	tbnz	w12, #0x7, 0x10084578c <_js_json_stringify+0x3e0>
10084575c:     	subs	x10, x10, #0x10
100845760:     	b.ne	0x10084574c <_js_json_stringify+0x3a0>
100845764:     	and	x10, x22, #0xf
100845768:     	cbz	x10, 0x100845784 <_js_json_stringify+0x3d8>
10084576c:     	add	x8, x8, x9
100845770:     	ldrsb	w9, [x8]
100845774:     	tbnz	w9, #0x1f, 0x10084578c <_js_json_stringify+0x3e0>
100845778:     	add	x8, x8, #0x1
10084577c:     	subs	x10, x10, #0x1
100845780:     	b.ne	0x100845770 <_js_json_stringify+0x3c4>
100845784:     	mov	w24, w22
100845788:     	b	0x1008457c0 <_js_json_stringify+0x414>
10084578c:     	mov	w24, w22
100845790:     	cbz	x24, 0x1008457c0 <_js_json_stringify+0x414>
100845794:     	mov	x8, x21
100845798:     	ands	x9, x22, #0x3
10084579c:     	b.eq	0x1008457b8 <_js_json_stringify+0x40c>
1008457a0:     	mov	x8, x21
1008457a4:     	ldrsb	w10, [x8]
1008457a8:     	tbnz	w10, #0x1f, 0x1008458b0 <_js_json_stringify+0x504>
1008457ac:     	add	x8, x8, #0x1
1008457b0:     	subs	x9, x9, #0x1
1008457b4:     	b.ne	0x1008457a4 <_js_json_stringify+0x3f8>
1008457b8:     	cmp	x24, #0x4
1008457bc:     	b.hs	0x10084587c <_js_json_stringify+0x4d0>
1008457c0:     	mov	x25, x22
1008457c4:     	b	0x1008458c0 <_js_json_stringify+0x514>
1008457c8:     	and	x8, x22, #0x7fffffffffffffc0
1008457cc:     	and	x8, x8, #0xffffffff0007ffff
1008457d0:     	add	x8, x21, x8
1008457d4:     	mov	x9, x21
1008457d8:     	ldp	q0, q1, [x9]
1008457dc:     	ldp	q2, q3, [x9, #0x20]
1008457e0:     	orr.16b	v0, v1, v0
1008457e4:     	orr.16b	v1, v2, v3
1008457e8:     	orr.16b	v0, v0, v1
1008457ec:     	umaxv.16b	b0, v0
1008457f0:     	fmov	w10, s0
1008457f4:     	tbnz	w10, #0x7, 0x1008456ec <_js_json_stringify+0x340>
1008457f8:     	add	x9, x9, #0x40
1008457fc:     	cmp	x9, x8
100845800:     	b.ne	0x1008457d8 <_js_json_stringify+0x42c>
100845804:     	ands	x9, x22, #0x30
100845808:     	b.eq	0x10084582c <_js_json_stringify+0x480>
10084580c:     	mov	x10, x9
100845810:     	mov	x11, x8
100845814:     	ldr	q0, [x11], #0x10
100845818:     	umaxv.16b	b0, v0
10084581c:     	fmov	w12, s0
100845820:     	tbnz	w12, #0x7, 0x1008456ec <_js_json_stringify+0x340>
100845824:     	subs	x10, x10, #0x10
100845828:     	b.ne	0x100845814 <_js_json_stringify+0x468>
10084582c:     	and	x10, x22, #0xf
100845830:     	cbz	x10, 0x10084584c <_js_json_stringify+0x4a0>
100845834:     	add	x8, x8, x9
100845838:     	ldrsb	w9, [x8]
10084583c:     	tbnz	w9, #0x1f, 0x1008456ec <_js_json_stringify+0x340>
100845840:     	add	x8, x8, #0x1
100845844:     	subs	x10, x10, #0x1
100845848:     	b.ne	0x100845838 <_js_json_stringify+0x48c>
10084584c:     	mov	x0, x22
100845850:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845854:     	mov	x23, x0
100845858:     	stp	w22, w22, [x0]
10084585c:     	stp	wzr, wzr, [x0, #0xc]
100845860:     	str	w22, [x0, #0x8]
100845864:     	cbz	w22, 0x100845948 <_js_json_stringify+0x59c>
100845868:     	and	x2, x22, #0x7ffff
10084586c:     	mov	x0, x1
100845870:     	mov	x1, x21
100845874:     	bl	0x100b61e2c <_writev+0x100b61e2c>
100845878:     	b	0x100845948 <_js_json_stringify+0x59c>
10084587c:     	add	x9, x21, x24
100845880:     	ldrsb	w10, [x8]
100845884:     	tbnz	w10, #0x1f, 0x1008458b0 <_js_json_stringify+0x504>
100845888:     	ldrsb	w10, [x8, #0x1]
10084588c:     	tbnz	w10, #0x1f, 0x1008458b0 <_js_json_stringify+0x504>
100845890:     	ldrsb	w10, [x8, #0x2]
100845894:     	tbnz	w10, #0x1f, 0x1008458b0 <_js_json_stringify+0x504>
100845898:     	ldrsb	w10, [x8, #0x3]
10084589c:     	tbnz	w10, #0x1f, 0x1008458b0 <_js_json_stringify+0x504>
1008458a0:     	add	x8, x8, #0x4
1008458a4:     	cmp	x8, x9
1008458a8:     	b.ne	0x100845880 <_js_json_stringify+0x4d4>
1008458ac:     	b	0x1008457c0 <_js_json_stringify+0x414>
1008458b0:     	mov	w1, w22
1008458b4:     	mov	x0, x21
1008458b8:     	bl	0x1005ea920 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1008458bc:     	mov	x25, x0
1008458c0:     	bl	0x1004eff00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
1008458c4:     	add	x0, x24, #0x14
1008458c8:     	mov	w1, #0x3                ; =3
1008458cc:     	bl	0x100458380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1008458d0:     	mov	x23, x0
1008458d4:     	stp	w25, w22, [x0]
1008458d8:     	stp	wzr, wzr, [x0, #0xc]
1008458dc:     	str	w22, [x0, #0x8]
1008458e0:     	add	x0, x0, #0x14
1008458e4:     	mov	x1, x21
1008458e8:     	mov	x2, x24
1008458ec:     	bl	0x100b61e2c <_writev+0x100b61e2c>
1008458f0:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008458f4:     	ldr	w21, [x8, #0x590]
1008458f8:     	cmp	w21, #0x300
1008458fc:     	b.hs	0x1008459d8 <_js_json_stringify+0x62c>
100845900:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100845904:     	ldr	x8, [x8, #0x48]
100845908:     	cmn	x8, #0x1
10084590c:     	b.eq	0x1008459c8 <_js_json_stringify+0x61c>
100845910:     	mrs	x9, TPIDRRO_EL0
100845914:     	and	x9, x9, #0xfffffffffffffff8
100845918:     	ldr	x0, [x9, x8, lsl #3]
10084591c:     	cbz	x0, 0x1008459c8 <_js_json_stringify+0x61c>
100845920:     	add	x8, x0, x21, lsl #3
100845924:     	ldr	x0, [x8, #0x1e8]
100845928:     	cbz	x0, 0x1008459d8 <_js_json_stringify+0x62c>
10084592c:     	ldr	x8, [x0]
100845930:     	adds	x8, x8, x24
100845934:     	csinv	x8, x8, xzr, lo
100845938:     	str	x8, [x0]
10084593c:     	lsr	x8, x8, #25
100845940:     	cbz	x8, 0x100845948 <_js_json_stringify+0x59c>
100845944:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845948:     	ldp	x22, x21, [sp, #0x8]
10084594c:     	ldrb	w8, [x20, #0x18]
100845950:     	cmp	w8, #0x1
100845954:     	b.ne	0x100845a30 <_js_json_stringify+0x684>
100845958:     	ldp	x8, x0, [x20]
10084595c:     	stp	x22, x21, [x20]
100845960:     	str	xzr, [x20, #0x10]
100845964:     	sub	x8, x8, #0x1
100845968:     	cmn	x8, #0x2
10084596c:     	b.hs	0x100845974 <_js_json_stringify+0x5c8>
100845970:     	bl	0x100b5ef80 <_mi_free>
100845974:     	cbz	w26, 0x100845980 <_js_json_stringify+0x5d4>
100845978:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084597c:     	b	0x100845984 <_js_json_stringify+0x5d8>
100845980:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845984:     	ldr	w8, [x19]
100845988:     	sub	w8, w8, #0x1
10084598c:     	str	w8, [x19]
100845990:     	mov	x0, x23
100845994:     	ldp	x29, x30, [sp, #0x70]
100845998:     	ldp	x20, x19, [sp, #0x60]
10084599c:     	ldp	x22, x21, [sp, #0x50]
1008459a0:     	ldp	x24, x23, [sp, #0x40]
1008459a4:     	ldp	x26, x25, [sp, #0x30]
1008459a8:     	ldp	d9, d8, [sp, #0x20]
1008459ac:     	add	sp, sp, #0x80
1008459b0:     	ret
1008459b4:     	mov	x22, x0
1008459b8:     	add	x0, x0, #0x8
1008459bc:     	bl	0x100b3bd10 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1008459c0:     	mov	x0, x22
1008459c4:     	b	0x1008454f0 <_js_json_stringify+0x144>
1008459c8:     	bl	0x100b3f3bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008459cc:     	add	x8, x0, x21, lsl #3
1008459d0:     	ldr	x0, [x8, #0x1e8]
1008459d4:     	cbnz	x0, 0x10084592c <_js_json_stringify+0x580>
1008459d8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008459dc:     	add	x0, x0, #0x78
1008459e0:     	bl	0x100b3cbdc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008459e4:     	ldr	x8, [x0]
1008459e8:     	adds	x8, x8, x24
1008459ec:     	csinv	x8, x8, xzr, lo
1008459f0:     	str	x8, [x0]
1008459f4:     	lsr	x8, x8, #25
1008459f8:     	cbnz	x8, 0x100845944 <_js_json_stringify+0x598>
1008459fc:     	b	0x100845948 <_js_json_stringify+0x59c>
100845a00:     	bl	0x100b3f3bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845a04:     	add	x8, x0, x20, lsl #3
100845a08:     	ldr	x0, [x8, #0x1e8]
100845a0c:     	cbnz	x0, 0x100845584 <_js_json_stringify+0x1d8>
100845a10:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845a14:     	add	x0, x0, #0x138
100845a18:     	bl	0x100b3cbdc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845a1c:     	b	0x100845584 <_js_json_stringify+0x1d8>
100845a20:     	mov	x0, x20
100845a24:     	bl	0x100b1e544 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845a28:     	cbnz	x0, 0x1008455cc <_js_json_stringify+0x220>
100845a2c:     	b	0x100845ad0 <_js_json_stringify+0x724>
100845a30:     	mov	x0, x20
100845a34:     	bl	0x100b1e544 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845a38:     	mov	x20, x0
100845a3c:     	cbnz	x0, 0x100845958 <_js_json_stringify+0x5ac>
100845a40:     	cbz	x22, 0x100845ad0 <_js_json_stringify+0x724>
100845a44:     	mov	x0, x21
100845a48:     	bl	0x100b5ef80 <_mi_free>
100845a4c:     	b	0x100845ad0 <_js_json_stringify+0x724>
100845a50:     	cmp	w8, #0x2
100845a54:     	b.eq	0x100845ad0 <_js_json_stringify+0x724>
100845a58:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845a5c:     	add	x1, x1, #0xff8
100845a60:     	mov	x22, x0
100845a64:     	bl	0x100a2041c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845a68:     	mov	x0, x22
100845a6c:     	strb	wzr, [x22, #0x20]
100845a70:     	ldr	x8, [x22]
100845a74:     	cbz	x8, 0x100845628 <_js_json_stringify+0x27c>
100845a78:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845a7c:     	add	x0, x0, #0xdb8
100845a80:     	bl	0x100b126ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845a84:     	bl	0x100b1e6a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100845a88:     	cbnz	x0, 0x1008454d0 <_js_json_stringify+0x124>
100845a8c:     	b	0x100845ad0 <_js_json_stringify+0x724>
100845a90:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100845a94:     	add	x0, x0, #0x440
100845a98:     	bl	0x100b126ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845a9c:     	cmp	w8, #0x1
100845aa0:     	b.ne	0x100845ad0 <_js_json_stringify+0x724>
100845aa4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845aa8:     	add	x1, x1, #0x998
100845aac:     	mov	x20, x0
100845ab0:     	bl	0x100a2041c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845ab4:     	mov	x0, x20
100845ab8:     	strb	wzr, [x20, #0x20]
100845abc:     	ldr	x8, [x20]
100845ac0:     	cbz	x8, 0x1008455a8 <_js_json_stringify+0x1fc>
100845ac4:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845ac8:     	add	x0, x0, #0xd88
100845acc:     	bl	0x100b126ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845ad0:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845ad4:     	add	x0, x0, #0xc18
100845ad8:     	bl	0x100b585dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
