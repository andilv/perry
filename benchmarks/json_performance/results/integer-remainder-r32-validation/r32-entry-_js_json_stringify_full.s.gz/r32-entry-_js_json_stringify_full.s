
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/integer-remainder-r32/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845b00 <_js_json_stringify_full>:
100845b00:     	sub	sp, sp, #0x120
100845b04:     	stp	d9, d8, [sp, #0xb0]
100845b08:     	stp	x28, x27, [sp, #0xc0]
100845b0c:     	stp	x26, x25, [sp, #0xd0]
100845b10:     	stp	x24, x23, [sp, #0xe0]
100845b14:     	stp	x22, x21, [sp, #0xf0]
100845b18:     	stp	x20, x19, [sp, #0x100]
100845b1c:     	stp	x29, x30, [sp, #0x110]
100845b20:     	add	x29, sp, #0x110
100845b24:     	mov.16b	v9, v2
100845b28:     	mov.16b	v8, v0
100845b2c:     	fmov	x19, d8
100845b30:     	fmov	x21, d1
100845b34:     	fmov	x23, d9
100845b38:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845b3c:     	add	x27, x21, x8
100845b40:     	add	x24, x23, x8
100845b44:     	fcmp	d2, #0.0
100845b48:     	ccmp	x24, #0x2, #0x0, ne
100845b4c:     	b.hi	0x100845b5c <_js_json_stringify_full+0x5c>
100845b50:     	cmp	x27, #0x2
100845b54:     	b.lo	0x100845b6c <_js_json_stringify_full+0x6c>
100845b58:     	b	0x1008460d8 <_js_json_stringify_full+0x5d8>
100845b5c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100845b60:     	cmp	x23, x8
100845b64:     	ccmp	x27, #0x2, #0x2, eq
100845b68:     	b.hs	0x1008460d8 <_js_json_stringify_full+0x5d8>
100845b6c:     	mov	x8, #-0x2               ; =-2
100845b70:     	movk	x8, #0x8003, lsl #48
100845b74:     	add	x8, x19, x8
100845b78:     	cmp	x8, #0x3
100845b7c:     	b.hs	0x100845b90 <_js_json_stringify_full+0x90>
100845b80:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e70>
100845b84:     	add	x9, x9, #0x718
100845b88:     	ldr	x20, [x9, x8, lsl #3]
100845b8c:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
100845b90:     	strb	wzr, [sp, #0x4c]
100845b94:     	str	wzr, [sp, #0x48]
100845b98:     	and	x8, x19, #0xffff000000000000
100845b9c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845ba0:     	cmp	x8, x9
100845ba4:     	b.eq	0x100845c18 <_js_json_stringify_full+0x118>
100845ba8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845bac:     	cmp	x8, x9
100845bb0:     	b.ne	0x100846014 <_js_json_stringify_full+0x514>
100845bb4:     	ubfx	x10, x19, #40, #8
100845bb8:     	cbz	x10, 0x100845c08 <_js_json_stringify_full+0x108>
100845bbc:     	strb	w19, [sp, #0x48]
100845bc0:     	cmp	x10, #0x1
100845bc4:     	b.eq	0x100845c08 <_js_json_stringify_full+0x108>
100845bc8:     	lsr	x9, x19, #8
100845bcc:     	strb	w9, [sp, #0x49]
100845bd0:     	cmp	x10, #0x2
100845bd4:     	b.eq	0x100845c08 <_js_json_stringify_full+0x108>
100845bd8:     	lsr	x9, x19, #16
100845bdc:     	strb	w9, [sp, #0x4a]
100845be0:     	cmp	x10, #0x3
100845be4:     	b.eq	0x100845c08 <_js_json_stringify_full+0x108>
100845be8:     	lsr	x9, x19, #24
100845bec:     	strb	w9, [sp, #0x4b]
100845bf0:     	cmp	x10, #0x4
100845bf4:     	b.eq	0x100845c08 <_js_json_stringify_full+0x108>
100845bf8:     	lsr	x9, x19, #32
100845bfc:     	strb	w9, [sp, #0x4c]
100845c00:     	cmp	x10, #0x5
100845c04:     	b.ne	0x10084777c <_js_json_stringify_full+0x1c7c>
100845c08:     	add	x11, sp, #0x48
100845c0c:     	cmp	w10, #0x3
100845c10:     	b.ls	0x100845c30 <_js_json_stringify_full+0x130>
100845c14:     	b	0x100846014 <_js_json_stringify_full+0x514>
100845c18:     	ands	x9, x19, #0xffffffffffff
100845c1c:     	b.eq	0x1008460d8 <_js_json_stringify_full+0x5d8>
100845c20:     	add	x11, x9, #0x14
100845c24:     	ldr	w10, [x9, #0x4]
100845c28:     	cmp	w10, #0x3
100845c2c:     	b.hi	0x100846014 <_js_json_stringify_full+0x514>
100845c30:     	stur	wzr, [sp, #0x81]
100845c34:     	mov	w9, #0x22               ; =34
100845c38:     	strb	w9, [sp, #0x80]
100845c3c:     	cbz	w10, 0x100845c74 <_js_json_stringify_full+0x174>
100845c40:     	add	x12, sp, #0x80
100845c44:     	ldrb	w13, [x11]
100845c48:     	sxtb	w15, w13
100845c4c:     	cmp	w13, #0xb
100845c50:     	b.le	0x100845c7c <_js_json_stringify_full+0x17c>
100845c54:     	cmp	w13, #0x21
100845c58:     	b.gt	0x100845c9c <_js_json_stringify_full+0x19c>
100845c5c:     	cmp	w13, #0xc
100845c60:     	b.eq	0x100845cd0 <_js_json_stringify_full+0x1d0>
100845c64:     	cmp	w13, #0xd
100845c68:     	b.ne	0x100845cac <_js_json_stringify_full+0x1ac>
100845c6c:     	mov	w15, #0x72              ; =114
100845c70:     	b	0x100845cdc <_js_json_stringify_full+0x1dc>
100845c74:     	mov	w12, #0x1               ; =1
100845c78:     	b	0x100845d04 <_js_json_stringify_full+0x204>
100845c7c:     	cmp	w13, #0x8
100845c80:     	b.eq	0x100845cc8 <_js_json_stringify_full+0x1c8>
100845c84:     	cmp	w13, #0x9
100845c88:     	b.eq	0x100845cd8 <_js_json_stringify_full+0x1d8>
100845c8c:     	cmp	w13, #0xa
100845c90:     	b.ne	0x100845cac <_js_json_stringify_full+0x1ac>
100845c94:     	mov	w15, #0x6e              ; =110
100845c98:     	b	0x100845cdc <_js_json_stringify_full+0x1dc>
100845c9c:     	cmp	w13, #0x22
100845ca0:     	b.eq	0x100845cdc <_js_json_stringify_full+0x1dc>
100845ca4:     	cmp	w13, #0x5c
100845ca8:     	b.eq	0x100845cdc <_js_json_stringify_full+0x1dc>
100845cac:     	cmp	w15, #0x20
100845cb0:     	b.lt	0x100846014 <_js_json_stringify_full+0x514>
100845cb4:     	mov	w14, #0x0               ; =0
100845cb8:     	add	x13, x12, #0x2
100845cbc:     	mov	w12, #0x2               ; =2
100845cc0:     	mov	w16, #0x1               ; =1
100845cc4:     	b	0x100845cf4 <_js_json_stringify_full+0x1f4>
100845cc8:     	mov	w15, #0x62              ; =98
100845ccc:     	b	0x100845cdc <_js_json_stringify_full+0x1dc>
100845cd0:     	mov	w15, #0x66              ; =102
100845cd4:     	b	0x100845cdc <_js_json_stringify_full+0x1dc>
100845cd8:     	mov	w15, #0x74              ; =116
100845cdc:     	add	x13, x12, #0x3
100845ce0:     	mov	w12, #0x5c              ; =92
100845ce4:     	strb	w12, [sp, #0x81]
100845ce8:     	mov	w14, #0x1               ; =1
100845cec:     	mov	w12, #0x3               ; =3
100845cf0:     	mov	w16, #0x2               ; =2
100845cf4:     	add	x17, sp, #0x80
100845cf8:     	strb	w15, [x17, x16]
100845cfc:     	cmp	w10, #0x1
100845d00:     	b.ne	0x100845d3c <_js_json_stringify_full+0x23c>
100845d04:     	add	x10, sp, #0x80
100845d08:     	strb	w9, [x10, x12]
100845d0c:     	add	x8, x12, #0x1
100845d10:     	cmp	x12, #0x3
100845d14:     	b.hs	0x100845d28 <_js_json_stringify_full+0x228>
100845d18:     	mov	x13, #0x0               ; =0
100845d1c:     	mov	x11, #0x0               ; =0
100845d20:     	add	x9, sp, #0x80
100845d24:     	b	0x100845f84 <_js_json_stringify_full+0x484>
100845d28:     	cmp	x12, #0xf
100845d2c:     	b.hs	0x100845d6c <_js_json_stringify_full+0x26c>
100845d30:     	mov	x11, #0x0               ; =0
100845d34:     	mov	x13, #0x0               ; =0
100845d38:     	b	0x100845ee0 <_js_json_stringify_full+0x3e0>
100845d3c:     	ldrb	w16, [x11, #0x1]
100845d40:     	sxtb	w15, w16
100845d44:     	cmp	w16, #0xb
100845d48:     	b.le	0x100845fb4 <_js_json_stringify_full+0x4b4>
100845d4c:     	cmp	w16, #0x21
100845d50:     	b.gt	0x100845fd4 <_js_json_stringify_full+0x4d4>
100845d54:     	cmp	w16, #0xc
100845d58:     	b.eq	0x100846004 <_js_json_stringify_full+0x504>
100845d5c:     	cmp	w16, #0xd
100845d60:     	b.ne	0x100845fe4 <_js_json_stringify_full+0x4e4>
100845d64:     	mov	w15, #0x72              ; =114
100845d68:     	b	0x100846010 <_js_json_stringify_full+0x510>
100845d6c:     	and	x12, x8, #0xc
100845d70:     	and	x11, x8, #0x10
100845d74:     	add	x13, sp, #0x80
100845d78:     	add	x9, x13, x11
100845d7c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e70>
100845d80:     	ldr	q0, [x14, #0x890]
100845d84:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e70>
100845d88:     	ldr	q1, [x14, #0x8a0]
100845d8c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e70>
100845d90:     	ldr	q2, [x14, #0x8b0]
100845d94:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e70>
100845d98:     	ldr	q3, [x14, #0x8c0]
100845d9c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e70>
100845da0:     	ldr	q4, [x14, #0x8d0]
100845da4:     	movi.2d	v5, #0000000000000000
100845da8:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e70>
100845dac:     	ldr	q6, [x14, #0x8e0]
100845db0:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e70>
100845db4:     	ldr	q7, [x14, #0xa00]
100845db8:     	mov	w14, #0x10              ; =16
100845dbc:     	movi.2d	v16, #0000000000000000
100845dc0:     	dup.2d	v17, x14
100845dc4:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3367a>
100845dc8:     	ldr	q19, [x14, #0x900]
100845dcc:     	and	x14, x8, #0x10
100845dd0:     	movi.2d	v20, #0000000000000000
100845dd4:     	movi.2d	v18, #0000000000000000
100845dd8:     	movi.2d	v23, #0000000000000000
100845ddc:     	movi.2d	v21, #0000000000000000
100845de0:     	movi.2d	v24, #0000000000000000
100845de4:     	movi.2d	v22, #0000000000000000
100845de8:     	ldr	q25, [x13], #0x10
100845dec:     	ushll.8h	v26, v25, #0x0
100845df0:     	ushll2.4s	v27, v26, #0x0
100845df4:     	ushll2.2d	v28, v27, #0x0
100845df8:     	ushll2.8h	v25, v25, #0x0
100845dfc:     	ushll.4s	v29, v25, #0x0
100845e00:     	ushll2.2d	v30, v29, #0x0
100845e04:     	ushll.2d	v29, v29, #0x0
100845e08:     	ushll.2d	v27, v27, #0x0
100845e0c:     	ushll.4s	v26, v26, #0x0
100845e10:     	ushll2.2d	v31, v26, #0x0
100845e14:     	ushll2.4s	v25, v25, #0x0
100845e18:     	ushll.2d	v8, v25, #0x0
100845e1c:     	ushll.2d	v26, v26, #0x0
100845e20:     	ushll2.2d	v25, v25, #0x0
100845e24:     	shl.2d	v9, v0, #0x3
100845e28:     	ushl.2d	v25, v25, v9
100845e2c:     	shl.2d	v9, v19, #0x3
100845e30:     	ushl.2d	v26, v26, v9
100845e34:     	shl.2d	v9, v1, #0x3
100845e38:     	ushl.2d	v8, v8, v9
100845e3c:     	shl.2d	v9, v7, #0x3
100845e40:     	ushl.2d	v31, v31, v9
100845e44:     	shl.2d	v9, v6, #0x3
100845e48:     	ushl.2d	v27, v27, v9
100845e4c:     	shl.2d	v9, v3, #0x3
100845e50:     	ushl.2d	v29, v29, v9
100845e54:     	shl.2d	v9, v2, #0x3
100845e58:     	ushl.2d	v30, v30, v9
100845e5c:     	shl.2d	v9, v4, #0x3
100845e60:     	ushl.2d	v28, v28, v9
100845e64:     	orr.16b	v18, v28, v18
100845e68:     	orr.16b	v21, v30, v21
100845e6c:     	orr.16b	v23, v29, v23
100845e70:     	orr.16b	v20, v27, v20
100845e74:     	orr.16b	v5, v31, v5
100845e78:     	orr.16b	v24, v8, v24
100845e7c:     	orr.16b	v16, v26, v16
100845e80:     	orr.16b	v22, v25, v22
100845e84:     	add.2d	v6, v6, v17
100845e88:     	add.2d	v7, v7, v17
100845e8c:     	add.2d	v19, v19, v17
100845e90:     	add.2d	v4, v4, v17
100845e94:     	add.2d	v3, v3, v17
100845e98:     	add.2d	v2, v2, v17
100845e9c:     	add.2d	v1, v1, v17
100845ea0:     	add.2d	v0, v0, v17
100845ea4:     	subs	x14, x14, #0x10
100845ea8:     	b.ne	0x100845de8 <_js_json_stringify_full+0x2e8>
100845eac:     	orr.16b	v0, v16, v23
100845eb0:     	orr.16b	v1, v20, v24
100845eb4:     	orr.16b	v0, v0, v1
100845eb8:     	orr.16b	v1, v5, v21
100845ebc:     	orr.16b	v2, v18, v22
100845ec0:     	orr.16b	v1, v1, v2
100845ec4:     	orr.16b	v0, v0, v1
100845ec8:     	mov	d1, v0[1]
100845ecc:     	orr.8b	v0, v0, v1
100845ed0:     	fmov	x13, d0
100845ed4:     	cmp	x8, x11
100845ed8:     	b.eq	0x100845fa4 <_js_json_stringify_full+0x4a4>
100845edc:     	cbz	x12, 0x100845f84 <_js_json_stringify_full+0x484>
100845ee0:     	mov	x14, x11
100845ee4:     	and	x11, x8, #0x1c
100845ee8:     	add	x15, sp, #0x80
100845eec:     	add	x9, x15, x11
100845ef0:     	fmov	d0, x13
100845ef4:     	movi.2d	v1, #0000000000000000
100845ef8:     	dup.2d	v3, x14
100845efc:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e70>
100845f00:     	ldr	q2, [x12, #0xa00]
100845f04:     	orr.16b	v2, v3, v2
100845f08:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3367a>
100845f0c:     	ldr	q4, [x12, #0x900]
100845f10:     	orr.16b	v3, v3, v4
100845f14:     	sub	x12, x14, x11
100845f18:     	add	x13, x15, x14
100845f1c:     	movi.2d	v4, #0x000000000000ff
100845f20:     	mov	w14, #0x4               ; =4
100845f24:     	dup.2d	v5, x14
100845f28:     	ldr	s6, [x13], #0x4
100845f2c:     	ushll.8h	v6, v6, #0x0
100845f30:     	ushll.4s	v6, v6, #0x0
100845f34:     	ushll2.2d	v7, v6, #0x0
100845f38:     	and.16b	v7, v7, v4
100845f3c:     	ushll.2d	v6, v6, #0x0
100845f40:     	and.16b	v6, v6, v4
100845f44:     	shl.2d	v16, v2, #0x3
100845f48:     	shl.2d	v17, v3, #0x3
100845f4c:     	ushl.2d	v6, v6, v17
100845f50:     	ushl.2d	v7, v7, v16
100845f54:     	orr.16b	v1, v7, v1
100845f58:     	orr.16b	v0, v6, v0
100845f5c:     	add.2d	v2, v2, v5
100845f60:     	add.2d	v3, v3, v5
100845f64:     	adds	x12, x12, #0x4
100845f68:     	b.ne	0x100845f28 <_js_json_stringify_full+0x428>
100845f6c:     	orr.16b	v0, v0, v1
100845f70:     	mov	d1, v0[1]
100845f74:     	orr.8b	v0, v0, v1
100845f78:     	fmov	x13, d0
100845f7c:     	cmp	x8, x11
100845f80:     	b.eq	0x100845fa4 <_js_json_stringify_full+0x4a4>
100845f84:     	add	x10, x10, x8
100845f88:     	lsl	x11, x11, #3
100845f8c:     	ldrb	w12, [x9], #0x1
100845f90:     	lsl	x12, x12, x11
100845f94:     	orr	x13, x12, x13
100845f98:     	add	x11, x11, #0x8
100845f9c:     	cmp	x9, x10
100845fa0:     	b.ne	0x100845f8c <_js_json_stringify_full+0x48c>
100845fa4:     	orr	x8, x13, x8, lsl #40
100845fa8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845fac:     	orr	x20, x8, x9
100845fb0:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
100845fb4:     	cmp	w16, #0x8
100845fb8:     	b.eq	0x100845ffc <_js_json_stringify_full+0x4fc>
100845fbc:     	cmp	w16, #0x9
100845fc0:     	b.eq	0x10084600c <_js_json_stringify_full+0x50c>
100845fc4:     	cmp	w16, #0xa
100845fc8:     	b.ne	0x100845fe4 <_js_json_stringify_full+0x4e4>
100845fcc:     	mov	w15, #0x6e              ; =110
100845fd0:     	b	0x100846010 <_js_json_stringify_full+0x510>
100845fd4:     	cmp	w16, #0x22
100845fd8:     	b.eq	0x100846010 <_js_json_stringify_full+0x510>
100845fdc:     	cmp	w16, #0x5c
100845fe0:     	b.eq	0x100846010 <_js_json_stringify_full+0x510>
100845fe4:     	cmp	w15, #0x20
100845fe8:     	b.lt	0x100846014 <_js_json_stringify_full+0x514>
100845fec:     	add	x13, sp, #0x80
100845ff0:     	strb	w15, [x13, x12]
100845ff4:     	add	x12, x12, #0x1
100845ff8:     	b	0x10084659c <_js_json_stringify_full+0xa9c>
100845ffc:     	mov	w15, #0x62              ; =98
100846000:     	b	0x100846010 <_js_json_stringify_full+0x510>
100846004:     	mov	w15, #0x66              ; =102
100846008:     	b	0x100846010 <_js_json_stringify_full+0x510>
10084600c:     	mov	w15, #0x74              ; =116
100846010:     	tbz	w14, #0x0, 0x100846588 <_js_json_stringify_full+0xa88>
100846014:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846018:     	cmp	x8, x9
10084601c:     	b.eq	0x100846064 <_js_json_stringify_full+0x564>
100846020:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846024:     	cmp	x8, x9
100846028:     	b.ne	0x1008460d8 <_js_json_stringify_full+0x5d8>
10084602c:     	and	x8, x19, #0xffffffffffff
100846030:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100846034:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100846038:     	movk	x10, #0xffef, lsl #16
10084603c:     	cmp	x9, x10
100846040:     	b.hi	0x1008460d8 <_js_json_stringify_full+0x5d8>
100846044:     	ldr	w8, [x8, #0x4]
100846048:     	cmp	w8, #0x40
10084604c:     	b.lo	0x1008460d8 <_js_json_stringify_full+0x5d8>
100846050:     	and	x0, x19, #0xffffffffffff
100846054:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846058:     	cmp	x0, #0x1
10084605c:     	b.ne	0x1008460d8 <_js_json_stringify_full+0x5d8>
100846060:     	b	0x100846224 <_js_json_stringify_full+0x724>
100846064:     	and	x25, x19, #0xffffffffffff
100846068:     	and	x0, x19, #0xffffffffffff
10084606c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846070:     	cbz	x0, 0x1008460a4 <_js_json_stringify_full+0x5a4>
100846074:     	ldrb	w8, [x0]
100846078:     	cmp	w8, #0x2
10084607c:     	b.ne	0x1008460a4 <_js_json_stringify_full+0x5a4>
100846080:     	ldrsb	w8, [x0, #0x1]
100846084:     	tbnz	w8, #0x1f, 0x1008460a4 <_js_json_stringify_full+0x5a4>
100846088:     	ldrh	w8, [x0, #0x2]
10084608c:     	tbnz	w8, #0xb, 0x1008460a4 <_js_json_stringify_full+0x5a4>
100846090:     	ldr	w8, [x0, #0x4]
100846094:     	cmp	w8, #0x18
100846098:     	b.lo	0x1008460a4 <_js_json_stringify_full+0x5a4>
10084609c:     	ldr	w8, [x25]
1008460a0:     	cbz	w8, 0x1008470fc <_js_json_stringify_full+0x15fc>
1008460a4:     	and	x0, x19, #0xffffffffffff
1008460a8:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008460ac:     	cbz	x0, 0x1008460d8 <_js_json_stringify_full+0x5d8>
1008460b0:     	ldrb	w8, [x0]
1008460b4:     	cmp	w8, #0x2
1008460b8:     	b.ne	0x1008460d8 <_js_json_stringify_full+0x5d8>
1008460bc:     	ldrh	w8, [x0, #0x2]
1008460c0:     	tbnz	w8, #0xb, 0x1008460d8 <_js_json_stringify_full+0x5d8>
1008460c4:     	ldr	w8, [x0, #0x4]
1008460c8:     	cmp	w8, #0x18
1008460cc:     	b.lo	0x1008460d8 <_js_json_stringify_full+0x5d8>
1008460d0:     	ldr	w8, [x25]
1008460d4:     	cbz	w8, 0x1008470a0 <_js_json_stringify_full+0x15a0>
1008460d8:     	mov	x20, #0x1               ; =1
1008460dc:     	movk	x20, #0x7ffc, lsl #48
1008460e0:     	cmp	x19, x20
1008460e4:     	b.eq	0x100846fa8 <_js_json_stringify_full+0x14a8>
1008460e8:     	and	x22, x19, #0xffff000000000000
1008460ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008460f0:     	cmp	x22, x8
1008460f4:     	b.ne	0x10084612c <_js_json_stringify_full+0x62c>
1008460f8:     	and	x8, x19, #0xffffffffffff
1008460fc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846100:     	b.lo	0x100846118 <_js_json_stringify_full+0x618>
100846104:     	ldr	w8, [x8, #0xc]
100846108:     	mov	w9, #0x4f53             ; =20307
10084610c:     	movk	w9, #0x434c, lsl #16
100846110:     	cmp	w8, w9
100846114:     	b.eq	0x100846fa8 <_js_json_stringify_full+0x14a8>
100846118:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084611c:     	cmp	x22, x8
100846120:     	b.ne	0x100846158 <_js_json_stringify_full+0x658>
100846124:     	and	x0, x19, #0xffffffffffff
100846128:     	b	0x100846180 <_js_json_stringify_full+0x680>
10084612c:     	lsr	x8, x19, #52
100846130:     	cbnz	x8, 0x100846208 <_js_json_stringify_full+0x708>
100846134:     	and	x8, x19, #0x7
100846138:     	cbz	x19, 0x100846164 <_js_json_stringify_full+0x664>
10084613c:     	cbnz	x8, 0x100846164 <_js_json_stringify_full+0x664>
100846140:     	mov	x0, x19
100846144:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846148:     	mov	x8, x19
10084614c:     	tbnz	w0, #0x0, 0x1008460fc <_js_json_stringify_full+0x5fc>
100846150:     	mov	x8, #0x0                ; =0
100846154:     	b	0x100846164 <_js_json_stringify_full+0x664>
100846158:     	lsr	x8, x19, #52
10084615c:     	cbnz	x8, 0x100846208 <_js_json_stringify_full+0x708>
100846160:     	and	x8, x19, #0x7
100846164:     	cbz	x19, 0x100846208 <_js_json_stringify_full+0x708>
100846168:     	cbnz	x8, 0x100846208 <_js_json_stringify_full+0x708>
10084616c:     	mov	x0, x19
100846170:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846174:     	mov	x8, x0
100846178:     	mov	x0, x19
10084617c:     	tbz	w8, #0x0, 0x100846208 <_js_json_stringify_full+0x708>
100846180:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846184:     	b.lo	0x100846208 <_js_json_stringify_full+0x708>
100846188:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084618c:     	add	x8, x8, #0xfb0
100846190:     	ldaprb	w8, [x8]
100846194:     	cbz	w8, 0x100846208 <_js_json_stringify_full+0x708>
100846198:     	lsr	x8, x0, #3
10084619c:     	mov	x9, #0x7c15             ; =31765
1008461a0:     	movk	x9, #0x7f4a, lsl #16
1008461a4:     	movk	x9, #0x79b9, lsl #32
1008461a8:     	movk	x9, #0x9e37, lsl #48
1008461ac:     	mul	x8, x8, x9
1008461b0:     	lsr	x10, x8, #54
1008461b4:     	lsr	x11, x8, #60
1008461b8:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1008461bc:     	add	x9, x9, #0xf30
1008461c0:     	add	x11, x9, x11, lsl #3
1008461c4:     	ldapr	x11, [x11]
1008461c8:     	lsr	x10, x11, x10
1008461cc:     	tbz	w10, #0x0, 0x100846208 <_js_json_stringify_full+0x708>
1008461d0:     	lsr	x10, x8, #44
1008461d4:     	ubfx	x11, x8, #50, #4
1008461d8:     	add	x11, x9, x11, lsl #3
1008461dc:     	ldapr	x11, [x11]
1008461e0:     	lsr	x10, x11, x10
1008461e4:     	tbz	w10, #0x0, 0x100846208 <_js_json_stringify_full+0x708>
1008461e8:     	lsr	x10, x8, #34
1008461ec:     	ubfx	x8, x8, #40, #4
1008461f0:     	add	x8, x9, x8, lsl #3
1008461f4:     	ldapr	x8, [x8]
1008461f8:     	lsr	x8, x8, x10
1008461fc:     	tbz	w8, #0x0, 0x100846208 <_js_json_stringify_full+0x708>
100846200:     	bl	0x10034ca2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100846204:     	tbnz	w0, #0x0, 0x100846fa8 <_js_json_stringify_full+0x14a8>
100846208:     	cmp	x24, #0x3
10084620c:     	ccmp	x27, #0x2, #0x2, lo
100846210:     	b.hs	0x100846230 <_js_json_stringify_full+0x730>
100846214:     	mov.16b	v0, v8
100846218:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084621c:     	cmp	x0, #0x1
100846220:     	b.ne	0x100846230 <_js_json_stringify_full+0x730>
100846224:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846228:     	bfxil	x20, x1, #0, #48
10084622c:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
100846230:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846234:     	cmp	x22, x8
100846238:     	b.ne	0x100846288 <_js_json_stringify_full+0x788>
10084623c:     	ands	x22, x19, #0xffffffffffff
100846240:     	b.eq	0x100846288 <_js_json_stringify_full+0x788>
100846244:     	mov	x0, x22
100846248:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084624c:     	cbz	w0, 0x100846288 <_js_json_stringify_full+0x788>
100846250:     	ldurb	w8, [x22, #-0x8]
100846254:     	cmp	w8, #0x9
100846258:     	b.ne	0x100846288 <_js_json_stringify_full+0x788>
10084625c:     	ldr	w8, [x22, #0x4]
100846260:     	mov	w9, #0x5841             ; =22593
100846264:     	movk	w9, #0x4c5a, lsl #16
100846268:     	cmp	w8, w9
10084626c:     	b.ne	0x100846288 <_js_json_stringify_full+0x788>
100846270:     	mov	x0, x22
100846274:     	bl	0x100688364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100846278:     	cbz	x0, 0x100846288 <_js_json_stringify_full+0x788>
10084627c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100846280:     	bfxil	x19, x0, #0, #48
100846284:     	fmov	d8, x19
100846288:     	mov	w8, #0x7ffd             ; =32765
10084628c:     	cmp	x8, x23, lsr #48
100846290:     	b.ne	0x1008462a4 <_js_json_stringify_full+0x7a4>
100846294:     	and	x1, x23, #0xffffffffffff
100846298:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084629c:     	b.hs	0x1008462b8 <_js_json_stringify_full+0x7b8>
1008462a0:     	b	0x10084630c <_js_json_stringify_full+0x80c>
1008462a4:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
1008462a8:     	mov	x9, #0xfffffff00000     ; =281474975662080
1008462ac:     	mov	x1, x23
1008462b0:     	cmp	x8, x9
1008462b4:     	b.hs	0x10084630c <_js_json_stringify_full+0x80c>
1008462b8:     	lsr	x8, x1, #47
1008462bc:     	cbnz	x8, 0x10084630c <_js_json_stringify_full+0x80c>
1008462c0:     	add	x0, sp, #0x80
1008462c4:     	bl	0x10076e16c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
1008462c8:     	ldr	w8, [sp, #0x80]
1008462cc:     	tbz	w8, #0x0, 0x10084630c <_js_json_stringify_full+0x80c>
1008462d0:     	ldr	w8, [sp, #0x88]
1008462d4:     	mov	w9, #-0xff30            ; =-65328
1008462d8:     	cmp	w8, w9
1008462dc:     	b.eq	0x100846300 <_js_json_stringify_full+0x800>
1008462e0:     	mov	w9, #-0xff2f            ; =-65327
1008462e4:     	cmp	w8, w9
1008462e8:     	b.ne	0x10084630c <_js_json_stringify_full+0x80c>
1008462ec:     	mov.16b	v0, v9
1008462f0:     	bl	0x1008483bc <_js_jsvalue_to_string>
1008462f4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1008462f8:     	bfxil	x23, x0, #0, #48
1008462fc:     	b	0x10084630c <_js_json_stringify_full+0x80c>
100846300:     	mov.16b	v0, v9
100846304:     	bl	0x10086f960 <_js_number_coerce>
100846308:     	fmov	x23, d0
10084630c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100846310:     	add	x8, x23, x8
100846314:     	cmp	x8, #0x3
100846318:     	b.hs	0x100846330 <_js_json_stringify_full+0x830>
10084631c:     	mov	x22, #0x0               ; =0
100846320:     	mov	w8, #0x1                ; =1
100846324:     	stp	xzr, x8, [sp, #0x10]
100846328:     	str	xzr, [sp, #0x20]
10084632c:     	b	0x1008465e4 <_js_json_stringify_full+0xae4>
100846330:     	and	x8, x23, #0xffff000000000000
100846334:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846338:     	cmp	x8, x9
10084633c:     	b.eq	0x100846360 <_js_json_stringify_full+0x860>
100846340:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846344:     	cmp	x8, x9
100846348:     	b.ne	0x1008463ec <_js_json_stringify_full+0x8ec>
10084634c:     	and	x8, x23, #0xffffffffffff
100846350:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846354:     	b.hs	0x100846434 <_js_json_stringify_full+0x934>
100846358:     	mov	x9, #0x0                ; =0
10084635c:     	b	0x10084643c <_js_json_stringify_full+0x93c>
100846360:     	strb	wzr, [sp, #0x4c]
100846364:     	str	wzr, [sp, #0x48]
100846368:     	ubfx	x1, x23, #40, #8
10084636c:     	cbz	x1, 0x1008463bc <_js_json_stringify_full+0x8bc>
100846370:     	strb	w23, [sp, #0x48]
100846374:     	cmp	x1, #0x1
100846378:     	b.eq	0x1008463bc <_js_json_stringify_full+0x8bc>
10084637c:     	lsr	x8, x23, #8
100846380:     	strb	w8, [sp, #0x49]
100846384:     	cmp	x1, #0x2
100846388:     	b.eq	0x1008463bc <_js_json_stringify_full+0x8bc>
10084638c:     	lsr	x8, x23, #16
100846390:     	strb	w8, [sp, #0x4a]
100846394:     	cmp	x1, #0x3
100846398:     	b.eq	0x1008463bc <_js_json_stringify_full+0x8bc>
10084639c:     	lsr	x8, x23, #24
1008463a0:     	strb	w8, [sp, #0x4b]
1008463a4:     	cmp	x1, #0x4
1008463a8:     	b.eq	0x1008463bc <_js_json_stringify_full+0x8bc>
1008463ac:     	lsr	x8, x23, #32
1008463b0:     	strb	w8, [sp, #0x4c]
1008463b4:     	cmp	x1, #0x5
1008463b8:     	b.ne	0x10084777c <_js_json_stringify_full+0x1c7c>
1008463bc:     	add	x8, sp, #0x80
1008463c0:     	add	x0, sp, #0x48
1008463c4:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1008463c8:     	ldr	w8, [sp, #0x80]
1008463cc:     	ldp	x9, x22, [sp, #0x88]
1008463d0:     	cmp	w8, #0x0
1008463d4:     	csinc	x23, x9, xzr, eq
1008463d8:     	csel	x25, xzr, x22, ne
1008463dc:     	tbz	x25, #0x3f, 0x10084651c <_js_json_stringify_full+0xa1c>
1008463e0:     	mov	x0, #0x0                ; =0
1008463e4:     	mov	x1, x22
1008463e8:     	bl	0x100b12340 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008463ec:     	add	x8, x20, #0x3
1008463f0:     	cmp	x23, x8
1008463f4:     	b.eq	0x10084631c <_js_json_stringify_full+0x81c>
1008463f8:     	fmov	d0, x23
1008463fc:     	fcvtzu	x8, d0
100846400:     	mov	w9, #0xa                ; =10
100846404:     	cmp	x8, #0xa
100846408:     	csel	x3, x8, x9, lo
10084640c:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x1ab4>
100846410:     	add	x1, x1, #0x6dc
100846414:     	add	x0, sp, #0x80
100846418:     	mov	w2, #0x1                ; =1
10084641c:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100846420:     	ldr	x22, [sp, #0x90]
100846424:     	str	x22, [sp, #0x20]
100846428:     	ldr	q0, [sp, #0x80]
10084642c:     	str	q0, [sp, #0x10]
100846430:     	b	0x1008465e4 <_js_json_stringify_full+0xae4>
100846434:     	ldr	w22, [x8, #0x4]
100846438:     	add	x9, x8, #0x14
10084643c:     	mov	x14, #0x0               ; =0
100846440:     	mov	x8, #0x0                ; =0
100846444:     	cmp	x9, #0x0
100846448:     	csel	x24, xzr, x22, eq
10084644c:     	csinc	x23, x9, xzr, ne
100846450:     	add	x9, x23, x24
100846454:     	mov	w10, #0x1               ; =1
100846458:     	mov	x11, x23
10084645c:     	b	0x10084648c <_js_json_stringify_full+0x98c>
100846460:     	add	x12, x11, #0x2
100846464:     	bfi	w15, w13, #6, #5
100846468:     	mov	x13, x15
10084646c:     	sub	x11, x25, x11
100846470:     	add	x14, x11, x12
100846474:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100846478:     	cinc	x11, x10, hs
10084647c:     	add	x8, x11, x8
100846480:     	mov	x11, x12
100846484:     	cmp	x8, #0xa
100846488:     	b.hi	0x100846544 <_js_json_stringify_full+0xa44>
10084648c:     	cmp	x11, x9
100846490:     	b.eq	0x1008464f4 <_js_json_stringify_full+0x9f4>
100846494:     	mov	x25, x14
100846498:     	mov	x12, x11
10084649c:     	ldrsb	w14, [x12], #0x1
1008464a0:     	and	w13, w14, #0xff
1008464a4:     	tbz	w14, #0x1f, 0x10084646c <_js_json_stringify_full+0x96c>
1008464a8:     	ldrb	w12, [x11, #0x1]
1008464ac:     	and	w15, w12, #0x3f
1008464b0:     	cmp	w13, #0xe0
1008464b4:     	b.lo	0x100846460 <_js_json_stringify_full+0x960>
1008464b8:     	and	w14, w13, #0x1f
1008464bc:     	ldrb	w12, [x11, #0x2]
1008464c0:     	and	w12, w12, #0x3f
1008464c4:     	orr	w15, w12, w15, lsl #6
1008464c8:     	cmp	w13, #0xf0
1008464cc:     	b.lo	0x1008464e8 <_js_json_stringify_full+0x9e8>
1008464d0:     	add	x12, x11, #0x4
1008464d4:     	ldrb	w13, [x11, #0x3]
1008464d8:     	and	w13, w13, #0x3f
1008464dc:     	orr	w13, w13, w15, lsl #6
1008464e0:     	bfi	w13, w14, #18, #3
1008464e4:     	b	0x10084646c <_js_json_stringify_full+0x96c>
1008464e8:     	add	x12, x11, #0x3
1008464ec:     	orr	w13, w15, w14, lsl #12
1008464f0:     	b	0x10084646c <_js_json_stringify_full+0x96c>
1008464f4:     	cbz	x24, 0x100846578 <_js_json_stringify_full+0xa78>
1008464f8:     	mov	x0, x24
1008464fc:     	mov	w1, #0x1                ; =1
100846500:     	bl	0x100b5f208 <_mi_malloc_aligned>
100846504:     	cbz	x0, 0x100847764 <_js_json_stringify_full+0x1c64>
100846508:     	mov	x26, x0
10084650c:     	mov	x1, x23
100846510:     	mov	x2, x24
100846514:     	bl	0x100b61e2c <_writev+0x100b61e2c>
100846518:     	b	0x100846580 <_js_json_stringify_full+0xa80>
10084651c:     	cbz	x25, 0x1008465d4 <_js_json_stringify_full+0xad4>
100846520:     	mov	x0, x25
100846524:     	mov	w1, #0x1                ; =1
100846528:     	bl	0x100b5f208 <_mi_malloc_aligned>
10084652c:     	cbz	x0, 0x100847770 <_js_json_stringify_full+0x1c70>
100846530:     	mov	x24, x0
100846534:     	mov	x1, x23
100846538:     	mov	x2, x25
10084653c:     	bl	0x100b61e2c <_writev+0x100b61e2c>
100846540:     	b	0x1008465dc <_js_json_stringify_full+0xadc>
100846544:     	cbz	x25, 0x100846578 <_js_json_stringify_full+0xa78>
100846548:     	cmp	x25, x24
10084654c:     	b.hs	0x100846ff4 <_js_json_stringify_full+0x14f4>
100846550:     	ldrsb	w8, [x23, x25]
100846554:     	cmn	w8, #0x40
100846558:     	b.ge	0x100846ff8 <_js_json_stringify_full+0x14f8>
10084655c:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846560:     	add	x4, x4, #0x270
100846564:     	mov	x0, x23
100846568:     	mov	x1, x24
10084656c:     	mov	x2, #0x0                ; =0
100846570:     	mov	x3, x25
100846574:     	bl	0x100b126b8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100846578:     	mov	x22, #0x0               ; =0
10084657c:     	mov	w26, #0x1               ; =1
100846580:     	stp	x22, x26, [sp, #0x10]
100846584:     	b	0x1008465e0 <_js_json_stringify_full+0xae0>
100846588:     	add	x14, sp, #0x80
10084658c:     	mov	w16, #0x5c              ; =92
100846590:     	strb	w16, [x14, x12]
100846594:     	add	x12, x12, #0x2
100846598:     	strb	w15, [x13, #0x1]
10084659c:     	cmp	w10, #0x2
1008465a0:     	b.eq	0x100845d04 <_js_json_stringify_full+0x204>
1008465a4:     	ldrb	w11, [x11, #0x2]
1008465a8:     	sxtb	w10, w11
1008465ac:     	cmp	w11, #0xb
1008465b0:     	b.le	0x100847080 <_js_json_stringify_full+0x1580>
1008465b4:     	cmp	w11, #0x21
1008465b8:     	b.gt	0x1008470cc <_js_json_stringify_full+0x15cc>
1008465bc:     	cmp	w11, #0xc
1008465c0:     	b.eq	0x100847158 <_js_json_stringify_full+0x1658>
1008465c4:     	cmp	w11, #0xd
1008465c8:     	b.ne	0x1008470dc <_js_json_stringify_full+0x15dc>
1008465cc:     	mov	w10, #0x72              ; =114
1008465d0:     	b	0x100847164 <_js_json_stringify_full+0x1664>
1008465d4:     	mov	x22, #0x0               ; =0
1008465d8:     	mov	w24, #0x1               ; =1
1008465dc:     	stp	x22, x24, [sp, #0x10]
1008465e0:     	str	x22, [sp, #0x20]
1008465e4:     	cmp	x27, #0x2
1008465e8:     	b.lo	0x100846728 <_js_json_stringify_full+0xc28>
1008465ec:     	and	x25, x21, #0xffff000000000000
1008465f0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008465f4:     	cmp	x25, x8
1008465f8:     	b.ne	0x100846704 <_js_json_stringify_full+0xc04>
1008465fc:     	and	x23, x21, #0xffffffffffff
100846600:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100846604:     	b.lo	0x100846728 <_js_json_stringify_full+0xc28>
100846608:     	mov	x0, x23
10084660c:     	bl	0x10050a640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100846610:     	tbnz	w0, #0x0, 0x100846728 <_js_json_stringify_full+0xc28>
100846614:     	lsr	x8, x23, #51
100846618:     	cmp	x8, #0xfff
10084661c:     	b.lo	0x100846634 <_js_json_stringify_full+0xb34>
100846620:     	mov	w8, #0x7ffc             ; =32764
100846624:     	cmp	x8, x23, lsr #48
100846628:     	b.eq	0x100846728 <_js_json_stringify_full+0xc28>
10084662c:     	ands	x23, x23, #0xffffffffffff
100846630:     	b.eq	0x100846728 <_js_json_stringify_full+0xc28>
100846634:     	and	x8, x23, #0xfffffffffff00000
100846638:     	lsr	x9, x23, #47
10084663c:     	cmp	x9, #0x0
100846640:     	ccmp	x8, #0x0, #0x4, eq
100846644:     	b.eq	0x100846728 <_js_json_stringify_full+0xc28>
100846648:     	tst	x23, #0x3
10084664c:     	ccmp	x23, #0x7, #0x0, eq
100846650:     	b.ls	0x100847394 <_js_json_stringify_full+0x1894>
100846654:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100846658:     	ldr	x8, [x8, #0x48]
10084665c:     	cmn	x8, #0x1
100846660:     	b.eq	0x1008472e4 <_js_json_stringify_full+0x17e4>
100846664:     	mrs	x9, TPIDRRO_EL0
100846668:     	and	x9, x9, #0xfffffffffffffff8
10084666c:     	ldr	x0, [x9, x8, lsl #3]
100846670:     	cbz	x0, 0x1008472e4 <_js_json_stringify_full+0x17e4>
100846674:     	lsr	x1, x23, #20
100846678:     	ldr	x8, [x0, #0x10]
10084667c:     	ldrb	w9, [x8]
100846680:     	cmp	w9, #0x2
100846684:     	b.ne	0x1008472fc <_js_json_stringify_full+0x17fc>
100846688:     	ldrb	w9, [x8, #0x88]
10084668c:     	tbz	w9, #0x0, 0x1008466ac <_js_json_stringify_full+0xbac>
100846690:     	ldr	x9, [x8, #0x80]
100846694:     	cmp	x9, x1
100846698:     	b.ne	0x1008466ac <_js_json_stringify_full+0xbac>
10084669c:     	ldp	x9, x10, [x8, #0x60]
1008466a0:     	cmp	x9, x23
1008466a4:     	ccmp	x10, x23, #0x0, ls
1008466a8:     	b.hi	0x1008472dc <_js_json_stringify_full+0x17dc>
1008466ac:     	ldrb	w9, [x8, #0xb8]
1008466b0:     	cbz	w9, 0x1008466d0 <_js_json_stringify_full+0xbd0>
1008466b4:     	ldr	x9, [x8, #0xb0]
1008466b8:     	cmp	x9, x1
1008466bc:     	b.ne	0x1008466d0 <_js_json_stringify_full+0xbd0>
1008466c0:     	ldp	x9, x10, [x8, #0x90]
1008466c4:     	cmp	x9, x23
1008466c8:     	ccmp	x10, x23, #0x0, ls
1008466cc:     	b.hi	0x100847564 <_js_json_stringify_full+0x1a64>
1008466d0:     	ldrb	w9, [x8, #0xe8]
1008466d4:     	cbz	w9, 0x10084711c <_js_json_stringify_full+0x161c>
1008466d8:     	ldr	x9, [x8, #0xe0]
1008466dc:     	cmp	x9, x1
1008466e0:     	b.ne	0x10084711c <_js_json_stringify_full+0x161c>
1008466e4:     	ldr	x9, [x8, #0xc0]
1008466e8:     	cmp	x9, x23
1008466ec:     	b.hi	0x10084711c <_js_json_stringify_full+0x161c>
1008466f0:     	ldr	x9, [x8, #0xc8]
1008466f4:     	cmp	x9, x23
1008466f8:     	b.ls	0x10084711c <_js_json_stringify_full+0x161c>
1008466fc:     	add	x9, x8, #0xc0
100846700:     	b	0x100847568 <_js_json_stringify_full+0x1a68>
100846704:     	lsr	x8, x21, #52
100846708:     	cbnz	x8, 0x100846728 <_js_json_stringify_full+0xc28>
10084670c:     	cbz	x21, 0x100846728 <_js_json_stringify_full+0xc28>
100846710:     	and	x8, x21, #0x7
100846714:     	cbnz	x8, 0x100846728 <_js_json_stringify_full+0xc28>
100846718:     	mov	x0, x21
10084671c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846720:     	mov	x23, x21
100846724:     	cbnz	w0, 0x100846600 <_js_json_stringify_full+0xb00>
100846728:     	mov	x25, #-0x1              ; =-1
10084672c:     	str	x25, [sp, #0x30]
100846730:     	mov	w24, #0x1               ; =1
100846734:     	cmp	x27, #0x1
100846738:     	cset	w8, hi
10084673c:     	tst	w8, w24
100846740:     	b.eq	0x1008467b4 <_js_json_stringify_full+0xcb4>
100846744:     	and	x23, x21, #0xffff000000000000
100846748:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084674c:     	cmp	x23, x8
100846750:     	b.ne	0x10084678c <_js_json_stringify_full+0xc8c>
100846754:     	and	x8, x21, #0xffffffffffff
100846758:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084675c:     	b.lo	0x1008467b4 <_js_json_stringify_full+0xcb4>
100846760:     	ldr	w8, [x8, #0xc]
100846764:     	mov	w9, #0x4f53             ; =20307
100846768:     	movk	w9, #0x434c, lsl #16
10084676c:     	cmp	w8, w9
100846770:     	b.ne	0x1008467b4 <_js_json_stringify_full+0xcb4>
100846774:     	and	x8, x21, #0xffffffffffff
100846778:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084677c:     	cmp	x23, x9
100846780:     	csel	x28, x8, x21, eq
100846784:     	mov	w27, #0x1               ; =1
100846788:     	b	0x1008467b8 <_js_json_stringify_full+0xcb8>
10084678c:     	lsr	x8, x21, #52
100846790:     	cbnz	x8, 0x1008467b4 <_js_json_stringify_full+0xcb4>
100846794:     	mov	w27, #0x0               ; =0
100846798:     	cbz	x21, 0x1008467b8 <_js_json_stringify_full+0xcb8>
10084679c:     	and	x8, x21, #0x7
1008467a0:     	cbnz	x8, 0x1008467b8 <_js_json_stringify_full+0xcb8>
1008467a4:     	mov	x0, x21
1008467a8:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008467ac:     	mov	x8, x21
1008467b0:     	tbnz	w0, #0x0, 0x100846758 <_js_json_stringify_full+0xc58>
1008467b4:     	mov	w27, #0x0               ; =0
1008467b8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008467bc:     	add	x0, x0, #0xd78
1008467c0:     	ldr	x8, [x0]
1008467c4:     	blr	x8
1008467c8:     	mov	x21, x0
1008467cc:     	ldr	w26, [x0]
1008467d0:     	add	w8, w26, #0x1
1008467d4:     	str	w8, [x0]
1008467d8:     	cbz	w26, 0x100846848 <_js_json_stringify_full+0xd48>
1008467dc:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008467e0:     	add	x0, x0, #0xd00
1008467e4:     	ldr	x8, [x0]
1008467e8:     	blr	x8
1008467ec:     	ldrb	w8, [x0, #0x20]
1008467f0:     	cmp	w8, #0x1
1008467f4:     	b.ne	0x1008475d4 <_js_json_stringify_full+0x1ad4>
1008467f8:     	ldr	x8, [x0]
1008467fc:     	cbnz	x8, 0x1008475e0 <_js_json_stringify_full+0x1ae0>
100846800:     	mov	x8, #-0x1               ; =-1
100846804:     	str	x8, [x0]
100846808:     	ldr	x23, [x0, #0x18]
10084680c:     	ldr	x8, [x0, #0x8]
100846810:     	cmp	x23, x8
100846814:     	b.eq	0x100846fd0 <_js_json_stringify_full+0x14d0>
100846818:     	ldr	x8, [x0, #0x10]
10084681c:     	mov	w9, #0x18               ; =24
100846820:     	madd	x8, x23, x9, x8
100846824:     	mov	w9, #0x8                ; =8
100846828:     	stp	xzr, x9, [x8]
10084682c:     	str	xzr, [x8, #0x10]
100846830:     	add	x8, x23, #0x1
100846834:     	str	x8, [x0, #0x18]
100846838:     	ldr	x8, [x0]
10084683c:     	add	x8, x8, #0x1
100846840:     	str	x8, [x0]
100846844:     	b	0x1008468b0 <_js_json_stringify_full+0xdb0>
100846848:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084684c:     	add	x0, x0, #0xdc0
100846850:     	ldr	x8, [x0]
100846854:     	blr	x8
100846858:     	strb	wzr, [x0]
10084685c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846860:     	add	x0, x0, #0xdf0
100846864:     	ldr	x8, [x0]
100846868:     	blr	x8
10084686c:     	strb	wzr, [x0]
100846870:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100846874:     	ldr	w23, [x8, #0x5a8]
100846878:     	cmp	w23, #0x300
10084687c:     	b.hs	0x100847018 <_js_json_stringify_full+0x1518>
100846880:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100846884:     	ldr	x8, [x8, #0x48]
100846888:     	cmn	x8, #0x1
10084688c:     	b.eq	0x100847008 <_js_json_stringify_full+0x1508>
100846890:     	mrs	x9, TPIDRRO_EL0
100846894:     	and	x9, x9, #0xfffffffffffffff8
100846898:     	ldr	x0, [x9, x8, lsl #3]
10084689c:     	cbz	x0, 0x100847008 <_js_json_stringify_full+0x1508>
1008468a0:     	add	x8, x0, x23, lsl #3
1008468a4:     	ldr	x0, [x8, #0x1e8]
1008468a8:     	cbz	x0, 0x100847018 <_js_json_stringify_full+0x1518>
1008468ac:     	str	xzr, [x0]
1008468b0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008468b4:     	add	x0, x0, #0xd30
1008468b8:     	ldr	x8, [x0]
1008468bc:     	blr	x8
1008468c0:     	mov	x23, x0
1008468c4:     	ldrb	w8, [x0, #0x18]
1008468c8:     	cmp	w8, #0x1
1008468cc:     	b.ne	0x100847588 <_js_json_stringify_full+0x1a88>
1008468d0:     	ldr	x8, [x0]
1008468d4:     	mov	x9, #-0x1               ; =-1
1008468d8:     	str	x9, [x0]
1008468dc:     	cmn	x8, #0x2
1008468e0:     	b.eq	0x100847710 <_js_json_stringify_full+0x1c10>
1008468e4:     	cmn	x8, #0x1
1008468e8:     	b.eq	0x1008469bc <_js_json_stringify_full+0xebc>
1008468ec:     	add	x9, sp, #0x48
1008468f0:     	ldur	q0, [x0, #0x8]
1008468f4:     	stur	q0, [x9, #0x8]
1008468f8:     	str	x8, [sp, #0x48]
1008468fc:     	tbz	w24, #0x0, 0x1008469d0 <_js_json_stringify_full+0xed0>
100846900:     	tbz	w27, #0x0, 0x100846ab8 <_js_json_stringify_full+0xfb8>
100846904:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100846908:     	str	x0, [sp, #0x60]
10084690c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846910:     	stp	x28, x8, [sp, #0x88]
100846914:     	mov	w8, #0x1                ; =1
100846918:     	str	x8, [sp, #0x80]
10084691c:     	add	x0, sp, #0x80
100846920:     	bl	0x10028b520 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100846924:     	mov	x22, x0
100846928:     	str	x0, [sp, #0x68]
10084692c:     	mov	w0, #0x0                ; =0
100846930:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846934:     	stp	xzr, xzr, [x0]
100846938:     	str	wzr, [x0, #0x10]
10084693c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846940:     	bfxil	x8, x0, #0, #48
100846944:     	fmov	d0, x8
100846948:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084694c:     	mov	x19, x0
100846950:     	adrp	x24, 0x100f7c000 <_perry_global_worker_ts__1>
100846954:     	ldr	x8, [x24, #0x48]
100846958:     	cmn	x8, #0x1
10084695c:     	b.eq	0x100846b1c <_js_json_stringify_full+0x101c>
100846960:     	mrs	x9, TPIDRRO_EL0
100846964:     	and	x9, x9, #0xfffffffffffffff8
100846968:     	ldr	x8, [x9, x8, lsl #3]
10084696c:     	cbz	x8, 0x100846b1c <_js_json_stringify_full+0x101c>
100846970:     	ldr	x8, [x8, #0x19e8]
100846974:     	cbz	x8, 0x100846b1c <_js_json_stringify_full+0x101c>
100846978:     	ldr	x9, [x8]
10084697c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846980:     	cmp	x9, x10
100846984:     	b.hs	0x10084765c <_js_json_stringify_full+0x1b5c>
100846988:     	add	x10, x9, #0x1
10084698c:     	str	x10, [x8]
100846990:     	ldr	x10, [x8, #0x18]
100846994:     	cmp	x19, x10
100846998:     	b.hs	0x100847668 <_js_json_stringify_full+0x1b68>
10084699c:     	ldr	x10, [x8, #0x10]
1008469a0:     	mov	w11, #0x18              ; =24
1008469a4:     	madd	x10, x19, x11, x10
1008469a8:     	ldr	x11, [x10]
1008469ac:     	cbnz	x11, 0x1008476c8 <_js_json_stringify_full+0x1bc8>
1008469b0:     	ldr	x0, [x10, #0x8]
1008469b4:     	str	x9, [x8]
1008469b8:     	b	0x100846b24 <_js_json_stringify_full+0x1024>
1008469bc:     	mov	x8, #0x0                ; =0
1008469c0:     	mov	w9, #0x1                ; =1
1008469c4:     	stp	x9, xzr, [sp, #0x50]
1008469c8:     	str	x8, [sp, #0x48]
1008469cc:     	tbnz	w24, #0x0, 0x100846900 <_js_json_stringify_full+0xe00>
1008469d0:     	cmp	x22, #0x0
1008469d4:     	cset	w6, ne
1008469d8:     	ldp	x0, x1, [sp, #0x38]
1008469dc:     	ldp	x3, x4, [sp, #0x18]
1008469e0:     	add	x2, sp, #0x48
1008469e4:     	mov.16b	v0, v8
1008469e8:     	mov	x5, #0x0                ; =0
1008469ec:     	bl	0x100502e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
1008469f0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008469f4:     	add	x0, x0, #0xd90
1008469f8:     	ldr	x8, [x0]
1008469fc:     	blr	x8
100846a00:     	ldrb	w8, [x0, #0x20]
100846a04:     	cbnz	w8, 0x1008475ec <_js_json_stringify_full+0x1aec>
100846a08:     	ldr	x8, [x0]
100846a0c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100846a10:     	cmp	x8, x9
100846a14:     	b.hs	0x10084761c <_js_json_stringify_full+0x1b1c>
100846a18:     	ldr	x9, [x0, #0x18]
100846a1c:     	cbz	x9, 0x100846a28 <_js_json_stringify_full+0xf28>
100846a20:     	cbnz	x8, 0x100847628 <_js_json_stringify_full+0x1b28>
100846a24:     	str	xzr, [x0, #0x18]
100846a28:     	ldp	x0, x1, [sp, #0x50]
100846a2c:     	cmp	x1, #0x5
100846a30:     	b.hi	0x100846a98 <_js_json_stringify_full+0xf98>
100846a34:     	cbz	x1, 0x100846ca8 <_js_json_stringify_full+0x11a8>
100846a38:     	ldrsb	w8, [x0]
100846a3c:     	tbnz	w8, #0x1f, 0x100846a98 <_js_json_stringify_full+0xf98>
100846a40:     	cmp	x1, #0x1
100846a44:     	b.eq	0x100846a80 <_js_json_stringify_full+0xf80>
100846a48:     	ldrsb	w8, [x0, #0x1]
100846a4c:     	tbnz	w8, #0x1f, 0x100846a98 <_js_json_stringify_full+0xf98>
100846a50:     	cmp	x1, #0x2
100846a54:     	b.eq	0x100846a80 <_js_json_stringify_full+0xf80>
100846a58:     	ldrsb	w8, [x0, #0x2]
100846a5c:     	tbnz	w8, #0x1f, 0x100846a98 <_js_json_stringify_full+0xf98>
100846a60:     	cmp	x1, #0x3
100846a64:     	b.eq	0x100846a80 <_js_json_stringify_full+0xf80>
100846a68:     	ldrsb	w8, [x0, #0x3]
100846a6c:     	tbnz	w8, #0x1f, 0x100846a98 <_js_json_stringify_full+0xf98>
100846a70:     	cmp	x1, #0x4
100846a74:     	b.eq	0x100846a80 <_js_json_stringify_full+0xf80>
100846a78:     	ldrsb	w8, [x0, #0x4]
100846a7c:     	tbnz	w8, #0x1f, 0x100846a98 <_js_json_stringify_full+0xf98>
100846a80:     	cmp	x1, #0x4
100846a84:     	b.hs	0x100846de8 <_js_json_stringify_full+0x12e8>
100846a88:     	mov	x10, #0x0               ; =0
100846a8c:     	mov	x9, #0x0                ; =0
100846a90:     	mov	x8, x0
100846a94:     	b	0x100846e78 <_js_json_stringify_full+0x1378>
100846a98:     	bl	0x100329e88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846a9c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846aa0:     	bfxil	x20, x0, #0, #48
100846aa4:     	ldp	x22, x0, [sp, #0x48]
100846aa8:     	ldrb	w8, [x23, #0x18]
100846aac:     	cmp	w8, #0x1
100846ab0:     	b.eq	0x100846eb4 <_js_json_stringify_full+0x13b4>
100846ab4:     	b	0x1008475b8 <_js_json_stringify_full+0x1ab8>
100846ab8:     	mov	w0, #0x0                ; =0
100846abc:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846ac0:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846ac4:     	bfxil	x8, x0, #0, #48
100846ac8:     	fmov	d1, x8
100846acc:     	stp	xzr, xzr, [x0]
100846ad0:     	str	wzr, [x0, #0x10]
100846ad4:     	mov.16b	v0, v8
100846ad8:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846adc:     	mov.16b	v8, v0
100846ae0:     	fmov	x24, d8
100846ae4:     	cmp	x24, x20
100846ae8:     	b.eq	0x100846d30 <_js_json_stringify_full+0x1230>
100846aec:     	mov	w8, #0x7ffd             ; =32765
100846af0:     	cmp	x8, x24, lsr #48
100846af4:     	b.ne	0x100846d00 <_js_json_stringify_full+0x1200>
100846af8:     	and	x8, x24, #0xffffffffffff
100846afc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846b00:     	b.lo	0x100846d24 <_js_json_stringify_full+0x1224>
100846b04:     	ldr	w8, [x8, #0xc]
100846b08:     	mov	w9, #0x4f53             ; =20307
100846b0c:     	movk	w9, #0x434c, lsl #16
100846b10:     	cmp	w8, w9
100846b14:     	b.ne	0x100846d24 <_js_json_stringify_full+0x1224>
100846b18:     	b	0x100846d30 <_js_json_stringify_full+0x1230>
100846b1c:     	mov	x0, x19
100846b20:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846b24:     	fmov	d1, x0
100846b28:     	mov.16b	v0, v8
100846b2c:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846b30:     	mov.16b	v8, v0
100846b34:     	ldr	x8, [x24, #0x48]
100846b38:     	cmn	x8, #0x1
100846b3c:     	b.eq	0x100846ba0 <_js_json_stringify_full+0x10a0>
100846b40:     	mrs	x9, TPIDRRO_EL0
100846b44:     	and	x9, x9, #0xfffffffffffffff8
100846b48:     	ldr	x8, [x9, x8, lsl #3]
100846b4c:     	cbz	x8, 0x100846ba0 <_js_json_stringify_full+0x10a0>
100846b50:     	ldr	x8, [x8, #0x19e8]
100846b54:     	cbz	x8, 0x100846ba0 <_js_json_stringify_full+0x10a0>
100846b58:     	ldr	x9, [x8]
100846b5c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846b60:     	cmp	x9, x10
100846b64:     	b.hs	0x10084765c <_js_json_stringify_full+0x1b5c>
100846b68:     	add	x10, x9, #0x1
100846b6c:     	str	x10, [x8]
100846b70:     	ldr	x10, [x8, #0x18]
100846b74:     	cmp	x22, x10
100846b78:     	b.hs	0x100847668 <_js_json_stringify_full+0x1b68>
100846b7c:     	ldr	x10, [x8, #0x10]
100846b80:     	mov	w11, #0x18              ; =24
100846b84:     	madd	x10, x22, x11, x10
100846b88:     	ldr	x11, [x10]
100846b8c:     	cmp	x11, #0x1
100846b90:     	b.ne	0x100847728 <_js_json_stringify_full+0x1c28>
100846b94:     	ldr	x22, [x10, #0x8]
100846b98:     	str	x9, [x8]
100846b9c:     	b	0x100846bac <_js_json_stringify_full+0x10ac>
100846ba0:     	mov	x0, x22
100846ba4:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846ba8:     	mov	x22, x0
100846bac:     	ldr	x8, [x24, #0x48]
100846bb0:     	cmn	x8, #0x1
100846bb4:     	b.eq	0x100846c14 <_js_json_stringify_full+0x1114>
100846bb8:     	mrs	x9, TPIDRRO_EL0
100846bbc:     	and	x9, x9, #0xfffffffffffffff8
100846bc0:     	ldr	x8, [x9, x8, lsl #3]
100846bc4:     	cbz	x8, 0x100846c14 <_js_json_stringify_full+0x1114>
100846bc8:     	ldr	x8, [x8, #0x19e8]
100846bcc:     	cbz	x8, 0x100846c14 <_js_json_stringify_full+0x1114>
100846bd0:     	ldr	x9, [x8]
100846bd4:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846bd8:     	cmp	x9, x10
100846bdc:     	b.hs	0x10084765c <_js_json_stringify_full+0x1b5c>
100846be0:     	add	x10, x9, #0x1
100846be4:     	str	x10, [x8]
100846be8:     	ldr	x10, [x8, #0x18]
100846bec:     	cmp	x19, x10
100846bf0:     	b.hs	0x100847668 <_js_json_stringify_full+0x1b68>
100846bf4:     	ldr	x10, [x8, #0x10]
100846bf8:     	mov	w11, #0x18              ; =24
100846bfc:     	madd	x10, x19, x11, x10
100846c00:     	ldr	x11, [x10]
100846c04:     	cbnz	x11, 0x1008476c8 <_js_json_stringify_full+0x1bc8>
100846c08:     	ldr	x0, [x10, #0x8]
100846c0c:     	str	x9, [x8]
100846c10:     	b	0x100846c1c <_js_json_stringify_full+0x111c>
100846c14:     	mov	x0, x19
100846c18:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846c1c:     	fmov	d9, x0
100846c20:     	mov.16b	v0, v8
100846c24:     	bl	0x1004ff434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100846c28:     	mov.16b	v2, v0
100846c2c:     	mov	x0, x22
100846c30:     	mov.16b	v0, v9
100846c34:     	mov.16b	v1, v8
100846c38:     	bl	0x1004ff714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100846c3c:     	str	d0, [sp, #0x70]
100846c40:     	fmov	x19, d0
100846c44:     	cmp	x19, x20
100846c48:     	b.ne	0x100846cb0 <_js_json_stringify_full+0x11b0>
100846c4c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846c50:     	add	x0, x0, #0xd90
100846c54:     	ldr	x8, [x0]
100846c58:     	blr	x8
100846c5c:     	ldrb	w8, [x0, #0x20]
100846c60:     	cbnz	w8, 0x100847708 <_js_json_stringify_full+0x1c08>
100846c64:     	ldr	x8, [x0]
100846c68:     	cbnz	x8, 0x100847758 <_js_json_stringify_full+0x1c58>
100846c6c:     	str	xzr, [x0, #0x18]
100846c70:     	ldp	x22, x19, [sp, #0x48]
100846c74:     	ldrb	w8, [x23, #0x18]
100846c78:     	cmp	w8, #0x1
100846c7c:     	b.ne	0x1008476a0 <_js_json_stringify_full+0x1ba0>
100846c80:     	ldp	x8, x0, [x23]
100846c84:     	stp	x22, x19, [x23]
100846c88:     	str	xzr, [x23, #0x10]
100846c8c:     	sub	x8, x8, #0x1
100846c90:     	cmn	x8, #0x2
100846c94:     	b.hs	0x100846c9c <_js_json_stringify_full+0x119c>
100846c98:     	bl	0x100b5ef80 <_mi_free>
100846c9c:     	cbz	w26, 0x100846f3c <_js_json_stringify_full+0x143c>
100846ca0:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846ca4:     	b	0x100846f40 <_js_json_stringify_full+0x1440>
100846ca8:     	mov	x10, #0x0               ; =0
100846cac:     	b	0x100846e98 <_js_json_stringify_full+0x1398>
100846cb0:     	add	x0, sp, #0x48
100846cb4:     	bl	0x100500470 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100846cb8:     	tbnz	w0, #0x0, 0x100846cf4 <_js_json_stringify_full+0x11f4>
100846cbc:     	mov	x0, x19
100846cc0:     	bl	0x100327dec <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100846cc4:     	cmp	x0, #0x1
100846cc8:     	b.ne	0x10084771c <_js_json_stringify_full+0x1c1c>
100846ccc:     	add	x8, sp, #0x78
100846cd0:     	add	x9, sp, #0x70
100846cd4:     	stp	x1, x8, [sp, #0x78]
100846cd8:     	str	x9, [sp, #0x88]
100846cdc:     	add	x8, sp, #0x48
100846ce0:     	add	x9, sp, #0x10
100846ce4:     	stp	x8, x9, [sp, #0x90]
100846ce8:     	add	x0, sp, #0x68
100846cec:     	add	x1, sp, #0x80
100846cf0:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100846cf4:     	add	x0, sp, #0x60
100846cf8:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846cfc:     	b	0x1008469f0 <_js_json_stringify_full+0xef0>
100846d00:     	lsr	x8, x24, #52
100846d04:     	cbnz	x8, 0x100846d24 <_js_json_stringify_full+0x1224>
100846d08:     	cbz	x24, 0x100846d24 <_js_json_stringify_full+0x1224>
100846d0c:     	and	x8, x24, #0x7
100846d10:     	cbnz	x8, 0x100846d24 <_js_json_stringify_full+0x1224>
100846d14:     	mov	x0, x24
100846d18:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846d1c:     	mov	x8, x24
100846d20:     	tbnz	w0, #0x0, 0x100846afc <_js_json_stringify_full+0xffc>
100846d24:     	mov	x0, x24
100846d28:     	bl	0x100509494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100846d2c:     	tbz	w0, #0x0, 0x100846dbc <_js_json_stringify_full+0x12bc>
100846d30:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846d34:     	add	x0, x0, #0xd90
100846d38:     	ldr	x8, [x0]
100846d3c:     	blr	x8
100846d40:     	ldrb	w8, [x0, #0x20]
100846d44:     	cbnz	w8, 0x10084766c <_js_json_stringify_full+0x1b6c>
100846d48:     	ldr	x8, [x0]
100846d4c:     	cbnz	x8, 0x100847694 <_js_json_stringify_full+0x1b94>
100846d50:     	str	xzr, [x0, #0x18]
100846d54:     	ldp	x22, x19, [sp, #0x48]
100846d58:     	ldrb	w8, [x23, #0x18]
100846d5c:     	cmp	w8, #0x1
100846d60:     	b.ne	0x100847648 <_js_json_stringify_full+0x1b48>
100846d64:     	ldp	x8, x0, [x23]
100846d68:     	stp	x22, x19, [x23]
100846d6c:     	str	xzr, [x23, #0x10]
100846d70:     	sub	x8, x8, #0x1
100846d74:     	cmn	x8, #0x2
100846d78:     	b.hs	0x100846d80 <_js_json_stringify_full+0x1280>
100846d7c:     	bl	0x100b5ef80 <_mi_free>
100846d80:     	cbz	w26, 0x100846da0 <_js_json_stringify_full+0x12a0>
100846d84:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846d88:     	ldr	w8, [x21]
100846d8c:     	sub	w8, w8, #0x1
100846d90:     	str	w8, [x21]
100846d94:     	cmn	x25, #0x1
100846d98:     	b.ne	0x100846f5c <_js_json_stringify_full+0x145c>
100846d9c:     	b	0x100846f98 <_js_json_stringify_full+0x1498>
100846da0:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846da4:     	ldr	w8, [x21]
100846da8:     	sub	w8, w8, #0x1
100846dac:     	str	w8, [x21]
100846db0:     	cmn	x25, #0x1
100846db4:     	b.ne	0x100846f5c <_js_json_stringify_full+0x145c>
100846db8:     	b	0x100846f98 <_js_json_stringify_full+0x1498>
100846dbc:     	cmp	x19, x24
100846dc0:     	b.eq	0x100846dcc <_js_json_stringify_full+0x12cc>
100846dc4:     	mov.16b	v0, v8
100846dc8:     	bl	0x10050e86c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100846dcc:     	cbz	x22, 0x100847028 <_js_json_stringify_full+0x1528>
100846dd0:     	ldp	x1, x2, [sp, #0x18]
100846dd4:     	add	x0, sp, #0x48
100846dd8:     	mov.16b	v0, v8
100846ddc:     	mov	x3, #0x0                ; =0
100846de0:     	bl	0x100500f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100846de4:     	b	0x100847038 <_js_json_stringify_full+0x1538>
100846de8:     	and	x9, x1, #0x4
100846dec:     	add	x8, x0, x9
100846df0:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e70>
100846df4:     	ldr	q0, [x10, #0xa00]
100846df8:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3367a>
100846dfc:     	ldr	q2, [x10, #0x900]
100846e00:     	movi.2d	v1, #0000000000000000
100846e04:     	movi.2d	v3, #0x000000000000ff
100846e08:     	mov	w10, #0x4               ; =4
100846e0c:     	dup.2d	v4, x10
100846e10:     	mov	x10, x0
100846e14:     	and	x11, x1, #0x4
100846e18:     	movi.2d	v5, #0000000000000000
100846e1c:     	ldr	s6, [x10], #0x4
100846e20:     	ushll.8h	v6, v6, #0x0
100846e24:     	ushll.4s	v6, v6, #0x0
100846e28:     	ushll2.2d	v7, v6, #0x0
100846e2c:     	and.16b	v7, v7, v3
100846e30:     	ushll.2d	v6, v6, #0x0
100846e34:     	and.16b	v6, v6, v3
100846e38:     	shl.2d	v16, v0, #0x3
100846e3c:     	shl.2d	v17, v2, #0x3
100846e40:     	ushl.2d	v6, v6, v17
100846e44:     	ushl.2d	v7, v7, v16
100846e48:     	orr.16b	v1, v7, v1
100846e4c:     	orr.16b	v5, v6, v5
100846e50:     	add.2d	v0, v0, v4
100846e54:     	add.2d	v2, v2, v4
100846e58:     	subs	x11, x11, #0x4
100846e5c:     	b.ne	0x100846e1c <_js_json_stringify_full+0x131c>
100846e60:     	orr.16b	v0, v5, v1
100846e64:     	mov	d1, v0[1]
100846e68:     	orr.8b	v0, v0, v1
100846e6c:     	fmov	x10, d0
100846e70:     	cmp	x1, x9
100846e74:     	b.eq	0x100846e98 <_js_json_stringify_full+0x1398>
100846e78:     	add	x11, x0, x1
100846e7c:     	lsl	x9, x9, #3
100846e80:     	ldrb	w12, [x8], #0x1
100846e84:     	lsl	x12, x12, x9
100846e88:     	orr	x10, x12, x10
100846e8c:     	add	x9, x9, #0x8
100846e90:     	cmp	x8, x11
100846e94:     	b.ne	0x100846e80 <_js_json_stringify_full+0x1380>
100846e98:     	orr	x8, x10, x1, lsl #40
100846e9c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846ea0:     	orr	x20, x8, x9
100846ea4:     	ldr	x22, [sp, #0x48]
100846ea8:     	ldrb	w8, [x23, #0x18]
100846eac:     	cmp	w8, #0x1
100846eb0:     	b.ne	0x1008475b8 <_js_json_stringify_full+0x1ab8>
100846eb4:     	ldp	x9, x8, [x23]
100846eb8:     	stp	x22, x0, [x23]
100846ebc:     	str	xzr, [x23, #0x10]
100846ec0:     	sub	x9, x9, #0x1
100846ec4:     	cmn	x9, #0x2
100846ec8:     	b.hs	0x100846ed4 <_js_json_stringify_full+0x13d4>
100846ecc:     	mov	x0, x8
100846ed0:     	bl	0x100b5ef80 <_mi_free>
100846ed4:     	cbz	w26, 0x100846ef4 <_js_json_stringify_full+0x13f4>
100846ed8:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846edc:     	ldr	w8, [x21]
100846ee0:     	sub	w8, w8, #0x1
100846ee4:     	str	w8, [x21]
100846ee8:     	cmn	x25, #0x1
100846eec:     	b.ne	0x100846f0c <_js_json_stringify_full+0x140c>
100846ef0:     	b	0x100846f98 <_js_json_stringify_full+0x1498>
100846ef4:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846ef8:     	ldr	w8, [x21]
100846efc:     	sub	w8, w8, #0x1
100846f00:     	str	w8, [x21]
100846f04:     	cmn	x25, #0x1
100846f08:     	b.eq	0x100846f98 <_js_json_stringify_full+0x1498>
100846f0c:     	ldp	x19, x21, [sp, #0x38]
100846f10:     	cbz	x21, 0x100846f8c <_js_json_stringify_full+0x148c>
100846f14:     	add	x22, x19, #0x8
100846f18:     	b	0x100846f28 <_js_json_stringify_full+0x1428>
100846f1c:     	add	x22, x22, #0x18
100846f20:     	subs	x21, x21, #0x1
100846f24:     	b.eq	0x100846f8c <_js_json_stringify_full+0x148c>
100846f28:     	ldur	x8, [x22, #-0x8]
100846f2c:     	cbz	x8, 0x100846f1c <_js_json_stringify_full+0x141c>
100846f30:     	ldr	x0, [x22]
100846f34:     	bl	0x100b5ef80 <_mi_free>
100846f38:     	b	0x100846f1c <_js_json_stringify_full+0x141c>
100846f3c:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846f40:     	ldr	w8, [x21]
100846f44:     	sub	w8, w8, #0x1
100846f48:     	str	w8, [x21]
100846f4c:     	add	x0, sp, #0x60
100846f50:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846f54:     	cmn	x25, #0x1
100846f58:     	b.eq	0x100846f98 <_js_json_stringify_full+0x1498>
100846f5c:     	ldp	x19, x21, [sp, #0x38]
100846f60:     	cbz	x21, 0x100846f8c <_js_json_stringify_full+0x148c>
100846f64:     	add	x22, x19, #0x8
100846f68:     	b	0x100846f78 <_js_json_stringify_full+0x1478>
100846f6c:     	add	x22, x22, #0x18
100846f70:     	subs	x21, x21, #0x1
100846f74:     	b.eq	0x100846f8c <_js_json_stringify_full+0x148c>
100846f78:     	ldur	x8, [x22, #-0x8]
100846f7c:     	cbz	x8, 0x100846f6c <_js_json_stringify_full+0x146c>
100846f80:     	ldr	x0, [x22]
100846f84:     	bl	0x100b5ef80 <_mi_free>
100846f88:     	b	0x100846f6c <_js_json_stringify_full+0x146c>
100846f8c:     	cbz	x25, 0x100846f98 <_js_json_stringify_full+0x1498>
100846f90:     	mov	x0, x19
100846f94:     	bl	0x100b5ef80 <_mi_free>
100846f98:     	ldr	x8, [sp, #0x10]
100846f9c:     	cbz	x8, 0x100846fa8 <_js_json_stringify_full+0x14a8>
100846fa0:     	ldr	x0, [sp, #0x18]
100846fa4:     	bl	0x100b5ef80 <_mi_free>
100846fa8:     	mov	x0, x20
100846fac:     	ldp	x29, x30, [sp, #0x110]
100846fb0:     	ldp	x20, x19, [sp, #0x100]
100846fb4:     	ldp	x22, x21, [sp, #0xf0]
100846fb8:     	ldp	x24, x23, [sp, #0xe0]
100846fbc:     	ldp	x26, x25, [sp, #0xd0]
100846fc0:     	ldp	x28, x27, [sp, #0xc0]
100846fc4:     	ldp	d9, d8, [sp, #0xb0]
100846fc8:     	add	sp, sp, #0x120
100846fcc:     	ret
100846fd0:     	str	x22, [sp, #0x8]
100846fd4:     	mov	x22, x28
100846fd8:     	mov	x28, x0
100846fdc:     	add	x0, x0, #0x8
100846fe0:     	bl	0x100b3bd10 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100846fe4:     	mov	x0, x28
100846fe8:     	mov	x28, x22
100846fec:     	ldr	x22, [sp, #0x8]
100846ff0:     	b	0x100846818 <_js_json_stringify_full+0xd18>
100846ff4:     	b.ne	0x10084655c <_js_json_stringify_full+0xa5c>
100846ff8:     	tbz	x25, #0x3f, 0x100847050 <_js_json_stringify_full+0x1550>
100846ffc:     	mov	x0, #0x0                ; =0
100847000:     	mov	x1, x25
100847004:     	bl	0x100b12340 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847008:     	bl	0x100b3f3bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084700c:     	add	x8, x0, x23, lsl #3
100847010:     	ldr	x0, [x8, #0x1e8]
100847014:     	cbnz	x0, 0x1008468ac <_js_json_stringify_full+0xdac>
100847018:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084701c:     	add	x0, x0, #0x138
100847020:     	bl	0x100b3cbdc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100847024:     	b	0x1008468ac <_js_json_stringify_full+0xdac>
100847028:     	add	x1, sp, #0x48
10084702c:     	mov.16b	v0, v8
100847030:     	mov	w0, #0x0                ; =0
100847034:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100847038:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084703c:     	add	x0, x0, #0xdc0
100847040:     	ldr	x8, [x0]
100847044:     	blr	x8
100847048:     	strb	wzr, [x0]
10084704c:     	b	0x1008469f0 <_js_json_stringify_full+0xef0>
100847050:     	mov	x0, x25
100847054:     	mov	w1, #0x1                ; =1
100847058:     	bl	0x100b5f208 <_mi_malloc_aligned>
10084705c:     	mov	x26, x0
100847060:     	mov	w0, #0x1                ; =1
100847064:     	cbz	x26, 0x100847000 <_js_json_stringify_full+0x1500>
100847068:     	mov	x0, x26
10084706c:     	mov	x1, x23
100847070:     	mov	x2, x25
100847074:     	bl	0x100b61e2c <_writev+0x100b61e2c>
100847078:     	mov	x22, x25
10084707c:     	b	0x100846580 <_js_json_stringify_full+0xa80>
100847080:     	cmp	w11, #0x8
100847084:     	b.eq	0x100847150 <_js_json_stringify_full+0x1650>
100847088:     	cmp	w11, #0x9
10084708c:     	b.eq	0x100847160 <_js_json_stringify_full+0x1660>
100847090:     	cmp	w11, #0xa
100847094:     	b.ne	0x1008470dc <_js_json_stringify_full+0x15dc>
100847098:     	mov	w10, #0x6e              ; =110
10084709c:     	b	0x100847164 <_js_json_stringify_full+0x1664>
1008470a0:     	mov	x22, x0
1008470a4:     	and	x0, x19, #0xffffffffffff
1008470a8:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008470ac:     	cbz	x0, 0x100847188 <_js_json_stringify_full+0x1688>
1008470b0:     	ldr	w20, [x0]
1008470b4:     	cmp	w20, #0x4
1008470b8:     	b.hi	0x1008460d8 <_js_json_stringify_full+0x5d8>
1008470bc:     	ldr	w8, [x0, #0x4]
1008470c0:     	cmp	w20, w8
1008470c4:     	b.hi	0x1008460d8 <_js_json_stringify_full+0x5d8>
1008470c8:     	b	0x10084718c <_js_json_stringify_full+0x168c>
1008470cc:     	cmp	w11, #0x22
1008470d0:     	b.eq	0x100847164 <_js_json_stringify_full+0x1664>
1008470d4:     	cmp	w11, #0x5c
1008470d8:     	b.eq	0x100847164 <_js_json_stringify_full+0x1664>
1008470dc:     	cmp	x12, #0x3
1008470e0:     	mov	w11, #0x20              ; =32
1008470e4:     	ccmp	w10, w11, #0x8, ls
1008470e8:     	b.lt	0x100846014 <_js_json_stringify_full+0x514>
1008470ec:     	add	x8, sp, #0x80
1008470f0:     	strb	w10, [x8, x12]
1008470f4:     	add	x12, x12, #0x1
1008470f8:     	b	0x100845d04 <_js_json_stringify_full+0x204>
1008470fc:     	mov	x1, x0
100847100:     	and	x0, x19, #0xffffffffffff
100847104:     	mov	x22, x1
100847108:     	bl	0x1004f8e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084710c:     	cmp	x0, #0x1
100847110:     	b.ne	0x100847234 <_js_json_stringify_full+0x1734>
100847114:     	mov	x20, x1
100847118:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
10084711c:     	ldrb	w9, [x8, #0x118]
100847120:     	cbz	w9, 0x10084735c <_js_json_stringify_full+0x185c>
100847124:     	ldr	x9, [x8, #0x110]
100847128:     	cmp	x9, x1
10084712c:     	b.ne	0x10084735c <_js_json_stringify_full+0x185c>
100847130:     	ldr	x9, [x8, #0xf0]
100847134:     	cmp	x9, x23
100847138:     	b.hi	0x10084735c <_js_json_stringify_full+0x185c>
10084713c:     	ldr	x9, [x8, #0xf8]
100847140:     	cmp	x9, x23
100847144:     	b.ls	0x10084735c <_js_json_stringify_full+0x185c>
100847148:     	add	x9, x8, #0xf0
10084714c:     	b	0x100847568 <_js_json_stringify_full+0x1a68>
100847150:     	mov	w10, #0x62              ; =98
100847154:     	b	0x100847164 <_js_json_stringify_full+0x1664>
100847158:     	mov	w10, #0x66              ; =102
10084715c:     	b	0x100847164 <_js_json_stringify_full+0x1664>
100847160:     	mov	w10, #0x74              ; =116
100847164:     	cmp	x12, #0x2
100847168:     	b.hi	0x100846014 <_js_json_stringify_full+0x514>
10084716c:     	add	x8, sp, #0x80
100847170:     	add	x8, x8, x12
100847174:     	add	x12, x12, #0x2
100847178:     	mov	w11, #0x5c              ; =92
10084717c:     	strb	w11, [x8]
100847180:     	strb	w10, [x8, #0x1]
100847184:     	b	0x100845d04 <_js_json_stringify_full+0x204>
100847188:     	mov	x20, #0x0               ; =0
10084718c:     	ldr	w8, [x22, #0x4]
100847190:     	lsl	x9, x20, #3
100847194:     	add	x9, x9, #0x18
100847198:     	cmp	x9, x8
10084719c:     	b.hi	0x1008460d8 <_js_json_stringify_full+0x5d8>
1008471a0:     	ldr	w8, [x25, #0x4]
1008471a4:     	mov	w9, #-0x40000000        ; =-1073741824
1008471a8:     	cmp	w8, w9
1008471ac:     	csel	w8, w8, wzr, lt
1008471b0:     	mov	x22, x0
1008471b4:     	mov	x0, x8
1008471b8:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1008471bc:     	mov	w9, #0x2                ; =2
1008471c0:     	cmp	w1, #0x2
1008471c4:     	csel	w10, w1, w9, hi
1008471c8:     	tst	w0, #0x1
1008471cc:     	csel	x8, x10, x9, ne
1008471d0:     	cmp	x20, x8
1008471d4:     	b.hi	0x1008460d8 <_js_json_stringify_full+0x5d8>
1008471d8:     	cbz	x20, 0x100847598 <_js_json_stringify_full+0x1a98>
1008471dc:     	mov	x0, x22
1008471e0:     	mov	x1, x20
1008471e4:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008471e8:     	tbz	w0, #0x0, 0x1008460d8 <_js_json_stringify_full+0x5d8>
1008471ec:     	cmp	x20, #0x1
1008471f0:     	b.eq	0x100847634 <_js_json_stringify_full+0x1b34>
1008471f4:     	cmp	x20, #0x2
1008471f8:     	b.ne	0x1008476f0 <_js_json_stringify_full+0x1bf0>
1008471fc:     	mov	x22, #0x0               ; =0
100847200:     	add	x25, x25, #0x10
100847204:     	mov	w8, #0x1                ; =1
100847208:     	mov	x26, x8
10084720c:     	ldr	x1, [x25, x22, lsl #3]
100847210:     	add	x0, sp, #0x80
100847214:     	bl	0x1004efe14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100847218:     	ldr	w8, [sp, #0x80]
10084721c:     	cmn	w8, #0x1
100847220:     	b.ne	0x1008476d8 <_js_json_stringify_full+0x1bd8>
100847224:     	mov	w8, #0x0                ; =0
100847228:     	mov	w22, #0x1               ; =1
10084722c:     	tbnz	w26, #0x0, 0x100847208 <_js_json_stringify_full+0x1708>
100847230:     	b	0x1008476f0 <_js_json_stringify_full+0x1bf0>
100847234:     	and	x0, x19, #0xffffffffffff
100847238:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084723c:     	cbz	x0, 0x1008472c8 <_js_json_stringify_full+0x17c8>
100847240:     	ldr	w20, [x0]
100847244:     	cbz	w20, 0x1008472c8 <_js_json_stringify_full+0x17c8>
100847248:     	cmp	w20, #0x8
10084724c:     	b.hi	0x1008460a4 <_js_json_stringify_full+0x5a4>
100847250:     	ldr	w8, [x0, #0x4]
100847254:     	cmp	w20, w8
100847258:     	b.hi	0x1008460a4 <_js_json_stringify_full+0x5a4>
10084725c:     	ldr	w8, [x22, #0x4]
100847260:     	lsl	x9, x20, #3
100847264:     	add	x9, x9, #0x18
100847268:     	cmp	x9, x8
10084726c:     	b.hi	0x1008460a4 <_js_json_stringify_full+0x5a4>
100847270:     	ldr	w8, [x25, #0x4]
100847274:     	mov	w9, #-0x40000000        ; =-1073741824
100847278:     	cmp	w8, w9
10084727c:     	csel	w8, w8, wzr, lt
100847280:     	mov	x22, x0
100847284:     	mov	x0, x8
100847288:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084728c:     	mov	w9, #0x2                ; =2
100847290:     	cmp	w1, #0x2
100847294:     	csel	w10, w1, w9, hi
100847298:     	tst	w0, #0x1
10084729c:     	csel	w8, w10, w9, ne
1008472a0:     	cmp	w20, w8
1008472a4:     	b.hi	0x1008460a4 <_js_json_stringify_full+0x5a4>
1008472a8:     	mov	x0, x22
1008472ac:     	mov	x1, x20
1008472b0:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008472b4:     	cbz	w0, 0x1008460a4 <_js_json_stringify_full+0x5a4>
1008472b8:     	and	x0, x19, #0xffffffffffff
1008472bc:     	mov	x1, x20
1008472c0:     	bl	0x1004f7f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
1008472c4:     	b	0x1008472d0 <_js_json_stringify_full+0x17d0>
1008472c8:     	and	x0, x19, #0xffffffffffff
1008472cc:     	bl	0x1004f8cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
1008472d0:     	mov	x20, x1
1008472d4:     	tbz	w0, #0x0, 0x1008460a4 <_js_json_stringify_full+0x5a4>
1008472d8:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
1008472dc:     	add	x9, x8, #0x60
1008472e0:     	b	0x100847568 <_js_json_stringify_full+0x1a68>
1008472e4:     	bl	0x100b3f3bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008472e8:     	lsr	x1, x23, #20
1008472ec:     	ldr	x8, [x0, #0x10]
1008472f0:     	ldrb	w9, [x8]
1008472f4:     	cmp	w9, #0x2
1008472f8:     	b.eq	0x100846688 <_js_json_stringify_full+0xb88>
1008472fc:     	ldr	x9, [x8, #0x8]
100847300:     	ldr	x10, [x8, #0x28]
100847304:     	sub	x9, x1, x9
100847308:     	cmp	x9, x10
10084730c:     	b.hs	0x100847350 <_js_json_stringify_full+0x1850>
100847310:     	ldr	x10, [x8, #0x20]
100847314:     	mov	w11, #0x28              ; =40
100847318:     	madd	x9, x9, x11, x10
10084731c:     	ldr	x10, [x9]
100847320:     	ldr	x11, [x8, #0x10]
100847324:     	cmp	x10, x11
100847328:     	b.ne	0x10084735c <_js_json_stringify_full+0x185c>
10084732c:     	ldp	x10, x11, [x9, #0x8]
100847330:     	cmp	x10, x23
100847334:     	ccmp	x11, x23, #0x0, ls
100847338:     	b.ls	0x10084735c <_js_json_stringify_full+0x185c>
10084733c:     	ldr	x10, [x8, #0x30]
100847340:     	add	x10, x10, #0x1
100847344:     	str	x10, [x8, #0x30]
100847348:     	add	x8, x9, #0x21
10084734c:     	b	0x100847578 <_js_json_stringify_full+0x1a78>
100847350:     	ldr	x9, [x8, #0x58]
100847354:     	add	x9, x9, #0x1
100847358:     	str	x9, [x8, #0x58]
10084735c:     	ldr	x9, [x8, #0x38]
100847360:     	add	x9, x9, #0x1
100847364:     	str	x9, [x8, #0x38]
100847368:     	mov	x0, x23
10084736c:     	bl	0x10051e348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100847370:     	and	w8, w0, #0xff
100847374:     	cbz	w8, 0x100847394 <_js_json_stringify_full+0x1894>
100847378:     	ldurb	w8, [x23, #-0x8]
10084737c:     	ldurb	w9, [x23, #-0x7]
100847380:     	mov	w10, #0x82              ; =130
100847384:     	and	w9, w9, w10
100847388:     	cmp	w9, #0x2
10084738c:     	ccmp	w8, #0x1, #0x0, eq
100847390:     	b.eq	0x100847428 <_js_json_stringify_full+0x1928>
100847394:     	mov	x0, x23
100847398:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084739c:     	mov	x24, x0
1008473a0:     	cbz	x0, 0x1008473cc <_js_json_stringify_full+0x18cc>
1008473a4:     	ldrb	w8, [x24]
1008473a8:     	cmp	w8, #0x1
1008473ac:     	b.ne	0x1008473ec <_js_json_stringify_full+0x18ec>
1008473b0:     	ldrsb	w8, [x24, #0x1]
1008473b4:     	tbnz	w8, #0x1f, 0x100847450 <_js_json_stringify_full+0x1950>
1008473b8:     	mov	x0, x24
1008473bc:     	ldp	w9, w8, [x23]
1008473c0:     	cmp	w9, w8
1008473c4:     	b.hi	0x1008474d4 <_js_json_stringify_full+0x19d4>
1008473c8:     	b	0x1008474ec <_js_json_stringify_full+0x19ec>
1008473cc:     	mov	x0, x23
1008473d0:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008473d4:     	tbnz	w0, #0x0, 0x1008473e4 <_js_json_stringify_full+0x18e4>
1008473d8:     	mov	x0, x23
1008473dc:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008473e0:     	tbz	w0, #0x0, 0x100846728 <_js_json_stringify_full+0xc28>
1008473e4:     	mov	x0, #0x0                ; =0
1008473e8:     	b	0x1008474c4 <_js_json_stringify_full+0x19c4>
1008473ec:     	mov	x0, x24
1008473f0:     	cmp	w8, #0x1
1008473f4:     	b.eq	0x1008474c4 <_js_json_stringify_full+0x19c4>
1008473f8:     	cmp	w8, #0x9
1008473fc:     	b.ne	0x100846728 <_js_json_stringify_full+0xc28>
100847400:     	ldr	w8, [x23, #0x4]
100847404:     	mov	w9, #0x5841             ; =22593
100847408:     	movk	w9, #0x4c5a, lsl #16
10084740c:     	cmp	w8, w9
100847410:     	b.ne	0x100846728 <_js_json_stringify_full+0xc28>
100847414:     	mov	x0, x23
100847418:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084741c:     	mov	x23, x0
100847420:     	cbnz	x0, 0x100847514 <_js_json_stringify_full+0x1a14>
100847424:     	b	0x100846728 <_js_json_stringify_full+0xc28>
100847428:     	ldr	w8, [x23]
10084742c:     	mov	w9, #0xe100             ; =57600
100847430:     	movk	w9, #0x5f5, lsl #16
100847434:     	orr	w9, w9, #0x1
100847438:     	cmp	w8, w9
10084743c:     	b.hs	0x100847394 <_js_json_stringify_full+0x1894>
100847440:     	ldr	w9, [x23, #0x4]
100847444:     	cmp	w8, w9
100847448:     	b.ls	0x100847514 <_js_json_stringify_full+0x1a14>
10084744c:     	b	0x100847394 <_js_json_stringify_full+0x1894>
100847450:     	ldr	x23, [x24, #0x8]
100847454:     	mov	x0, x23
100847458:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084745c:     	cbz	x0, 0x100846728 <_js_json_stringify_full+0xc28>
100847460:     	ldrb	w8, [x0]
100847464:     	cmp	w8, #0x1
100847468:     	b.ne	0x100846728 <_js_json_stringify_full+0xc28>
10084746c:     	ldrsb	w8, [x0, #0x1]
100847470:     	tbz	w8, #0x1f, 0x1008473bc <_js_json_stringify_full+0x18bc>
100847474:     	mov	w26, #0x1               ; =1
100847478:     	ldr	x23, [x0, #0x8]
10084747c:     	mov	x0, x23
100847480:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847484:     	cbz	x0, 0x100846728 <_js_json_stringify_full+0xc28>
100847488:     	ldrb	w8, [x0]
10084748c:     	cmp	w8, #0x1
100847490:     	b.ne	0x100846728 <_js_json_stringify_full+0xc28>
100847494:     	cmp	w26, #0x3f
100847498:     	b.hi	0x100846728 <_js_json_stringify_full+0xc28>
10084749c:     	add	w26, w26, #0x1
1008474a0:     	ldrsb	w8, [x0, #0x1]
1008474a4:     	tbnz	w8, #0x1f, 0x100847478 <_js_json_stringify_full+0x1978>
1008474a8:     	str	x23, [x24, #0x8]
1008474ac:     	ldrb	w8, [x24, #0x1]
1008474b0:     	orr	w8, w8, #0x80
1008474b4:     	strb	w8, [x24, #0x1]
1008474b8:     	ldrb	w8, [x0]
1008474bc:     	cmp	w8, #0x1
1008474c0:     	b.ne	0x1008473f8 <_js_json_stringify_full+0x18f8>
1008474c4:     	ldp	w9, w8, [x23]
1008474c8:     	cmp	w9, w8
1008474cc:     	b.ls	0x1008474ec <_js_json_stringify_full+0x19ec>
1008474d0:     	cbz	x24, 0x1008474fc <_js_json_stringify_full+0x19fc>
1008474d4:     	ldr	w9, [x0, #0x4]
1008474d8:     	ubfiz	x8, x8, #3, #32
1008474dc:     	add	x8, x8, #0x10
1008474e0:     	cmp	x8, x9
1008474e4:     	b.eq	0x100847514 <_js_json_stringify_full+0x1a14>
1008474e8:     	b	0x1008474fc <_js_json_stringify_full+0x19fc>
1008474ec:     	mov	w8, #0xe100             ; =57600
1008474f0:     	movk	w8, #0x5f5, lsl #16
1008474f4:     	cmp	w9, w8
1008474f8:     	b.ls	0x100847514 <_js_json_stringify_full+0x1a14>
1008474fc:     	mov	x0, x23
100847500:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847504:     	tbnz	w0, #0x0, 0x100847514 <_js_json_stringify_full+0x1a14>
100847508:     	mov	x0, x23
10084750c:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847510:     	tbz	w0, #0x0, 0x100846728 <_js_json_stringify_full+0xc28>
100847514:     	ldp	w8, w9, [x23]
100847518:     	sub	w10, w9, #0x1
10084751c:     	mov	w11, #0x270f            ; =9999
100847520:     	cmp	w10, w11
100847524:     	ccmp	w8, w9, #0x2, lo
100847528:     	b.hi	0x100846728 <_js_json_stringify_full+0xc28>
10084752c:     	and	x8, x21, #0xffffffffffff
100847530:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100847534:     	cmp	x25, x9
100847538:     	csel	x1, x8, x21, eq
10084753c:     	add	x0, sp, #0x30
100847540:     	bl	0x1004ffc78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100847544:     	ldr	x25, [sp, #0x30]
100847548:     	cmn	x25, #0x1
10084754c:     	cset	w24, eq
100847550:     	cmp	x27, #0x1
100847554:     	cset	w8, hi
100847558:     	tst	w8, w24
10084755c:     	b.ne	0x100846744 <_js_json_stringify_full+0xc44>
100847560:     	b	0x1008467b4 <_js_json_stringify_full+0xcb4>
100847564:     	add	x9, x8, #0x90
100847568:     	ldr	x10, [x8, #0x30]
10084756c:     	add	x10, x10, #0x1
100847570:     	str	x10, [x8, #0x30]
100847574:     	add	x8, x9, #0x19
100847578:     	ldrb	w8, [x8]
10084757c:     	cmp	w8, #0xff
100847580:     	b.ne	0x100847374 <_js_json_stringify_full+0x1874>
100847584:     	b	0x100847368 <_js_json_stringify_full+0x1868>
100847588:     	mov	x0, x23
10084758c:     	bl	0x100b1e544 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847590:     	cbnz	x0, 0x1008468d0 <_js_json_stringify_full+0xdd0>
100847594:     	b	0x100847710 <_js_json_stringify_full+0x1c10>
100847598:     	and	x0, x19, #0xffffffffffff
10084759c:     	bl	0x1004f7d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
1008475a0:     	mov	w0, w0
1008475a4:     	mov	x20, #0x7d7b            ; =32123
1008475a8:     	movk	x20, #0x200, lsl #32
1008475ac:     	movk	x20, #0x7ff9, lsl #48
1008475b0:     	tbz	w0, #0x0, 0x1008460d8 <_js_json_stringify_full+0x5d8>
1008475b4:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
1008475b8:     	mov	x19, x0
1008475bc:     	mov	x0, x23
1008475c0:     	bl	0x100b1e544 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008475c4:     	mov	x23, x0
1008475c8:     	mov	x0, x19
1008475cc:     	cbnz	x23, 0x100846eb4 <_js_json_stringify_full+0x13b4>
1008475d0:     	b	0x1008476b0 <_js_json_stringify_full+0x1bb0>
1008475d4:     	bl	0x100b1e6a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
1008475d8:     	cbnz	x0, 0x1008467f8 <_js_json_stringify_full+0xcf8>
1008475dc:     	b	0x100847710 <_js_json_stringify_full+0x1c10>
1008475e0:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1008475e4:     	add	x0, x0, #0x440
1008475e8:     	bl	0x100b126ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008475ec:     	cmp	w8, #0x1
1008475f0:     	b.ne	0x100847710 <_js_json_stringify_full+0x1c10>
1008475f4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008475f8:     	add	x1, x1, #0x998
1008475fc:     	mov	x19, x0
100847600:     	bl	0x100a2041c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847604:     	mov	x0, x19
100847608:     	strb	wzr, [x19, #0x20]
10084760c:     	ldr	x8, [x19]
100847610:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847614:     	cmp	x8, x9
100847618:     	b.lo	0x100846a18 <_js_json_stringify_full+0xf18>
10084761c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847620:     	add	x0, x0, #0xea8
100847624:     	bl	0x100b1271c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847628:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084762c:     	add	x0, x0, #0xec0
100847630:     	bl	0x100b126ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847634:     	and	x0, x19, #0xffffffffffff
100847638:     	bl	0x1004ef9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
10084763c:     	mov	x20, x1
100847640:     	tbz	w0, #0x0, 0x1008460d8 <_js_json_stringify_full+0x5d8>
100847644:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
100847648:     	mov	x0, x23
10084764c:     	bl	0x100b1e544 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847650:     	mov	x23, x0
100847654:     	cbnz	x0, 0x100846d64 <_js_json_stringify_full+0x1264>
100847658:     	b	0x1008476b0 <_js_json_stringify_full+0x1bb0>
10084765c:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847660:     	add	x0, x0, #0xd70
100847664:     	bl	0x100b1271c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847668:     	bl	0x100b4b914 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084766c:     	cmp	w8, #0x2
100847670:     	b.eq	0x100847710 <_js_json_stringify_full+0x1c10>
100847674:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847678:     	add	x1, x1, #0x998
10084767c:     	mov	x19, x0
100847680:     	bl	0x100a2041c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847684:     	mov	x0, x19
100847688:     	strb	wzr, [x19, #0x20]
10084768c:     	ldr	x8, [x19]
100847690:     	cbz	x8, 0x100846d50 <_js_json_stringify_full+0x1250>
100847694:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847698:     	add	x0, x0, #0xe90
10084769c:     	bl	0x100b126ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008476a0:     	mov	x0, x23
1008476a4:     	bl	0x100b1e544 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008476a8:     	mov	x23, x0
1008476ac:     	cbnz	x0, 0x100846c80 <_js_json_stringify_full+0x1180>
1008476b0:     	cbz	x22, 0x100847710 <_js_json_stringify_full+0x1c10>
1008476b4:     	mov	x0, x19
1008476b8:     	bl	0x100b5ef80 <_mi_free>
1008476bc:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008476c0:     	add	x0, x0, #0xc18
1008476c4:     	bl	0x100b585dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008476c8:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xab4>
1008476cc:     	add	x0, x0, #0x470
1008476d0:     	mov	w1, #0xf                ; =15
1008476d4:     	bl	0x100b4b8dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008476d8:     	and	x0, x19, #0xffffffffffff
1008476dc:     	add	x2, sp, #0x80
1008476e0:     	mov	x1, x22
1008476e4:     	bl	0x1004f01c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008476e8:     	tbnz	w0, #0x0, 0x100847114 <_js_json_stringify_full+0x1614>
1008476ec:     	mov	w20, #0x2               ; =2
1008476f0:     	and	x0, x19, #0xffffffffffff
1008476f4:     	mov	x1, x20
1008476f8:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
1008476fc:     	mov	x20, x1
100847700:     	tbz	w0, #0x0, 0x1008460d8 <_js_json_stringify_full+0x5d8>
100847704:     	b	0x100846fa8 <_js_json_stringify_full+0x14a8>
100847708:     	cmp	w8, #0x2
10084770c:     	b.ne	0x100847738 <_js_json_stringify_full+0x1c38>
100847710:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847714:     	add	x0, x0, #0xc18
100847718:     	bl	0x100b585dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084771c:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
100847720:     	add	x0, x0, #0x800
100847724:     	bl	0x100b127b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100847728:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xab4>
10084772c:     	add	x0, x0, #0x1a7
100847730:     	mov	w1, #0xb                ; =11
100847734:     	bl	0x100b4b8dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847738:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
10084773c:     	add	x1, x1, #0x998
100847740:     	mov	x19, x0
100847744:     	bl	0x100a2041c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847748:     	mov	x0, x19
10084774c:     	strb	wzr, [x19, #0x20]
100847750:     	ldr	x8, [x19]
100847754:     	cbz	x8, 0x100846c6c <_js_json_stringify_full+0x116c>
100847758:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084775c:     	add	x0, x0, #0xe78
100847760:     	bl	0x100b126ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847764:     	mov	w0, #0x1                ; =1
100847768:     	mov	x1, x24
10084776c:     	bl	0x100b12340 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847770:     	mov	w0, #0x1                ; =1
100847774:     	mov	x1, x22
100847778:     	bl	0x100b12340 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084777c:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847780:     	add	x2, x2, #0x3c8
100847784:     	mov	w0, #0x5                ; =5
100847788:     	mov	w1, #0x5                ; =5
10084778c:     	bl	0x100b1284c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
