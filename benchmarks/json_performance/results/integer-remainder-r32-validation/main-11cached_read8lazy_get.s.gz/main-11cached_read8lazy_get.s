
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/trusted-materialized-read-r26/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100686d84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>:
100686d84:     	stp	x22, x21, [sp, #-0x30]!
100686d88:     	stp	x20, x19, [sp, #0x10]
100686d8c:     	stp	x29, x30, [sp, #0x20]
100686d90:     	add	x29, sp, #0x20
100686d94:     	mov	x19, #0x1               ; =1
100686d98:     	movk	x19, #0x7ffc, lsl #48
100686d9c:     	cbz	x0, 0x100686e5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xd8>
100686da0:     	ldr	x8, [x0, #0x20]
100686da4:     	cbz	x8, 0x100686e28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xa4>
100686da8:     	ldurb	w9, [x8, #-0x8]
100686dac:     	cmp	w9, #0x1
100686db0:     	b.ne	0x100686dd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0x50>
100686db4:     	ldursb	w9, [x8, #-0x7]
100686db8:     	tbnz	w9, #0x1f, 0x100686dd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0x50>
100686dbc:     	ldp	w9, w10, [x8]
100686dc0:     	mov	w11, #0xe100            ; =57600
100686dc4:     	movk	w11, #0x5f5, lsl #16
100686dc8:     	cmp	w9, w11
100686dcc:     	ccmp	w9, w10, #0x2, ls
100686dd0:     	b.ls	0x100686e70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xec>
100686dd4:     	mov	x20, x0
100686dd8:     	mov	x21, x1
100686ddc:     	bl	0x1006871e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100686de0:     	mov	x1, x21
100686de4:     	mov	x8, x0
100686de8:     	mov	x0, x20
100686dec:     	cbz	x8, 0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686df0:     	ldurh	w9, [x8, #-0x6]
100686df4:     	tbnz	w9, #0xa, 0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686df8:     	ldr	w9, [x8]
100686dfc:     	cmp	w1, w9
100686e00:     	b.hs	0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686e04:     	ldr	w9, [x8, #0x4]
100686e08:     	cmp	w1, w9
100686e0c:     	b.hs	0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686e10:     	add	x8, x8, w1, uxtw #3
100686e14:     	add	x9, x19, #0xf
100686e18:     	ldr	x19, [x8, #0x8]
100686e1c:     	cmp	x19, x9
100686e20:     	b.ne	0x100686e5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xd8>
100686e24:     	b	0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686e28:     	ldr	w8, [x0]
100686e2c:     	cmp	w1, w8
100686e30:     	b.hs	0x100686e5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xd8>
100686e34:     	ldr	x9, [x0, #0x30]
100686e38:     	cbz	x9, 0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686e3c:     	ldr	x8, [x0, #0x28]
100686e40:     	cbz	x8, 0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686e44:     	mov	w10, w1
100686e48:     	lsr	x11, x10, #6
100686e4c:     	ldr	x9, [x9, x11, lsl #3]
100686e50:     	lsr	x9, x9, x1
100686e54:     	tbz	w9, #0x0, 0x100686e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xf8>
100686e58:     	ldr	x19, [x8, x10, lsl #3]
100686e5c:     	mov	x0, x19
100686e60:     	ldp	x29, x30, [sp, #0x20]
100686e64:     	ldp	x20, x19, [sp, #0x10]
100686e68:     	ldp	x22, x21, [sp], #0x30
100686e6c:     	ret
100686e70:     	str	w9, [x0]
100686e74:     	ldurh	w9, [x8, #-0x6]
100686e78:     	tbz	w9, #0xa, 0x100686df8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0x74>
100686e7c:     	ldp	x29, x30, [sp, #0x20]
100686e80:     	ldp	x20, x19, [sp, #0x10]
100686e84:     	ldp	x22, x21, [sp], #0x30
100686e88:     	b	0x1003744dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>
