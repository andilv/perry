
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/zero-spacing-r25/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001003744dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>:
1003744dc:     	sub	sp, sp, #0xc0
1003744e0:     	stp	x28, x27, [sp, #0x60]
1003744e4:     	stp	x26, x25, [sp, #0x70]
1003744e8:     	stp	x24, x23, [sp, #0x80]
1003744ec:     	stp	x22, x21, [sp, #0x90]
1003744f0:     	stp	x20, x19, [sp, #0xa0]
1003744f4:     	stp	x29, x30, [sp, #0xb0]
1003744f8:     	add	x29, sp, #0xb0
1003744fc:     	mov	x19, x1
100374500:     	mov	x20, x0
100374504:     	bl	0x10028a298 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100374508:     	str	x0, [sp, #0x10]
10037450c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100374510:     	stp	x20, x8, [sp, #0x28]
100374514:     	mov	w8, #0x1                ; =1
100374518:     	str	x8, [sp, #0x20]
10037451c:     	add	x0, sp, #0x20
100374520:     	bl	0x10028a3a0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100374524:     	mov	x20, x0
100374528:     	str	x0, [sp, #0x18]
10037452c:     	adrp	x24, 0x100f7c000 <_perry_global_access_worker_ts__1>
100374530:     	ldr	x8, [x24, #0x30]
100374534:     	cmn	x8, #0x1
100374538:     	b.eq	0x1003745a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xcc>
10037453c:     	mrs	x9, TPIDRRO_EL0
100374540:     	and	x9, x9, #0xfffffffffffffff8
100374544:     	ldr	x8, [x9, x8, lsl #3]
100374548:     	cbz	x8, 0x1003745a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xcc>
10037454c:     	ldr	x8, [x8, #0x19e8]
100374550:     	cbz	x8, 0x1003745a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xcc>
100374554:     	ldr	x9, [x8]
100374558:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10037455c:     	cmp	x9, x10
100374560:     	b.hs	0x10037495c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x480>
100374564:     	add	x10, x9, #0x1
100374568:     	str	x10, [x8]
10037456c:     	ldr	x10, [x8, #0x18]
100374570:     	cmp	x20, x10
100374574:     	b.hs	0x100374968 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x48c>
100374578:     	ldr	x10, [x8, #0x10]
10037457c:     	mov	w11, #0x18              ; =24
100374580:     	madd	x10, x20, x11, x10
100374584:     	ldr	x11, [x10]
100374588:     	cmp	x11, #0x1
10037458c:     	b.ne	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x490>
100374590:     	ldr	x21, [x10, #0x8]
100374594:     	str	x9, [x8]
100374598:     	mov	x22, #0x1               ; =1
10037459c:     	movk	x22, #0x7ffc, lsl #48
1003745a0:     	cbnz	x21, 0x1003745c0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xe4>
1003745a4:     	b	0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003745a8:     	mov	x0, x20
1003745ac:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1003745b0:     	mov	x21, x0
1003745b4:     	mov	x22, #0x1               ; =1
1003745b8:     	movk	x22, #0x7ffc, lsl #48
1003745bc:     	cbz	x0, 0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003745c0:     	mov	x0, x21
1003745c4:     	bl	0x1006871ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1003745c8:     	cbz	x0, 0x1003745dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x100>
1003745cc:     	mov	x1, x19
1003745d0:     	bl	0x1007bcd50 <_js_array_get_f64>
1003745d4:     	fmov	x22, d0
1003745d8:     	b	0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003745dc:     	ldr	w23, [x21]
1003745e0:     	cmp	w19, w23
1003745e4:     	b.hs	0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003745e8:     	ldr	x9, [x21, #0x30]
1003745ec:     	cbz	x9, 0x100374614 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x138>
1003745f0:     	ldr	x8, [x21, #0x28]
1003745f4:     	cbz	x8, 0x100374614 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x138>
1003745f8:     	mov	w10, w19
1003745fc:     	lsr	x11, x10, #6
100374600:     	ldr	x9, [x9, x11, lsl #3]
100374604:     	lsr	x9, x9, x10
100374608:     	tbz	w9, #0x0, 0x100374614 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x138>
10037460c:     	ldr	x22, [x8, x10, lsl #3]
100374610:     	b	0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
100374614:     	stp	xzr, x20, [sp, #0x20]
100374618:     	ldr	w25, [x21, #0x8]
10037461c:     	ldr	x8, [x24, #0x30]
100374620:     	cmn	x8, #0x1
100374624:     	b.eq	0x100374688 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1ac>
100374628:     	mrs	x9, TPIDRRO_EL0
10037462c:     	and	x9, x9, #0xfffffffffffffff8
100374630:     	ldr	x8, [x9, x8, lsl #3]
100374634:     	cbz	x8, 0x100374688 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1ac>
100374638:     	ldr	x8, [x8, #0x19e8]
10037463c:     	cbz	x8, 0x100374688 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1ac>
100374640:     	ldr	x9, [x8]
100374644:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100374648:     	cmp	x9, x10
10037464c:     	b.hs	0x10037495c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x480>
100374650:     	add	x10, x9, #0x1
100374654:     	str	x10, [x8]
100374658:     	ldr	x10, [x8, #0x18]
10037465c:     	cmp	x20, x10
100374660:     	b.hs	0x100374968 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x48c>
100374664:     	ldr	x10, [x8, #0x10]
100374668:     	mov	w11, #0x18              ; =24
10037466c:     	madd	x10, x20, x11, x10
100374670:     	ldr	x11, [x10]
100374674:     	cmp	x11, #0x1
100374678:     	b.ne	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x490>
10037467c:     	ldr	x0, [x10, #0x8]
100374680:     	str	x9, [x8]
100374684:     	b	0x100374690 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1b4>
100374688:     	mov	x0, x20
10037468c:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100374690:     	cbz	x0, 0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
100374694:     	ldr	w8, [x0, #0xc]
100374698:     	cmp	w25, w8
10037469c:     	b.hs	0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003746a0:     	ldr	x8, [x0, #0x10]
1003746a4:     	cbz	x8, 0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003746a8:     	mov	w9, #0xc                ; =12
1003746ac:     	umaddl	x8, w25, w9, x8
1003746b0:     	ldrb	w9, [x8, #0x8]
1003746b4:     	cmp	w9, #0x3
1003746b8:     	b.ne	0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003746bc:     	ldr	w28, [x8, #0x4]
1003746c0:     	ldr	w26, [x21, #0x38]
1003746c4:     	cmn	w26, #0x1
1003746c8:     	b.eq	0x1003746e0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x204>
1003746cc:     	cmp	w19, w26
1003746d0:     	b.lo	0x1003746e0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x204>
1003746d4:     	ldr	w25, [x21, #0x3c]
1003746d8:     	mov	x9, x26
1003746dc:     	b	0x1003746e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x20c>
1003746e0:     	mov	w9, #0x0                ; =0
1003746e4:     	add	x25, x25, #0x1
1003746e8:     	str	x25, [sp, #0x40]
1003746ec:     	cmp	x25, x28
1003746f0:     	cset	w8, lo
1003746f4:     	str	w9, [sp, #0xc]
1003746f8:     	b.hs	0x1003747d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2f4>
1003746fc:     	cmp	w19, w9
100374700:     	b.ls	0x1003747d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2f4>
100374704:     	add	w27, w9, #0x1
100374708:     	ldr	x8, [x24, #0x30]
10037470c:     	cmn	x8, #0x1
100374710:     	b.eq	0x100374774 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x298>
100374714:     	mrs	x9, TPIDRRO_EL0
100374718:     	and	x9, x9, #0xfffffffffffffff8
10037471c:     	ldr	x8, [x9, x8, lsl #3]
100374720:     	cbz	x8, 0x100374774 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x298>
100374724:     	ldr	x8, [x8, #0x19e8]
100374728:     	cbz	x8, 0x100374774 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x298>
10037472c:     	ldr	x9, [x8]
100374730:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100374734:     	cmp	x9, x10
100374738:     	b.hs	0x10037495c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x480>
10037473c:     	add	x10, x9, #0x1
100374740:     	str	x10, [x8]
100374744:     	ldr	x10, [x8, #0x18]
100374748:     	cmp	x20, x10
10037474c:     	b.hs	0x100374968 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x48c>
100374750:     	ldr	x10, [x8, #0x10]
100374754:     	mov	w11, #0x18              ; =24
100374758:     	madd	x10, x20, x11, x10
10037475c:     	ldr	x11, [x10]
100374760:     	cmp	x11, #0x1
100374764:     	b.ne	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x490>
100374768:     	ldr	x0, [x10, #0x8]
10037476c:     	str	x9, [x8]
100374770:     	b	0x10037477c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2a0>
100374774:     	mov	x0, x20
100374778:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10037477c:     	cbz	x0, 0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
100374780:     	ldr	w8, [x0, #0xc]
100374784:     	cmp	x25, x8
100374788:     	b.hs	0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
10037478c:     	ldr	x8, [x0, #0x10]
100374790:     	cbz	x8, 0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
100374794:     	mov	w9, #0xc                ; =12
100374798:     	madd	x8, x25, x9, x8
10037479c:     	ldrb	w9, [x8, #0x8]
1003747a0:     	orr	w9, w9, #0x2
1003747a4:     	cmp	w9, #0x3
1003747a8:     	b.ne	0x1003747b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2d4>
1003747ac:     	ldr	w25, [x8, #0x4]
1003747b0:     	add	x25, x25, #0x1
1003747b4:     	str	x25, [sp, #0x40]
1003747b8:     	cmp	x25, x28
1003747bc:     	cset	w8, lo
1003747c0:     	b.hs	0x1003747d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2f4>
1003747c4:     	cmp	w27, w19
1003747c8:     	add	w27, w27, #0x1
1003747cc:     	b.lo	0x100374708 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x22c>
1003747d0:     	tbz	w8, #0x0, 0x100374930 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x454>
1003747d4:     	ldr	w8, [sp, #0xc]
1003747d8:     	sub	w8, w19, w8
1003747dc:     	add	w9, w26, #0x1
1003747e0:     	cmp	w19, w9
1003747e4:     	ccmn	w26, #0x1, #0x4, eq
1003747e8:     	b.eq	0x1003747fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x320>
1003747ec:     	ldr	w9, [x21, #0x48]
1003747f0:     	adds	w9, w9, #0x1
1003747f4:     	csinv	w22, w9, wzr, lo
1003747f8:     	b	0x100374800 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x324>
1003747fc:     	mov	w22, #0x1               ; =1
100374800:     	str	w22, [x21, #0x48]
100374804:     	stp	w19, w25, [x21, #0x38]
100374808:     	ldr	x9, [x21, #0x40]
10037480c:     	adds	x8, x9, x8
100374810:     	csinv	x8, x8, xzr, lo
100374814:     	str	x8, [x21, #0x40]
100374818:     	add	x8, sp, #0x20
10037481c:     	add	x9, sp, #0x10
100374820:     	stp	x8, x9, [sp, #0x48]
100374824:     	add	x8, sp, #0x40
100374828:     	str	x8, [sp, #0x58]
10037482c:     	cmp	w22, #0x1
100374830:     	b.ls	0x100374850 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x374>
100374834:     	add	x0, sp, #0x48
100374838:     	bl	0x100215184 <__RNCNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted0B5_>
10037483c:     	mov	x8, x0
100374840:     	tbz	w8, #0x0, 0x10037484c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x370>
100374844:     	mov	x0, x1
100374848:     	b	0x100374860 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x384>
10037484c:     	ldr	x25, [sp, #0x40]
100374850:     	str	x25, [sp, #0x48]
100374854:     	add	x0, sp, #0x20
100374858:     	add	x1, sp, #0x48
10037485c:     	bl	0x100377100 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
100374860:     	stp	xzr, x0, [sp, #0x48]
100374864:     	add	x0, sp, #0x48
100374868:     	bl	0x10028a3a0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
10037486c:     	str	x0, [sp, #0x48]
100374870:     	add	x0, sp, #0x18
100374874:     	bl	0x10013f958 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle10across_mutNtNtBc_9json_tape15LazyArrayHeaderuNCNvB1D_19reparse_materializes_0EBc_>
100374878:     	ldr	x21, [x0, #0x30]
10037487c:     	cbz	x21, 0x1003748c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x3ec>
100374880:     	ldr	x24, [x0, #0x28]
100374884:     	cbz	x24, 0x1003748c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x3ec>
100374888:     	mov	x20, x0
10037488c:     	add	x0, sp, #0x48
100374890:     	bl	0x100266aec <__RNvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB5_13RuntimeHandle14get_nanbox_u64>
100374894:     	mov	x2, x0
100374898:     	mov	w25, w19
10037489c:     	add	x1, x24, w19, uxtw #3
1003748a0:     	str	x0, [x1]
1003748a4:     	mov	x0, x20
1003748a8:     	bl	0x100374c50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape20note_lazy_cache_slot>
1003748ac:     	mov	w8, #0x1                ; =1
1003748b0:     	lsl	x8, x8, x25
1003748b4:     	lsr	x9, x25, #3
1003748b8:     	and	x9, x9, #0x1ffffff8
1003748bc:     	ldr	x10, [x21, x9]
1003748c0:     	orr	x8, x10, x8
1003748c4:     	str	x8, [x21, x9]
1003748c8:     	add	x0, sp, #0x18
1003748cc:     	bl	0x10013f958 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle10across_mutNtNtBc_9json_tape15LazyArrayHeaderuNCNvB1D_19reparse_materializes_0EBc_>
1003748d0:     	lsr	w8, w23, #6
1003748d4:     	mov	w9, #0x40               ; =64
1003748d8:     	cmp	w8, #0x40
1003748dc:     	csel	w8, w8, w9, hi
1003748e0:     	cmp	w22, w8
1003748e4:     	b.hs	0x1003748f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x41c>
1003748e8:     	ldr	x8, [x0, #0x40]
1003748ec:     	cmp	x8, x23, lsl #1
1003748f0:     	b.hi	0x100374920 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x444>
1003748f4:     	b	0x100374924 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x448>
1003748f8:     	mov	x19, x0
1003748fc:     	bl	0x10037497c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape17lazy_cached_count>
100374900:     	mov	x8, x0
100374904:     	mov	x0, x19
100374908:     	ldr	x9, [x19, #0x40]
10037490c:     	cmp	x9, x23, lsl #1
100374910:     	b.hi	0x100374920 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x444>
100374914:     	lsl	x8, x8, #1
100374918:     	cmp	x8, x23
10037491c:     	b.hs	0x100374924 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x448>
100374920:     	bl	0x100374cd0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100374924:     	add	x0, sp, #0x48
100374928:     	bl	0x100266aec <__RNvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB5_13RuntimeHandle14get_nanbox_u64>
10037492c:     	mov	x22, x0
100374930:     	add	x0, sp, #0x10
100374934:     	bl	0x100165cfc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100374938:     	mov	x0, x22
10037493c:     	ldp	x29, x30, [sp, #0xb0]
100374940:     	ldp	x20, x19, [sp, #0xa0]
100374944:     	ldp	x22, x21, [sp, #0x90]
100374948:     	ldp	x24, x23, [sp, #0x80]
10037494c:     	ldp	x26, x25, [sp, #0x70]
100374950:     	ldp	x28, x27, [sp, #0x60]
100374954:     	add	sp, sp, #0xc0
100374958:     	ret
10037495c:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100374960:     	add	x0, x0, #0xd70
100374964:     	bl	0x100b1125c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100374968:     	bl	0x100b4a454 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10037496c:     	adrp	x0, 0x100c40000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x5440>
100374970:     	add	x0, x0, #0xce7
100374974:     	mov	w1, #0xb                ; =11
100374978:     	bl	0x100b4a41c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
