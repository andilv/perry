
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/zero-spacing-r25/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100686d84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>:
100686d84:     	stp	x22, x21, [sp, #-0x30]!
100686d88:     	stp	x20, x19, [sp, #0x10]
100686d8c:     	stp	x29, x30, [sp, #0x20]
100686d90:     	add	x29, sp, #0x20
100686d94:     	mov	x19, #0x1               ; =1
100686d98:     	movk	x19, #0x7ffc, lsl #48
100686d9c:     	cbz	x0, 0x100686e30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xac>
100686da0:     	ldr	x8, [x0, #0x20]
100686da4:     	cbz	x8, 0x100686dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0x78>
100686da8:     	mov	x20, x0
100686dac:     	mov	x21, x1
100686db0:     	bl	0x1006871ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100686db4:     	mov	x1, x21
100686db8:     	mov	x8, x0
100686dbc:     	mov	x0, x20
100686dc0:     	cbz	x8, 0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686dc4:     	ldurh	w9, [x8, #-0x6]
100686dc8:     	tbnz	w9, #0xa, 0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686dcc:     	ldr	w9, [x8]
100686dd0:     	cmp	w1, w9
100686dd4:     	b.hs	0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686dd8:     	ldr	w9, [x8, #0x4]
100686ddc:     	cmp	w1, w9
100686de0:     	b.hs	0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686de4:     	add	x8, x8, w1, uxtw #3
100686de8:     	add	x9, x19, #0xf
100686dec:     	ldr	x19, [x8, #0x8]
100686df0:     	cmp	x19, x9
100686df4:     	b.ne	0x100686e30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xac>
100686df8:     	b	0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686dfc:     	ldr	w8, [x0]
100686e00:     	cmp	w1, w8
100686e04:     	b.hs	0x100686e30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xac>
100686e08:     	ldr	x9, [x0, #0x30]
100686e0c:     	cbz	x9, 0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686e10:     	ldr	x8, [x0, #0x28]
100686e14:     	cbz	x8, 0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686e18:     	mov	w10, w1
100686e1c:     	lsr	x11, x10, #6
100686e20:     	ldr	x9, [x9, x11, lsl #3]
100686e24:     	lsr	x9, x9, x1
100686e28:     	tbz	w9, #0x0, 0x100686e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get+0xc0>
100686e2c:     	ldr	x19, [x8, x10, lsl #3]
100686e30:     	mov	x0, x19
100686e34:     	ldp	x29, x30, [sp, #0x20]
100686e38:     	ldp	x20, x19, [sp, #0x10]
100686e3c:     	ldp	x22, x21, [sp], #0x30
100686e40:     	ret
100686e44:     	ldp	x29, x30, [sp, #0x20]
100686e48:     	ldp	x20, x19, [sp, #0x10]
100686e4c:     	ldp	x22, x21, [sp], #0x30
100686e50:     	b	0x1003744dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>
