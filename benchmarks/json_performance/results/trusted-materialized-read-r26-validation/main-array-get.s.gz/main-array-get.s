
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/trusted-materialized-read-r26/main-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bcd50 <_js_array_get_f64>:
1007bcd50:     	sub	sp, sp, #0x70
1007bcd54:     	stp	x26, x25, [sp, #0x20]
1007bcd58:     	stp	x24, x23, [sp, #0x30]
1007bcd5c:     	stp	x22, x21, [sp, #0x40]
1007bcd60:     	stp	x20, x19, [sp, #0x50]
1007bcd64:     	stp	x29, x30, [sp, #0x60]
1007bcd68:     	add	x29, sp, #0x60
1007bcd6c:     	mov	x19, x1
1007bcd70:     	mov	x22, x0
1007bcd74:     	lsr	x25, x0, #51
1007bcd78:     	mov	x20, x0
1007bcd7c:     	cmp	x25, #0xfff
1007bcd80:     	b.lo	0x1007bcd9c <_js_array_get_f64+0x4c>
1007bcd84:     	mov	w8, #0x7ffc             ; =32764
1007bcd88:     	cmp	x8, x22, lsr #48
1007bcd8c:     	b.ne	0x1007bcd98 <_js_array_get_f64+0x48>
1007bcd90:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bcd94:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bcd98:     	and	x20, x22, #0xffffffffffff
1007bcd9c:     	lsr	x8, x20, #3
1007bcda0:     	cmp	x8, #0x200
1007bcda4:     	b.ls	0x1007bcddc <_js_array_get_f64+0x8c>
1007bcda8:     	ldurb	w8, [x20, #-0x8]
1007bcdac:     	cmp	w8, #0x9
1007bcdb0:     	b.ne	0x1007bcddc <_js_array_get_f64+0x8c>
1007bcdb4:     	ldr	w8, [x20, #0x4]
1007bcdb8:     	mov	w9, #0x5841             ; =22593
1007bcdbc:     	movk	w9, #0x4c5a, lsl #16
1007bcdc0:     	cmp	w8, w9
1007bcdc4:     	b.ne	0x1007bcddc <_js_array_get_f64+0x8c>
1007bcdc8:     	mov	x0, x20
1007bcdcc:     	mov	x1, x19
1007bcdd0:     	bl	0x100686d84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007bcdd4:     	fmov	d0, x0
1007bcdd8:     	b	0x1007bd44c <_js_array_get_f64+0x6fc>
1007bcddc:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcde0:     	b.lo	0x1007bce90 <_js_array_get_f64+0x140>
1007bcde4:     	tst	x20, #0xffff800000000000
1007bcde8:     	mov	w8, #0x1000             ; =4096
1007bcdec:     	ccmp	x20, x8, #0x0, eq
1007bcdf0:     	b.lo	0x1007bce90 <_js_array_get_f64+0x140>
1007bcdf4:     	ldurb	w24, [x20, #-0x8]
1007bcdf8:     	ldurh	w23, [x20, #-0x6]
1007bcdfc:     	cmp	w24, #0xa
1007bce00:     	b.gt	0x1007bcfa8 <_js_array_get_f64+0x258>
1007bce04:     	cmp	w24, #0x2
1007bce08:     	b.eq	0x1007bd030 <_js_array_get_f64+0x2e0>
1007bce0c:     	cmp	w24, #0x8
1007bce10:     	b.ne	0x1007bce98 <_js_array_get_f64+0x148>
1007bce14:     	mov	x0, x20
1007bce18:     	bl	0x100304028 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bce1c:     	cbz	w0, 0x1007bd0c0 <_js_array_get_f64+0x370>
1007bce20:     	mov	x22, #0x1               ; =1
1007bce24:     	movk	x22, #0x7ffc, lsl #48
1007bce28:     	lsr	x8, x20, #51
1007bce2c:     	cmp	x8, #0xfff
1007bce30:     	b.lo	0x1007bce44 <_js_array_get_f64+0xf4>
1007bce34:     	mov	w8, #0x7ffc             ; =32764
1007bce38:     	cmp	x8, x20, lsr #48
1007bce3c:     	b.eq	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bce40:     	and	x20, x20, #0xffffffffffff
1007bce44:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bce48:     	b.lo	0x1007bce68 <_js_array_get_f64+0x118>
1007bce4c:     	tst	x20, #0xffff800000000000
1007bce50:     	mov	w8, #0x1000             ; =4096
1007bce54:     	ccmp	x20, x8, #0x0, eq
1007bce58:     	b.lo	0x1007bce68 <_js_array_get_f64+0x118>
1007bce5c:     	ldurb	w8, [x20, #-0x8]
1007bce60:     	cmp	w8, #0x2
1007bce64:     	b.eq	0x1007bd734 <_js_array_get_f64+0x9e4>
1007bce68:     	cbz	x20, 0x1007bd448 <_js_array_get_f64+0x6f8>
1007bce6c:     	mov	x0, x20
1007bce70:     	mov	x1, x19
1007bce74:     	bl	0x1003041d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bce78:     	cmp	w0, #0x1
1007bce7c:     	b.ne	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bce80:     	ldr	x8, [x20, #0x8]
1007bce84:     	ubfiz	x9, x1, #4, #32
1007bce88:     	ldr	x22, [x8, x9]
1007bce8c:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bce90:     	mov	w23, #0x0               ; =0
1007bce94:     	mov	w24, #0x0               ; =0
1007bce98:     	mov	x21, x22
1007bce9c:     	cmp	x25, #0xfff
1007bcea0:     	b.lo	0x1007bceb8 <_js_array_get_f64+0x168>
1007bcea4:     	mov	w8, #0x7ffc             ; =32764
1007bcea8:     	cmp	x8, x22, lsr #48
1007bceac:     	b.eq	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bceb0:     	ands	x21, x22, #0xffffffffffff
1007bceb4:     	b.eq	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bceb8:     	and	x8, x21, #0xfffffffffff00000
1007bcebc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bcec0:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bcec4:     	cmp	x9, x10
1007bcec8:     	ccmp	x8, #0x0, #0x4, lo
1007bcecc:     	b.eq	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bced0:     	tst	x21, #0x3
1007bced4:     	ccmp	x21, #0x7, #0x0, eq
1007bced8:     	b.ls	0x1007bd188 <_js_array_get_f64+0x438>
1007bcedc:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bcee0:     	ldr	x8, [x8, #0x30]
1007bcee4:     	cmn	x8, #0x1
1007bcee8:     	b.eq	0x1007bd0d8 <_js_array_get_f64+0x388>
1007bceec:     	mrs	x9, TPIDRRO_EL0
1007bcef0:     	and	x9, x9, #0xfffffffffffffff8
1007bcef4:     	ldr	x0, [x9, x8, lsl #3]
1007bcef8:     	cbz	x0, 0x1007bd0d8 <_js_array_get_f64+0x388>
1007bcefc:     	lsr	x1, x21, #20
1007bcf00:     	ldr	x8, [x0, #0x10]
1007bcf04:     	ldrb	w9, [x8]
1007bcf08:     	cmp	w9, #0x2
1007bcf0c:     	b.ne	0x1007bd0f0 <_js_array_get_f64+0x3a0>
1007bcf10:     	ldrb	w9, [x8, #0x88]
1007bcf14:     	tbz	w9, #0x0, 0x1007bcf34 <_js_array_get_f64+0x1e4>
1007bcf18:     	ldr	x9, [x8, #0x80]
1007bcf1c:     	cmp	x9, x1
1007bcf20:     	b.ne	0x1007bcf34 <_js_array_get_f64+0x1e4>
1007bcf24:     	ldp	x9, x10, [x8, #0x60]
1007bcf28:     	cmp	x9, x21
1007bcf2c:     	ccmp	x10, x21, #0x0, ls
1007bcf30:     	b.hi	0x1007bd0d0 <_js_array_get_f64+0x380>
1007bcf34:     	ldrb	w9, [x8, #0xb8]
1007bcf38:     	cbz	w9, 0x1007bcf58 <_js_array_get_f64+0x208>
1007bcf3c:     	ldr	x9, [x8, #0xb0]
1007bcf40:     	cmp	x9, x1
1007bcf44:     	b.ne	0x1007bcf58 <_js_array_get_f64+0x208>
1007bcf48:     	ldp	x9, x10, [x8, #0x90]
1007bcf4c:     	cmp	x9, x21
1007bcf50:     	ccmp	x10, x21, #0x0, ls
1007bcf54:     	b.hi	0x1007bd598 <_js_array_get_f64+0x848>
1007bcf58:     	ldrb	w9, [x8, #0xe8]
1007bcf5c:     	cbz	w9, 0x1007bcf7c <_js_array_get_f64+0x22c>
1007bcf60:     	ldr	x9, [x8, #0xe0]
1007bcf64:     	cmp	x9, x1
1007bcf68:     	b.ne	0x1007bcf7c <_js_array_get_f64+0x22c>
1007bcf6c:     	ldp	x9, x10, [x8, #0xc0]
1007bcf70:     	cmp	x9, x21
1007bcf74:     	ccmp	x10, x21, #0x0, ls
1007bcf78:     	b.hi	0x1007bd680 <_js_array_get_f64+0x930>
1007bcf7c:     	ldrb	w9, [x8, #0x118]
1007bcf80:     	cbz	w9, 0x1007bd150 <_js_array_get_f64+0x400>
1007bcf84:     	ldr	x9, [x8, #0x110]
1007bcf88:     	cmp	x9, x1
1007bcf8c:     	b.ne	0x1007bd150 <_js_array_get_f64+0x400>
1007bcf90:     	ldp	x9, x10, [x8, #0xf0]
1007bcf94:     	cmp	x9, x21
1007bcf98:     	ccmp	x10, x21, #0x0, ls
1007bcf9c:     	b.ls	0x1007bd150 <_js_array_get_f64+0x400>
1007bcfa0:     	add	x9, x8, #0xf0
1007bcfa4:     	b	0x1007bd684 <_js_array_get_f64+0x934>
1007bcfa8:     	cmp	w24, #0xb
1007bcfac:     	b.eq	0x1007bd048 <_js_array_get_f64+0x2f8>
1007bcfb0:     	cmp	w24, #0xc
1007bcfb4:     	b.ne	0x1007bce98 <_js_array_get_f64+0x148>
1007bcfb8:     	mov	x0, x20
1007bcfbc:     	bl	0x100309db8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007bcfc0:     	cbz	w0, 0x1007bd0c8 <_js_array_get_f64+0x378>
1007bcfc4:     	mov	x22, #0x1               ; =1
1007bcfc8:     	movk	x22, #0x7ffc, lsl #48
1007bcfcc:     	lsr	x8, x20, #51
1007bcfd0:     	cmp	x8, #0xfff
1007bcfd4:     	b.lo	0x1007bcfe8 <_js_array_get_f64+0x298>
1007bcfd8:     	mov	w8, #0x7ffc             ; =32764
1007bcfdc:     	cmp	x8, x20, lsr #48
1007bcfe0:     	b.eq	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bcfe4:     	and	x20, x20, #0xffffffffffff
1007bcfe8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcfec:     	b.lo	0x1007bd00c <_js_array_get_f64+0x2bc>
1007bcff0:     	tst	x20, #0xffff800000000000
1007bcff4:     	mov	w8, #0x1000             ; =4096
1007bcff8:     	ccmp	x20, x8, #0x0, eq
1007bcffc:     	b.lo	0x1007bd00c <_js_array_get_f64+0x2bc>
1007bd000:     	ldurb	w8, [x20, #-0x8]
1007bd004:     	cmp	w8, #0x2
1007bd008:     	b.eq	0x1007bd74c <_js_array_get_f64+0x9fc>
1007bd00c:     	cbz	x20, 0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd010:     	mov	x0, x20
1007bd014:     	mov	x1, x19
1007bd018:     	bl	0x10030ba30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007bd01c:     	cmp	w0, #0x1
1007bd020:     	b.ne	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd024:     	ldr	x8, [x20, #0x8]
1007bd028:     	ldr	x22, [x8, w1, uxtw #3]
1007bd02c:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd030:     	mov	x0, x22
1007bd034:     	mov	x1, x19
1007bd038:     	bl	0x10054748c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd03c:     	tbnz	w0, #0x0, 0x1007bd444 <_js_array_get_f64+0x6f4>
1007bd040:     	mov	w24, #0x2               ; =2
1007bd044:     	b	0x1007bce98 <_js_array_get_f64+0x148>
1007bd048:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd04c:     	add	x8, x8, #0xe80
1007bd050:     	ldaprb	w8, [x8]
1007bd054:     	cbz	w8, 0x1007bd0b8 <_js_array_get_f64+0x368>
1007bd058:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd05c:     	add	x8, x8, #0x40
1007bd060:     	ldapr	x8, [x8]
1007bd064:     	cmp	x20, x8
1007bd068:     	b.lo	0x1007bd0b8 <_js_array_get_f64+0x368>
1007bd06c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd070:     	add	x8, x8, #0x48
1007bd074:     	ldapr	x8, [x8]
1007bd078:     	cmp	x20, x8
1007bd07c:     	b.hi	0x1007bd0b8 <_js_array_get_f64+0x368>
1007bd080:     	mov	x0, x20
1007bd084:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd088:     	tbz	w0, #0x0, 0x1007bd0b8 <_js_array_get_f64+0x368>
1007bd08c:     	add	x0, sp, #0x8
1007bd090:     	mov	x1, x20
1007bd094:     	bl	0x1002a392c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007bd098:     	ldr	x8, [sp, #0x8]
1007bd09c:     	cbz	x8, 0x1007bd6c4 <_js_array_get_f64+0x974>
1007bd0a0:     	cmp	x8, #0x1
1007bd0a4:     	b.ne	0x1007bd708 <_js_array_get_f64+0x9b8>
1007bd0a8:     	ldr	d0, [sp, #0x10]
1007bd0ac:     	scvtf	d1, w19
1007bd0b0:     	bl	0x10081b2f4 <_js_dyn_index_get>
1007bd0b4:     	b	0x1007bd444 <_js_array_get_f64+0x6f4>
1007bd0b8:     	mov	w24, #0xb               ; =11
1007bd0bc:     	b	0x1007bce98 <_js_array_get_f64+0x148>
1007bd0c0:     	mov	w24, #0x8               ; =8
1007bd0c4:     	b	0x1007bce98 <_js_array_get_f64+0x148>
1007bd0c8:     	mov	w24, #0xc               ; =12
1007bd0cc:     	b	0x1007bce98 <_js_array_get_f64+0x148>
1007bd0d0:     	add	x9, x8, #0x60
1007bd0d4:     	b	0x1007bd684 <_js_array_get_f64+0x934>
1007bd0d8:     	bl	0x100b3defc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007bd0dc:     	lsr	x1, x21, #20
1007bd0e0:     	ldr	x8, [x0, #0x10]
1007bd0e4:     	ldrb	w9, [x8]
1007bd0e8:     	cmp	w9, #0x2
1007bd0ec:     	b.eq	0x1007bcf10 <_js_array_get_f64+0x1c0>
1007bd0f0:     	ldr	x9, [x8, #0x8]
1007bd0f4:     	ldr	x10, [x8, #0x28]
1007bd0f8:     	sub	x9, x1, x9
1007bd0fc:     	cmp	x9, x10
1007bd100:     	b.hs	0x1007bd144 <_js_array_get_f64+0x3f4>
1007bd104:     	ldr	x10, [x8, #0x20]
1007bd108:     	mov	w11, #0x28              ; =40
1007bd10c:     	madd	x9, x9, x11, x10
1007bd110:     	ldr	x10, [x9]
1007bd114:     	ldr	x11, [x8, #0x10]
1007bd118:     	cmp	x10, x11
1007bd11c:     	b.ne	0x1007bd150 <_js_array_get_f64+0x400>
1007bd120:     	ldp	x10, x11, [x9, #0x8]
1007bd124:     	cmp	x10, x21
1007bd128:     	ccmp	x11, x21, #0x0, ls
1007bd12c:     	b.ls	0x1007bd150 <_js_array_get_f64+0x400>
1007bd130:     	ldr	x10, [x8, #0x30]
1007bd134:     	add	x10, x10, #0x1
1007bd138:     	str	x10, [x8, #0x30]
1007bd13c:     	add	x8, x9, #0x21
1007bd140:     	b	0x1007bd694 <_js_array_get_f64+0x944>
1007bd144:     	ldr	x9, [x8, #0x58]
1007bd148:     	add	x9, x9, #0x1
1007bd14c:     	str	x9, [x8, #0x58]
1007bd150:     	ldr	x9, [x8, #0x38]
1007bd154:     	add	x9, x9, #0x1
1007bd158:     	str	x9, [x8, #0x38]
1007bd15c:     	mov	x0, x21
1007bd160:     	bl	0x10051d1c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007bd164:     	and	w8, w0, #0xff
1007bd168:     	cbz	w8, 0x1007bd188 <_js_array_get_f64+0x438>
1007bd16c:     	ldurb	w8, [x21, #-0x8]
1007bd170:     	ldurb	w9, [x21, #-0x7]
1007bd174:     	mov	w10, #0x82              ; =130
1007bd178:     	and	w9, w9, w10
1007bd17c:     	cmp	w9, #0x2
1007bd180:     	ccmp	w8, #0x1, #0x0, eq
1007bd184:     	b.eq	0x1007bd258 <_js_array_get_f64+0x508>
1007bd188:     	mov	x0, x21
1007bd18c:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd190:     	cbz	x0, 0x1007bd1b8 <_js_array_get_f64+0x468>
1007bd194:     	ldrb	w9, [x0]
1007bd198:     	cmp	w9, #0x1
1007bd19c:     	b.ne	0x1007bd1d4 <_js_array_get_f64+0x484>
1007bd1a0:     	ldrsb	w8, [x0, #0x1]
1007bd1a4:     	tbnz	w8, #0x1f, 0x1007bd280 <_js_array_get_f64+0x530>
1007bd1a8:     	ldp	w10, w9, [x21]
1007bd1ac:     	cmp	w10, w9
1007bd1b0:     	b.hi	0x1007bd30c <_js_array_get_f64+0x5bc>
1007bd1b4:     	b	0x1007bd324 <_js_array_get_f64+0x5d4>
1007bd1b8:     	mov	x25, x0
1007bd1bc:     	mov	x0, x21
1007bd1c0:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd1c4:     	tbz	w0, #0x0, 0x1007bd210 <_js_array_get_f64+0x4c0>
1007bd1c8:     	mov	x0, #0x0                ; =0
1007bd1cc:     	mov	x8, x25
1007bd1d0:     	b	0x1007bd2fc <_js_array_get_f64+0x5ac>
1007bd1d4:     	mov	x8, x0
1007bd1d8:     	cmp	w9, #0x1
1007bd1dc:     	b.eq	0x1007bd2fc <_js_array_get_f64+0x5ac>
1007bd1e0:     	cmp	w9, #0x9
1007bd1e4:     	b.ne	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd1e8:     	ldr	w8, [x21, #0x4]
1007bd1ec:     	mov	w9, #0x5841             ; =22593
1007bd1f0:     	movk	w9, #0x4c5a, lsl #16
1007bd1f4:     	cmp	w8, w9
1007bd1f8:     	b.ne	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd1fc:     	mov	x0, x21
1007bd200:     	bl	0x100374cd0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007bd204:     	cbz	x0, 0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd208:     	mov	x21, x0
1007bd20c:     	b	0x1007bd340 <_js_array_get_f64+0x5f0>
1007bd210:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd214:     	add	x8, x8, #0xe80
1007bd218:     	ldaprb	w8, [x8]
1007bd21c:     	cbz	w8, 0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd220:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd224:     	add	x8, x8, #0x40
1007bd228:     	ldapr	x8, [x8]
1007bd22c:     	cmp	x8, x21
1007bd230:     	b.hi	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd234:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd238:     	add	x8, x8, #0x48
1007bd23c:     	ldapr	x8, [x8]
1007bd240:     	cmp	x8, x21
1007bd244:     	b.lo	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd248:     	mov	x0, x21
1007bd24c:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd250:     	tbnz	w0, #0x0, 0x1007bd1c8 <_js_array_get_f64+0x478>
1007bd254:     	b	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd258:     	ldr	w8, [x21]
1007bd25c:     	mov	w9, #0xe100             ; =57600
1007bd260:     	movk	w9, #0x5f5, lsl #16
1007bd264:     	orr	w9, w9, #0x1
1007bd268:     	cmp	w8, w9
1007bd26c:     	b.hs	0x1007bd188 <_js_array_get_f64+0x438>
1007bd270:     	ldr	w9, [x21, #0x4]
1007bd274:     	cmp	w8, w9
1007bd278:     	b.ls	0x1007bd340 <_js_array_get_f64+0x5f0>
1007bd27c:     	b	0x1007bd188 <_js_array_get_f64+0x438>
1007bd280:     	mov	x25, x0
1007bd284:     	ldr	x21, [x0, #0x8]
1007bd288:     	mov	x0, x21
1007bd28c:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd290:     	cbz	x0, 0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd294:     	ldrb	w8, [x0]
1007bd298:     	cmp	w8, #0x1
1007bd29c:     	b.ne	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd2a0:     	ldrsb	w8, [x0, #0x1]
1007bd2a4:     	tbz	w8, #0x1f, 0x1007bd1a8 <_js_array_get_f64+0x458>
1007bd2a8:     	mov	w26, #0x1               ; =1
1007bd2ac:     	ldr	x21, [x0, #0x8]
1007bd2b0:     	mov	x0, x21
1007bd2b4:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd2b8:     	cbz	x0, 0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd2bc:     	ldrb	w8, [x0]
1007bd2c0:     	cmp	w8, #0x1
1007bd2c4:     	b.ne	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd2c8:     	cmp	w26, #0x3f
1007bd2cc:     	b.hi	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd2d0:     	add	w26, w26, #0x1
1007bd2d4:     	ldrsb	w8, [x0, #0x1]
1007bd2d8:     	tbnz	w8, #0x1f, 0x1007bd2ac <_js_array_get_f64+0x55c>
1007bd2dc:     	str	x21, [x25, #0x8]
1007bd2e0:     	ldrb	w8, [x25, #0x1]
1007bd2e4:     	orr	w9, w8, #0x80
1007bd2e8:     	mov	x8, x25
1007bd2ec:     	strb	w9, [x25, #0x1]
1007bd2f0:     	ldrb	w9, [x0]
1007bd2f4:     	cmp	w9, #0x1
1007bd2f8:     	b.ne	0x1007bd1e0 <_js_array_get_f64+0x490>
1007bd2fc:     	ldp	w10, w9, [x21]
1007bd300:     	cmp	w10, w9
1007bd304:     	b.ls	0x1007bd324 <_js_array_get_f64+0x5d4>
1007bd308:     	cbz	x8, 0x1007bd334 <_js_array_get_f64+0x5e4>
1007bd30c:     	ldr	w8, [x0, #0x4]
1007bd310:     	ubfiz	x9, x9, #3, #32
1007bd314:     	add	x9, x9, #0x10
1007bd318:     	cmp	x9, x8
1007bd31c:     	b.eq	0x1007bd340 <_js_array_get_f64+0x5f0>
1007bd320:     	b	0x1007bd334 <_js_array_get_f64+0x5e4>
1007bd324:     	mov	w8, #0xe100             ; =57600
1007bd328:     	movk	w8, #0x5f5, lsl #16
1007bd32c:     	cmp	w10, w8
1007bd330:     	b.ls	0x1007bd340 <_js_array_get_f64+0x5f0>
1007bd334:     	mov	x0, x21
1007bd338:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd33c:     	tbz	w0, #0x0, 0x1007bd3f0 <_js_array_get_f64+0x6a0>
1007bd340:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd344:     	add	x8, x8, #0xe80
1007bd348:     	ldaprb	w8, [x8]
1007bd34c:     	cbz	w8, 0x1007bd394 <_js_array_get_f64+0x644>
1007bd350:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd354:     	add	x8, x8, #0x40
1007bd358:     	ldapr	x8, [x8]
1007bd35c:     	cmp	x21, x8
1007bd360:     	b.lo	0x1007bd394 <_js_array_get_f64+0x644>
1007bd364:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd368:     	add	x8, x8, #0x48
1007bd36c:     	ldapr	x8, [x8]
1007bd370:     	cmp	x21, x8
1007bd374:     	b.hi	0x1007bd394 <_js_array_get_f64+0x644>
1007bd378:     	mov	x0, x21
1007bd37c:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd380:     	tbz	w0, #0x0, 0x1007bd394 <_js_array_get_f64+0x644>
1007bd384:     	mov	x0, x21
1007bd388:     	mov	x1, x19
1007bd38c:     	bl	0x1008fafc8 <_js_typed_array_get>
1007bd390:     	b	0x1007bd444 <_js_array_get_f64+0x6f4>
1007bd394:     	mov	x0, x21
1007bd398:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd39c:     	tbz	w0, #0x0, 0x1007bd3c4 <_js_array_get_f64+0x674>
1007bd3a0:     	mov	x0, x21
1007bd3a4:     	mov	x1, x19
1007bd3a8:     	bl	0x10058539c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bd3ac:     	and	w8, w1, #0xff
1007bd3b0:     	ucvtf	d0, w8
1007bd3b4:     	fmov	x8, d0
1007bd3b8:     	tst	w0, #0x1
1007bd3bc:     	csel	x22, x8, xzr, ne
1007bd3c0:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd3c4:     	cmp	x21, x20
1007bd3c8:     	b.eq	0x1007bd470 <_js_array_get_f64+0x720>
1007bd3cc:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bd3d0:     	b.lo	0x1007bd468 <_js_array_get_f64+0x718>
1007bd3d4:     	tst	x21, #0xffff800000000000
1007bd3d8:     	mov	w8, #0x1000             ; =4096
1007bd3dc:     	ccmp	x21, x8, #0x0, eq
1007bd3e0:     	b.lo	0x1007bd468 <_js_array_get_f64+0x718>
1007bd3e4:     	ldurb	w24, [x21, #-0x8]
1007bd3e8:     	ldurh	w23, [x21, #-0x6]
1007bd3ec:     	b	0x1007bd470 <_js_array_get_f64+0x720>
1007bd3f0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd3f4:     	add	x8, x8, #0xe80
1007bd3f8:     	ldaprb	w8, [x8]
1007bd3fc:     	cbz	w8, 0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd400:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd404:     	add	x8, x8, #0x40
1007bd408:     	ldapr	x8, [x8]
1007bd40c:     	cmp	x21, x8
1007bd410:     	b.lo	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd414:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd418:     	add	x8, x8, #0x48
1007bd41c:     	ldapr	x8, [x8]
1007bd420:     	cmp	x21, x8
1007bd424:     	b.hi	0x1007bd434 <_js_array_get_f64+0x6e4>
1007bd428:     	mov	x0, x21
1007bd42c:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd430:     	tbnz	w0, #0x0, 0x1007bd340 <_js_array_get_f64+0x5f0>
1007bd434:     	mov	x0, x22
1007bd438:     	mov	x1, x19
1007bd43c:     	bl	0x10054748c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd440:     	tbz	w0, #0x0, 0x1007bd718 <_js_array_get_f64+0x9c8>
1007bd444:     	fmov	x22, d0
1007bd448:     	fmov	d0, x22
1007bd44c:     	ldp	x29, x30, [sp, #0x60]
1007bd450:     	ldp	x20, x19, [sp, #0x50]
1007bd454:     	ldp	x22, x21, [sp, #0x40]
1007bd458:     	ldp	x24, x23, [sp, #0x30]
1007bd45c:     	ldp	x26, x25, [sp, #0x20]
1007bd460:     	add	sp, sp, #0x70
1007bd464:     	ret
1007bd468:     	mov	w23, #0x0               ; =0
1007bd46c:     	mov	w24, #0x0               ; =0
1007bd470:     	cmp	w24, #0x1
1007bd474:     	b.ne	0x1007bd628 <_js_array_get_f64+0x8d8>
1007bd478:     	tbz	w23, #0xa, 0x1007bd628 <_js_array_get_f64+0x8d8>
1007bd47c:     	adrp	x8, 0x100b63000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data1n7OFFSETS+0xa6>
1007bd480:     	add	x8, x8, #0x90c
1007bd484:     	cmp	w19, #0x3e8
1007bd488:     	b.lo	0x1007bd500 <_js_array_get_f64+0x7b0>
1007bd48c:     	mov	x9, #0x0                ; =0
1007bd490:     	mov	w11, #0x1759            ; =5977
1007bd494:     	movk	w11, #0xd1b7, lsl #16
1007bd498:     	mov	w12, #0x2710            ; =10000
1007bd49c:     	mov	w13, #0x147b            ; =5243
1007bd4a0:     	mov	w14, #0x64              ; =100
1007bd4a4:     	add	x15, sp, #0x8
1007bd4a8:     	mov	w16, #0x967f            ; =38527
1007bd4ac:     	movk	w16, #0x98, lsl #16
1007bd4b0:     	mov	x10, x19
1007bd4b4:     	mov	x17, x10
1007bd4b8:     	umull	x10, w10, w11
1007bd4bc:     	lsr	x10, x10, #45
1007bd4c0:     	msub	w0, w10, w12, w17
1007bd4c4:     	ubfx	w1, w0, #2, #14
1007bd4c8:     	mul	w1, w1, w13
1007bd4cc:     	lsr	w1, w1, #17
1007bd4d0:     	msub	w0, w1, w14, w0
1007bd4d4:     	add	x2, x15, x9
1007bd4d8:     	ldrh	w1, [x8, w1, uxtw #1]
1007bd4dc:     	strh	w1, [x2, #0x6]
1007bd4e0:     	and	x0, x0, #0xffff
1007bd4e4:     	ldrh	w0, [x8, x0, lsl #1]
1007bd4e8:     	strh	w0, [x2, #0x8]
1007bd4ec:     	sub	x9, x9, #0x4
1007bd4f0:     	cmp	w17, w16
1007bd4f4:     	b.hi	0x1007bd4b4 <_js_array_get_f64+0x764>
1007bd4f8:     	add	x9, x9, #0xa
1007bd4fc:     	b	0x1007bd508 <_js_array_get_f64+0x7b8>
1007bd500:     	mov	w9, #0xa                ; =10
1007bd504:     	mov	x10, x19
1007bd508:     	cmp	w10, #0x9
1007bd50c:     	b.ls	0x1007bd540 <_js_array_get_f64+0x7f0>
1007bd510:     	sub	x9, x9, #0x2
1007bd514:     	ubfx	w11, w10, #2, #14
1007bd518:     	mov	w12, #0x147b            ; =5243
1007bd51c:     	mul	w11, w11, w12
1007bd520:     	lsr	w11, w11, #17
1007bd524:     	mov	w12, #0x64              ; =100
1007bd528:     	msub	w10, w11, w12, w10
1007bd52c:     	and	x10, x10, #0xffff
1007bd530:     	ldrh	w10, [x8, x10, lsl #1]
1007bd534:     	add	x12, sp, #0x8
1007bd538:     	strh	w10, [x12, x9]
1007bd53c:     	mov	x10, x11
1007bd540:     	cbz	w19, 0x1007bd578 <_js_array_get_f64+0x828>
1007bd544:     	cbnz	w10, 0x1007bd578 <_js_array_get_f64+0x828>
1007bd548:     	cmp	x9, #0xa
1007bd54c:     	b.ne	0x1007bd5a0 <_js_array_get_f64+0x850>
1007bd550:     	mov	w23, #0x1               ; =1
1007bd554:     	add	x0, sp, #0x8
1007bd558:     	mov	x1, x21
1007bd55c:     	mov	w2, #0x1                ; =1
1007bd560:     	mov	x3, #0x0                ; =0
1007bd564:     	bl	0x1005b177c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd568:     	ldr	x8, [sp, #0x8]
1007bd56c:     	mov	w20, #0x1               ; =1
1007bd570:     	cbnz	x8, 0x1007bd5f0 <_js_array_get_f64+0x8a0>
1007bd574:     	b	0x1007bd628 <_js_array_get_f64+0x8d8>
1007bd578:     	sub	x23, x9, #0x1
1007bd57c:     	ubfiz	w10, w10, #1, #4
1007bd580:     	add	x8, x8, x10
1007bd584:     	ldrb	w8, [x8, #0x1]
1007bd588:     	add	x10, sp, #0x8
1007bd58c:     	strb	w8, [x10, x23]
1007bd590:     	mov	w8, #0xb                ; =11
1007bd594:     	b	0x1007bd5a8 <_js_array_get_f64+0x858>
1007bd598:     	add	x9, x8, #0x90
1007bd59c:     	b	0x1007bd684 <_js_array_get_f64+0x934>
1007bd5a0:     	mov	w8, #0xa                ; =10
1007bd5a4:     	mov	x23, x9
1007bd5a8:     	sub	x22, x8, x9
1007bd5ac:     	mov	x0, x22
1007bd5b0:     	mov	w1, #0x1                ; =1
1007bd5b4:     	bl	0x100b5dd48 <_mi_malloc_aligned>
1007bd5b8:     	cbz	x0, 0x1007bd764 <_js_array_get_f64+0xa14>
1007bd5bc:     	mov	x20, x0
1007bd5c0:     	add	x8, sp, #0x8
1007bd5c4:     	add	x1, x8, x23
1007bd5c8:     	mov	x2, x22
1007bd5cc:     	bl	0x100b6096c <_writev+0x100b6096c>
1007bd5d0:     	add	x0, sp, #0x8
1007bd5d4:     	mov	x1, x21
1007bd5d8:     	mov	x2, x20
1007bd5dc:     	mov	x3, x22
1007bd5e0:     	bl	0x1005b177c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd5e4:     	ldr	w8, [sp, #0x8]
1007bd5e8:     	tbz	w8, #0x0, 0x1007bd620 <_js_array_get_f64+0x8d0>
1007bd5ec:     	mov	w23, #0x0               ; =0
1007bd5f0:     	mov	x22, #0x1               ; =1
1007bd5f4:     	movk	x22, #0x7ffc, lsl #48
1007bd5f8:     	ldr	x0, [sp, #0x10]
1007bd5fc:     	cbz	x0, 0x1007bd6b4 <_js_array_get_f64+0x964>
1007bd600:     	cbz	x21, 0x1007bd6a4 <_js_array_get_f64+0x954>
1007bd604:     	lsr	x8, x21, #52
1007bd608:     	cmp	x8, #0x7fe
1007bd60c:     	b.hi	0x1007bd6a8 <_js_array_get_f64+0x958>
1007bd610:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bd614:     	bfxil	x8, x21, #0, #48
1007bd618:     	mov	x21, x8
1007bd61c:     	b	0x1007bd6a8 <_js_array_get_f64+0x958>
1007bd620:     	mov	x0, x20
1007bd624:     	bl	0x100b5dac0 <_mi_free>
1007bd628:     	ldr	w8, [x21]
1007bd62c:     	cmp	w19, w8
1007bd630:     	b.hs	0x1007bd670 <_js_array_get_f64+0x920>
1007bd634:     	ldr	w8, [x21, #0x4]
1007bd638:     	cmp	w19, w8
1007bd63c:     	b.hs	0x1007bd660 <_js_array_get_f64+0x910>
1007bd640:     	add	x8, x21, w19, uxtw #3
1007bd644:     	ldr	x22, [x8, #0x8]
1007bd648:     	mov	x8, #0x1                ; =1
1007bd64c:     	movk	x8, #0x7ffc, lsl #48
1007bd650:     	add	x8, x8, #0xf
1007bd654:     	cmp	x22, x8
1007bd658:     	b.ne	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd65c:     	b	0x1007bd670 <_js_array_get_f64+0x920>
1007bd660:     	mov	x0, x21
1007bd664:     	mov	x1, x19
1007bd668:     	bl	0x100529884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bd66c:     	tbnz	w0, #0x0, 0x1007bd444 <_js_array_get_f64+0x6f4>
1007bd670:     	mov	x0, x21
1007bd674:     	mov	x1, x19
1007bd678:     	bl	0x1006c6198 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bd67c:     	b	0x1007bd444 <_js_array_get_f64+0x6f4>
1007bd680:     	add	x9, x8, #0xc0
1007bd684:     	ldr	x10, [x8, #0x30]
1007bd688:     	add	x10, x10, #0x1
1007bd68c:     	str	x10, [x8, #0x30]
1007bd690:     	add	x8, x9, #0x19
1007bd694:     	ldrb	w8, [x8]
1007bd698:     	cmp	w8, #0xff
1007bd69c:     	b.ne	0x1007bd168 <_js_array_get_f64+0x418>
1007bd6a0:     	b	0x1007bd15c <_js_array_get_f64+0x40c>
1007bd6a4:     	add	x21, x22, #0x1
1007bd6a8:     	fmov	d0, x21
1007bd6ac:     	bl	0x1006fbfbc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bd6b0:     	mov	x22, x0
1007bd6b4:     	tbnz	w23, #0x0, 0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd6b8:     	mov	x0, x20
1007bd6bc:     	bl	0x100b5dac0 <_mi_free>
1007bd6c0:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd6c4:     	ldr	x20, [sp, #0x10]
1007bd6c8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd6cc:     	ldr	x8, [x8, #0xe98]
1007bd6d0:     	cbz	x8, 0x1007bd6e8 <_js_array_get_f64+0x998>
1007bd6d4:     	mov	x0, x20
1007bd6d8:     	bl	0x10013bbc0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bd6dc:     	tbz	w0, #0x0, 0x1007bd6e8 <_js_array_get_f64+0x998>
1007bd6e0:     	mov	x0, x20
1007bd6e4:     	bl	0x1002bdd00 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bd6e8:     	tbnz	w19, #0x1f, 0x1007bd708 <_js_array_get_f64+0x9b8>
1007bd6ec:     	ldr	w8, [x20]
1007bd6f0:     	cmp	w19, w8
1007bd6f4:     	b.hs	0x1007bd708 <_js_array_get_f64+0x9b8>
1007bd6f8:     	mov	w1, w19
1007bd6fc:     	mov	x0, x20
1007bd700:     	bl	0x1002a3f8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bd704:     	b	0x1007bd444 <_js_array_get_f64+0x6f4>
1007bd708:     	mov	x8, #0x1                ; =1
1007bd70c:     	movk	x8, #0x7ffc, lsl #48
1007bd710:     	mov	x22, x8
1007bd714:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd718:     	mov	x0, x22
1007bd71c:     	bl	0x100b46430 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bd720:     	cmp	x0, #0x1
1007bd724:     	b.ne	0x1007bcd90 <_js_array_get_f64+0x40>
1007bd728:     	mov	x0, x19
1007bd72c:     	bl	0x100b46450 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bd730:     	b	0x1007bd444 <_js_array_get_f64+0x6f4>
1007bd734:     	mov	x0, x20
1007bd738:     	mov	w1, #0x0                ; =0
1007bd73c:     	bl	0x100b489c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd740:     	mov	x20, x0
1007bd744:     	cbnz	x0, 0x1007bce6c <_js_array_get_f64+0x11c>
1007bd748:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd74c:     	mov	x0, x20
1007bd750:     	mov	w1, #0x1                ; =1
1007bd754:     	bl	0x100b489c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd758:     	mov	x20, x0
1007bd75c:     	cbnz	x0, 0x1007bd010 <_js_array_get_f64+0x2c0>
1007bd760:     	b	0x1007bd448 <_js_array_get_f64+0x6f8>
1007bd764:     	mov	w0, #0x1                ; =1
1007bd768:     	mov	x1, x22
1007bd76c:     	bl	0x100b10e80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
