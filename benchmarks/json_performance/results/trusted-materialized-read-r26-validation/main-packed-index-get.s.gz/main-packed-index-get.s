
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/trusted-materialized-read-r26/main-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010089c220 <_js_packed_arraylike_index_get>:
10089c220:     	sub	sp, sp, #0x90
10089c224:     	stp	d9, d8, [sp, #0x20]
10089c228:     	stp	x28, x27, [sp, #0x30]
10089c22c:     	stp	x26, x25, [sp, #0x40]
10089c230:     	stp	x24, x23, [sp, #0x50]
10089c234:     	stp	x22, x21, [sp, #0x60]
10089c238:     	stp	x20, x19, [sp, #0x70]
10089c23c:     	stp	x29, x30, [sp, #0x80]
10089c240:     	add	x29, sp, #0x80
10089c244:     	fmov	x1, d1
10089c248:     	mov	w8, #0x7ffe0000         ; =2147352576
10089c24c:     	cmp	x8, x1, lsr #32
10089c250:     	b.ne	0x10089c26c <_js_packed_arraylike_index_get+0x4c>
10089c254:     	tbnz	w1, #0x1f, 0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c258:     	fmov	x8, d0
10089c25c:     	mov	w9, #0x7ffd             ; =32765
10089c260:     	cmp	x9, x8, lsr #48
10089c264:     	b.eq	0x10089c2f4 <_js_packed_arraylike_index_get+0xd4>
10089c268:     	b	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c26c:     	and	x8, x1, #0xffff000000000000
10089c270:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10089c274:     	cmp	x1, x9
10089c278:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10089c27c:     	ccmp	x8, x9, #0x2, hs
10089c280:     	cset	w8, hi
10089c284:     	fmov	x9, d1
10089c288:     	ands	x10, x9, #0x7fffffffffffffff
10089c28c:     	cset	w11, eq
10089c290:     	sub	x12, x9, #0x1
10089c294:     	mov	x13, #0xfffffffffffff   ; =4503599627370495
10089c298:     	cmp	x12, x13
10089c29c:     	csinc	w11, w11, wzr, hs
10089c2a0:     	mov	x12, #-0x10000000000000 ; =-4503599627370496
10089c2a4:     	add	x10, x10, x12
10089c2a8:     	lsr	x10, x10, #53
10089c2ac:     	cmp	x10, #0x3ff
10089c2b0:     	ccmn	x9, #0x1, #0x4, lo
10089c2b4:     	csinc	w9, w11, wzr, le
10089c2b8:     	mov	x10, #0xffffffc00000    ; =281474972516352
10089c2bc:     	movk	x10, #0x41ef, lsl #48
10089c2c0:     	fmov	d2, x10
10089c2c4:     	fcmp	d1, d2
10089c2c8:     	b.hi	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c2cc:     	frintz	d2, d1
10089c2d0:     	fcmp	d1, d2
10089c2d4:     	b.ne	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c2d8:     	cbz	w9, 0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c2dc:     	cbz	w8, 0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c2e0:     	fcvtzu	w1, d1
10089c2e4:     	fmov	x8, d0
10089c2e8:     	mov	w9, #0x7ffd             ; =32765
10089c2ec:     	cmp	x9, x8, lsr #48
10089c2f0:     	b.ne	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c2f4:     	and	x19, x8, #0xffffffffffff
10089c2f8:     	sub	x8, x19, #0x100, lsl #12 ; =0x100000
10089c2fc:     	mov	x9, #0x7fffffffffff     ; =140737488355327
10089c300:     	movk	x9, #0xffef, lsl #16
10089c304:     	cmp	x8, x9
10089c308:     	b.hi	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c30c:     	ldurb	w8, [x19, #-0x8]
10089c310:     	cmp	w8, #0x9
10089c314:     	b.eq	0x10089c328 <_js_packed_arraylike_index_get+0x108>
10089c318:     	cmp	w8, #0x2
10089c31c:     	b.eq	0x10089c350 <_js_packed_arraylike_index_get+0x130>
10089c320:     	cmp	w8, #0x1
10089c324:     	b.ne	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c328:     	mov	x0, x19
10089c32c:     	ldp	x29, x30, [sp, #0x80]
10089c330:     	ldp	x20, x19, [sp, #0x70]
10089c334:     	ldp	x22, x21, [sp, #0x60]
10089c338:     	ldp	x24, x23, [sp, #0x50]
10089c33c:     	ldp	x26, x25, [sp, #0x40]
10089c340:     	ldp	x28, x27, [sp, #0x30]
10089c344:     	ldp	d9, d8, [sp, #0x20]
10089c348:     	add	sp, sp, #0x90
10089c34c:     	b	0x1007bcd50 <_js_array_get_f64>
10089c350:     	ldursb	w8, [x19, #-0x7]
10089c354:     	tbnz	w8, #0x1f, 0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c358:     	ldr	x8, [x19, #0x8]
10089c35c:     	cbz	x8, 0x10089c398 <_js_packed_arraylike_index_get+0x178>
10089c360:     	ldr	x8, [x8, #0x60]
10089c364:     	cbz	x8, 0x10089c398 <_js_packed_arraylike_index_get+0x178>
10089c368:     	ldr	w9, [x8]
10089c36c:     	cmp	w1, w9
10089c370:     	b.hs	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c374:     	add	x8, x8, w1, uxtw #3
10089c378:     	ldr	x8, [x8, #0x8]
10089c37c:     	mov	x9, #0x1                ; =1
10089c380:     	movk	x9, #0x7ffc, lsl #48
10089c384:     	add	x9, x9, #0xf
10089c388:     	cmp	x8, x9
10089c38c:     	b.eq	0x10089c4f0 <_js_packed_arraylike_index_get+0x2d0>
10089c390:     	fmov	d0, x8
10089c394:     	b	0x10089c5a8 <_js_packed_arraylike_index_get+0x388>
10089c398:     	mov	x21, x0
10089c39c:     	mov	x22, x1
10089c3a0:     	mov.16b	v8, v0
10089c3a4:     	mov.16b	v9, v1
10089c3a8:     	add	x0, sp, #0xc
10089c3ac:     	mov	x1, x19
10089c3b0:     	bl	0x100547724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33dense_layout_for_validated_object>
10089c3b4:     	ldr	w8, [sp, #0xc]
10089c3b8:     	cbz	w8, 0x10089c4e8 <_js_packed_arraylike_index_get+0x2c8>
10089c3bc:     	ldp	w20, w25, [sp, #0x10]
10089c3c0:     	adrp	x24, 0x100f7d000 <__MergedGlobals+0xd0>
10089c3c4:     	add	x24, x24, #0x390
10089c3c8:     	adrp	x23, 0x100f7d000 <__MergedGlobals+0xd0>
10089c3cc:     	ldp	w27, w26, [sp, #0x18]
10089c3d0:     	cbz	x21, 0x10089c414 <_js_packed_arraylike_index_get+0x1f4>
10089c3d4:     	mov	x0, x21
10089c3d8:     	ldapr	x8, [x24]
10089c3dc:     	cbnz	x8, 0x10089c468 <_js_packed_arraylike_index_get+0x248>
10089c3e0:     	ldrb	w8, [x23, #0x398]
10089c3e4:     	tbz	w8, #0x0, 0x10089c414 <_js_packed_arraylike_index_get+0x1f4>
10089c3e8:     	ldapr	x21, [x0]
10089c3ec:     	cbz	x21, 0x10089c554 <_js_packed_arraylike_index_get+0x334>
10089c3f0:     	mov	x0, x19
10089c3f4:     	mov	x1, x20
10089c3f8:     	bl	0x100548600 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass42array_subclass_named_prefix_token_for_slot>
10089c3fc:     	stp	x20, x25, [x21, #0x8]
10089c400:     	stp	x27, x26, [x21, #0x18]
10089c404:     	cbnz	x0, 0x10089c410 <_js_packed_arraylike_index_get+0x1f0>
10089c408:     	ldp	w9, w8, [x19]
10089c40c:     	orr	x0, x8, x9, lsl #32
10089c410:     	str	x0, [x21]
10089c414:     	cmp	w20, w26
10089c418:     	b.hs	0x10089c428 <_js_packed_arraylike_index_get+0x208>
10089c41c:     	add	x8, x19, x20, lsl #3
10089c420:     	ldr	x0, [x8, #0x10]
10089c424:     	b	0x10089c4b0 <_js_packed_arraylike_index_get+0x290>
10089c428:     	ldapr	x8, [x24]
10089c42c:     	cbnz	x8, 0x10089c47c <_js_packed_arraylike_index_get+0x25c>
10089c430:     	mov	x0, #0x1                ; =1
10089c434:     	movk	x0, #0x7ffc, lsl #48
10089c438:     	ldrb	w8, [x23, #0x398]
10089c43c:     	tbz	w8, #0x0, 0x10089c490 <_js_packed_arraylike_index_get+0x270>
10089c440:     	ldr	x8, [x19, #0x8]
10089c444:     	cbz	x8, 0x10089c4b0 <_js_packed_arraylike_index_get+0x290>
10089c448:     	ldr	x8, [x8, #0x20]
10089c44c:     	cbz	x8, 0x10089c4b0 <_js_packed_arraylike_index_get+0x290>
10089c450:     	ldr	w9, [x8]
10089c454:     	cmp	w20, w9
10089c458:     	b.hs	0x10089c4b0 <_js_packed_arraylike_index_get+0x290>
10089c45c:     	add	x8, x8, x20, lsl #3
10089c460:     	ldr	x0, [x8, #0x8]
10089c464:     	b	0x10089c4b0 <_js_packed_arraylike_index_get+0x290>
10089c468:     	bl	0x100b1836c <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c46c:     	mov	x0, x21
10089c470:     	ldrb	w8, [x23, #0x398]
10089c474:     	tbnz	w8, #0x0, 0x10089c3e8 <_js_packed_arraylike_index_get+0x1c8>
10089c478:     	b	0x10089c414 <_js_packed_arraylike_index_get+0x1f4>
10089c47c:     	bl	0x100b1836c <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c480:     	mov	x0, #0x1                ; =1
10089c484:     	movk	x0, #0x7ffc, lsl #48
10089c488:     	ldrb	w8, [x23, #0x398]
10089c48c:     	tbnz	w8, #0x0, 0x10089c440 <_js_packed_arraylike_index_get+0x220>
10089c490:     	mov	x0, x19
10089c494:     	mov	x1, x20
10089c498:     	bl	0x1005d9b1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill12overflow_get>
10089c49c:     	mov	x8, x0
10089c4a0:     	mov	x0, #0x1                ; =1
10089c4a4:     	movk	x0, #0x7ffc, lsl #48
10089c4a8:     	tst	w8, #0x1
10089c4ac:     	csel	x0, x1, x0, ne
10089c4b0:     	bl	0x100546420 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22nonnegative_u32_length>
10089c4b4:     	cmp	w0, #0x1
10089c4b8:     	b.ne	0x10089c4e8 <_js_packed_arraylike_index_get+0x2c8>
10089c4bc:     	cmp	w22, w1
10089c4c0:     	b.hs	0x10089c4e8 <_js_packed_arraylike_index_get+0x2c8>
10089c4c4:     	cmp	w22, w27
10089c4c8:     	b.hs	0x10089c4e8 <_js_packed_arraylike_index_get+0x2c8>
10089c4cc:     	adds	w1, w25, w22
10089c4d0:     	b.hs	0x10089c4e8 <_js_packed_arraylike_index_get+0x2c8>
10089c4d4:     	cmp	w1, w26
10089c4d8:     	b.hs	0x10089c514 <_js_packed_arraylike_index_get+0x2f4>
10089c4dc:     	add	x8, x19, w1, uxtw #3
10089c4e0:     	ldr	x20, [x8, #0x10]
10089c4e4:     	b	0x10089c5a4 <_js_packed_arraylike_index_get+0x384>
10089c4e8:     	mov.16b	v1, v9
10089c4ec:     	mov.16b	v0, v8
10089c4f0:     	ldp	x29, x30, [sp, #0x80]
10089c4f4:     	ldp	x20, x19, [sp, #0x70]
10089c4f8:     	ldp	x22, x21, [sp, #0x60]
10089c4fc:     	ldp	x24, x23, [sp, #0x50]
10089c500:     	ldp	x26, x25, [sp, #0x40]
10089c504:     	ldp	x28, x27, [sp, #0x30]
10089c508:     	ldp	d9, d8, [sp, #0x20]
10089c50c:     	add	sp, sp, #0x90
10089c510:     	b	0x10081b2f4 <_js_dyn_index_get>
10089c514:     	ldapr	x8, [x24]
10089c518:     	cbnz	x8, 0x10089c578 <_js_packed_arraylike_index_get+0x358>
10089c51c:     	mov	x20, #0x1               ; =1
10089c520:     	movk	x20, #0x7ffc, lsl #48
10089c524:     	ldrb	w8, [x23, #0x398]
10089c528:     	tbz	w8, #0x0, 0x10089c594 <_js_packed_arraylike_index_get+0x374>
10089c52c:     	ldr	x8, [x19, #0x8]
10089c530:     	cbz	x8, 0x10089c5a4 <_js_packed_arraylike_index_get+0x384>
10089c534:     	ldr	x8, [x8, #0x20]
10089c538:     	cbz	x8, 0x10089c5a4 <_js_packed_arraylike_index_get+0x384>
10089c53c:     	ldr	w9, [x8]
10089c540:     	cmp	w1, w9
10089c544:     	b.hs	0x10089c5a4 <_js_packed_arraylike_index_get+0x384>
10089c548:     	add	x8, x8, w1, uxtw #3
10089c54c:     	ldr	x20, [x8, #0x8]
10089c550:     	b	0x10089c5a4 <_js_packed_arraylike_index_get+0x384>
10089c554:     	bl	0x100b37f28 <__RINvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set7ic_slot16pic_slot_publishAyj5_EB8_>
10089c558:     	mov	x21, x0
10089c55c:     	mov	x0, x19
10089c560:     	mov	x1, x20
10089c564:     	bl	0x100548600 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass42array_subclass_named_prefix_token_for_slot>
10089c568:     	stp	x20, x25, [x21, #0x8]
10089c56c:     	stp	x27, x26, [x21, #0x18]
10089c570:     	cbnz	x0, 0x10089c410 <_js_packed_arraylike_index_get+0x1f0>
10089c574:     	b	0x10089c408 <_js_packed_arraylike_index_get+0x1e8>
10089c578:     	mov	x20, x1
10089c57c:     	bl	0x100b1836c <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c580:     	mov	x1, x20
10089c584:     	mov	x20, #0x1               ; =1
10089c588:     	movk	x20, #0x7ffc, lsl #48
10089c58c:     	ldrb	w8, [x23, #0x398]
10089c590:     	tbnz	w8, #0x0, 0x10089c52c <_js_packed_arraylike_index_get+0x30c>
10089c594:     	mov	x0, x19
10089c598:     	bl	0x1005d9b1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill12overflow_get>
10089c59c:     	tst	w0, #0x1
10089c5a0:     	csel	x20, x1, x20, ne
10089c5a4:     	fmov	d0, x20
10089c5a8:     	ldp	x29, x30, [sp, #0x80]
10089c5ac:     	ldp	x20, x19, [sp, #0x70]
10089c5b0:     	ldp	x22, x21, [sp, #0x60]
10089c5b4:     	ldp	x24, x23, [sp, #0x50]
10089c5b8:     	ldp	x26, x25, [sp, #0x40]
10089c5bc:     	ldp	x28, x27, [sp, #0x30]
10089c5c0:     	ldp	d9, d8, [sp, #0x20]
10089c5c4:     	add	sp, sp, #0x90
10089c5c8:     	ret
10089c5cc:     	nop
10089c5d0:     	nop
10089c5d4:     	nop
10089c5d8:     	nop
10089c5dc:     	nop
10089c5e0:     	nop
10089c5e4:     	nop
10089c5e8:     	nop
10089c5ec:     	nop
10089c5f0:     	nop
10089c5f4:     	nop
10089c5f8:     	nop
10089c5fc:     	nop
