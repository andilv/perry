
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/trusted-materialized-read-r26/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844654 <_js_json_parse>:
100844654:     	stp	x29, x30, [sp, #-0x10]!
100844658:     	mov	x29, sp
10084465c:     	cbz	x0, 0x1008446b4 <_js_json_parse+0x60>
100844660:     	ldr	w1, [x0, #0x4]
100844664:     	cmp	w1, #0x2
100844668:     	b.eq	0x100844678 <_js_json_parse+0x24>
10084466c:     	cbz	w1, 0x1008446b4 <_js_json_parse+0x60>
100844670:     	ldrb	w8, [x0, #0x14]
100844674:     	b	0x100844698 <_js_json_parse+0x44>
100844678:     	ldrb	w8, [x0, #0x14]
10084467c:     	cmp	w8, #0x7b
100844680:     	b.ne	0x100844698 <_js_json_parse+0x44>
100844684:     	ldrb	w8, [x0, #0x15]
100844688:     	cmp	w8, #0x7d
10084468c:     	b.ne	0x1008446a4 <_js_json_parse+0x50>
100844690:     	ldp	x29, x30, [sp], #0x10
100844694:     	b	0x1004ec900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100844698:     	orr	w8, w8, #0x20
10084469c:     	cmp	w8, #0x7b
1008446a0:     	b.ne	0x1008446ac <_js_json_parse+0x58>
1008446a4:     	ldp	x29, x30, [sp], #0x10
1008446a8:     	b	0x100505d78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008446ac:     	ldp	x29, x30, [sp], #0x10
1008446b0:     	b	0x1005083f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008446b4:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6f5c>
1008446b8:     	add	x0, x0, #0x581
1008446bc:     	mov	w1, #0x1c               ; =28
1008446c0:     	bl	0x100508828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
