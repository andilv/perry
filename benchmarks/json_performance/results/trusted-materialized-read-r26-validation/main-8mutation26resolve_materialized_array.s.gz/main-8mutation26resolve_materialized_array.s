
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/trusted-materialized-read-r26/main-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001006871ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>:
1006871ac:     	stp	x24, x23, [sp, #-0x40]!
1006871b0:     	stp	x22, x21, [sp, #0x10]
1006871b4:     	stp	x20, x19, [sp, #0x20]
1006871b8:     	stp	x29, x30, [sp, #0x30]
1006871bc:     	add	x29, sp, #0x30
1006871c0:     	mov	x20, x0
1006871c4:     	ldr	x23, [x20, #0x20]!
1006871c8:     	cbz	x23, 0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006871cc:     	mov	x19, x0
1006871d0:     	lsr	x8, x23, #51
1006871d4:     	mov	x21, x23
1006871d8:     	cmp	x8, #0xfff
1006871dc:     	b.lo	0x1006871f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x48>
1006871e0:     	mov	w8, #0x7ffc             ; =32764
1006871e4:     	cmp	x8, x23, lsr #48
1006871e8:     	b.eq	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006871ec:     	ands	x21, x23, #0xffffffffffff
1006871f0:     	b.eq	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006871f4:     	and	x8, x21, #0xfffffffffff00000
1006871f8:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1006871fc:     	mov	x10, #0x7ffffffff000    ; =140737488351232
100687200:     	cmp	x9, x10
100687204:     	ccmp	x8, #0x0, #0x4, lo
100687208:     	b.eq	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068720c:     	tst	x21, #0x3
100687210:     	ccmp	x21, #0x7, #0x0, eq
100687214:     	b.ls	0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687218:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
10068721c:     	ldr	x8, [x8, #0x30]
100687220:     	cmn	x8, #0x1
100687224:     	b.eq	0x1006872ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
100687228:     	mrs	x9, TPIDRRO_EL0
10068722c:     	and	x9, x9, #0xfffffffffffffff8
100687230:     	ldr	x0, [x9, x8, lsl #3]
100687234:     	cbz	x0, 0x1006872ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
100687238:     	lsr	x1, x21, #20
10068723c:     	ldr	x8, [x0, #0x10]
100687240:     	ldrb	w9, [x8]
100687244:     	cmp	w9, #0x2
100687248:     	b.ne	0x100687304 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x158>
10068724c:     	ldrb	w9, [x8, #0x88]
100687250:     	tbz	w9, #0x0, 0x100687270 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
100687254:     	ldr	x9, [x8, #0x80]
100687258:     	cmp	x9, x1
10068725c:     	b.ne	0x100687270 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
100687260:     	ldp	x9, x10, [x8, #0x60]
100687264:     	cmp	x9, x21
100687268:     	ccmp	x10, x21, #0x0, ls
10068726c:     	b.hi	0x1006872e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x138>
100687270:     	ldrb	w9, [x8, #0xb8]
100687274:     	cbz	w9, 0x100687294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
100687278:     	ldr	x9, [x8, #0xb0]
10068727c:     	cmp	x9, x1
100687280:     	b.ne	0x100687294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
100687284:     	ldp	x9, x10, [x8, #0x90]
100687288:     	cmp	x9, x21
10068728c:     	ccmp	x10, x21, #0x0, ls
100687290:     	b.hi	0x100687610 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x464>
100687294:     	ldrb	w9, [x8, #0xe8]
100687298:     	cbz	w9, 0x1006872b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
10068729c:     	ldr	x9, [x8, #0xe0]
1006872a0:     	cmp	x9, x1
1006872a4:     	b.ne	0x1006872b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
1006872a8:     	ldp	x9, x10, [x8, #0xc0]
1006872ac:     	cmp	x9, x21
1006872b0:     	ccmp	x10, x21, #0x0, ls
1006872b4:     	b.hi	0x100687618 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x46c>
1006872b8:     	ldrb	w9, [x8, #0x118]
1006872bc:     	cbz	w9, 0x100687364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006872c0:     	ldr	x9, [x8, #0x110]
1006872c4:     	cmp	x9, x1
1006872c8:     	b.ne	0x100687364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006872cc:     	ldp	x9, x10, [x8, #0xf0]
1006872d0:     	cmp	x9, x21
1006872d4:     	ccmp	x10, x21, #0x0, ls
1006872d8:     	b.ls	0x100687364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006872dc:     	add	x9, x8, #0xf0
1006872e0:     	b	0x10068761c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
1006872e4:     	add	x9, x8, #0x60
1006872e8:     	b	0x10068761c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
1006872ec:     	bl	0x100b3defc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1006872f0:     	lsr	x1, x21, #20
1006872f4:     	ldr	x8, [x0, #0x10]
1006872f8:     	ldrb	w9, [x8]
1006872fc:     	cmp	w9, #0x2
100687300:     	b.eq	0x10068724c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xa0>
100687304:     	ldr	x9, [x8, #0x8]
100687308:     	ldr	x10, [x8, #0x28]
10068730c:     	sub	x9, x1, x9
100687310:     	cmp	x9, x10
100687314:     	b.hs	0x100687358 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1ac>
100687318:     	ldr	x10, [x8, #0x20]
10068731c:     	mov	w11, #0x28              ; =40
100687320:     	madd	x9, x9, x11, x10
100687324:     	ldr	x10, [x9]
100687328:     	ldr	x11, [x8, #0x10]
10068732c:     	cmp	x10, x11
100687330:     	b.ne	0x100687364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
100687334:     	ldp	x10, x11, [x9, #0x8]
100687338:     	cmp	x10, x21
10068733c:     	ccmp	x11, x21, #0x0, ls
100687340:     	b.ls	0x100687364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
100687344:     	ldr	x10, [x8, #0x30]
100687348:     	add	x10, x10, #0x1
10068734c:     	str	x10, [x8, #0x30]
100687350:     	add	x8, x9, #0x21
100687354:     	b	0x10068762c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x480>
100687358:     	ldr	x9, [x8, #0x58]
10068735c:     	add	x9, x9, #0x1
100687360:     	str	x9, [x8, #0x58]
100687364:     	ldr	x9, [x8, #0x38]
100687368:     	add	x9, x9, #0x1
10068736c:     	str	x9, [x8, #0x38]
100687370:     	mov	x0, x21
100687374:     	bl	0x10051d1c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100687378:     	and	w8, w0, #0xff
10068737c:     	cbz	w8, 0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687380:     	ldurb	w8, [x21, #-0x8]
100687384:     	ldurb	w9, [x21, #-0x7]
100687388:     	mov	w10, #0x82              ; =130
10068738c:     	and	w9, w9, w10
100687390:     	cmp	w9, #0x2
100687394:     	ccmp	w8, #0x1, #0x0, eq
100687398:     	b.eq	0x10068750c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x360>
10068739c:     	mov	x0, x21
1006873a0:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006873a4:     	mov	x22, x0
1006873a8:     	cbz	x0, 0x1006873d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x228>
1006873ac:     	ldrb	w8, [x22]
1006873b0:     	cmp	w8, #0x1
1006873b4:     	b.ne	0x1006873e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x23c>
1006873b8:     	ldrsb	w8, [x22, #0x1]
1006873bc:     	tbnz	w8, #0x1f, 0x100687578 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3cc>
1006873c0:     	mov	x0, x22
1006873c4:     	ldp	w9, w8, [x21]
1006873c8:     	cmp	w9, w8
1006873cc:     	b.ls	0x1006874a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
1006873d0:     	b	0x100687484 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2d8>
1006873d4:     	mov	x0, x21
1006873d8:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1006873dc:     	tbz	w0, #0x0, 0x100687424 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x278>
1006873e0:     	mov	x0, #0x0                ; =0
1006873e4:     	b	0x100687474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
1006873e8:     	mov	x0, x22
1006873ec:     	cmp	w8, #0x1
1006873f0:     	b.eq	0x100687474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
1006873f4:     	cmp	w8, #0x9
1006873f8:     	b.ne	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006873fc:     	ldr	w8, [x21, #0x4]
100687400:     	mov	w9, #0x5841             ; =22593
100687404:     	movk	w9, #0x4c5a, lsl #16
100687408:     	cmp	w8, w9
10068740c:     	b.ne	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687410:     	mov	x0, x21
100687414:     	bl	0x100374cd0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100687418:     	mov	x8, x0
10068741c:     	cbnz	x0, 0x100687534 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
100687420:     	b	0x1006875f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687424:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687428:     	add	x8, x8, #0xe80
10068742c:     	ldaprb	w8, [x8]
100687430:     	cbz	w8, 0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687434:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687438:     	add	x8, x8, #0x40
10068743c:     	ldapr	x8, [x8]
100687440:     	cmp	x8, x21
100687444:     	b.hi	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687448:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
10068744c:     	add	x8, x8, #0x48
100687450:     	ldapr	x8, [x8]
100687454:     	cmp	x8, x21
100687458:     	b.lo	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068745c:     	mov	x0, x21
100687460:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100687464:     	mov	x9, x0
100687468:     	mov	x0, #0x0                ; =0
10068746c:     	mov	x8, #0x0                ; =0
100687470:     	tbz	w9, #0x0, 0x1006875f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687474:     	ldp	w9, w8, [x21]
100687478:     	cmp	w9, w8
10068747c:     	b.ls	0x1006874a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
100687480:     	cbz	x22, 0x1006874b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
100687484:     	ldr	w9, [x0, #0x4]
100687488:     	ubfiz	x8, x8, #3, #32
10068748c:     	add	x10, x8, #0x10
100687490:     	mov	x8, x21
100687494:     	cmp	x10, x9
100687498:     	b.ne	0x1006874b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
10068749c:     	b	0x100687534 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
1006874a0:     	mov	w10, #0xe100            ; =57600
1006874a4:     	movk	w10, #0x5f5, lsl #16
1006874a8:     	mov	x8, x21
1006874ac:     	cmp	w9, w10
1006874b0:     	b.ls	0x100687534 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
1006874b4:     	mov	x0, x21
1006874b8:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1006874bc:     	tbnz	w0, #0x0, 0x100687530 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x384>
1006874c0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1006874c4:     	add	x8, x8, #0xe80
1006874c8:     	ldaprb	w8, [x8]
1006874cc:     	cbz	w8, 0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006874d0:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1006874d4:     	add	x8, x8, #0x40
1006874d8:     	ldapr	x8, [x8]
1006874dc:     	cmp	x21, x8
1006874e0:     	b.lo	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006874e4:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1006874e8:     	add	x8, x8, #0x48
1006874ec:     	ldapr	x8, [x8]
1006874f0:     	cmp	x21, x8
1006874f4:     	b.hi	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006874f8:     	mov	x0, x21
1006874fc:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100687500:     	mov	x8, x21
100687504:     	tbz	w0, #0x0, 0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687508:     	b	0x100687534 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
10068750c:     	ldr	w8, [x21]
100687510:     	mov	w9, #0xe100             ; =57600
100687514:     	movk	w9, #0x5f5, lsl #16
100687518:     	orr	w9, w9, #0x1
10068751c:     	cmp	w8, w9
100687520:     	b.hs	0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687524:     	ldr	w9, [x21, #0x4]
100687528:     	cmp	w8, w9
10068752c:     	b.hi	0x10068739c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687530:     	mov	x8, x21
100687534:     	cmp	x8, x23
100687538:     	b.eq	0x100687698 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
10068753c:     	str	x8, [x19, #0x20]
100687540:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
100687544:     	add	x9, x9, #0x260
100687548:     	ldapr	x9, [x9]
10068754c:     	cbnz	x9, 0x10068763c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x490>
100687550:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
100687554:     	ldrb	w9, [x9, #0x268]
100687558:     	tbz	w9, #0x0, 0x100687654 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4a8>
10068755c:     	mov	x21, x8
100687560:     	mov	x0, x19
100687564:     	mov	x1, x20
100687568:     	mov	x2, x8
10068756c:     	mov	w3, #0x0                ; =0
100687570:     	bl	0x100473c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier26write_barrier_slot_decoded>
100687574:     	b	0x10068766c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c0>
100687578:     	ldr	x21, [x22, #0x8]
10068757c:     	mov	x0, x21
100687580:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100687584:     	cbz	x0, 0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687588:     	ldrb	w8, [x0]
10068758c:     	cmp	w8, #0x1
100687590:     	b.ne	0x1006875f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687594:     	ldrsb	w8, [x0, #0x1]
100687598:     	tbz	w8, #0x1f, 0x1006873c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x218>
10068759c:     	mov	w24, #0x1               ; =1
1006875a0:     	ldr	x21, [x0, #0x8]
1006875a4:     	mov	x0, x21
1006875a8:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006875ac:     	mov	x8, #0x0                ; =0
1006875b0:     	cbz	x0, 0x1006875f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006875b4:     	ldrb	w9, [x0]
1006875b8:     	cmp	w9, #0x1
1006875bc:     	b.ne	0x1006875f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006875c0:     	cmp	w24, #0x3f
1006875c4:     	b.hi	0x1006875f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006875c8:     	add	w24, w24, #0x1
1006875cc:     	ldrsb	w8, [x0, #0x1]
1006875d0:     	tbnz	w8, #0x1f, 0x1006875a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3f4>
1006875d4:     	str	x21, [x22, #0x8]
1006875d8:     	ldrb	w8, [x22, #0x1]
1006875dc:     	orr	w8, w8, #0x80
1006875e0:     	strb	w8, [x22, #0x1]
1006875e4:     	ldrb	w8, [x0]
1006875e8:     	cmp	w8, #0x1
1006875ec:     	b.ne	0x1006873f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x248>
1006875f0:     	b	0x100687474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
1006875f4:     	mov	x8, #0x0                ; =0
1006875f8:     	mov	x0, x8
1006875fc:     	ldp	x29, x30, [sp, #0x30]
100687600:     	ldp	x20, x19, [sp, #0x20]
100687604:     	ldp	x22, x21, [sp, #0x10]
100687608:     	ldp	x24, x23, [sp], #0x40
10068760c:     	ret
100687610:     	add	x9, x8, #0x90
100687614:     	b	0x10068761c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
100687618:     	add	x9, x8, #0xc0
10068761c:     	ldr	x10, [x8, #0x30]
100687620:     	add	x10, x10, #0x1
100687624:     	str	x10, [x8, #0x30]
100687628:     	add	x8, x9, #0x19
10068762c:     	ldrb	w8, [x8]
100687630:     	cmp	w8, #0xff
100687634:     	b.ne	0x10068737c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1d0>
100687638:     	b	0x100687370 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1c4>
10068763c:     	mov	x21, x8
100687640:     	bl	0x100b18024 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier22write_barriers_enabled0E0zEB1A_>
100687644:     	mov	x8, x21
100687648:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
10068764c:     	ldrb	w9, [x9, #0x268]
100687650:     	tbnz	w9, #0x0, 0x10068755c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3b0>
100687654:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687658:     	ldr	w9, [x9, #0x824]
10068765c:     	cbz	w9, 0x100687670 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c4>
100687660:     	mov	x21, x8
100687664:     	mov	x0, x8
100687668:     	bl	0x1004755b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
10068766c:     	mov	x8, x21
100687670:     	ldr	x9, [x20]
100687674:     	cbz	x9, 0x100687698 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
100687678:     	ldr	x9, [x19, #0x10]
10068767c:     	cbz	x9, 0x100687698 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
100687680:     	mov	x20, x8
100687684:     	mov	x0, x19
100687688:     	bl	0x1002dce7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime15json_tape_store7release>
10068768c:     	mov	x8, x20
100687690:     	str	xzr, [x19, #0x10]
100687694:     	str	wzr, [x19, #0xc]
100687698:     	ldr	w9, [x8]
10068769c:     	str	w9, [x19]
1006876a0:     	b	0x1006875f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
