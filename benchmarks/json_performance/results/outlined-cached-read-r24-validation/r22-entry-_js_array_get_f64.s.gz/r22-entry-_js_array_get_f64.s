
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/r22-shared-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bde10 <_js_array_get_f64>:
1007bde10:     	sub	sp, sp, #0x70
1007bde14:     	stp	x26, x25, [sp, #0x20]
1007bde18:     	stp	x24, x23, [sp, #0x30]
1007bde1c:     	stp	x22, x21, [sp, #0x40]
1007bde20:     	stp	x20, x19, [sp, #0x50]
1007bde24:     	stp	x29, x30, [sp, #0x60]
1007bde28:     	add	x29, sp, #0x60
1007bde2c:     	mov	x19, x1
1007bde30:     	mov	x22, x0
1007bde34:     	lsr	x25, x0, #51
1007bde38:     	mov	x20, x0
1007bde3c:     	cmp	x25, #0xfff
1007bde40:     	b.lo	0x1007bde5c <_js_array_get_f64+0x4c>
1007bde44:     	mov	w8, #0x7ffc             ; =32764
1007bde48:     	cmp	x8, x22, lsr #48
1007bde4c:     	b.ne	0x1007bde58 <_js_array_get_f64+0x48>
1007bde50:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bde54:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007bde58:     	and	x20, x22, #0xffffffffffff
1007bde5c:     	lsr	x8, x20, #3
1007bde60:     	cmp	x8, #0x200
1007bde64:     	b.ls	0x1007bdea4 <_js_array_get_f64+0x94>
1007bde68:     	ldurb	w8, [x20, #-0x8]
1007bde6c:     	cmp	w8, #0x9
1007bde70:     	b.ne	0x1007bdea4 <_js_array_get_f64+0x94>
1007bde74:     	ldr	w8, [x20, #0x4]
1007bde78:     	mov	w9, #0x5841             ; =22593
1007bde7c:     	movk	w9, #0x4c5a, lsl #16
1007bde80:     	cmp	w8, w9
1007bde84:     	b.ne	0x1007bdea4 <_js_array_get_f64+0x94>
1007bde88:     	ldr	x8, [x20, #0x20]
1007bde8c:     	cbz	x8, 0x1007be0f8 <_js_array_get_f64+0x2e8>
1007bde90:     	mov	x0, x20
1007bde94:     	mov	x1, x19
1007bde98:     	bl	0x10037569c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>
1007bde9c:     	fmov	d0, x0
1007bdea0:     	b	0x1007be558 <_js_array_get_f64+0x748>
1007bdea4:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bdea8:     	b.lo	0x1007bdf58 <_js_array_get_f64+0x148>
1007bdeac:     	tst	x20, #0xffff800000000000
1007bdeb0:     	mov	w8, #0x1000             ; =4096
1007bdeb4:     	ccmp	x20, x8, #0x0, eq
1007bdeb8:     	b.lo	0x1007bdf58 <_js_array_get_f64+0x148>
1007bdebc:     	ldurb	w24, [x20, #-0x8]
1007bdec0:     	ldurh	w23, [x20, #-0x6]
1007bdec4:     	cmp	w24, #0xa
1007bdec8:     	b.gt	0x1007be070 <_js_array_get_f64+0x260>
1007bdecc:     	cmp	w24, #0x2
1007bded0:     	b.eq	0x1007be130 <_js_array_get_f64+0x320>
1007bded4:     	cmp	w24, #0x8
1007bded8:     	b.ne	0x1007bdf60 <_js_array_get_f64+0x150>
1007bdedc:     	mov	x0, x20
1007bdee0:     	bl	0x1003051e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bdee4:     	cbz	w0, 0x1007be1cc <_js_array_get_f64+0x3bc>
1007bdee8:     	mov	x22, #0x1               ; =1
1007bdeec:     	movk	x22, #0x7ffc, lsl #48
1007bdef0:     	lsr	x8, x20, #51
1007bdef4:     	cmp	x8, #0xfff
1007bdef8:     	b.lo	0x1007bdf0c <_js_array_get_f64+0xfc>
1007bdefc:     	mov	w8, #0x7ffc             ; =32764
1007bdf00:     	cmp	x8, x20, lsr #48
1007bdf04:     	b.eq	0x1007be554 <_js_array_get_f64+0x744>
1007bdf08:     	and	x20, x20, #0xffffffffffff
1007bdf0c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bdf10:     	b.lo	0x1007bdf30 <_js_array_get_f64+0x120>
1007bdf14:     	tst	x20, #0xffff800000000000
1007bdf18:     	mov	w8, #0x1000             ; =4096
1007bdf1c:     	ccmp	x20, x8, #0x0, eq
1007bdf20:     	b.lo	0x1007bdf30 <_js_array_get_f64+0x120>
1007bdf24:     	ldurb	w8, [x20, #-0x8]
1007bdf28:     	cmp	w8, #0x2
1007bdf2c:     	b.eq	0x1007be840 <_js_array_get_f64+0xa30>
1007bdf30:     	cbz	x20, 0x1007be554 <_js_array_get_f64+0x744>
1007bdf34:     	mov	x0, x20
1007bdf38:     	mov	x1, x19
1007bdf3c:     	bl	0x100305398 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bdf40:     	cmp	w0, #0x1
1007bdf44:     	b.ne	0x1007be554 <_js_array_get_f64+0x744>
1007bdf48:     	ldr	x8, [x20, #0x8]
1007bdf4c:     	ubfiz	x9, x1, #4, #32
1007bdf50:     	ldr	x22, [x8, x9]
1007bdf54:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007bdf58:     	mov	w23, #0x0               ; =0
1007bdf5c:     	mov	w24, #0x0               ; =0
1007bdf60:     	mov	x21, x22
1007bdf64:     	cmp	x25, #0xfff
1007bdf68:     	b.lo	0x1007bdf80 <_js_array_get_f64+0x170>
1007bdf6c:     	mov	w8, #0x7ffc             ; =32764
1007bdf70:     	cmp	x8, x22, lsr #48
1007bdf74:     	b.eq	0x1007be540 <_js_array_get_f64+0x730>
1007bdf78:     	ands	x21, x22, #0xffffffffffff
1007bdf7c:     	b.eq	0x1007be540 <_js_array_get_f64+0x730>
1007bdf80:     	and	x8, x21, #0xfffffffffff00000
1007bdf84:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bdf88:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bdf8c:     	cmp	x9, x10
1007bdf90:     	ccmp	x8, #0x0, #0x4, lo
1007bdf94:     	b.eq	0x1007be540 <_js_array_get_f64+0x730>
1007bdf98:     	tst	x21, #0x3
1007bdf9c:     	ccmp	x21, #0x7, #0x0, eq
1007bdfa0:     	b.ls	0x1007be294 <_js_array_get_f64+0x484>
1007bdfa4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bdfa8:     	ldr	x8, [x8, #0x48]
1007bdfac:     	cmn	x8, #0x1
1007bdfb0:     	b.eq	0x1007be1e4 <_js_array_get_f64+0x3d4>
1007bdfb4:     	mrs	x9, TPIDRRO_EL0
1007bdfb8:     	and	x9, x9, #0xfffffffffffffff8
1007bdfbc:     	ldr	x0, [x9, x8, lsl #3]
1007bdfc0:     	cbz	x0, 0x1007be1e4 <_js_array_get_f64+0x3d4>
1007bdfc4:     	lsr	x1, x21, #20
1007bdfc8:     	ldr	x8, [x0, #0x10]
1007bdfcc:     	ldrb	w9, [x8]
1007bdfd0:     	cmp	w9, #0x2
1007bdfd4:     	b.ne	0x1007be1fc <_js_array_get_f64+0x3ec>
1007bdfd8:     	ldrb	w9, [x8, #0x88]
1007bdfdc:     	tbz	w9, #0x0, 0x1007bdffc <_js_array_get_f64+0x1ec>
1007bdfe0:     	ldr	x9, [x8, #0x80]
1007bdfe4:     	cmp	x9, x1
1007bdfe8:     	b.ne	0x1007bdffc <_js_array_get_f64+0x1ec>
1007bdfec:     	ldp	x9, x10, [x8, #0x60]
1007bdff0:     	cmp	x9, x21
1007bdff4:     	ccmp	x10, x21, #0x0, ls
1007bdff8:     	b.hi	0x1007be1dc <_js_array_get_f64+0x3cc>
1007bdffc:     	ldrb	w9, [x8, #0xb8]
1007be000:     	cbz	w9, 0x1007be020 <_js_array_get_f64+0x210>
1007be004:     	ldr	x9, [x8, #0xb0]
1007be008:     	cmp	x9, x1
1007be00c:     	b.ne	0x1007be020 <_js_array_get_f64+0x210>
1007be010:     	ldp	x9, x10, [x8, #0x90]
1007be014:     	cmp	x9, x21
1007be018:     	ccmp	x10, x21, #0x0, ls
1007be01c:     	b.hi	0x1007be6a4 <_js_array_get_f64+0x894>
1007be020:     	ldrb	w9, [x8, #0xe8]
1007be024:     	cbz	w9, 0x1007be044 <_js_array_get_f64+0x234>
1007be028:     	ldr	x9, [x8, #0xe0]
1007be02c:     	cmp	x9, x1
1007be030:     	b.ne	0x1007be044 <_js_array_get_f64+0x234>
1007be034:     	ldp	x9, x10, [x8, #0xc0]
1007be038:     	cmp	x9, x21
1007be03c:     	ccmp	x10, x21, #0x0, ls
1007be040:     	b.hi	0x1007be78c <_js_array_get_f64+0x97c>
1007be044:     	ldrb	w9, [x8, #0x118]
1007be048:     	cbz	w9, 0x1007be25c <_js_array_get_f64+0x44c>
1007be04c:     	ldr	x9, [x8, #0x110]
1007be050:     	cmp	x9, x1
1007be054:     	b.ne	0x1007be25c <_js_array_get_f64+0x44c>
1007be058:     	ldp	x9, x10, [x8, #0xf0]
1007be05c:     	cmp	x9, x21
1007be060:     	ccmp	x10, x21, #0x0, ls
1007be064:     	b.ls	0x1007be25c <_js_array_get_f64+0x44c>
1007be068:     	add	x9, x8, #0xf0
1007be06c:     	b	0x1007be790 <_js_array_get_f64+0x980>
1007be070:     	cmp	w24, #0xb
1007be074:     	b.eq	0x1007be148 <_js_array_get_f64+0x338>
1007be078:     	cmp	w24, #0xc
1007be07c:     	b.ne	0x1007bdf60 <_js_array_get_f64+0x150>
1007be080:     	mov	x0, x20
1007be084:     	bl	0x10030af78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be088:     	cbz	w0, 0x1007be1d4 <_js_array_get_f64+0x3c4>
1007be08c:     	mov	x22, #0x1               ; =1
1007be090:     	movk	x22, #0x7ffc, lsl #48
1007be094:     	lsr	x8, x20, #51
1007be098:     	cmp	x8, #0xfff
1007be09c:     	b.lo	0x1007be0b0 <_js_array_get_f64+0x2a0>
1007be0a0:     	mov	w8, #0x7ffc             ; =32764
1007be0a4:     	cmp	x8, x20, lsr #48
1007be0a8:     	b.eq	0x1007be554 <_js_array_get_f64+0x744>
1007be0ac:     	and	x20, x20, #0xffffffffffff
1007be0b0:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be0b4:     	b.lo	0x1007be0d4 <_js_array_get_f64+0x2c4>
1007be0b8:     	tst	x20, #0xffff800000000000
1007be0bc:     	mov	w8, #0x1000             ; =4096
1007be0c0:     	ccmp	x20, x8, #0x0, eq
1007be0c4:     	b.lo	0x1007be0d4 <_js_array_get_f64+0x2c4>
1007be0c8:     	ldurb	w8, [x20, #-0x8]
1007be0cc:     	cmp	w8, #0x2
1007be0d0:     	b.eq	0x1007be858 <_js_array_get_f64+0xa48>
1007be0d4:     	cbz	x20, 0x1007be554 <_js_array_get_f64+0x744>
1007be0d8:     	mov	x0, x20
1007be0dc:     	mov	x1, x19
1007be0e0:     	bl	0x10030cbf0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be0e4:     	cmp	w0, #0x1
1007be0e8:     	b.ne	0x1007be554 <_js_array_get_f64+0x744>
1007be0ec:     	ldr	x8, [x20, #0x8]
1007be0f0:     	ldr	x22, [x8, w1, uxtw #3]
1007be0f4:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be0f8:     	ldr	w8, [x20]
1007be0fc:     	cmp	w19, w8
1007be100:     	b.hs	0x1007be1c0 <_js_array_get_f64+0x3b0>
1007be104:     	ldr	x9, [x20, #0x30]
1007be108:     	cbz	x9, 0x1007bde90 <_js_array_get_f64+0x80>
1007be10c:     	ldr	x8, [x20, #0x28]
1007be110:     	cbz	x8, 0x1007bde90 <_js_array_get_f64+0x80>
1007be114:     	mov	w10, w19
1007be118:     	lsr	x11, x10, #6
1007be11c:     	ldr	x9, [x9, x11, lsl #3]
1007be120:     	lsr	x9, x9, x19
1007be124:     	tbz	w9, #0x0, 0x1007bde90 <_js_array_get_f64+0x80>
1007be128:     	ldr	x22, [x8, x10, lsl #3]
1007be12c:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be130:     	mov	x0, x22
1007be134:     	mov	x1, x19
1007be138:     	bl	0x10054864c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be13c:     	tbnz	w0, #0x0, 0x1007be550 <_js_array_get_f64+0x740>
1007be140:     	mov	w24, #0x2               ; =2
1007be144:     	b	0x1007bdf60 <_js_array_get_f64+0x150>
1007be148:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be14c:     	add	x8, x8, #0xec0
1007be150:     	ldaprb	w8, [x8]
1007be154:     	cbz	w8, 0x1007be1b8 <_js_array_get_f64+0x3a8>
1007be158:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be15c:     	add	x8, x8, #0x58
1007be160:     	ldapr	x8, [x8]
1007be164:     	cmp	x20, x8
1007be168:     	b.lo	0x1007be1b8 <_js_array_get_f64+0x3a8>
1007be16c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be170:     	add	x8, x8, #0x60
1007be174:     	ldapr	x8, [x8]
1007be178:     	cmp	x20, x8
1007be17c:     	b.hi	0x1007be1b8 <_js_array_get_f64+0x3a8>
1007be180:     	mov	x0, x20
1007be184:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be188:     	tbz	w0, #0x0, 0x1007be1b8 <_js_array_get_f64+0x3a8>
1007be18c:     	add	x0, sp, #0x8
1007be190:     	mov	x1, x20
1007be194:     	bl	0x1002a4aec <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be198:     	ldr	x8, [sp, #0x8]
1007be19c:     	cbz	x8, 0x1007be7d0 <_js_array_get_f64+0x9c0>
1007be1a0:     	cmp	x8, #0x1
1007be1a4:     	b.ne	0x1007be814 <_js_array_get_f64+0xa04>
1007be1a8:     	ldr	d0, [sp, #0x10]
1007be1ac:     	scvtf	d1, w19
1007be1b0:     	bl	0x10081c3f4 <_js_dyn_index_get>
1007be1b4:     	b	0x1007be550 <_js_array_get_f64+0x740>
1007be1b8:     	mov	w24, #0xb               ; =11
1007be1bc:     	b	0x1007bdf60 <_js_array_get_f64+0x150>
1007be1c0:     	mov	x22, #0x1               ; =1
1007be1c4:     	movk	x22, #0x7ffc, lsl #48
1007be1c8:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be1cc:     	mov	w24, #0x8               ; =8
1007be1d0:     	b	0x1007bdf60 <_js_array_get_f64+0x150>
1007be1d4:     	mov	w24, #0xc               ; =12
1007be1d8:     	b	0x1007bdf60 <_js_array_get_f64+0x150>
1007be1dc:     	add	x9, x8, #0x60
1007be1e0:     	b	0x1007be790 <_js_array_get_f64+0x980>
1007be1e4:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be1e8:     	lsr	x1, x21, #20
1007be1ec:     	ldr	x8, [x0, #0x10]
1007be1f0:     	ldrb	w9, [x8]
1007be1f4:     	cmp	w9, #0x2
1007be1f8:     	b.eq	0x1007bdfd8 <_js_array_get_f64+0x1c8>
1007be1fc:     	ldr	x9, [x8, #0x8]
1007be200:     	ldr	x10, [x8, #0x28]
1007be204:     	sub	x9, x1, x9
1007be208:     	cmp	x9, x10
1007be20c:     	b.hs	0x1007be250 <_js_array_get_f64+0x440>
1007be210:     	ldr	x10, [x8, #0x20]
1007be214:     	mov	w11, #0x28              ; =40
1007be218:     	madd	x9, x9, x11, x10
1007be21c:     	ldr	x10, [x9]
1007be220:     	ldr	x11, [x8, #0x10]
1007be224:     	cmp	x10, x11
1007be228:     	b.ne	0x1007be25c <_js_array_get_f64+0x44c>
1007be22c:     	ldp	x10, x11, [x9, #0x8]
1007be230:     	cmp	x10, x21
1007be234:     	ccmp	x11, x21, #0x0, ls
1007be238:     	b.ls	0x1007be25c <_js_array_get_f64+0x44c>
1007be23c:     	ldr	x10, [x8, #0x30]
1007be240:     	add	x10, x10, #0x1
1007be244:     	str	x10, [x8, #0x30]
1007be248:     	add	x8, x9, #0x21
1007be24c:     	b	0x1007be7a0 <_js_array_get_f64+0x990>
1007be250:     	ldr	x9, [x8, #0x58]
1007be254:     	add	x9, x9, #0x1
1007be258:     	str	x9, [x8, #0x58]
1007be25c:     	ldr	x9, [x8, #0x38]
1007be260:     	add	x9, x9, #0x1
1007be264:     	str	x9, [x8, #0x38]
1007be268:     	mov	x0, x21
1007be26c:     	bl	0x10051e388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be270:     	and	w8, w0, #0xff
1007be274:     	cbz	w8, 0x1007be294 <_js_array_get_f64+0x484>
1007be278:     	ldurb	w8, [x21, #-0x8]
1007be27c:     	ldurb	w9, [x21, #-0x7]
1007be280:     	mov	w10, #0x82              ; =130
1007be284:     	and	w9, w9, w10
1007be288:     	cmp	w9, #0x2
1007be28c:     	ccmp	w8, #0x1, #0x0, eq
1007be290:     	b.eq	0x1007be364 <_js_array_get_f64+0x554>
1007be294:     	mov	x0, x21
1007be298:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be29c:     	cbz	x0, 0x1007be2c4 <_js_array_get_f64+0x4b4>
1007be2a0:     	ldrb	w9, [x0]
1007be2a4:     	cmp	w9, #0x1
1007be2a8:     	b.ne	0x1007be2e0 <_js_array_get_f64+0x4d0>
1007be2ac:     	ldrsb	w8, [x0, #0x1]
1007be2b0:     	tbnz	w8, #0x1f, 0x1007be38c <_js_array_get_f64+0x57c>
1007be2b4:     	ldp	w10, w9, [x21]
1007be2b8:     	cmp	w10, w9
1007be2bc:     	b.hi	0x1007be418 <_js_array_get_f64+0x608>
1007be2c0:     	b	0x1007be430 <_js_array_get_f64+0x620>
1007be2c4:     	mov	x25, x0
1007be2c8:     	mov	x0, x21
1007be2cc:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be2d0:     	tbz	w0, #0x0, 0x1007be31c <_js_array_get_f64+0x50c>
1007be2d4:     	mov	x0, #0x0                ; =0
1007be2d8:     	mov	x8, x25
1007be2dc:     	b	0x1007be408 <_js_array_get_f64+0x5f8>
1007be2e0:     	mov	x8, x0
1007be2e4:     	cmp	w9, #0x1
1007be2e8:     	b.eq	0x1007be408 <_js_array_get_f64+0x5f8>
1007be2ec:     	cmp	w9, #0x9
1007be2f0:     	b.ne	0x1007be540 <_js_array_get_f64+0x730>
1007be2f4:     	ldr	w8, [x21, #0x4]
1007be2f8:     	mov	w9, #0x5841             ; =22593
1007be2fc:     	movk	w9, #0x4c5a, lsl #16
1007be300:     	cmp	w8, w9
1007be304:     	b.ne	0x1007be540 <_js_array_get_f64+0x730>
1007be308:     	mov	x0, x21
1007be30c:     	bl	0x100375e8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be310:     	cbz	x0, 0x1007be540 <_js_array_get_f64+0x730>
1007be314:     	mov	x21, x0
1007be318:     	b	0x1007be44c <_js_array_get_f64+0x63c>
1007be31c:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be320:     	add	x8, x8, #0xec0
1007be324:     	ldaprb	w8, [x8]
1007be328:     	cbz	w8, 0x1007be540 <_js_array_get_f64+0x730>
1007be32c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be330:     	add	x8, x8, #0x58
1007be334:     	ldapr	x8, [x8]
1007be338:     	cmp	x8, x21
1007be33c:     	b.hi	0x1007be540 <_js_array_get_f64+0x730>
1007be340:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be344:     	add	x8, x8, #0x60
1007be348:     	ldapr	x8, [x8]
1007be34c:     	cmp	x8, x21
1007be350:     	b.lo	0x1007be540 <_js_array_get_f64+0x730>
1007be354:     	mov	x0, x21
1007be358:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be35c:     	tbnz	w0, #0x0, 0x1007be2d4 <_js_array_get_f64+0x4c4>
1007be360:     	b	0x1007be540 <_js_array_get_f64+0x730>
1007be364:     	ldr	w8, [x21]
1007be368:     	mov	w9, #0xe100             ; =57600
1007be36c:     	movk	w9, #0x5f5, lsl #16
1007be370:     	orr	w9, w9, #0x1
1007be374:     	cmp	w8, w9
1007be378:     	b.hs	0x1007be294 <_js_array_get_f64+0x484>
1007be37c:     	ldr	w9, [x21, #0x4]
1007be380:     	cmp	w8, w9
1007be384:     	b.ls	0x1007be44c <_js_array_get_f64+0x63c>
1007be388:     	b	0x1007be294 <_js_array_get_f64+0x484>
1007be38c:     	mov	x25, x0
1007be390:     	ldr	x21, [x0, #0x8]
1007be394:     	mov	x0, x21
1007be398:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be39c:     	cbz	x0, 0x1007be540 <_js_array_get_f64+0x730>
1007be3a0:     	ldrb	w8, [x0]
1007be3a4:     	cmp	w8, #0x1
1007be3a8:     	b.ne	0x1007be540 <_js_array_get_f64+0x730>
1007be3ac:     	ldrsb	w8, [x0, #0x1]
1007be3b0:     	tbz	w8, #0x1f, 0x1007be2b4 <_js_array_get_f64+0x4a4>
1007be3b4:     	mov	w26, #0x1               ; =1
1007be3b8:     	ldr	x21, [x0, #0x8]
1007be3bc:     	mov	x0, x21
1007be3c0:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be3c4:     	cbz	x0, 0x1007be540 <_js_array_get_f64+0x730>
1007be3c8:     	ldrb	w8, [x0]
1007be3cc:     	cmp	w8, #0x1
1007be3d0:     	b.ne	0x1007be540 <_js_array_get_f64+0x730>
1007be3d4:     	cmp	w26, #0x3f
1007be3d8:     	b.hi	0x1007be540 <_js_array_get_f64+0x730>
1007be3dc:     	add	w26, w26, #0x1
1007be3e0:     	ldrsb	w8, [x0, #0x1]
1007be3e4:     	tbnz	w8, #0x1f, 0x1007be3b8 <_js_array_get_f64+0x5a8>
1007be3e8:     	str	x21, [x25, #0x8]
1007be3ec:     	ldrb	w8, [x25, #0x1]
1007be3f0:     	orr	w9, w8, #0x80
1007be3f4:     	mov	x8, x25
1007be3f8:     	strb	w9, [x25, #0x1]
1007be3fc:     	ldrb	w9, [x0]
1007be400:     	cmp	w9, #0x1
1007be404:     	b.ne	0x1007be2ec <_js_array_get_f64+0x4dc>
1007be408:     	ldp	w10, w9, [x21]
1007be40c:     	cmp	w10, w9
1007be410:     	b.ls	0x1007be430 <_js_array_get_f64+0x620>
1007be414:     	cbz	x8, 0x1007be440 <_js_array_get_f64+0x630>
1007be418:     	ldr	w8, [x0, #0x4]
1007be41c:     	ubfiz	x9, x9, #3, #32
1007be420:     	add	x9, x9, #0x10
1007be424:     	cmp	x9, x8
1007be428:     	b.eq	0x1007be44c <_js_array_get_f64+0x63c>
1007be42c:     	b	0x1007be440 <_js_array_get_f64+0x630>
1007be430:     	mov	w8, #0xe100             ; =57600
1007be434:     	movk	w8, #0x5f5, lsl #16
1007be438:     	cmp	w10, w8
1007be43c:     	b.ls	0x1007be44c <_js_array_get_f64+0x63c>
1007be440:     	mov	x0, x21
1007be444:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be448:     	tbz	w0, #0x0, 0x1007be4fc <_js_array_get_f64+0x6ec>
1007be44c:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be450:     	add	x8, x8, #0xec0
1007be454:     	ldaprb	w8, [x8]
1007be458:     	cbz	w8, 0x1007be4a0 <_js_array_get_f64+0x690>
1007be45c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be460:     	add	x8, x8, #0x58
1007be464:     	ldapr	x8, [x8]
1007be468:     	cmp	x21, x8
1007be46c:     	b.lo	0x1007be4a0 <_js_array_get_f64+0x690>
1007be470:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be474:     	add	x8, x8, #0x60
1007be478:     	ldapr	x8, [x8]
1007be47c:     	cmp	x21, x8
1007be480:     	b.hi	0x1007be4a0 <_js_array_get_f64+0x690>
1007be484:     	mov	x0, x21
1007be488:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be48c:     	tbz	w0, #0x0, 0x1007be4a0 <_js_array_get_f64+0x690>
1007be490:     	mov	x0, x21
1007be494:     	mov	x1, x19
1007be498:     	bl	0x1008fc188 <_js_typed_array_get>
1007be49c:     	b	0x1007be550 <_js_array_get_f64+0x740>
1007be4a0:     	mov	x0, x21
1007be4a4:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be4a8:     	tbz	w0, #0x0, 0x1007be4d0 <_js_array_get_f64+0x6c0>
1007be4ac:     	mov	x0, x21
1007be4b0:     	mov	x1, x19
1007be4b4:     	bl	0x10058655c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007be4b8:     	and	w8, w1, #0xff
1007be4bc:     	ucvtf	d0, w8
1007be4c0:     	fmov	x8, d0
1007be4c4:     	tst	w0, #0x1
1007be4c8:     	csel	x22, x8, xzr, ne
1007be4cc:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be4d0:     	cmp	x21, x20
1007be4d4:     	b.eq	0x1007be57c <_js_array_get_f64+0x76c>
1007be4d8:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007be4dc:     	b.lo	0x1007be574 <_js_array_get_f64+0x764>
1007be4e0:     	tst	x21, #0xffff800000000000
1007be4e4:     	mov	w8, #0x1000             ; =4096
1007be4e8:     	ccmp	x21, x8, #0x0, eq
1007be4ec:     	b.lo	0x1007be574 <_js_array_get_f64+0x764>
1007be4f0:     	ldurb	w24, [x21, #-0x8]
1007be4f4:     	ldurh	w23, [x21, #-0x6]
1007be4f8:     	b	0x1007be57c <_js_array_get_f64+0x76c>
1007be4fc:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be500:     	add	x8, x8, #0xec0
1007be504:     	ldaprb	w8, [x8]
1007be508:     	cbz	w8, 0x1007be540 <_js_array_get_f64+0x730>
1007be50c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be510:     	add	x8, x8, #0x58
1007be514:     	ldapr	x8, [x8]
1007be518:     	cmp	x21, x8
1007be51c:     	b.lo	0x1007be540 <_js_array_get_f64+0x730>
1007be520:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be524:     	add	x8, x8, #0x60
1007be528:     	ldapr	x8, [x8]
1007be52c:     	cmp	x21, x8
1007be530:     	b.hi	0x1007be540 <_js_array_get_f64+0x730>
1007be534:     	mov	x0, x21
1007be538:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be53c:     	tbnz	w0, #0x0, 0x1007be44c <_js_array_get_f64+0x63c>
1007be540:     	mov	x0, x22
1007be544:     	mov	x1, x19
1007be548:     	bl	0x10054864c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be54c:     	tbz	w0, #0x0, 0x1007be824 <_js_array_get_f64+0xa14>
1007be550:     	fmov	x22, d0
1007be554:     	fmov	d0, x22
1007be558:     	ldp	x29, x30, [sp, #0x60]
1007be55c:     	ldp	x20, x19, [sp, #0x50]
1007be560:     	ldp	x22, x21, [sp, #0x40]
1007be564:     	ldp	x24, x23, [sp, #0x30]
1007be568:     	ldp	x26, x25, [sp, #0x20]
1007be56c:     	add	sp, sp, #0x70
1007be570:     	ret
1007be574:     	mov	w23, #0x0               ; =0
1007be578:     	mov	w24, #0x0               ; =0
1007be57c:     	cmp	w24, #0x1
1007be580:     	b.ne	0x1007be734 <_js_array_get_f64+0x924>
1007be584:     	tbz	w23, #0xa, 0x1007be734 <_js_array_get_f64+0x924>
1007be588:     	adrp	x8, 0x100b64000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data14case_ignorable7OFFSETS+0x2bc>
1007be58c:     	add	x8, x8, #0xd8c
1007be590:     	cmp	w19, #0x3e8
1007be594:     	b.lo	0x1007be60c <_js_array_get_f64+0x7fc>
1007be598:     	mov	x9, #0x0                ; =0
1007be59c:     	mov	w11, #0x1759            ; =5977
1007be5a0:     	movk	w11, #0xd1b7, lsl #16
1007be5a4:     	mov	w12, #0x2710            ; =10000
1007be5a8:     	mov	w13, #0x147b            ; =5243
1007be5ac:     	mov	w14, #0x64              ; =100
1007be5b0:     	add	x15, sp, #0x8
1007be5b4:     	mov	w16, #0x967f            ; =38527
1007be5b8:     	movk	w16, #0x98, lsl #16
1007be5bc:     	mov	x10, x19
1007be5c0:     	mov	x17, x10
1007be5c4:     	umull	x10, w10, w11
1007be5c8:     	lsr	x10, x10, #45
1007be5cc:     	msub	w0, w10, w12, w17
1007be5d0:     	ubfx	w1, w0, #2, #14
1007be5d4:     	mul	w1, w1, w13
1007be5d8:     	lsr	w1, w1, #17
1007be5dc:     	msub	w0, w1, w14, w0
1007be5e0:     	add	x2, x15, x9
1007be5e4:     	ldrh	w1, [x8, w1, uxtw #1]
1007be5e8:     	strh	w1, [x2, #0x6]
1007be5ec:     	and	x0, x0, #0xffff
1007be5f0:     	ldrh	w0, [x8, x0, lsl #1]
1007be5f4:     	strh	w0, [x2, #0x8]
1007be5f8:     	sub	x9, x9, #0x4
1007be5fc:     	cmp	w17, w16
1007be600:     	b.hi	0x1007be5c0 <_js_array_get_f64+0x7b0>
1007be604:     	add	x9, x9, #0xa
1007be608:     	b	0x1007be614 <_js_array_get_f64+0x804>
1007be60c:     	mov	w9, #0xa                ; =10
1007be610:     	mov	x10, x19
1007be614:     	cmp	w10, #0x9
1007be618:     	b.ls	0x1007be64c <_js_array_get_f64+0x83c>
1007be61c:     	sub	x9, x9, #0x2
1007be620:     	ubfx	w11, w10, #2, #14
1007be624:     	mov	w12, #0x147b            ; =5243
1007be628:     	mul	w11, w11, w12
1007be62c:     	lsr	w11, w11, #17
1007be630:     	mov	w12, #0x64              ; =100
1007be634:     	msub	w10, w11, w12, w10
1007be638:     	and	x10, x10, #0xffff
1007be63c:     	ldrh	w10, [x8, x10, lsl #1]
1007be640:     	add	x12, sp, #0x8
1007be644:     	strh	w10, [x12, x9]
1007be648:     	mov	x10, x11
1007be64c:     	cbz	w19, 0x1007be684 <_js_array_get_f64+0x874>
1007be650:     	cbnz	w10, 0x1007be684 <_js_array_get_f64+0x874>
1007be654:     	cmp	x9, #0xa
1007be658:     	b.ne	0x1007be6ac <_js_array_get_f64+0x89c>
1007be65c:     	mov	w23, #0x1               ; =1
1007be660:     	add	x0, sp, #0x8
1007be664:     	mov	x1, x21
1007be668:     	mov	w2, #0x1                ; =1
1007be66c:     	mov	x3, #0x0                ; =0
1007be670:     	bl	0x1005b293c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be674:     	ldr	x8, [sp, #0x8]
1007be678:     	mov	w20, #0x1               ; =1
1007be67c:     	cbnz	x8, 0x1007be6fc <_js_array_get_f64+0x8ec>
1007be680:     	b	0x1007be734 <_js_array_get_f64+0x924>
1007be684:     	sub	x23, x9, #0x1
1007be688:     	ubfiz	w10, w10, #1, #4
1007be68c:     	add	x8, x8, x10
1007be690:     	ldrb	w8, [x8, #0x1]
1007be694:     	add	x10, sp, #0x8
1007be698:     	strb	w8, [x10, x23]
1007be69c:     	mov	w8, #0xb                ; =11
1007be6a0:     	b	0x1007be6b4 <_js_array_get_f64+0x8a4>
1007be6a4:     	add	x9, x8, #0x90
1007be6a8:     	b	0x1007be790 <_js_array_get_f64+0x980>
1007be6ac:     	mov	w8, #0xa                ; =10
1007be6b0:     	mov	x23, x9
1007be6b4:     	sub	x22, x8, x9
1007be6b8:     	mov	x0, x22
1007be6bc:     	mov	w1, #0x1                ; =1
1007be6c0:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
1007be6c4:     	cbz	x0, 0x1007be870 <_js_array_get_f64+0xa60>
1007be6c8:     	mov	x20, x0
1007be6cc:     	add	x8, sp, #0x8
1007be6d0:     	add	x1, x8, x23
1007be6d4:     	mov	x2, x22
1007be6d8:     	bl	0x100b61dec <_writev+0x100b61dec>
1007be6dc:     	add	x0, sp, #0x8
1007be6e0:     	mov	x1, x21
1007be6e4:     	mov	x2, x20
1007be6e8:     	mov	x3, x22
1007be6ec:     	bl	0x1005b293c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be6f0:     	ldr	w8, [sp, #0x8]
1007be6f4:     	tbz	w8, #0x0, 0x1007be72c <_js_array_get_f64+0x91c>
1007be6f8:     	mov	w23, #0x0               ; =0
1007be6fc:     	mov	x22, #0x1               ; =1
1007be700:     	movk	x22, #0x7ffc, lsl #48
1007be704:     	ldr	x0, [sp, #0x10]
1007be708:     	cbz	x0, 0x1007be7c0 <_js_array_get_f64+0x9b0>
1007be70c:     	cbz	x21, 0x1007be7b0 <_js_array_get_f64+0x9a0>
1007be710:     	lsr	x8, x21, #52
1007be714:     	cmp	x8, #0x7fe
1007be718:     	b.hi	0x1007be7b4 <_js_array_get_f64+0x9a4>
1007be71c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007be720:     	bfxil	x8, x21, #0, #48
1007be724:     	mov	x21, x8
1007be728:     	b	0x1007be7b4 <_js_array_get_f64+0x9a4>
1007be72c:     	mov	x0, x20
1007be730:     	bl	0x100b5ef40 <_mi_free>
1007be734:     	ldr	w8, [x21]
1007be738:     	cmp	w19, w8
1007be73c:     	b.hs	0x1007be77c <_js_array_get_f64+0x96c>
1007be740:     	ldr	w8, [x21, #0x4]
1007be744:     	cmp	w19, w8
1007be748:     	b.hs	0x1007be76c <_js_array_get_f64+0x95c>
1007be74c:     	add	x8, x21, w19, uxtw #3
1007be750:     	ldr	x22, [x8, #0x8]
1007be754:     	mov	x8, #0x1                ; =1
1007be758:     	movk	x8, #0x7ffc, lsl #48
1007be75c:     	add	x8, x8, #0xf
1007be760:     	cmp	x22, x8
1007be764:     	b.ne	0x1007be554 <_js_array_get_f64+0x744>
1007be768:     	b	0x1007be77c <_js_array_get_f64+0x96c>
1007be76c:     	mov	x0, x21
1007be770:     	mov	x1, x19
1007be774:     	bl	0x10052aa44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007be778:     	tbnz	w0, #0x0, 0x1007be550 <_js_array_get_f64+0x740>
1007be77c:     	mov	x0, x21
1007be780:     	mov	x1, x19
1007be784:     	bl	0x1006c7258 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007be788:     	b	0x1007be550 <_js_array_get_f64+0x740>
1007be78c:     	add	x9, x8, #0xc0
1007be790:     	ldr	x10, [x8, #0x30]
1007be794:     	add	x10, x10, #0x1
1007be798:     	str	x10, [x8, #0x30]
1007be79c:     	add	x8, x9, #0x19
1007be7a0:     	ldrb	w8, [x8]
1007be7a4:     	cmp	w8, #0xff
1007be7a8:     	b.ne	0x1007be274 <_js_array_get_f64+0x464>
1007be7ac:     	b	0x1007be268 <_js_array_get_f64+0x458>
1007be7b0:     	add	x21, x22, #0x1
1007be7b4:     	fmov	d0, x21
1007be7b8:     	bl	0x1006fd07c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007be7bc:     	mov	x22, x0
1007be7c0:     	tbnz	w23, #0x0, 0x1007be554 <_js_array_get_f64+0x744>
1007be7c4:     	mov	x0, x20
1007be7c8:     	bl	0x100b5ef40 <_mi_free>
1007be7cc:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be7d0:     	ldr	x20, [sp, #0x10]
1007be7d4:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be7d8:     	ldr	x8, [x8, #0xed8]
1007be7dc:     	cbz	x8, 0x1007be7f4 <_js_array_get_f64+0x9e4>
1007be7e0:     	mov	x0, x20
1007be7e4:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007be7e8:     	tbz	w0, #0x0, 0x1007be7f4 <_js_array_get_f64+0x9e4>
1007be7ec:     	mov	x0, x20
1007be7f0:     	bl	0x1002beec0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007be7f4:     	tbnz	w19, #0x1f, 0x1007be814 <_js_array_get_f64+0xa04>
1007be7f8:     	ldr	w8, [x20]
1007be7fc:     	cmp	w19, w8
1007be800:     	b.hs	0x1007be814 <_js_array_get_f64+0xa04>
1007be804:     	mov	w1, w19
1007be808:     	mov	x0, x20
1007be80c:     	bl	0x1002a514c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007be810:     	b	0x1007be550 <_js_array_get_f64+0x740>
1007be814:     	mov	x8, #0x1                ; =1
1007be818:     	movk	x8, #0x7ffc, lsl #48
1007be81c:     	mov	x22, x8
1007be820:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be824:     	mov	x0, x22
1007be828:     	bl	0x100b478b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007be82c:     	cmp	x0, #0x1
1007be830:     	b.ne	0x1007bde50 <_js_array_get_f64+0x40>
1007be834:     	mov	x0, x19
1007be838:     	bl	0x100b478d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007be83c:     	b	0x1007be550 <_js_array_get_f64+0x740>
1007be840:     	mov	x0, x20
1007be844:     	mov	w1, #0x0                ; =0
1007be848:     	bl	0x100b49e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be84c:     	mov	x20, x0
1007be850:     	cbnz	x0, 0x1007bdf34 <_js_array_get_f64+0x124>
1007be854:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be858:     	mov	x0, x20
1007be85c:     	mov	w1, #0x1                ; =1
1007be860:     	bl	0x100b49e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be864:     	mov	x20, x0
1007be868:     	cbnz	x0, 0x1007be0d8 <_js_array_get_f64+0x2c8>
1007be86c:     	b	0x1007be554 <_js_array_get_f64+0x744>
1007be870:     	mov	w0, #0x1                ; =1
1007be874:     	mov	x1, x22
1007be878:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1007be87c:     	udf	#0x0
