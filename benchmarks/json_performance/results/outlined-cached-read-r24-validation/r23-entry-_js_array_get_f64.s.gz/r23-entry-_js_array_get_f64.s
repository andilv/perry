
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bde10 <_js_array_get_f64>:
1007bde10:     	sub	sp, sp, #0x70
1007bde14:     	stp	x26, x25, [sp, #0x20]
1007bde18:     	stp	x24, x23, [sp, #0x30]
1007bde1c:     	stp	x22, x21, [sp, #0x40]
1007bde20:     	stp	x20, x19, [sp, #0x50]
1007bde24:     	stp	x29, x30, [sp, #0x60]
1007bde28:     	add	x29, sp, #0x60
1007bde2c:     	mov	x19, x1
1007bde30:     	mov	x22, x0
1007bde34:     	lsr	x25, x0, #51
1007bde38:     	mov	x20, x0
1007bde3c:     	cmp	x25, #0xfff
1007bde40:     	b.lo	0x1007bde5c <_js_array_get_f64+0x4c>
1007bde44:     	mov	w8, #0x7ffc             ; =32764
1007bde48:     	cmp	x8, x22, lsr #48
1007bde4c:     	b.ne	0x1007bde58 <_js_array_get_f64+0x48>
1007bde50:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bde54:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007bde58:     	and	x20, x22, #0xffffffffffff
1007bde5c:     	lsr	x8, x20, #3
1007bde60:     	cmp	x8, #0x200
1007bde64:     	b.ls	0x1007bdedc <_js_array_get_f64+0xcc>
1007bde68:     	ldurb	w8, [x20, #-0x8]
1007bde6c:     	cmp	w8, #0x9
1007bde70:     	b.ne	0x1007bdedc <_js_array_get_f64+0xcc>
1007bde74:     	ldr	w8, [x20, #0x4]
1007bde78:     	mov	w9, #0x5841             ; =22593
1007bde7c:     	movk	w9, #0x4c5a, lsl #16
1007bde80:     	cmp	w8, w9
1007bde84:     	b.ne	0x1007bdedc <_js_array_get_f64+0xcc>
1007bde88:     	ldr	x8, [x20, #0x20]
1007bde8c:     	cbz	x8, 0x1007be130 <_js_array_get_f64+0x320>
1007bde90:     	mov	x0, x20
1007bde94:     	bl	0x10068829c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1007bde98:     	cbz	x0, 0x1007be168 <_js_array_get_f64+0x358>
1007bde9c:     	ldurh	w8, [x0, #-0x6]
1007bdea0:     	tbnz	w8, #0xa, 0x1007be168 <_js_array_get_f64+0x358>
1007bdea4:     	ldr	w8, [x0]
1007bdea8:     	cmp	w19, w8
1007bdeac:     	b.hs	0x1007be168 <_js_array_get_f64+0x358>
1007bdeb0:     	ldr	w8, [x0, #0x4]
1007bdeb4:     	cmp	w19, w8
1007bdeb8:     	b.hs	0x1007be168 <_js_array_get_f64+0x358>
1007bdebc:     	add	x8, x0, w19, uxtw #3
1007bdec0:     	ldr	x22, [x8, #0x8]
1007bdec4:     	mov	x8, #0x1                ; =1
1007bdec8:     	movk	x8, #0x7ffc, lsl #48
1007bdecc:     	add	x8, x8, #0xf
1007bded0:     	cmp	x22, x8
1007bded4:     	b.ne	0x1007be5a0 <_js_array_get_f64+0x790>
1007bded8:     	b	0x1007be168 <_js_array_get_f64+0x358>
1007bdedc:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bdee0:     	b.lo	0x1007bdf90 <_js_array_get_f64+0x180>
1007bdee4:     	tst	x20, #0xffff800000000000
1007bdee8:     	mov	w8, #0x1000             ; =4096
1007bdeec:     	ccmp	x20, x8, #0x0, eq
1007bdef0:     	b.lo	0x1007bdf90 <_js_array_get_f64+0x180>
1007bdef4:     	ldurb	w24, [x20, #-0x8]
1007bdef8:     	ldurh	w23, [x20, #-0x6]
1007bdefc:     	cmp	w24, #0xa
1007bdf00:     	b.gt	0x1007be0a8 <_js_array_get_f64+0x298>
1007bdf04:     	cmp	w24, #0x2
1007bdf08:     	b.eq	0x1007be17c <_js_array_get_f64+0x36c>
1007bdf0c:     	cmp	w24, #0x8
1007bdf10:     	b.ne	0x1007bdf98 <_js_array_get_f64+0x188>
1007bdf14:     	mov	x0, x20
1007bdf18:     	bl	0x1003051e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bdf1c:     	cbz	w0, 0x1007be218 <_js_array_get_f64+0x408>
1007bdf20:     	mov	x22, #0x1               ; =1
1007bdf24:     	movk	x22, #0x7ffc, lsl #48
1007bdf28:     	lsr	x8, x20, #51
1007bdf2c:     	cmp	x8, #0xfff
1007bdf30:     	b.lo	0x1007bdf44 <_js_array_get_f64+0x134>
1007bdf34:     	mov	w8, #0x7ffc             ; =32764
1007bdf38:     	cmp	x8, x20, lsr #48
1007bdf3c:     	b.eq	0x1007be5a0 <_js_array_get_f64+0x790>
1007bdf40:     	and	x20, x20, #0xffffffffffff
1007bdf44:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bdf48:     	b.lo	0x1007bdf68 <_js_array_get_f64+0x158>
1007bdf4c:     	tst	x20, #0xffff800000000000
1007bdf50:     	mov	w8, #0x1000             ; =4096
1007bdf54:     	ccmp	x20, x8, #0x0, eq
1007bdf58:     	b.lo	0x1007bdf68 <_js_array_get_f64+0x158>
1007bdf5c:     	ldurb	w8, [x20, #-0x8]
1007bdf60:     	cmp	w8, #0x2
1007bdf64:     	b.eq	0x1007be88c <_js_array_get_f64+0xa7c>
1007bdf68:     	cbz	x20, 0x1007be5a0 <_js_array_get_f64+0x790>
1007bdf6c:     	mov	x0, x20
1007bdf70:     	mov	x1, x19
1007bdf74:     	bl	0x100305398 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bdf78:     	cmp	w0, #0x1
1007bdf7c:     	b.ne	0x1007be5a0 <_js_array_get_f64+0x790>
1007bdf80:     	ldr	x8, [x20, #0x8]
1007bdf84:     	ubfiz	x9, x1, #4, #32
1007bdf88:     	ldr	x22, [x8, x9]
1007bdf8c:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007bdf90:     	mov	w23, #0x0               ; =0
1007bdf94:     	mov	w24, #0x0               ; =0
1007bdf98:     	mov	x21, x22
1007bdf9c:     	cmp	x25, #0xfff
1007bdfa0:     	b.lo	0x1007bdfb8 <_js_array_get_f64+0x1a8>
1007bdfa4:     	mov	w8, #0x7ffc             ; =32764
1007bdfa8:     	cmp	x8, x22, lsr #48
1007bdfac:     	b.eq	0x1007be58c <_js_array_get_f64+0x77c>
1007bdfb0:     	ands	x21, x22, #0xffffffffffff
1007bdfb4:     	b.eq	0x1007be58c <_js_array_get_f64+0x77c>
1007bdfb8:     	and	x8, x21, #0xfffffffffff00000
1007bdfbc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bdfc0:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bdfc4:     	cmp	x9, x10
1007bdfc8:     	ccmp	x8, #0x0, #0x4, lo
1007bdfcc:     	b.eq	0x1007be58c <_js_array_get_f64+0x77c>
1007bdfd0:     	tst	x21, #0x3
1007bdfd4:     	ccmp	x21, #0x7, #0x0, eq
1007bdfd8:     	b.ls	0x1007be2e0 <_js_array_get_f64+0x4d0>
1007bdfdc:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bdfe0:     	ldr	x8, [x8, #0x48]
1007bdfe4:     	cmn	x8, #0x1
1007bdfe8:     	b.eq	0x1007be230 <_js_array_get_f64+0x420>
1007bdfec:     	mrs	x9, TPIDRRO_EL0
1007bdff0:     	and	x9, x9, #0xfffffffffffffff8
1007bdff4:     	ldr	x0, [x9, x8, lsl #3]
1007bdff8:     	cbz	x0, 0x1007be230 <_js_array_get_f64+0x420>
1007bdffc:     	lsr	x1, x21, #20
1007be000:     	ldr	x8, [x0, #0x10]
1007be004:     	ldrb	w9, [x8]
1007be008:     	cmp	w9, #0x2
1007be00c:     	b.ne	0x1007be248 <_js_array_get_f64+0x438>
1007be010:     	ldrb	w9, [x8, #0x88]
1007be014:     	tbz	w9, #0x0, 0x1007be034 <_js_array_get_f64+0x224>
1007be018:     	ldr	x9, [x8, #0x80]
1007be01c:     	cmp	x9, x1
1007be020:     	b.ne	0x1007be034 <_js_array_get_f64+0x224>
1007be024:     	ldp	x9, x10, [x8, #0x60]
1007be028:     	cmp	x9, x21
1007be02c:     	ccmp	x10, x21, #0x0, ls
1007be030:     	b.hi	0x1007be228 <_js_array_get_f64+0x418>
1007be034:     	ldrb	w9, [x8, #0xb8]
1007be038:     	cbz	w9, 0x1007be058 <_js_array_get_f64+0x248>
1007be03c:     	ldr	x9, [x8, #0xb0]
1007be040:     	cmp	x9, x1
1007be044:     	b.ne	0x1007be058 <_js_array_get_f64+0x248>
1007be048:     	ldp	x9, x10, [x8, #0x90]
1007be04c:     	cmp	x9, x21
1007be050:     	ccmp	x10, x21, #0x0, ls
1007be054:     	b.hi	0x1007be6f0 <_js_array_get_f64+0x8e0>
1007be058:     	ldrb	w9, [x8, #0xe8]
1007be05c:     	cbz	w9, 0x1007be07c <_js_array_get_f64+0x26c>
1007be060:     	ldr	x9, [x8, #0xe0]
1007be064:     	cmp	x9, x1
1007be068:     	b.ne	0x1007be07c <_js_array_get_f64+0x26c>
1007be06c:     	ldp	x9, x10, [x8, #0xc0]
1007be070:     	cmp	x9, x21
1007be074:     	ccmp	x10, x21, #0x0, ls
1007be078:     	b.hi	0x1007be7d8 <_js_array_get_f64+0x9c8>
1007be07c:     	ldrb	w9, [x8, #0x118]
1007be080:     	cbz	w9, 0x1007be2a8 <_js_array_get_f64+0x498>
1007be084:     	ldr	x9, [x8, #0x110]
1007be088:     	cmp	x9, x1
1007be08c:     	b.ne	0x1007be2a8 <_js_array_get_f64+0x498>
1007be090:     	ldp	x9, x10, [x8, #0xf0]
1007be094:     	cmp	x9, x21
1007be098:     	ccmp	x10, x21, #0x0, ls
1007be09c:     	b.ls	0x1007be2a8 <_js_array_get_f64+0x498>
1007be0a0:     	add	x9, x8, #0xf0
1007be0a4:     	b	0x1007be7dc <_js_array_get_f64+0x9cc>
1007be0a8:     	cmp	w24, #0xb
1007be0ac:     	b.eq	0x1007be194 <_js_array_get_f64+0x384>
1007be0b0:     	cmp	w24, #0xc
1007be0b4:     	b.ne	0x1007bdf98 <_js_array_get_f64+0x188>
1007be0b8:     	mov	x0, x20
1007be0bc:     	bl	0x10030af78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be0c0:     	cbz	w0, 0x1007be220 <_js_array_get_f64+0x410>
1007be0c4:     	mov	x22, #0x1               ; =1
1007be0c8:     	movk	x22, #0x7ffc, lsl #48
1007be0cc:     	lsr	x8, x20, #51
1007be0d0:     	cmp	x8, #0xfff
1007be0d4:     	b.lo	0x1007be0e8 <_js_array_get_f64+0x2d8>
1007be0d8:     	mov	w8, #0x7ffc             ; =32764
1007be0dc:     	cmp	x8, x20, lsr #48
1007be0e0:     	b.eq	0x1007be5a0 <_js_array_get_f64+0x790>
1007be0e4:     	and	x20, x20, #0xffffffffffff
1007be0e8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be0ec:     	b.lo	0x1007be10c <_js_array_get_f64+0x2fc>
1007be0f0:     	tst	x20, #0xffff800000000000
1007be0f4:     	mov	w8, #0x1000             ; =4096
1007be0f8:     	ccmp	x20, x8, #0x0, eq
1007be0fc:     	b.lo	0x1007be10c <_js_array_get_f64+0x2fc>
1007be100:     	ldurb	w8, [x20, #-0x8]
1007be104:     	cmp	w8, #0x2
1007be108:     	b.eq	0x1007be8a4 <_js_array_get_f64+0xa94>
1007be10c:     	cbz	x20, 0x1007be5a0 <_js_array_get_f64+0x790>
1007be110:     	mov	x0, x20
1007be114:     	mov	x1, x19
1007be118:     	bl	0x10030cbf0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be11c:     	cmp	w0, #0x1
1007be120:     	b.ne	0x1007be5a0 <_js_array_get_f64+0x790>
1007be124:     	ldr	x8, [x20, #0x8]
1007be128:     	ldr	x22, [x8, w1, uxtw #3]
1007be12c:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be130:     	ldr	w8, [x20]
1007be134:     	cmp	w19, w8
1007be138:     	b.hs	0x1007be20c <_js_array_get_f64+0x3fc>
1007be13c:     	ldr	x9, [x20, #0x30]
1007be140:     	cbz	x9, 0x1007be168 <_js_array_get_f64+0x358>
1007be144:     	ldr	x8, [x20, #0x28]
1007be148:     	cbz	x8, 0x1007be168 <_js_array_get_f64+0x358>
1007be14c:     	mov	w10, w19
1007be150:     	lsr	x11, x10, #6
1007be154:     	ldr	x9, [x9, x11, lsl #3]
1007be158:     	lsr	x9, x9, x19
1007be15c:     	tbz	w9, #0x0, 0x1007be168 <_js_array_get_f64+0x358>
1007be160:     	ldr	x22, [x8, x10, lsl #3]
1007be164:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be168:     	mov	x0, x20
1007be16c:     	mov	x1, x19
1007be170:     	bl	0x10037569c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>
1007be174:     	fmov	d0, x0
1007be178:     	b	0x1007be5a4 <_js_array_get_f64+0x794>
1007be17c:     	mov	x0, x22
1007be180:     	mov	x1, x19
1007be184:     	bl	0x10054864c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be188:     	tbnz	w0, #0x0, 0x1007be59c <_js_array_get_f64+0x78c>
1007be18c:     	mov	w24, #0x2               ; =2
1007be190:     	b	0x1007bdf98 <_js_array_get_f64+0x188>
1007be194:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be198:     	add	x8, x8, #0xec0
1007be19c:     	ldaprb	w8, [x8]
1007be1a0:     	cbz	w8, 0x1007be204 <_js_array_get_f64+0x3f4>
1007be1a4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be1a8:     	add	x8, x8, #0x58
1007be1ac:     	ldapr	x8, [x8]
1007be1b0:     	cmp	x20, x8
1007be1b4:     	b.lo	0x1007be204 <_js_array_get_f64+0x3f4>
1007be1b8:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be1bc:     	add	x8, x8, #0x60
1007be1c0:     	ldapr	x8, [x8]
1007be1c4:     	cmp	x20, x8
1007be1c8:     	b.hi	0x1007be204 <_js_array_get_f64+0x3f4>
1007be1cc:     	mov	x0, x20
1007be1d0:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be1d4:     	tbz	w0, #0x0, 0x1007be204 <_js_array_get_f64+0x3f4>
1007be1d8:     	add	x0, sp, #0x8
1007be1dc:     	mov	x1, x20
1007be1e0:     	bl	0x1002a4aec <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be1e4:     	ldr	x8, [sp, #0x8]
1007be1e8:     	cbz	x8, 0x1007be81c <_js_array_get_f64+0xa0c>
1007be1ec:     	cmp	x8, #0x1
1007be1f0:     	b.ne	0x1007be860 <_js_array_get_f64+0xa50>
1007be1f4:     	ldr	d0, [sp, #0x10]
1007be1f8:     	scvtf	d1, w19
1007be1fc:     	bl	0x10081c474 <_js_dyn_index_get>
1007be200:     	b	0x1007be59c <_js_array_get_f64+0x78c>
1007be204:     	mov	w24, #0xb               ; =11
1007be208:     	b	0x1007bdf98 <_js_array_get_f64+0x188>
1007be20c:     	mov	x22, #0x1               ; =1
1007be210:     	movk	x22, #0x7ffc, lsl #48
1007be214:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be218:     	mov	w24, #0x8               ; =8
1007be21c:     	b	0x1007bdf98 <_js_array_get_f64+0x188>
1007be220:     	mov	w24, #0xc               ; =12
1007be224:     	b	0x1007bdf98 <_js_array_get_f64+0x188>
1007be228:     	add	x9, x8, #0x60
1007be22c:     	b	0x1007be7dc <_js_array_get_f64+0x9cc>
1007be230:     	bl	0x100b3f3fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be234:     	lsr	x1, x21, #20
1007be238:     	ldr	x8, [x0, #0x10]
1007be23c:     	ldrb	w9, [x8]
1007be240:     	cmp	w9, #0x2
1007be244:     	b.eq	0x1007be010 <_js_array_get_f64+0x200>
1007be248:     	ldr	x9, [x8, #0x8]
1007be24c:     	ldr	x10, [x8, #0x28]
1007be250:     	sub	x9, x1, x9
1007be254:     	cmp	x9, x10
1007be258:     	b.hs	0x1007be29c <_js_array_get_f64+0x48c>
1007be25c:     	ldr	x10, [x8, #0x20]
1007be260:     	mov	w11, #0x28              ; =40
1007be264:     	madd	x9, x9, x11, x10
1007be268:     	ldr	x10, [x9]
1007be26c:     	ldr	x11, [x8, #0x10]
1007be270:     	cmp	x10, x11
1007be274:     	b.ne	0x1007be2a8 <_js_array_get_f64+0x498>
1007be278:     	ldp	x10, x11, [x9, #0x8]
1007be27c:     	cmp	x10, x21
1007be280:     	ccmp	x11, x21, #0x0, ls
1007be284:     	b.ls	0x1007be2a8 <_js_array_get_f64+0x498>
1007be288:     	ldr	x10, [x8, #0x30]
1007be28c:     	add	x10, x10, #0x1
1007be290:     	str	x10, [x8, #0x30]
1007be294:     	add	x8, x9, #0x21
1007be298:     	b	0x1007be7ec <_js_array_get_f64+0x9dc>
1007be29c:     	ldr	x9, [x8, #0x58]
1007be2a0:     	add	x9, x9, #0x1
1007be2a4:     	str	x9, [x8, #0x58]
1007be2a8:     	ldr	x9, [x8, #0x38]
1007be2ac:     	add	x9, x9, #0x1
1007be2b0:     	str	x9, [x8, #0x38]
1007be2b4:     	mov	x0, x21
1007be2b8:     	bl	0x10051e388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be2bc:     	and	w8, w0, #0xff
1007be2c0:     	cbz	w8, 0x1007be2e0 <_js_array_get_f64+0x4d0>
1007be2c4:     	ldurb	w8, [x21, #-0x8]
1007be2c8:     	ldurb	w9, [x21, #-0x7]
1007be2cc:     	mov	w10, #0x82              ; =130
1007be2d0:     	and	w9, w9, w10
1007be2d4:     	cmp	w9, #0x2
1007be2d8:     	ccmp	w8, #0x1, #0x0, eq
1007be2dc:     	b.eq	0x1007be3b0 <_js_array_get_f64+0x5a0>
1007be2e0:     	mov	x0, x21
1007be2e4:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be2e8:     	cbz	x0, 0x1007be310 <_js_array_get_f64+0x500>
1007be2ec:     	ldrb	w9, [x0]
1007be2f0:     	cmp	w9, #0x1
1007be2f4:     	b.ne	0x1007be32c <_js_array_get_f64+0x51c>
1007be2f8:     	ldrsb	w8, [x0, #0x1]
1007be2fc:     	tbnz	w8, #0x1f, 0x1007be3d8 <_js_array_get_f64+0x5c8>
1007be300:     	ldp	w10, w9, [x21]
1007be304:     	cmp	w10, w9
1007be308:     	b.hi	0x1007be464 <_js_array_get_f64+0x654>
1007be30c:     	b	0x1007be47c <_js_array_get_f64+0x66c>
1007be310:     	mov	x25, x0
1007be314:     	mov	x0, x21
1007be318:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be31c:     	tbz	w0, #0x0, 0x1007be368 <_js_array_get_f64+0x558>
1007be320:     	mov	x0, #0x0                ; =0
1007be324:     	mov	x8, x25
1007be328:     	b	0x1007be454 <_js_array_get_f64+0x644>
1007be32c:     	mov	x8, x0
1007be330:     	cmp	w9, #0x1
1007be334:     	b.eq	0x1007be454 <_js_array_get_f64+0x644>
1007be338:     	cmp	w9, #0x9
1007be33c:     	b.ne	0x1007be58c <_js_array_get_f64+0x77c>
1007be340:     	ldr	w8, [x21, #0x4]
1007be344:     	mov	w9, #0x5841             ; =22593
1007be348:     	movk	w9, #0x4c5a, lsl #16
1007be34c:     	cmp	w8, w9
1007be350:     	b.ne	0x1007be58c <_js_array_get_f64+0x77c>
1007be354:     	mov	x0, x21
1007be358:     	bl	0x100375e8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be35c:     	cbz	x0, 0x1007be58c <_js_array_get_f64+0x77c>
1007be360:     	mov	x21, x0
1007be364:     	b	0x1007be498 <_js_array_get_f64+0x688>
1007be368:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be36c:     	add	x8, x8, #0xec0
1007be370:     	ldaprb	w8, [x8]
1007be374:     	cbz	w8, 0x1007be58c <_js_array_get_f64+0x77c>
1007be378:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be37c:     	add	x8, x8, #0x58
1007be380:     	ldapr	x8, [x8]
1007be384:     	cmp	x8, x21
1007be388:     	b.hi	0x1007be58c <_js_array_get_f64+0x77c>
1007be38c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be390:     	add	x8, x8, #0x60
1007be394:     	ldapr	x8, [x8]
1007be398:     	cmp	x8, x21
1007be39c:     	b.lo	0x1007be58c <_js_array_get_f64+0x77c>
1007be3a0:     	mov	x0, x21
1007be3a4:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be3a8:     	tbnz	w0, #0x0, 0x1007be320 <_js_array_get_f64+0x510>
1007be3ac:     	b	0x1007be58c <_js_array_get_f64+0x77c>
1007be3b0:     	ldr	w8, [x21]
1007be3b4:     	mov	w9, #0xe100             ; =57600
1007be3b8:     	movk	w9, #0x5f5, lsl #16
1007be3bc:     	orr	w9, w9, #0x1
1007be3c0:     	cmp	w8, w9
1007be3c4:     	b.hs	0x1007be2e0 <_js_array_get_f64+0x4d0>
1007be3c8:     	ldr	w9, [x21, #0x4]
1007be3cc:     	cmp	w8, w9
1007be3d0:     	b.ls	0x1007be498 <_js_array_get_f64+0x688>
1007be3d4:     	b	0x1007be2e0 <_js_array_get_f64+0x4d0>
1007be3d8:     	mov	x25, x0
1007be3dc:     	ldr	x21, [x0, #0x8]
1007be3e0:     	mov	x0, x21
1007be3e4:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be3e8:     	cbz	x0, 0x1007be58c <_js_array_get_f64+0x77c>
1007be3ec:     	ldrb	w8, [x0]
1007be3f0:     	cmp	w8, #0x1
1007be3f4:     	b.ne	0x1007be58c <_js_array_get_f64+0x77c>
1007be3f8:     	ldrsb	w8, [x0, #0x1]
1007be3fc:     	tbz	w8, #0x1f, 0x1007be300 <_js_array_get_f64+0x4f0>
1007be400:     	mov	w26, #0x1               ; =1
1007be404:     	ldr	x21, [x0, #0x8]
1007be408:     	mov	x0, x21
1007be40c:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be410:     	cbz	x0, 0x1007be58c <_js_array_get_f64+0x77c>
1007be414:     	ldrb	w8, [x0]
1007be418:     	cmp	w8, #0x1
1007be41c:     	b.ne	0x1007be58c <_js_array_get_f64+0x77c>
1007be420:     	cmp	w26, #0x3f
1007be424:     	b.hi	0x1007be58c <_js_array_get_f64+0x77c>
1007be428:     	add	w26, w26, #0x1
1007be42c:     	ldrsb	w8, [x0, #0x1]
1007be430:     	tbnz	w8, #0x1f, 0x1007be404 <_js_array_get_f64+0x5f4>
1007be434:     	str	x21, [x25, #0x8]
1007be438:     	ldrb	w8, [x25, #0x1]
1007be43c:     	orr	w9, w8, #0x80
1007be440:     	mov	x8, x25
1007be444:     	strb	w9, [x25, #0x1]
1007be448:     	ldrb	w9, [x0]
1007be44c:     	cmp	w9, #0x1
1007be450:     	b.ne	0x1007be338 <_js_array_get_f64+0x528>
1007be454:     	ldp	w10, w9, [x21]
1007be458:     	cmp	w10, w9
1007be45c:     	b.ls	0x1007be47c <_js_array_get_f64+0x66c>
1007be460:     	cbz	x8, 0x1007be48c <_js_array_get_f64+0x67c>
1007be464:     	ldr	w8, [x0, #0x4]
1007be468:     	ubfiz	x9, x9, #3, #32
1007be46c:     	add	x9, x9, #0x10
1007be470:     	cmp	x9, x8
1007be474:     	b.eq	0x1007be498 <_js_array_get_f64+0x688>
1007be478:     	b	0x1007be48c <_js_array_get_f64+0x67c>
1007be47c:     	mov	w8, #0xe100             ; =57600
1007be480:     	movk	w8, #0x5f5, lsl #16
1007be484:     	cmp	w10, w8
1007be488:     	b.ls	0x1007be498 <_js_array_get_f64+0x688>
1007be48c:     	mov	x0, x21
1007be490:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be494:     	tbz	w0, #0x0, 0x1007be548 <_js_array_get_f64+0x738>
1007be498:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be49c:     	add	x8, x8, #0xec0
1007be4a0:     	ldaprb	w8, [x8]
1007be4a4:     	cbz	w8, 0x1007be4ec <_js_array_get_f64+0x6dc>
1007be4a8:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be4ac:     	add	x8, x8, #0x58
1007be4b0:     	ldapr	x8, [x8]
1007be4b4:     	cmp	x21, x8
1007be4b8:     	b.lo	0x1007be4ec <_js_array_get_f64+0x6dc>
1007be4bc:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be4c0:     	add	x8, x8, #0x60
1007be4c4:     	ldapr	x8, [x8]
1007be4c8:     	cmp	x21, x8
1007be4cc:     	b.hi	0x1007be4ec <_js_array_get_f64+0x6dc>
1007be4d0:     	mov	x0, x21
1007be4d4:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be4d8:     	tbz	w0, #0x0, 0x1007be4ec <_js_array_get_f64+0x6dc>
1007be4dc:     	mov	x0, x21
1007be4e0:     	mov	x1, x19
1007be4e4:     	bl	0x1008fc208 <_js_typed_array_get>
1007be4e8:     	b	0x1007be59c <_js_array_get_f64+0x78c>
1007be4ec:     	mov	x0, x21
1007be4f0:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be4f4:     	tbz	w0, #0x0, 0x1007be51c <_js_array_get_f64+0x70c>
1007be4f8:     	mov	x0, x21
1007be4fc:     	mov	x1, x19
1007be500:     	bl	0x10058655c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007be504:     	and	w8, w1, #0xff
1007be508:     	ucvtf	d0, w8
1007be50c:     	fmov	x8, d0
1007be510:     	tst	w0, #0x1
1007be514:     	csel	x22, x8, xzr, ne
1007be518:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be51c:     	cmp	x21, x20
1007be520:     	b.eq	0x1007be5c8 <_js_array_get_f64+0x7b8>
1007be524:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007be528:     	b.lo	0x1007be5c0 <_js_array_get_f64+0x7b0>
1007be52c:     	tst	x21, #0xffff800000000000
1007be530:     	mov	w8, #0x1000             ; =4096
1007be534:     	ccmp	x21, x8, #0x0, eq
1007be538:     	b.lo	0x1007be5c0 <_js_array_get_f64+0x7b0>
1007be53c:     	ldurb	w24, [x21, #-0x8]
1007be540:     	ldurh	w23, [x21, #-0x6]
1007be544:     	b	0x1007be5c8 <_js_array_get_f64+0x7b8>
1007be548:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be54c:     	add	x8, x8, #0xec0
1007be550:     	ldaprb	w8, [x8]
1007be554:     	cbz	w8, 0x1007be58c <_js_array_get_f64+0x77c>
1007be558:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be55c:     	add	x8, x8, #0x58
1007be560:     	ldapr	x8, [x8]
1007be564:     	cmp	x21, x8
1007be568:     	b.lo	0x1007be58c <_js_array_get_f64+0x77c>
1007be56c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be570:     	add	x8, x8, #0x60
1007be574:     	ldapr	x8, [x8]
1007be578:     	cmp	x21, x8
1007be57c:     	b.hi	0x1007be58c <_js_array_get_f64+0x77c>
1007be580:     	mov	x0, x21
1007be584:     	bl	0x1002a4cb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be588:     	tbnz	w0, #0x0, 0x1007be498 <_js_array_get_f64+0x688>
1007be58c:     	mov	x0, x22
1007be590:     	mov	x1, x19
1007be594:     	bl	0x10054864c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be598:     	tbz	w0, #0x0, 0x1007be870 <_js_array_get_f64+0xa60>
1007be59c:     	fmov	x22, d0
1007be5a0:     	fmov	d0, x22
1007be5a4:     	ldp	x29, x30, [sp, #0x60]
1007be5a8:     	ldp	x20, x19, [sp, #0x50]
1007be5ac:     	ldp	x22, x21, [sp, #0x40]
1007be5b0:     	ldp	x24, x23, [sp, #0x30]
1007be5b4:     	ldp	x26, x25, [sp, #0x20]
1007be5b8:     	add	sp, sp, #0x70
1007be5bc:     	ret
1007be5c0:     	mov	w23, #0x0               ; =0
1007be5c4:     	mov	w24, #0x0               ; =0
1007be5c8:     	cmp	w24, #0x1
1007be5cc:     	b.ne	0x1007be780 <_js_array_get_f64+0x970>
1007be5d0:     	tbz	w23, #0xa, 0x1007be780 <_js_array_get_f64+0x970>
1007be5d4:     	adrp	x8, 0x100b64000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data14case_ignorable7OFFSETS+0x23c>
1007be5d8:     	add	x8, x8, #0xe0c
1007be5dc:     	cmp	w19, #0x3e8
1007be5e0:     	b.lo	0x1007be658 <_js_array_get_f64+0x848>
1007be5e4:     	mov	x9, #0x0                ; =0
1007be5e8:     	mov	w11, #0x1759            ; =5977
1007be5ec:     	movk	w11, #0xd1b7, lsl #16
1007be5f0:     	mov	w12, #0x2710            ; =10000
1007be5f4:     	mov	w13, #0x147b            ; =5243
1007be5f8:     	mov	w14, #0x64              ; =100
1007be5fc:     	add	x15, sp, #0x8
1007be600:     	mov	w16, #0x967f            ; =38527
1007be604:     	movk	w16, #0x98, lsl #16
1007be608:     	mov	x10, x19
1007be60c:     	mov	x17, x10
1007be610:     	umull	x10, w10, w11
1007be614:     	lsr	x10, x10, #45
1007be618:     	msub	w0, w10, w12, w17
1007be61c:     	ubfx	w1, w0, #2, #14
1007be620:     	mul	w1, w1, w13
1007be624:     	lsr	w1, w1, #17
1007be628:     	msub	w0, w1, w14, w0
1007be62c:     	add	x2, x15, x9
1007be630:     	ldrh	w1, [x8, w1, uxtw #1]
1007be634:     	strh	w1, [x2, #0x6]
1007be638:     	and	x0, x0, #0xffff
1007be63c:     	ldrh	w0, [x8, x0, lsl #1]
1007be640:     	strh	w0, [x2, #0x8]
1007be644:     	sub	x9, x9, #0x4
1007be648:     	cmp	w17, w16
1007be64c:     	b.hi	0x1007be60c <_js_array_get_f64+0x7fc>
1007be650:     	add	x9, x9, #0xa
1007be654:     	b	0x1007be660 <_js_array_get_f64+0x850>
1007be658:     	mov	w9, #0xa                ; =10
1007be65c:     	mov	x10, x19
1007be660:     	cmp	w10, #0x9
1007be664:     	b.ls	0x1007be698 <_js_array_get_f64+0x888>
1007be668:     	sub	x9, x9, #0x2
1007be66c:     	ubfx	w11, w10, #2, #14
1007be670:     	mov	w12, #0x147b            ; =5243
1007be674:     	mul	w11, w11, w12
1007be678:     	lsr	w11, w11, #17
1007be67c:     	mov	w12, #0x64              ; =100
1007be680:     	msub	w10, w11, w12, w10
1007be684:     	and	x10, x10, #0xffff
1007be688:     	ldrh	w10, [x8, x10, lsl #1]
1007be68c:     	add	x12, sp, #0x8
1007be690:     	strh	w10, [x12, x9]
1007be694:     	mov	x10, x11
1007be698:     	cbz	w19, 0x1007be6d0 <_js_array_get_f64+0x8c0>
1007be69c:     	cbnz	w10, 0x1007be6d0 <_js_array_get_f64+0x8c0>
1007be6a0:     	cmp	x9, #0xa
1007be6a4:     	b.ne	0x1007be6f8 <_js_array_get_f64+0x8e8>
1007be6a8:     	mov	w23, #0x1               ; =1
1007be6ac:     	add	x0, sp, #0x8
1007be6b0:     	mov	x1, x21
1007be6b4:     	mov	w2, #0x1                ; =1
1007be6b8:     	mov	x3, #0x0                ; =0
1007be6bc:     	bl	0x1005b293c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be6c0:     	ldr	x8, [sp, #0x8]
1007be6c4:     	mov	w20, #0x1               ; =1
1007be6c8:     	cbnz	x8, 0x1007be748 <_js_array_get_f64+0x938>
1007be6cc:     	b	0x1007be780 <_js_array_get_f64+0x970>
1007be6d0:     	sub	x23, x9, #0x1
1007be6d4:     	ubfiz	w10, w10, #1, #4
1007be6d8:     	add	x8, x8, x10
1007be6dc:     	ldrb	w8, [x8, #0x1]
1007be6e0:     	add	x10, sp, #0x8
1007be6e4:     	strb	w8, [x10, x23]
1007be6e8:     	mov	w8, #0xb                ; =11
1007be6ec:     	b	0x1007be700 <_js_array_get_f64+0x8f0>
1007be6f0:     	add	x9, x8, #0x90
1007be6f4:     	b	0x1007be7dc <_js_array_get_f64+0x9cc>
1007be6f8:     	mov	w8, #0xa                ; =10
1007be6fc:     	mov	x23, x9
1007be700:     	sub	x22, x8, x9
1007be704:     	mov	x0, x22
1007be708:     	mov	w1, #0x1                ; =1
1007be70c:     	bl	0x100b5f248 <_mi_malloc_aligned>
1007be710:     	cbz	x0, 0x1007be8bc <_js_array_get_f64+0xaac>
1007be714:     	mov	x20, x0
1007be718:     	add	x8, sp, #0x8
1007be71c:     	add	x1, x8, x23
1007be720:     	mov	x2, x22
1007be724:     	bl	0x100b61e6c <_writev+0x100b61e6c>
1007be728:     	add	x0, sp, #0x8
1007be72c:     	mov	x1, x21
1007be730:     	mov	x2, x20
1007be734:     	mov	x3, x22
1007be738:     	bl	0x1005b293c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be73c:     	ldr	w8, [sp, #0x8]
1007be740:     	tbz	w8, #0x0, 0x1007be778 <_js_array_get_f64+0x968>
1007be744:     	mov	w23, #0x0               ; =0
1007be748:     	mov	x22, #0x1               ; =1
1007be74c:     	movk	x22, #0x7ffc, lsl #48
1007be750:     	ldr	x0, [sp, #0x10]
1007be754:     	cbz	x0, 0x1007be80c <_js_array_get_f64+0x9fc>
1007be758:     	cbz	x21, 0x1007be7fc <_js_array_get_f64+0x9ec>
1007be75c:     	lsr	x8, x21, #52
1007be760:     	cmp	x8, #0x7fe
1007be764:     	b.hi	0x1007be800 <_js_array_get_f64+0x9f0>
1007be768:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007be76c:     	bfxil	x8, x21, #0, #48
1007be770:     	mov	x21, x8
1007be774:     	b	0x1007be800 <_js_array_get_f64+0x9f0>
1007be778:     	mov	x0, x20
1007be77c:     	bl	0x100b5efc0 <_mi_free>
1007be780:     	ldr	w8, [x21]
1007be784:     	cmp	w19, w8
1007be788:     	b.hs	0x1007be7c8 <_js_array_get_f64+0x9b8>
1007be78c:     	ldr	w8, [x21, #0x4]
1007be790:     	cmp	w19, w8
1007be794:     	b.hs	0x1007be7b8 <_js_array_get_f64+0x9a8>
1007be798:     	add	x8, x21, w19, uxtw #3
1007be79c:     	ldr	x22, [x8, #0x8]
1007be7a0:     	mov	x8, #0x1                ; =1
1007be7a4:     	movk	x8, #0x7ffc, lsl #48
1007be7a8:     	add	x8, x8, #0xf
1007be7ac:     	cmp	x22, x8
1007be7b0:     	b.ne	0x1007be5a0 <_js_array_get_f64+0x790>
1007be7b4:     	b	0x1007be7c8 <_js_array_get_f64+0x9b8>
1007be7b8:     	mov	x0, x21
1007be7bc:     	mov	x1, x19
1007be7c0:     	bl	0x10052aa44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007be7c4:     	tbnz	w0, #0x0, 0x1007be59c <_js_array_get_f64+0x78c>
1007be7c8:     	mov	x0, x21
1007be7cc:     	mov	x1, x19
1007be7d0:     	bl	0x1006c7258 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007be7d4:     	b	0x1007be59c <_js_array_get_f64+0x78c>
1007be7d8:     	add	x9, x8, #0xc0
1007be7dc:     	ldr	x10, [x8, #0x30]
1007be7e0:     	add	x10, x10, #0x1
1007be7e4:     	str	x10, [x8, #0x30]
1007be7e8:     	add	x8, x9, #0x19
1007be7ec:     	ldrb	w8, [x8]
1007be7f0:     	cmp	w8, #0xff
1007be7f4:     	b.ne	0x1007be2c0 <_js_array_get_f64+0x4b0>
1007be7f8:     	b	0x1007be2b4 <_js_array_get_f64+0x4a4>
1007be7fc:     	add	x21, x22, #0x1
1007be800:     	fmov	d0, x21
1007be804:     	bl	0x1006fd07c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007be808:     	mov	x22, x0
1007be80c:     	tbnz	w23, #0x0, 0x1007be5a0 <_js_array_get_f64+0x790>
1007be810:     	mov	x0, x20
1007be814:     	bl	0x100b5efc0 <_mi_free>
1007be818:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be81c:     	ldr	x20, [sp, #0x10]
1007be820:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be824:     	ldr	x8, [x8, #0xed8]
1007be828:     	cbz	x8, 0x1007be840 <_js_array_get_f64+0xa30>
1007be82c:     	mov	x0, x20
1007be830:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007be834:     	tbz	w0, #0x0, 0x1007be840 <_js_array_get_f64+0xa30>
1007be838:     	mov	x0, x20
1007be83c:     	bl	0x1002beec0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007be840:     	tbnz	w19, #0x1f, 0x1007be860 <_js_array_get_f64+0xa50>
1007be844:     	ldr	w8, [x20]
1007be848:     	cmp	w19, w8
1007be84c:     	b.hs	0x1007be860 <_js_array_get_f64+0xa50>
1007be850:     	mov	w1, w19
1007be854:     	mov	x0, x20
1007be858:     	bl	0x1002a514c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007be85c:     	b	0x1007be59c <_js_array_get_f64+0x78c>
1007be860:     	mov	x8, #0x1                ; =1
1007be864:     	movk	x8, #0x7ffc, lsl #48
1007be868:     	mov	x22, x8
1007be86c:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be870:     	mov	x0, x22
1007be874:     	bl	0x100b47930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007be878:     	cmp	x0, #0x1
1007be87c:     	b.ne	0x1007bde50 <_js_array_get_f64+0x40>
1007be880:     	mov	x0, x19
1007be884:     	bl	0x100b47950 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007be888:     	b	0x1007be59c <_js_array_get_f64+0x78c>
1007be88c:     	mov	x0, x20
1007be890:     	mov	w1, #0x0                ; =0
1007be894:     	bl	0x100b49ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be898:     	mov	x20, x0
1007be89c:     	cbnz	x0, 0x1007bdf6c <_js_array_get_f64+0x15c>
1007be8a0:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be8a4:     	mov	x0, x20
1007be8a8:     	mov	w1, #0x1                ; =1
1007be8ac:     	bl	0x100b49ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be8b0:     	mov	x20, x0
1007be8b4:     	cbnz	x0, 0x1007be110 <_js_array_get_f64+0x300>
1007be8b8:     	b	0x1007be5a0 <_js_array_get_f64+0x790>
1007be8bc:     	mov	w0, #0x1                ; =1
1007be8c0:     	mov	x1, x22
1007be8c4:     	bl	0x100b12380 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
