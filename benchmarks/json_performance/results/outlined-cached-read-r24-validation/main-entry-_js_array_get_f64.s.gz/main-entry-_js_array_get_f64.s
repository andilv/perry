
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-cached-read-r24/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bddd0 <_js_array_get_f64>:
1007bddd0:     	sub	sp, sp, #0x70
1007bddd4:     	stp	x26, x25, [sp, #0x20]
1007bddd8:     	stp	x24, x23, [sp, #0x30]
1007bdddc:     	stp	x22, x21, [sp, #0x40]
1007bdde0:     	stp	x20, x19, [sp, #0x50]
1007bdde4:     	stp	x29, x30, [sp, #0x60]
1007bdde8:     	add	x29, sp, #0x60
1007bddec:     	mov	x19, x1
1007bddf0:     	mov	x22, x0
1007bddf4:     	lsr	x25, x0, #51
1007bddf8:     	mov	x20, x0
1007bddfc:     	cmp	x25, #0xfff
1007bde00:     	b.lo	0x1007bde1c <_js_array_get_f64+0x4c>
1007bde04:     	mov	w8, #0x7ffc             ; =32764
1007bde08:     	cmp	x8, x22, lsr #48
1007bde0c:     	b.ne	0x1007bde18 <_js_array_get_f64+0x48>
1007bde10:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bde14:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007bde18:     	and	x20, x22, #0xffffffffffff
1007bde1c:     	lsr	x8, x20, #3
1007bde20:     	cmp	x8, #0x200
1007bde24:     	b.ls	0x1007bde5c <_js_array_get_f64+0x8c>
1007bde28:     	ldurb	w8, [x20, #-0x8]
1007bde2c:     	cmp	w8, #0x9
1007bde30:     	b.ne	0x1007bde5c <_js_array_get_f64+0x8c>
1007bde34:     	ldr	w8, [x20, #0x4]
1007bde38:     	mov	w9, #0x5841             ; =22593
1007bde3c:     	movk	w9, #0x4c5a, lsl #16
1007bde40:     	cmp	w8, w9
1007bde44:     	b.ne	0x1007bde5c <_js_array_get_f64+0x8c>
1007bde48:     	mov	x0, x20
1007bde4c:     	mov	x1, x19
1007bde50:     	bl	0x1003788bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get>
1007bde54:     	fmov	d0, x0
1007bde58:     	b	0x1007be4cc <_js_array_get_f64+0x6fc>
1007bde5c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bde60:     	b.lo	0x1007bdf10 <_js_array_get_f64+0x140>
1007bde64:     	tst	x20, #0xffff800000000000
1007bde68:     	mov	w8, #0x1000             ; =4096
1007bde6c:     	ccmp	x20, x8, #0x0, eq
1007bde70:     	b.lo	0x1007bdf10 <_js_array_get_f64+0x140>
1007bde74:     	ldurb	w24, [x20, #-0x8]
1007bde78:     	ldurh	w23, [x20, #-0x6]
1007bde7c:     	cmp	w24, #0xa
1007bde80:     	b.gt	0x1007be028 <_js_array_get_f64+0x258>
1007bde84:     	cmp	w24, #0x2
1007bde88:     	b.eq	0x1007be0b0 <_js_array_get_f64+0x2e0>
1007bde8c:     	cmp	w24, #0x8
1007bde90:     	b.ne	0x1007bdf18 <_js_array_get_f64+0x148>
1007bde94:     	mov	x0, x20
1007bde98:     	bl	0x1003051a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bde9c:     	cbz	w0, 0x1007be140 <_js_array_get_f64+0x370>
1007bdea0:     	mov	x22, #0x1               ; =1
1007bdea4:     	movk	x22, #0x7ffc, lsl #48
1007bdea8:     	lsr	x8, x20, #51
1007bdeac:     	cmp	x8, #0xfff
1007bdeb0:     	b.lo	0x1007bdec4 <_js_array_get_f64+0xf4>
1007bdeb4:     	mov	w8, #0x7ffc             ; =32764
1007bdeb8:     	cmp	x8, x20, lsr #48
1007bdebc:     	b.eq	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007bdec0:     	and	x20, x20, #0xffffffffffff
1007bdec4:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bdec8:     	b.lo	0x1007bdee8 <_js_array_get_f64+0x118>
1007bdecc:     	tst	x20, #0xffff800000000000
1007bded0:     	mov	w8, #0x1000             ; =4096
1007bded4:     	ccmp	x20, x8, #0x0, eq
1007bded8:     	b.lo	0x1007bdee8 <_js_array_get_f64+0x118>
1007bdedc:     	ldurb	w8, [x20, #-0x8]
1007bdee0:     	cmp	w8, #0x2
1007bdee4:     	b.eq	0x1007be7b4 <_js_array_get_f64+0x9e4>
1007bdee8:     	cbz	x20, 0x1007be4c8 <_js_array_get_f64+0x6f8>
1007bdeec:     	mov	x0, x20
1007bdef0:     	mov	x1, x19
1007bdef4:     	bl	0x100305358 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bdef8:     	cmp	w0, #0x1
1007bdefc:     	b.ne	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007bdf00:     	ldr	x8, [x20, #0x8]
1007bdf04:     	ubfiz	x9, x1, #4, #32
1007bdf08:     	ldr	x22, [x8, x9]
1007bdf0c:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007bdf10:     	mov	w23, #0x0               ; =0
1007bdf14:     	mov	w24, #0x0               ; =0
1007bdf18:     	mov	x21, x22
1007bdf1c:     	cmp	x25, #0xfff
1007bdf20:     	b.lo	0x1007bdf38 <_js_array_get_f64+0x168>
1007bdf24:     	mov	w8, #0x7ffc             ; =32764
1007bdf28:     	cmp	x8, x22, lsr #48
1007bdf2c:     	b.eq	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007bdf30:     	ands	x21, x22, #0xffffffffffff
1007bdf34:     	b.eq	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007bdf38:     	and	x8, x21, #0xfffffffffff00000
1007bdf3c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bdf40:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bdf44:     	cmp	x9, x10
1007bdf48:     	ccmp	x8, #0x0, #0x4, lo
1007bdf4c:     	b.eq	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007bdf50:     	tst	x21, #0x3
1007bdf54:     	ccmp	x21, #0x7, #0x0, eq
1007bdf58:     	b.ls	0x1007be208 <_js_array_get_f64+0x438>
1007bdf5c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bdf60:     	ldr	x8, [x8, #0x48]
1007bdf64:     	cmn	x8, #0x1
1007bdf68:     	b.eq	0x1007be158 <_js_array_get_f64+0x388>
1007bdf6c:     	mrs	x9, TPIDRRO_EL0
1007bdf70:     	and	x9, x9, #0xfffffffffffffff8
1007bdf74:     	ldr	x0, [x9, x8, lsl #3]
1007bdf78:     	cbz	x0, 0x1007be158 <_js_array_get_f64+0x388>
1007bdf7c:     	lsr	x1, x21, #20
1007bdf80:     	ldr	x8, [x0, #0x10]
1007bdf84:     	ldrb	w9, [x8]
1007bdf88:     	cmp	w9, #0x2
1007bdf8c:     	b.ne	0x1007be170 <_js_array_get_f64+0x3a0>
1007bdf90:     	ldrb	w9, [x8, #0x88]
1007bdf94:     	tbz	w9, #0x0, 0x1007bdfb4 <_js_array_get_f64+0x1e4>
1007bdf98:     	ldr	x9, [x8, #0x80]
1007bdf9c:     	cmp	x9, x1
1007bdfa0:     	b.ne	0x1007bdfb4 <_js_array_get_f64+0x1e4>
1007bdfa4:     	ldp	x9, x10, [x8, #0x60]
1007bdfa8:     	cmp	x9, x21
1007bdfac:     	ccmp	x10, x21, #0x0, ls
1007bdfb0:     	b.hi	0x1007be150 <_js_array_get_f64+0x380>
1007bdfb4:     	ldrb	w9, [x8, #0xb8]
1007bdfb8:     	cbz	w9, 0x1007bdfd8 <_js_array_get_f64+0x208>
1007bdfbc:     	ldr	x9, [x8, #0xb0]
1007bdfc0:     	cmp	x9, x1
1007bdfc4:     	b.ne	0x1007bdfd8 <_js_array_get_f64+0x208>
1007bdfc8:     	ldp	x9, x10, [x8, #0x90]
1007bdfcc:     	cmp	x9, x21
1007bdfd0:     	ccmp	x10, x21, #0x0, ls
1007bdfd4:     	b.hi	0x1007be618 <_js_array_get_f64+0x848>
1007bdfd8:     	ldrb	w9, [x8, #0xe8]
1007bdfdc:     	cbz	w9, 0x1007bdffc <_js_array_get_f64+0x22c>
1007bdfe0:     	ldr	x9, [x8, #0xe0]
1007bdfe4:     	cmp	x9, x1
1007bdfe8:     	b.ne	0x1007bdffc <_js_array_get_f64+0x22c>
1007bdfec:     	ldp	x9, x10, [x8, #0xc0]
1007bdff0:     	cmp	x9, x21
1007bdff4:     	ccmp	x10, x21, #0x0, ls
1007bdff8:     	b.hi	0x1007be700 <_js_array_get_f64+0x930>
1007bdffc:     	ldrb	w9, [x8, #0x118]
1007be000:     	cbz	w9, 0x1007be1d0 <_js_array_get_f64+0x400>
1007be004:     	ldr	x9, [x8, #0x110]
1007be008:     	cmp	x9, x1
1007be00c:     	b.ne	0x1007be1d0 <_js_array_get_f64+0x400>
1007be010:     	ldp	x9, x10, [x8, #0xf0]
1007be014:     	cmp	x9, x21
1007be018:     	ccmp	x10, x21, #0x0, ls
1007be01c:     	b.ls	0x1007be1d0 <_js_array_get_f64+0x400>
1007be020:     	add	x9, x8, #0xf0
1007be024:     	b	0x1007be704 <_js_array_get_f64+0x934>
1007be028:     	cmp	w24, #0xb
1007be02c:     	b.eq	0x1007be0c8 <_js_array_get_f64+0x2f8>
1007be030:     	cmp	w24, #0xc
1007be034:     	b.ne	0x1007bdf18 <_js_array_get_f64+0x148>
1007be038:     	mov	x0, x20
1007be03c:     	bl	0x10030af38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be040:     	cbz	w0, 0x1007be148 <_js_array_get_f64+0x378>
1007be044:     	mov	x22, #0x1               ; =1
1007be048:     	movk	x22, #0x7ffc, lsl #48
1007be04c:     	lsr	x8, x20, #51
1007be050:     	cmp	x8, #0xfff
1007be054:     	b.lo	0x1007be068 <_js_array_get_f64+0x298>
1007be058:     	mov	w8, #0x7ffc             ; =32764
1007be05c:     	cmp	x8, x20, lsr #48
1007be060:     	b.eq	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be064:     	and	x20, x20, #0xffffffffffff
1007be068:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be06c:     	b.lo	0x1007be08c <_js_array_get_f64+0x2bc>
1007be070:     	tst	x20, #0xffff800000000000
1007be074:     	mov	w8, #0x1000             ; =4096
1007be078:     	ccmp	x20, x8, #0x0, eq
1007be07c:     	b.lo	0x1007be08c <_js_array_get_f64+0x2bc>
1007be080:     	ldurb	w8, [x20, #-0x8]
1007be084:     	cmp	w8, #0x2
1007be088:     	b.eq	0x1007be7cc <_js_array_get_f64+0x9fc>
1007be08c:     	cbz	x20, 0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be090:     	mov	x0, x20
1007be094:     	mov	x1, x19
1007be098:     	bl	0x10030cbb0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be09c:     	cmp	w0, #0x1
1007be0a0:     	b.ne	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be0a4:     	ldr	x8, [x20, #0x8]
1007be0a8:     	ldr	x22, [x8, w1, uxtw #3]
1007be0ac:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be0b0:     	mov	x0, x22
1007be0b4:     	mov	x1, x19
1007be0b8:     	bl	0x10054860c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be0bc:     	tbnz	w0, #0x0, 0x1007be4c4 <_js_array_get_f64+0x6f4>
1007be0c0:     	mov	w24, #0x2               ; =2
1007be0c4:     	b	0x1007bdf18 <_js_array_get_f64+0x148>
1007be0c8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be0cc:     	add	x8, x8, #0xec0
1007be0d0:     	ldaprb	w8, [x8]
1007be0d4:     	cbz	w8, 0x1007be138 <_js_array_get_f64+0x368>
1007be0d8:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be0dc:     	add	x8, x8, #0x58
1007be0e0:     	ldapr	x8, [x8]
1007be0e4:     	cmp	x20, x8
1007be0e8:     	b.lo	0x1007be138 <_js_array_get_f64+0x368>
1007be0ec:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be0f0:     	add	x8, x8, #0x60
1007be0f4:     	ldapr	x8, [x8]
1007be0f8:     	cmp	x20, x8
1007be0fc:     	b.hi	0x1007be138 <_js_array_get_f64+0x368>
1007be100:     	mov	x0, x20
1007be104:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be108:     	tbz	w0, #0x0, 0x1007be138 <_js_array_get_f64+0x368>
1007be10c:     	add	x0, sp, #0x8
1007be110:     	mov	x1, x20
1007be114:     	bl	0x1002a4aac <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be118:     	ldr	x8, [sp, #0x8]
1007be11c:     	cbz	x8, 0x1007be744 <_js_array_get_f64+0x974>
1007be120:     	cmp	x8, #0x1
1007be124:     	b.ne	0x1007be788 <_js_array_get_f64+0x9b8>
1007be128:     	ldr	d0, [sp, #0x10]
1007be12c:     	scvtf	d1, w19
1007be130:     	bl	0x10081c374 <_js_dyn_index_get>
1007be134:     	b	0x1007be4c4 <_js_array_get_f64+0x6f4>
1007be138:     	mov	w24, #0xb               ; =11
1007be13c:     	b	0x1007bdf18 <_js_array_get_f64+0x148>
1007be140:     	mov	w24, #0x8               ; =8
1007be144:     	b	0x1007bdf18 <_js_array_get_f64+0x148>
1007be148:     	mov	w24, #0xc               ; =12
1007be14c:     	b	0x1007bdf18 <_js_array_get_f64+0x148>
1007be150:     	add	x9, x8, #0x60
1007be154:     	b	0x1007be704 <_js_array_get_f64+0x934>
1007be158:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be15c:     	lsr	x1, x21, #20
1007be160:     	ldr	x8, [x0, #0x10]
1007be164:     	ldrb	w9, [x8]
1007be168:     	cmp	w9, #0x2
1007be16c:     	b.eq	0x1007bdf90 <_js_array_get_f64+0x1c0>
1007be170:     	ldr	x9, [x8, #0x8]
1007be174:     	ldr	x10, [x8, #0x28]
1007be178:     	sub	x9, x1, x9
1007be17c:     	cmp	x9, x10
1007be180:     	b.hs	0x1007be1c4 <_js_array_get_f64+0x3f4>
1007be184:     	ldr	x10, [x8, #0x20]
1007be188:     	mov	w11, #0x28              ; =40
1007be18c:     	madd	x9, x9, x11, x10
1007be190:     	ldr	x10, [x9]
1007be194:     	ldr	x11, [x8, #0x10]
1007be198:     	cmp	x10, x11
1007be19c:     	b.ne	0x1007be1d0 <_js_array_get_f64+0x400>
1007be1a0:     	ldp	x10, x11, [x9, #0x8]
1007be1a4:     	cmp	x10, x21
1007be1a8:     	ccmp	x11, x21, #0x0, ls
1007be1ac:     	b.ls	0x1007be1d0 <_js_array_get_f64+0x400>
1007be1b0:     	ldr	x10, [x8, #0x30]
1007be1b4:     	add	x10, x10, #0x1
1007be1b8:     	str	x10, [x8, #0x30]
1007be1bc:     	add	x8, x9, #0x21
1007be1c0:     	b	0x1007be714 <_js_array_get_f64+0x944>
1007be1c4:     	ldr	x9, [x8, #0x58]
1007be1c8:     	add	x9, x9, #0x1
1007be1cc:     	str	x9, [x8, #0x58]
1007be1d0:     	ldr	x9, [x8, #0x38]
1007be1d4:     	add	x9, x9, #0x1
1007be1d8:     	str	x9, [x8, #0x38]
1007be1dc:     	mov	x0, x21
1007be1e0:     	bl	0x10051e348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be1e4:     	and	w8, w0, #0xff
1007be1e8:     	cbz	w8, 0x1007be208 <_js_array_get_f64+0x438>
1007be1ec:     	ldurb	w8, [x21, #-0x8]
1007be1f0:     	ldurb	w9, [x21, #-0x7]
1007be1f4:     	mov	w10, #0x82              ; =130
1007be1f8:     	and	w9, w9, w10
1007be1fc:     	cmp	w9, #0x2
1007be200:     	ccmp	w8, #0x1, #0x0, eq
1007be204:     	b.eq	0x1007be2d8 <_js_array_get_f64+0x508>
1007be208:     	mov	x0, x21
1007be20c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be210:     	cbz	x0, 0x1007be238 <_js_array_get_f64+0x468>
1007be214:     	ldrb	w9, [x0]
1007be218:     	cmp	w9, #0x1
1007be21c:     	b.ne	0x1007be254 <_js_array_get_f64+0x484>
1007be220:     	ldrsb	w8, [x0, #0x1]
1007be224:     	tbnz	w8, #0x1f, 0x1007be300 <_js_array_get_f64+0x530>
1007be228:     	ldp	w10, w9, [x21]
1007be22c:     	cmp	w10, w9
1007be230:     	b.hi	0x1007be38c <_js_array_get_f64+0x5bc>
1007be234:     	b	0x1007be3a4 <_js_array_get_f64+0x5d4>
1007be238:     	mov	x25, x0
1007be23c:     	mov	x0, x21
1007be240:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be244:     	tbz	w0, #0x0, 0x1007be290 <_js_array_get_f64+0x4c0>
1007be248:     	mov	x0, #0x0                ; =0
1007be24c:     	mov	x8, x25
1007be250:     	b	0x1007be37c <_js_array_get_f64+0x5ac>
1007be254:     	mov	x8, x0
1007be258:     	cmp	w9, #0x1
1007be25c:     	b.eq	0x1007be37c <_js_array_get_f64+0x5ac>
1007be260:     	cmp	w9, #0x9
1007be264:     	b.ne	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be268:     	ldr	w8, [x21, #0x4]
1007be26c:     	mov	w9, #0x5841             ; =22593
1007be270:     	movk	w9, #0x4c5a, lsl #16
1007be274:     	cmp	w8, w9
1007be278:     	b.ne	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be27c:     	mov	x0, x21
1007be280:     	bl	0x1003759b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be284:     	cbz	x0, 0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be288:     	mov	x21, x0
1007be28c:     	b	0x1007be3c0 <_js_array_get_f64+0x5f0>
1007be290:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be294:     	add	x8, x8, #0xec0
1007be298:     	ldaprb	w8, [x8]
1007be29c:     	cbz	w8, 0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be2a0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be2a4:     	add	x8, x8, #0x58
1007be2a8:     	ldapr	x8, [x8]
1007be2ac:     	cmp	x8, x21
1007be2b0:     	b.hi	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be2b4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be2b8:     	add	x8, x8, #0x60
1007be2bc:     	ldapr	x8, [x8]
1007be2c0:     	cmp	x8, x21
1007be2c4:     	b.lo	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be2c8:     	mov	x0, x21
1007be2cc:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be2d0:     	tbnz	w0, #0x0, 0x1007be248 <_js_array_get_f64+0x478>
1007be2d4:     	b	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be2d8:     	ldr	w8, [x21]
1007be2dc:     	mov	w9, #0xe100             ; =57600
1007be2e0:     	movk	w9, #0x5f5, lsl #16
1007be2e4:     	orr	w9, w9, #0x1
1007be2e8:     	cmp	w8, w9
1007be2ec:     	b.hs	0x1007be208 <_js_array_get_f64+0x438>
1007be2f0:     	ldr	w9, [x21, #0x4]
1007be2f4:     	cmp	w8, w9
1007be2f8:     	b.ls	0x1007be3c0 <_js_array_get_f64+0x5f0>
1007be2fc:     	b	0x1007be208 <_js_array_get_f64+0x438>
1007be300:     	mov	x25, x0
1007be304:     	ldr	x21, [x0, #0x8]
1007be308:     	mov	x0, x21
1007be30c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be310:     	cbz	x0, 0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be314:     	ldrb	w8, [x0]
1007be318:     	cmp	w8, #0x1
1007be31c:     	b.ne	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be320:     	ldrsb	w8, [x0, #0x1]
1007be324:     	tbz	w8, #0x1f, 0x1007be228 <_js_array_get_f64+0x458>
1007be328:     	mov	w26, #0x1               ; =1
1007be32c:     	ldr	x21, [x0, #0x8]
1007be330:     	mov	x0, x21
1007be334:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be338:     	cbz	x0, 0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be33c:     	ldrb	w8, [x0]
1007be340:     	cmp	w8, #0x1
1007be344:     	b.ne	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be348:     	cmp	w26, #0x3f
1007be34c:     	b.hi	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be350:     	add	w26, w26, #0x1
1007be354:     	ldrsb	w8, [x0, #0x1]
1007be358:     	tbnz	w8, #0x1f, 0x1007be32c <_js_array_get_f64+0x55c>
1007be35c:     	str	x21, [x25, #0x8]
1007be360:     	ldrb	w8, [x25, #0x1]
1007be364:     	orr	w9, w8, #0x80
1007be368:     	mov	x8, x25
1007be36c:     	strb	w9, [x25, #0x1]
1007be370:     	ldrb	w9, [x0]
1007be374:     	cmp	w9, #0x1
1007be378:     	b.ne	0x1007be260 <_js_array_get_f64+0x490>
1007be37c:     	ldp	w10, w9, [x21]
1007be380:     	cmp	w10, w9
1007be384:     	b.ls	0x1007be3a4 <_js_array_get_f64+0x5d4>
1007be388:     	cbz	x8, 0x1007be3b4 <_js_array_get_f64+0x5e4>
1007be38c:     	ldr	w8, [x0, #0x4]
1007be390:     	ubfiz	x9, x9, #3, #32
1007be394:     	add	x9, x9, #0x10
1007be398:     	cmp	x9, x8
1007be39c:     	b.eq	0x1007be3c0 <_js_array_get_f64+0x5f0>
1007be3a0:     	b	0x1007be3b4 <_js_array_get_f64+0x5e4>
1007be3a4:     	mov	w8, #0xe100             ; =57600
1007be3a8:     	movk	w8, #0x5f5, lsl #16
1007be3ac:     	cmp	w10, w8
1007be3b0:     	b.ls	0x1007be3c0 <_js_array_get_f64+0x5f0>
1007be3b4:     	mov	x0, x21
1007be3b8:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be3bc:     	tbz	w0, #0x0, 0x1007be470 <_js_array_get_f64+0x6a0>
1007be3c0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be3c4:     	add	x8, x8, #0xec0
1007be3c8:     	ldaprb	w8, [x8]
1007be3cc:     	cbz	w8, 0x1007be414 <_js_array_get_f64+0x644>
1007be3d0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be3d4:     	add	x8, x8, #0x58
1007be3d8:     	ldapr	x8, [x8]
1007be3dc:     	cmp	x21, x8
1007be3e0:     	b.lo	0x1007be414 <_js_array_get_f64+0x644>
1007be3e4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be3e8:     	add	x8, x8, #0x60
1007be3ec:     	ldapr	x8, [x8]
1007be3f0:     	cmp	x21, x8
1007be3f4:     	b.hi	0x1007be414 <_js_array_get_f64+0x644>
1007be3f8:     	mov	x0, x21
1007be3fc:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be400:     	tbz	w0, #0x0, 0x1007be414 <_js_array_get_f64+0x644>
1007be404:     	mov	x0, x21
1007be408:     	mov	x1, x19
1007be40c:     	bl	0x1008fc108 <_js_typed_array_get>
1007be410:     	b	0x1007be4c4 <_js_array_get_f64+0x6f4>
1007be414:     	mov	x0, x21
1007be418:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be41c:     	tbz	w0, #0x0, 0x1007be444 <_js_array_get_f64+0x674>
1007be420:     	mov	x0, x21
1007be424:     	mov	x1, x19
1007be428:     	bl	0x10058651c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007be42c:     	and	w8, w1, #0xff
1007be430:     	ucvtf	d0, w8
1007be434:     	fmov	x8, d0
1007be438:     	tst	w0, #0x1
1007be43c:     	csel	x22, x8, xzr, ne
1007be440:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be444:     	cmp	x21, x20
1007be448:     	b.eq	0x1007be4f0 <_js_array_get_f64+0x720>
1007be44c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007be450:     	b.lo	0x1007be4e8 <_js_array_get_f64+0x718>
1007be454:     	tst	x21, #0xffff800000000000
1007be458:     	mov	w8, #0x1000             ; =4096
1007be45c:     	ccmp	x21, x8, #0x0, eq
1007be460:     	b.lo	0x1007be4e8 <_js_array_get_f64+0x718>
1007be464:     	ldurb	w24, [x21, #-0x8]
1007be468:     	ldurh	w23, [x21, #-0x6]
1007be46c:     	b	0x1007be4f0 <_js_array_get_f64+0x720>
1007be470:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be474:     	add	x8, x8, #0xec0
1007be478:     	ldaprb	w8, [x8]
1007be47c:     	cbz	w8, 0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be480:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be484:     	add	x8, x8, #0x58
1007be488:     	ldapr	x8, [x8]
1007be48c:     	cmp	x21, x8
1007be490:     	b.lo	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be494:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be498:     	add	x8, x8, #0x60
1007be49c:     	ldapr	x8, [x8]
1007be4a0:     	cmp	x21, x8
1007be4a4:     	b.hi	0x1007be4b4 <_js_array_get_f64+0x6e4>
1007be4a8:     	mov	x0, x21
1007be4ac:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be4b0:     	tbnz	w0, #0x0, 0x1007be3c0 <_js_array_get_f64+0x5f0>
1007be4b4:     	mov	x0, x22
1007be4b8:     	mov	x1, x19
1007be4bc:     	bl	0x10054860c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be4c0:     	tbz	w0, #0x0, 0x1007be798 <_js_array_get_f64+0x9c8>
1007be4c4:     	fmov	x22, d0
1007be4c8:     	fmov	d0, x22
1007be4cc:     	ldp	x29, x30, [sp, #0x60]
1007be4d0:     	ldp	x20, x19, [sp, #0x50]
1007be4d4:     	ldp	x22, x21, [sp, #0x40]
1007be4d8:     	ldp	x24, x23, [sp, #0x30]
1007be4dc:     	ldp	x26, x25, [sp, #0x20]
1007be4e0:     	add	sp, sp, #0x70
1007be4e4:     	ret
1007be4e8:     	mov	w23, #0x0               ; =0
1007be4ec:     	mov	w24, #0x0               ; =0
1007be4f0:     	cmp	w24, #0x1
1007be4f4:     	b.ne	0x1007be6a8 <_js_array_get_f64+0x8d8>
1007be4f8:     	tbz	w23, #0xa, 0x1007be6a8 <_js_array_get_f64+0x8d8>
1007be4fc:     	adrp	x8, 0x100b64000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data14case_ignorable7OFFSETS+0x33c>
1007be500:     	add	x8, x8, #0xd0c
1007be504:     	cmp	w19, #0x3e8
1007be508:     	b.lo	0x1007be580 <_js_array_get_f64+0x7b0>
1007be50c:     	mov	x9, #0x0                ; =0
1007be510:     	mov	w11, #0x1759            ; =5977
1007be514:     	movk	w11, #0xd1b7, lsl #16
1007be518:     	mov	w12, #0x2710            ; =10000
1007be51c:     	mov	w13, #0x147b            ; =5243
1007be520:     	mov	w14, #0x64              ; =100
1007be524:     	add	x15, sp, #0x8
1007be528:     	mov	w16, #0x967f            ; =38527
1007be52c:     	movk	w16, #0x98, lsl #16
1007be530:     	mov	x10, x19
1007be534:     	mov	x17, x10
1007be538:     	umull	x10, w10, w11
1007be53c:     	lsr	x10, x10, #45
1007be540:     	msub	w0, w10, w12, w17
1007be544:     	ubfx	w1, w0, #2, #14
1007be548:     	mul	w1, w1, w13
1007be54c:     	lsr	w1, w1, #17
1007be550:     	msub	w0, w1, w14, w0
1007be554:     	add	x2, x15, x9
1007be558:     	ldrh	w1, [x8, w1, uxtw #1]
1007be55c:     	strh	w1, [x2, #0x6]
1007be560:     	and	x0, x0, #0xffff
1007be564:     	ldrh	w0, [x8, x0, lsl #1]
1007be568:     	strh	w0, [x2, #0x8]
1007be56c:     	sub	x9, x9, #0x4
1007be570:     	cmp	w17, w16
1007be574:     	b.hi	0x1007be534 <_js_array_get_f64+0x764>
1007be578:     	add	x9, x9, #0xa
1007be57c:     	b	0x1007be588 <_js_array_get_f64+0x7b8>
1007be580:     	mov	w9, #0xa                ; =10
1007be584:     	mov	x10, x19
1007be588:     	cmp	w10, #0x9
1007be58c:     	b.ls	0x1007be5c0 <_js_array_get_f64+0x7f0>
1007be590:     	sub	x9, x9, #0x2
1007be594:     	ubfx	w11, w10, #2, #14
1007be598:     	mov	w12, #0x147b            ; =5243
1007be59c:     	mul	w11, w11, w12
1007be5a0:     	lsr	w11, w11, #17
1007be5a4:     	mov	w12, #0x64              ; =100
1007be5a8:     	msub	w10, w11, w12, w10
1007be5ac:     	and	x10, x10, #0xffff
1007be5b0:     	ldrh	w10, [x8, x10, lsl #1]
1007be5b4:     	add	x12, sp, #0x8
1007be5b8:     	strh	w10, [x12, x9]
1007be5bc:     	mov	x10, x11
1007be5c0:     	cbz	w19, 0x1007be5f8 <_js_array_get_f64+0x828>
1007be5c4:     	cbnz	w10, 0x1007be5f8 <_js_array_get_f64+0x828>
1007be5c8:     	cmp	x9, #0xa
1007be5cc:     	b.ne	0x1007be620 <_js_array_get_f64+0x850>
1007be5d0:     	mov	w23, #0x1               ; =1
1007be5d4:     	add	x0, sp, #0x8
1007be5d8:     	mov	x1, x21
1007be5dc:     	mov	w2, #0x1                ; =1
1007be5e0:     	mov	x3, #0x0                ; =0
1007be5e4:     	bl	0x1005b28fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be5e8:     	ldr	x8, [sp, #0x8]
1007be5ec:     	mov	w20, #0x1               ; =1
1007be5f0:     	cbnz	x8, 0x1007be670 <_js_array_get_f64+0x8a0>
1007be5f4:     	b	0x1007be6a8 <_js_array_get_f64+0x8d8>
1007be5f8:     	sub	x23, x9, #0x1
1007be5fc:     	ubfiz	w10, w10, #1, #4
1007be600:     	add	x8, x8, x10
1007be604:     	ldrb	w8, [x8, #0x1]
1007be608:     	add	x10, sp, #0x8
1007be60c:     	strb	w8, [x10, x23]
1007be610:     	mov	w8, #0xb                ; =11
1007be614:     	b	0x1007be628 <_js_array_get_f64+0x858>
1007be618:     	add	x9, x8, #0x90
1007be61c:     	b	0x1007be704 <_js_array_get_f64+0x934>
1007be620:     	mov	w8, #0xa                ; =10
1007be624:     	mov	x23, x9
1007be628:     	sub	x22, x8, x9
1007be62c:     	mov	x0, x22
1007be630:     	mov	w1, #0x1                ; =1
1007be634:     	bl	0x100b5f148 <_mi_malloc_aligned>
1007be638:     	cbz	x0, 0x1007be7e4 <_js_array_get_f64+0xa14>
1007be63c:     	mov	x20, x0
1007be640:     	add	x8, sp, #0x8
1007be644:     	add	x1, x8, x23
1007be648:     	mov	x2, x22
1007be64c:     	bl	0x100b61d6c <_writev+0x100b61d6c>
1007be650:     	add	x0, sp, #0x8
1007be654:     	mov	x1, x21
1007be658:     	mov	x2, x20
1007be65c:     	mov	x3, x22
1007be660:     	bl	0x1005b28fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be664:     	ldr	w8, [sp, #0x8]
1007be668:     	tbz	w8, #0x0, 0x1007be6a0 <_js_array_get_f64+0x8d0>
1007be66c:     	mov	w23, #0x0               ; =0
1007be670:     	mov	x22, #0x1               ; =1
1007be674:     	movk	x22, #0x7ffc, lsl #48
1007be678:     	ldr	x0, [sp, #0x10]
1007be67c:     	cbz	x0, 0x1007be734 <_js_array_get_f64+0x964>
1007be680:     	cbz	x21, 0x1007be724 <_js_array_get_f64+0x954>
1007be684:     	lsr	x8, x21, #52
1007be688:     	cmp	x8, #0x7fe
1007be68c:     	b.hi	0x1007be728 <_js_array_get_f64+0x958>
1007be690:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007be694:     	bfxil	x8, x21, #0, #48
1007be698:     	mov	x21, x8
1007be69c:     	b	0x1007be728 <_js_array_get_f64+0x958>
1007be6a0:     	mov	x0, x20
1007be6a4:     	bl	0x100b5eec0 <_mi_free>
1007be6a8:     	ldr	w8, [x21]
1007be6ac:     	cmp	w19, w8
1007be6b0:     	b.hs	0x1007be6f0 <_js_array_get_f64+0x920>
1007be6b4:     	ldr	w8, [x21, #0x4]
1007be6b8:     	cmp	w19, w8
1007be6bc:     	b.hs	0x1007be6e0 <_js_array_get_f64+0x910>
1007be6c0:     	add	x8, x21, w19, uxtw #3
1007be6c4:     	ldr	x22, [x8, #0x8]
1007be6c8:     	mov	x8, #0x1                ; =1
1007be6cc:     	movk	x8, #0x7ffc, lsl #48
1007be6d0:     	add	x8, x8, #0xf
1007be6d4:     	cmp	x22, x8
1007be6d8:     	b.ne	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be6dc:     	b	0x1007be6f0 <_js_array_get_f64+0x920>
1007be6e0:     	mov	x0, x21
1007be6e4:     	mov	x1, x19
1007be6e8:     	bl	0x10052aa04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007be6ec:     	tbnz	w0, #0x0, 0x1007be4c4 <_js_array_get_f64+0x6f4>
1007be6f0:     	mov	x0, x21
1007be6f4:     	mov	x1, x19
1007be6f8:     	bl	0x1006c7218 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007be6fc:     	b	0x1007be4c4 <_js_array_get_f64+0x6f4>
1007be700:     	add	x9, x8, #0xc0
1007be704:     	ldr	x10, [x8, #0x30]
1007be708:     	add	x10, x10, #0x1
1007be70c:     	str	x10, [x8, #0x30]
1007be710:     	add	x8, x9, #0x19
1007be714:     	ldrb	w8, [x8]
1007be718:     	cmp	w8, #0xff
1007be71c:     	b.ne	0x1007be1e8 <_js_array_get_f64+0x418>
1007be720:     	b	0x1007be1dc <_js_array_get_f64+0x40c>
1007be724:     	add	x21, x22, #0x1
1007be728:     	fmov	d0, x21
1007be72c:     	bl	0x1006fd03c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007be730:     	mov	x22, x0
1007be734:     	tbnz	w23, #0x0, 0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be738:     	mov	x0, x20
1007be73c:     	bl	0x100b5eec0 <_mi_free>
1007be740:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be744:     	ldr	x20, [sp, #0x10]
1007be748:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be74c:     	ldr	x8, [x8, #0xed8]
1007be750:     	cbz	x8, 0x1007be768 <_js_array_get_f64+0x998>
1007be754:     	mov	x0, x20
1007be758:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007be75c:     	tbz	w0, #0x0, 0x1007be768 <_js_array_get_f64+0x998>
1007be760:     	mov	x0, x20
1007be764:     	bl	0x1002bee80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007be768:     	tbnz	w19, #0x1f, 0x1007be788 <_js_array_get_f64+0x9b8>
1007be76c:     	ldr	w8, [x20]
1007be770:     	cmp	w19, w8
1007be774:     	b.hs	0x1007be788 <_js_array_get_f64+0x9b8>
1007be778:     	mov	w1, w19
1007be77c:     	mov	x0, x20
1007be780:     	bl	0x1002a510c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007be784:     	b	0x1007be4c4 <_js_array_get_f64+0x6f4>
1007be788:     	mov	x8, #0x1                ; =1
1007be78c:     	movk	x8, #0x7ffc, lsl #48
1007be790:     	mov	x22, x8
1007be794:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be798:     	mov	x0, x22
1007be79c:     	bl	0x100b47830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007be7a0:     	cmp	x0, #0x1
1007be7a4:     	b.ne	0x1007bde10 <_js_array_get_f64+0x40>
1007be7a8:     	mov	x0, x19
1007be7ac:     	bl	0x100b47850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007be7b0:     	b	0x1007be4c4 <_js_array_get_f64+0x6f4>
1007be7b4:     	mov	x0, x20
1007be7b8:     	mov	w1, #0x0                ; =0
1007be7bc:     	bl	0x100b49dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be7c0:     	mov	x20, x0
1007be7c4:     	cbnz	x0, 0x1007bdeec <_js_array_get_f64+0x11c>
1007be7c8:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be7cc:     	mov	x0, x20
1007be7d0:     	mov	w1, #0x1                ; =1
1007be7d4:     	bl	0x100b49dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007be7d8:     	mov	x20, x0
1007be7dc:     	cbnz	x0, 0x1007be090 <_js_array_get_f64+0x2c0>
1007be7e0:     	b	0x1007be4c8 <_js_array_get_f64+0x6f8>
1007be7e4:     	mov	w0, #0x1                ; =1
1007be7e8:     	mov	x1, x22
1007be7ec:     	bl	0x100b12280 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
