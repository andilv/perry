let callbackChecksum = 0;
console.log('moving-callback', JSON.stringify({item: {id: 7}}, function(key: string, value: any) {
    const keep: any[] = [];
    for (let j = 0; j < 64; j++) {
        keep.push({id: j, text: 'callback-' + j});
        callbackChecksum += keep[j].id;
    }
    if (key === 'id') return value + 1;
    return value;
}), callbackChecksum);

