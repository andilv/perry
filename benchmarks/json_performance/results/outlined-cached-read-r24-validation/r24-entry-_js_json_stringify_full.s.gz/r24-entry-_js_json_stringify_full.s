
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-cached-read-r24/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845ac0 <_js_json_stringify_full>:
100845ac0:     	sub	sp, sp, #0x110
100845ac4:     	stp	d9, d8, [sp, #0xa0]
100845ac8:     	stp	x28, x27, [sp, #0xb0]
100845acc:     	stp	x26, x25, [sp, #0xc0]
100845ad0:     	stp	x24, x23, [sp, #0xd0]
100845ad4:     	stp	x22, x21, [sp, #0xe0]
100845ad8:     	stp	x20, x19, [sp, #0xf0]
100845adc:     	stp	x29, x30, [sp, #0x100]
100845ae0:     	add	x29, sp, #0x100
100845ae4:     	mov.16b	v9, v2
100845ae8:     	mov.16b	v8, v0
100845aec:     	mov	x26, #0x1               ; =1
100845af0:     	movk	x26, #0x7ffc, lsl #48
100845af4:     	fmov	x19, d8
100845af8:     	fmov	x20, d1
100845afc:     	fmov	x23, d9
100845b00:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845b04:     	add	x9, x23, x8
100845b08:     	add	x27, x20, x8
100845b0c:     	cmp	x9, #0x2
100845b10:     	b.hs	0x100845b2c <_js_json_stringify_full+0x6c>
100845b14:     	cmp	x27, #0x2
100845b18:     	b.lo	0x100845b3c <_js_json_stringify_full+0x7c>
100845b1c:     	mov	w21, #0x0               ; =0
100845b20:     	cmp	x19, x26
100845b24:     	b.eq	0x100846f8c <_js_json_stringify_full+0x14cc>
100845b28:     	b	0x1008460b4 <_js_json_stringify_full+0x5f4>
100845b2c:     	add	x8, x26, #0x2
100845b30:     	cmp	x23, x8
100845b34:     	ccmp	x27, #0x2, #0x2, eq
100845b38:     	b.hs	0x100845b1c <_js_json_stringify_full+0x5c>
100845b3c:     	mov	x8, #-0x2               ; =-2
100845b40:     	movk	x8, #0x8003, lsl #48
100845b44:     	add	x8, x19, x8
100845b48:     	cmp	x8, #0x3
100845b4c:     	b.hs	0x100845b60 <_js_json_stringify_full+0xa0>
100845b50:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
100845b54:     	add	x9, x9, #0x758
100845b58:     	ldr	x21, [x9, x8, lsl #3]
100845b5c:     	b	0x100846f94 <_js_json_stringify_full+0x14d4>
100845b60:     	strb	wzr, [sp, #0x3c]
100845b64:     	str	wzr, [sp, #0x38]
100845b68:     	and	x8, x19, #0xffff000000000000
100845b6c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845b70:     	cmp	x8, x9
100845b74:     	b.eq	0x100845be8 <_js_json_stringify_full+0x128>
100845b78:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845b7c:     	cmp	x8, x9
100845b80:     	b.ne	0x100845fe4 <_js_json_stringify_full+0x524>
100845b84:     	ubfx	x10, x19, #40, #8
100845b88:     	cbz	x10, 0x100845bd8 <_js_json_stringify_full+0x118>
100845b8c:     	strb	w19, [sp, #0x38]
100845b90:     	cmp	x10, #0x1
100845b94:     	b.eq	0x100845bd8 <_js_json_stringify_full+0x118>
100845b98:     	lsr	x9, x19, #8
100845b9c:     	strb	w9, [sp, #0x39]
100845ba0:     	cmp	x10, #0x2
100845ba4:     	b.eq	0x100845bd8 <_js_json_stringify_full+0x118>
100845ba8:     	lsr	x9, x19, #16
100845bac:     	strb	w9, [sp, #0x3a]
100845bb0:     	cmp	x10, #0x3
100845bb4:     	b.eq	0x100845bd8 <_js_json_stringify_full+0x118>
100845bb8:     	lsr	x9, x19, #24
100845bbc:     	strb	w9, [sp, #0x3b]
100845bc0:     	cmp	x10, #0x4
100845bc4:     	b.eq	0x100845bd8 <_js_json_stringify_full+0x118>
100845bc8:     	lsr	x9, x19, #32
100845bcc:     	strb	w9, [sp, #0x3c]
100845bd0:     	cmp	x10, #0x5
100845bd4:     	b.ne	0x100847780 <_js_json_stringify_full+0x1cc0>
100845bd8:     	add	x11, sp, #0x38
100845bdc:     	cmp	w10, #0x3
100845be0:     	b.ls	0x100845c00 <_js_json_stringify_full+0x140>
100845be4:     	b	0x100845fe4 <_js_json_stringify_full+0x524>
100845be8:     	ands	x9, x19, #0xffffffffffff
100845bec:     	b.eq	0x1008460a8 <_js_json_stringify_full+0x5e8>
100845bf0:     	add	x11, x9, #0x14
100845bf4:     	ldr	w10, [x9, #0x4]
100845bf8:     	cmp	w10, #0x3
100845bfc:     	b.hi	0x100845fe4 <_js_json_stringify_full+0x524>
100845c00:     	stur	wzr, [sp, #0x71]
100845c04:     	mov	w9, #0x22               ; =34
100845c08:     	strb	w9, [sp, #0x70]
100845c0c:     	cbz	w10, 0x100845c44 <_js_json_stringify_full+0x184>
100845c10:     	add	x12, sp, #0x70
100845c14:     	ldrb	w13, [x11]
100845c18:     	sxtb	w15, w13
100845c1c:     	cmp	w13, #0xb
100845c20:     	b.le	0x100845c4c <_js_json_stringify_full+0x18c>
100845c24:     	cmp	w13, #0x21
100845c28:     	b.gt	0x100845c6c <_js_json_stringify_full+0x1ac>
100845c2c:     	cmp	w13, #0xc
100845c30:     	b.eq	0x100845ca0 <_js_json_stringify_full+0x1e0>
100845c34:     	cmp	w13, #0xd
100845c38:     	b.ne	0x100845c7c <_js_json_stringify_full+0x1bc>
100845c3c:     	mov	w15, #0x72              ; =114
100845c40:     	b	0x100845cac <_js_json_stringify_full+0x1ec>
100845c44:     	mov	w12, #0x1               ; =1
100845c48:     	b	0x100845cd4 <_js_json_stringify_full+0x214>
100845c4c:     	cmp	w13, #0x8
100845c50:     	b.eq	0x100845c98 <_js_json_stringify_full+0x1d8>
100845c54:     	cmp	w13, #0x9
100845c58:     	b.eq	0x100845ca8 <_js_json_stringify_full+0x1e8>
100845c5c:     	cmp	w13, #0xa
100845c60:     	b.ne	0x100845c7c <_js_json_stringify_full+0x1bc>
100845c64:     	mov	w15, #0x6e              ; =110
100845c68:     	b	0x100845cac <_js_json_stringify_full+0x1ec>
100845c6c:     	cmp	w13, #0x22
100845c70:     	b.eq	0x100845cac <_js_json_stringify_full+0x1ec>
100845c74:     	cmp	w13, #0x5c
100845c78:     	b.eq	0x100845cac <_js_json_stringify_full+0x1ec>
100845c7c:     	cmp	w15, #0x20
100845c80:     	b.lt	0x100845fe4 <_js_json_stringify_full+0x524>
100845c84:     	mov	w14, #0x0               ; =0
100845c88:     	add	x13, x12, #0x2
100845c8c:     	mov	w12, #0x2               ; =2
100845c90:     	mov	w16, #0x1               ; =1
100845c94:     	b	0x100845cc4 <_js_json_stringify_full+0x204>
100845c98:     	mov	w15, #0x62              ; =98
100845c9c:     	b	0x100845cac <_js_json_stringify_full+0x1ec>
100845ca0:     	mov	w15, #0x66              ; =102
100845ca4:     	b	0x100845cac <_js_json_stringify_full+0x1ec>
100845ca8:     	mov	w15, #0x74              ; =116
100845cac:     	add	x13, x12, #0x3
100845cb0:     	mov	w12, #0x5c              ; =92
100845cb4:     	strb	w12, [sp, #0x71]
100845cb8:     	mov	w14, #0x1               ; =1
100845cbc:     	mov	w12, #0x3               ; =3
100845cc0:     	mov	w16, #0x2               ; =2
100845cc4:     	add	x17, sp, #0x70
100845cc8:     	strb	w15, [x17, x16]
100845ccc:     	cmp	w10, #0x1
100845cd0:     	b.ne	0x100845d0c <_js_json_stringify_full+0x24c>
100845cd4:     	add	x10, sp, #0x70
100845cd8:     	strb	w9, [x10, x12]
100845cdc:     	add	x8, x12, #0x1
100845ce0:     	cmp	x12, #0x3
100845ce4:     	b.hs	0x100845cf8 <_js_json_stringify_full+0x238>
100845ce8:     	mov	x13, #0x0               ; =0
100845cec:     	mov	x11, #0x0               ; =0
100845cf0:     	add	x9, sp, #0x70
100845cf4:     	b	0x100845f54 <_js_json_stringify_full+0x494>
100845cf8:     	cmp	x12, #0xf
100845cfc:     	b.hs	0x100845d3c <_js_json_stringify_full+0x27c>
100845d00:     	mov	x11, #0x0               ; =0
100845d04:     	mov	x13, #0x0               ; =0
100845d08:     	b	0x100845eb0 <_js_json_stringify_full+0x3f0>
100845d0c:     	ldrb	w16, [x11, #0x1]
100845d10:     	sxtb	w15, w16
100845d14:     	cmp	w16, #0xb
100845d18:     	b.le	0x100845f84 <_js_json_stringify_full+0x4c4>
100845d1c:     	cmp	w16, #0x21
100845d20:     	b.gt	0x100845fa4 <_js_json_stringify_full+0x4e4>
100845d24:     	cmp	w16, #0xc
100845d28:     	b.eq	0x100845fd4 <_js_json_stringify_full+0x514>
100845d2c:     	cmp	w16, #0xd
100845d30:     	b.ne	0x100845fb4 <_js_json_stringify_full+0x4f4>
100845d34:     	mov	w15, #0x72              ; =114
100845d38:     	b	0x100845fe0 <_js_json_stringify_full+0x520>
100845d3c:     	and	x12, x8, #0xc
100845d40:     	and	x11, x8, #0x10
100845d44:     	add	x13, sp, #0x70
100845d48:     	add	x9, x13, x11
100845d4c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100845d50:     	ldr	q0, [x14, #0x8d0]
100845d54:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100845d58:     	ldr	q1, [x14, #0x8e0]
100845d5c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100845d60:     	ldr	q2, [x14, #0x8f0]
100845d64:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100845d68:     	ldr	q3, [x14, #0x900]
100845d6c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100845d70:     	ldr	q4, [x14, #0x910]
100845d74:     	movi.2d	v5, #0000000000000000
100845d78:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100845d7c:     	ldr	q6, [x14, #0x920]
100845d80:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
100845d84:     	ldr	q7, [x14, #0xa40]
100845d88:     	mov	w14, #0x10              ; =16
100845d8c:     	movi.2d	v16, #0000000000000000
100845d90:     	dup.2d	v17, x14
100845d94:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3363a>
100845d98:     	ldr	q19, [x14, #0x940]
100845d9c:     	and	x14, x8, #0x10
100845da0:     	movi.2d	v20, #0000000000000000
100845da4:     	movi.2d	v18, #0000000000000000
100845da8:     	movi.2d	v23, #0000000000000000
100845dac:     	movi.2d	v21, #0000000000000000
100845db0:     	movi.2d	v24, #0000000000000000
100845db4:     	movi.2d	v22, #0000000000000000
100845db8:     	ldr	q25, [x13], #0x10
100845dbc:     	ushll.8h	v26, v25, #0x0
100845dc0:     	ushll2.4s	v27, v26, #0x0
100845dc4:     	ushll2.2d	v28, v27, #0x0
100845dc8:     	ushll2.8h	v25, v25, #0x0
100845dcc:     	ushll.4s	v29, v25, #0x0
100845dd0:     	ushll2.2d	v30, v29, #0x0
100845dd4:     	ushll.2d	v29, v29, #0x0
100845dd8:     	ushll.2d	v27, v27, #0x0
100845ddc:     	ushll.4s	v26, v26, #0x0
100845de0:     	ushll2.2d	v31, v26, #0x0
100845de4:     	ushll2.4s	v25, v25, #0x0
100845de8:     	ushll.2d	v8, v25, #0x0
100845dec:     	ushll.2d	v26, v26, #0x0
100845df0:     	ushll2.2d	v25, v25, #0x0
100845df4:     	shl.2d	v9, v0, #0x3
100845df8:     	ushl.2d	v25, v25, v9
100845dfc:     	shl.2d	v9, v19, #0x3
100845e00:     	ushl.2d	v26, v26, v9
100845e04:     	shl.2d	v9, v1, #0x3
100845e08:     	ushl.2d	v8, v8, v9
100845e0c:     	shl.2d	v9, v7, #0x3
100845e10:     	ushl.2d	v31, v31, v9
100845e14:     	shl.2d	v9, v6, #0x3
100845e18:     	ushl.2d	v27, v27, v9
100845e1c:     	shl.2d	v9, v3, #0x3
100845e20:     	ushl.2d	v29, v29, v9
100845e24:     	shl.2d	v9, v2, #0x3
100845e28:     	ushl.2d	v30, v30, v9
100845e2c:     	shl.2d	v9, v4, #0x3
100845e30:     	ushl.2d	v28, v28, v9
100845e34:     	orr.16b	v18, v28, v18
100845e38:     	orr.16b	v21, v30, v21
100845e3c:     	orr.16b	v23, v29, v23
100845e40:     	orr.16b	v20, v27, v20
100845e44:     	orr.16b	v5, v31, v5
100845e48:     	orr.16b	v24, v8, v24
100845e4c:     	orr.16b	v16, v26, v16
100845e50:     	orr.16b	v22, v25, v22
100845e54:     	add.2d	v6, v6, v17
100845e58:     	add.2d	v7, v7, v17
100845e5c:     	add.2d	v19, v19, v17
100845e60:     	add.2d	v4, v4, v17
100845e64:     	add.2d	v3, v3, v17
100845e68:     	add.2d	v2, v2, v17
100845e6c:     	add.2d	v1, v1, v17
100845e70:     	add.2d	v0, v0, v17
100845e74:     	subs	x14, x14, #0x10
100845e78:     	b.ne	0x100845db8 <_js_json_stringify_full+0x2f8>
100845e7c:     	orr.16b	v0, v16, v23
100845e80:     	orr.16b	v1, v20, v24
100845e84:     	orr.16b	v0, v0, v1
100845e88:     	orr.16b	v1, v5, v21
100845e8c:     	orr.16b	v2, v18, v22
100845e90:     	orr.16b	v1, v1, v2
100845e94:     	orr.16b	v0, v0, v1
100845e98:     	mov	d1, v0[1]
100845e9c:     	orr.8b	v0, v0, v1
100845ea0:     	fmov	x13, d0
100845ea4:     	cmp	x8, x11
100845ea8:     	b.eq	0x100845f74 <_js_json_stringify_full+0x4b4>
100845eac:     	cbz	x12, 0x100845f54 <_js_json_stringify_full+0x494>
100845eb0:     	mov	x14, x11
100845eb4:     	and	x11, x8, #0x1c
100845eb8:     	add	x15, sp, #0x70
100845ebc:     	add	x9, x15, x11
100845ec0:     	fmov	d0, x13
100845ec4:     	movi.2d	v1, #0000000000000000
100845ec8:     	dup.2d	v3, x14
100845ecc:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
100845ed0:     	ldr	q2, [x12, #0xa40]
100845ed4:     	orr.16b	v2, v3, v2
100845ed8:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3363a>
100845edc:     	ldr	q4, [x12, #0x940]
100845ee0:     	orr.16b	v3, v3, v4
100845ee4:     	sub	x12, x14, x11
100845ee8:     	add	x13, x15, x14
100845eec:     	movi.2d	v4, #0x000000000000ff
100845ef0:     	mov	w14, #0x4               ; =4
100845ef4:     	dup.2d	v5, x14
100845ef8:     	ldr	s6, [x13], #0x4
100845efc:     	ushll.8h	v6, v6, #0x0
100845f00:     	ushll.4s	v6, v6, #0x0
100845f04:     	ushll2.2d	v7, v6, #0x0
100845f08:     	and.16b	v7, v7, v4
100845f0c:     	ushll.2d	v6, v6, #0x0
100845f10:     	and.16b	v6, v6, v4
100845f14:     	shl.2d	v16, v2, #0x3
100845f18:     	shl.2d	v17, v3, #0x3
100845f1c:     	ushl.2d	v6, v6, v17
100845f20:     	ushl.2d	v7, v7, v16
100845f24:     	orr.16b	v1, v7, v1
100845f28:     	orr.16b	v0, v6, v0
100845f2c:     	add.2d	v2, v2, v5
100845f30:     	add.2d	v3, v3, v5
100845f34:     	adds	x12, x12, #0x4
100845f38:     	b.ne	0x100845ef8 <_js_json_stringify_full+0x438>
100845f3c:     	orr.16b	v0, v0, v1
100845f40:     	mov	d1, v0[1]
100845f44:     	orr.8b	v0, v0, v1
100845f48:     	fmov	x13, d0
100845f4c:     	cmp	x8, x11
100845f50:     	b.eq	0x100845f74 <_js_json_stringify_full+0x4b4>
100845f54:     	add	x10, x10, x8
100845f58:     	lsl	x11, x11, #3
100845f5c:     	ldrb	w12, [x9], #0x1
100845f60:     	lsl	x12, x12, x11
100845f64:     	orr	x13, x12, x13
100845f68:     	add	x11, x11, #0x8
100845f6c:     	cmp	x9, x10
100845f70:     	b.ne	0x100845f5c <_js_json_stringify_full+0x49c>
100845f74:     	orr	x8, x13, x8, lsl #40
100845f78:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845f7c:     	orr	x21, x8, x9
100845f80:     	b	0x100846f94 <_js_json_stringify_full+0x14d4>
100845f84:     	cmp	w16, #0x8
100845f88:     	b.eq	0x100845fcc <_js_json_stringify_full+0x50c>
100845f8c:     	cmp	w16, #0x9
100845f90:     	b.eq	0x100845fdc <_js_json_stringify_full+0x51c>
100845f94:     	cmp	w16, #0xa
100845f98:     	b.ne	0x100845fb4 <_js_json_stringify_full+0x4f4>
100845f9c:     	mov	w15, #0x6e              ; =110
100845fa0:     	b	0x100845fe0 <_js_json_stringify_full+0x520>
100845fa4:     	cmp	w16, #0x22
100845fa8:     	b.eq	0x100845fe0 <_js_json_stringify_full+0x520>
100845fac:     	cmp	w16, #0x5c
100845fb0:     	b.eq	0x100845fe0 <_js_json_stringify_full+0x520>
100845fb4:     	cmp	w15, #0x20
100845fb8:     	b.lt	0x100845fe4 <_js_json_stringify_full+0x524>
100845fbc:     	add	x13, sp, #0x70
100845fc0:     	strb	w15, [x13, x12]
100845fc4:     	add	x12, x12, #0x1
100845fc8:     	b	0x100846560 <_js_json_stringify_full+0xaa0>
100845fcc:     	mov	w15, #0x62              ; =98
100845fd0:     	b	0x100845fe0 <_js_json_stringify_full+0x520>
100845fd4:     	mov	w15, #0x66              ; =102
100845fd8:     	b	0x100845fe0 <_js_json_stringify_full+0x520>
100845fdc:     	mov	w15, #0x74              ; =116
100845fe0:     	tbz	w14, #0x0, 0x10084654c <_js_json_stringify_full+0xa8c>
100845fe4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100845fe8:     	cmp	x8, x9
100845fec:     	b.eq	0x100846034 <_js_json_stringify_full+0x574>
100845ff0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845ff4:     	cmp	x8, x9
100845ff8:     	b.ne	0x1008460a8 <_js_json_stringify_full+0x5e8>
100845ffc:     	and	x8, x19, #0xffffffffffff
100846000:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100846004:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100846008:     	movk	x10, #0xffef, lsl #16
10084600c:     	cmp	x9, x10
100846010:     	b.hi	0x1008460a8 <_js_json_stringify_full+0x5e8>
100846014:     	ldr	w8, [x8, #0x4]
100846018:     	cmp	w8, #0x40
10084601c:     	b.lo	0x1008460a8 <_js_json_stringify_full+0x5e8>
100846020:     	and	x0, x19, #0xffffffffffff
100846024:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846028:     	cmp	x0, #0x1
10084602c:     	b.ne	0x1008460a8 <_js_json_stringify_full+0x5e8>
100846030:     	b	0x1008461e8 <_js_json_stringify_full+0x728>
100846034:     	and	x24, x19, #0xffffffffffff
100846038:     	and	x0, x19, #0xffffffffffff
10084603c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846040:     	cbz	x0, 0x100846074 <_js_json_stringify_full+0x5b4>
100846044:     	ldrb	w8, [x0]
100846048:     	cmp	w8, #0x2
10084604c:     	b.ne	0x100846074 <_js_json_stringify_full+0x5b4>
100846050:     	ldrsb	w8, [x0, #0x1]
100846054:     	tbnz	w8, #0x1f, 0x100846074 <_js_json_stringify_full+0x5b4>
100846058:     	ldrh	w8, [x0, #0x2]
10084605c:     	tbnz	w8, #0xb, 0x100846074 <_js_json_stringify_full+0x5b4>
100846060:     	ldr	w8, [x0, #0x4]
100846064:     	cmp	w8, #0x18
100846068:     	b.lo	0x100846074 <_js_json_stringify_full+0x5b4>
10084606c:     	ldr	w8, [x24]
100846070:     	cbz	w8, 0x1008470f0 <_js_json_stringify_full+0x1630>
100846074:     	and	x0, x19, #0xffffffffffff
100846078:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084607c:     	cbz	x0, 0x1008460a8 <_js_json_stringify_full+0x5e8>
100846080:     	ldrb	w8, [x0]
100846084:     	cmp	w8, #0x2
100846088:     	b.ne	0x1008460a8 <_js_json_stringify_full+0x5e8>
10084608c:     	ldrh	w8, [x0, #0x2]
100846090:     	tbnz	w8, #0xb, 0x1008460a8 <_js_json_stringify_full+0x5e8>
100846094:     	ldr	w8, [x0, #0x4]
100846098:     	cmp	w8, #0x18
10084609c:     	b.lo	0x1008460a8 <_js_json_stringify_full+0x5e8>
1008460a0:     	ldr	w8, [x24]
1008460a4:     	cbz	w8, 0x100847094 <_js_json_stringify_full+0x15d4>
1008460a8:     	mov	w21, #0x1               ; =1
1008460ac:     	cmp	x19, x26
1008460b0:     	b.eq	0x100846f8c <_js_json_stringify_full+0x14cc>
1008460b4:     	and	x22, x19, #0xffff000000000000
1008460b8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008460bc:     	cmp	x22, x8
1008460c0:     	b.ne	0x1008460f8 <_js_json_stringify_full+0x638>
1008460c4:     	and	x8, x19, #0xffffffffffff
1008460c8:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008460cc:     	b.lo	0x1008460e4 <_js_json_stringify_full+0x624>
1008460d0:     	ldr	w8, [x8, #0xc]
1008460d4:     	mov	w9, #0x4f53             ; =20307
1008460d8:     	movk	w9, #0x434c, lsl #16
1008460dc:     	cmp	w8, w9
1008460e0:     	b.eq	0x100846f8c <_js_json_stringify_full+0x14cc>
1008460e4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008460e8:     	cmp	x22, x8
1008460ec:     	b.ne	0x100846124 <_js_json_stringify_full+0x664>
1008460f0:     	and	x0, x19, #0xffffffffffff
1008460f4:     	b	0x10084614c <_js_json_stringify_full+0x68c>
1008460f8:     	lsr	x8, x19, #52
1008460fc:     	cbnz	x8, 0x1008461d4 <_js_json_stringify_full+0x714>
100846100:     	and	x8, x19, #0x7
100846104:     	cbz	x19, 0x100846130 <_js_json_stringify_full+0x670>
100846108:     	cbnz	x8, 0x100846130 <_js_json_stringify_full+0x670>
10084610c:     	mov	x0, x19
100846110:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846114:     	mov	x8, x19
100846118:     	tbnz	w0, #0x0, 0x1008460c8 <_js_json_stringify_full+0x608>
10084611c:     	mov	x8, #0x0                ; =0
100846120:     	b	0x100846130 <_js_json_stringify_full+0x670>
100846124:     	lsr	x8, x19, #52
100846128:     	cbnz	x8, 0x1008461d4 <_js_json_stringify_full+0x714>
10084612c:     	and	x8, x19, #0x7
100846130:     	cbz	x19, 0x1008461d4 <_js_json_stringify_full+0x714>
100846134:     	cbnz	x8, 0x1008461d4 <_js_json_stringify_full+0x714>
100846138:     	mov	x0, x19
10084613c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846140:     	mov	x8, x0
100846144:     	mov	x0, x19
100846148:     	tbz	w8, #0x0, 0x1008461d4 <_js_json_stringify_full+0x714>
10084614c:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846150:     	b.lo	0x1008461d4 <_js_json_stringify_full+0x714>
100846154:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100846158:     	add	x8, x8, #0xfb0
10084615c:     	ldaprb	w8, [x8]
100846160:     	cbz	w8, 0x1008461d4 <_js_json_stringify_full+0x714>
100846164:     	lsr	x8, x0, #3
100846168:     	mov	x9, #0x7c15             ; =31765
10084616c:     	movk	x9, #0x7f4a, lsl #16
100846170:     	movk	x9, #0x79b9, lsl #32
100846174:     	movk	x9, #0x9e37, lsl #48
100846178:     	mul	x8, x8, x9
10084617c:     	lsr	x10, x8, #54
100846180:     	lsr	x11, x8, #60
100846184:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100846188:     	add	x9, x9, #0xf30
10084618c:     	add	x11, x9, x11, lsl #3
100846190:     	ldapr	x11, [x11]
100846194:     	lsr	x10, x11, x10
100846198:     	tbz	w10, #0x0, 0x1008461d4 <_js_json_stringify_full+0x714>
10084619c:     	lsr	x10, x8, #44
1008461a0:     	ubfx	x11, x8, #50, #4
1008461a4:     	add	x11, x9, x11, lsl #3
1008461a8:     	ldapr	x11, [x11]
1008461ac:     	lsr	x10, x11, x10
1008461b0:     	tbz	w10, #0x0, 0x1008461d4 <_js_json_stringify_full+0x714>
1008461b4:     	lsr	x10, x8, #34
1008461b8:     	ubfx	x8, x8, #40, #4
1008461bc:     	add	x8, x9, x8, lsl #3
1008461c0:     	ldapr	x8, [x8]
1008461c4:     	lsr	x8, x8, x10
1008461c8:     	tbz	w8, #0x0, 0x1008461d4 <_js_json_stringify_full+0x714>
1008461cc:     	bl	0x10034ca2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
1008461d0:     	tbnz	w0, #0x0, 0x100846f8c <_js_json_stringify_full+0x14cc>
1008461d4:     	tbz	w21, #0x0, 0x1008461f4 <_js_json_stringify_full+0x734>
1008461d8:     	mov.16b	v0, v8
1008461dc:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008461e0:     	cmp	x0, #0x1
1008461e4:     	b.ne	0x1008461f4 <_js_json_stringify_full+0x734>
1008461e8:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
1008461ec:     	bfxil	x21, x1, #0, #48
1008461f0:     	b	0x100846f94 <_js_json_stringify_full+0x14d4>
1008461f4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008461f8:     	cmp	x22, x8
1008461fc:     	b.ne	0x10084624c <_js_json_stringify_full+0x78c>
100846200:     	ands	x21, x19, #0xffffffffffff
100846204:     	b.eq	0x10084624c <_js_json_stringify_full+0x78c>
100846208:     	mov	x0, x21
10084620c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846210:     	cbz	w0, 0x10084624c <_js_json_stringify_full+0x78c>
100846214:     	ldurb	w8, [x21, #-0x8]
100846218:     	cmp	w8, #0x9
10084621c:     	b.ne	0x10084624c <_js_json_stringify_full+0x78c>
100846220:     	ldr	w8, [x21, #0x4]
100846224:     	mov	w9, #0x5841             ; =22593
100846228:     	movk	w9, #0x4c5a, lsl #16
10084622c:     	cmp	w8, w9
100846230:     	b.ne	0x10084624c <_js_json_stringify_full+0x78c>
100846234:     	mov	x0, x21
100846238:     	bl	0x10068832c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084623c:     	cbz	x0, 0x10084624c <_js_json_stringify_full+0x78c>
100846240:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100846244:     	bfxil	x19, x0, #0, #48
100846248:     	fmov	d8, x19
10084624c:     	mov	w8, #0x7ffd             ; =32765
100846250:     	cmp	x8, x23, lsr #48
100846254:     	b.ne	0x100846268 <_js_json_stringify_full+0x7a8>
100846258:     	and	x1, x23, #0xffffffffffff
10084625c:     	cmp	x1, #0x100, lsl #12     ; =0x100000
100846260:     	b.hs	0x10084627c <_js_json_stringify_full+0x7bc>
100846264:     	b	0x1008462d0 <_js_json_stringify_full+0x810>
100846268:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084626c:     	mov	x9, #0xfffffff00000     ; =281474975662080
100846270:     	mov	x1, x23
100846274:     	cmp	x8, x9
100846278:     	b.hs	0x1008462d0 <_js_json_stringify_full+0x810>
10084627c:     	lsr	x8, x1, #47
100846280:     	cbnz	x8, 0x1008462d0 <_js_json_stringify_full+0x810>
100846284:     	add	x0, sp, #0x70
100846288:     	bl	0x10076e16c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084628c:     	ldr	w8, [sp, #0x70]
100846290:     	tbz	w8, #0x0, 0x1008462d0 <_js_json_stringify_full+0x810>
100846294:     	ldr	w8, [sp, #0x78]
100846298:     	mov	w9, #-0xff30            ; =-65328
10084629c:     	cmp	w8, w9
1008462a0:     	b.eq	0x1008462c4 <_js_json_stringify_full+0x804>
1008462a4:     	mov	w9, #-0xff2f            ; =-65327
1008462a8:     	cmp	w8, w9
1008462ac:     	b.ne	0x1008462d0 <_js_json_stringify_full+0x810>
1008462b0:     	mov.16b	v0, v9
1008462b4:     	bl	0x1008483fc <_js_jsvalue_to_string>
1008462b8:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1008462bc:     	bfxil	x23, x0, #0, #48
1008462c0:     	b	0x1008462d0 <_js_json_stringify_full+0x810>
1008462c4:     	mov.16b	v0, v9
1008462c8:     	bl	0x10086f9a0 <_js_number_coerce>
1008462cc:     	fmov	x23, d0
1008462d0:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008462d4:     	add	x8, x23, x8
1008462d8:     	cmp	x8, #0x3
1008462dc:     	b.hs	0x1008462f4 <_js_json_stringify_full+0x834>
1008462e0:     	mov	x21, #0x0               ; =0
1008462e4:     	mov	w8, #0x1                ; =1
1008462e8:     	stp	xzr, x8, [sp]
1008462ec:     	str	xzr, [sp, #0x10]
1008462f0:     	b	0x1008465a8 <_js_json_stringify_full+0xae8>
1008462f4:     	and	x8, x23, #0xffff000000000000
1008462f8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008462fc:     	cmp	x8, x9
100846300:     	b.eq	0x100846324 <_js_json_stringify_full+0x864>
100846304:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846308:     	cmp	x8, x9
10084630c:     	b.ne	0x1008463b0 <_js_json_stringify_full+0x8f0>
100846310:     	and	x8, x23, #0xffffffffffff
100846314:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846318:     	b.hs	0x1008463f8 <_js_json_stringify_full+0x938>
10084631c:     	mov	x9, #0x0                ; =0
100846320:     	b	0x100846400 <_js_json_stringify_full+0x940>
100846324:     	strb	wzr, [sp, #0x3c]
100846328:     	str	wzr, [sp, #0x38]
10084632c:     	ubfx	x1, x23, #40, #8
100846330:     	cbz	x1, 0x100846380 <_js_json_stringify_full+0x8c0>
100846334:     	strb	w23, [sp, #0x38]
100846338:     	cmp	x1, #0x1
10084633c:     	b.eq	0x100846380 <_js_json_stringify_full+0x8c0>
100846340:     	lsr	x8, x23, #8
100846344:     	strb	w8, [sp, #0x39]
100846348:     	cmp	x1, #0x2
10084634c:     	b.eq	0x100846380 <_js_json_stringify_full+0x8c0>
100846350:     	lsr	x8, x23, #16
100846354:     	strb	w8, [sp, #0x3a]
100846358:     	cmp	x1, #0x3
10084635c:     	b.eq	0x100846380 <_js_json_stringify_full+0x8c0>
100846360:     	lsr	x8, x23, #24
100846364:     	strb	w8, [sp, #0x3b]
100846368:     	cmp	x1, #0x4
10084636c:     	b.eq	0x100846380 <_js_json_stringify_full+0x8c0>
100846370:     	lsr	x8, x23, #32
100846374:     	strb	w8, [sp, #0x3c]
100846378:     	cmp	x1, #0x5
10084637c:     	b.ne	0x100847780 <_js_json_stringify_full+0x1cc0>
100846380:     	add	x8, sp, #0x70
100846384:     	add	x0, sp, #0x38
100846388:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084638c:     	ldr	w8, [sp, #0x70]
100846390:     	ldp	x9, x21, [sp, #0x78]
100846394:     	cmp	w8, #0x0
100846398:     	csinc	x22, x9, xzr, eq
10084639c:     	csel	x24, xzr, x21, ne
1008463a0:     	tbz	x24, #0x3f, 0x1008464e0 <_js_json_stringify_full+0xa20>
1008463a4:     	mov	x0, #0x0                ; =0
1008463a8:     	mov	x1, x21
1008463ac:     	bl	0x100b12380 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008463b0:     	add	x8, x26, #0x3
1008463b4:     	cmp	x23, x8
1008463b8:     	b.eq	0x1008462e0 <_js_json_stringify_full+0x820>
1008463bc:     	fmov	d0, x23
1008463c0:     	fcvtzu	x8, d0
1008463c4:     	mov	w9, #0xa                ; =10
1008463c8:     	cmp	x8, #0xa
1008463cc:     	csel	x3, x8, x9, lo
1008463d0:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x1a74>
1008463d4:     	add	x1, x1, #0x71c
1008463d8:     	add	x0, sp, #0x70
1008463dc:     	mov	w2, #0x1                ; =1
1008463e0:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
1008463e4:     	ldr	x21, [sp, #0x80]
1008463e8:     	str	x21, [sp, #0x10]
1008463ec:     	ldr	q0, [sp, #0x70]
1008463f0:     	str	q0, [sp]
1008463f4:     	b	0x1008465a8 <_js_json_stringify_full+0xae8>
1008463f8:     	ldr	w21, [x8, #0x4]
1008463fc:     	add	x9, x8, #0x14
100846400:     	mov	x14, #0x0               ; =0
100846404:     	mov	x8, #0x0                ; =0
100846408:     	cmp	x9, #0x0
10084640c:     	csel	x23, xzr, x21, eq
100846410:     	csinc	x22, x9, xzr, ne
100846414:     	add	x9, x22, x23
100846418:     	mov	w10, #0x1               ; =1
10084641c:     	mov	x11, x22
100846420:     	b	0x100846450 <_js_json_stringify_full+0x990>
100846424:     	add	x12, x11, #0x2
100846428:     	bfi	w15, w13, #6, #5
10084642c:     	mov	x13, x15
100846430:     	sub	x11, x24, x11
100846434:     	add	x14, x11, x12
100846438:     	cmp	w13, #0x10, lsl #12     ; =0x10000
10084643c:     	cinc	x11, x10, hs
100846440:     	add	x8, x11, x8
100846444:     	mov	x11, x12
100846448:     	cmp	x8, #0xa
10084644c:     	b.hi	0x100846508 <_js_json_stringify_full+0xa48>
100846450:     	cmp	x11, x9
100846454:     	b.eq	0x1008464b8 <_js_json_stringify_full+0x9f8>
100846458:     	mov	x24, x14
10084645c:     	mov	x12, x11
100846460:     	ldrsb	w14, [x12], #0x1
100846464:     	and	w13, w14, #0xff
100846468:     	tbz	w14, #0x1f, 0x100846430 <_js_json_stringify_full+0x970>
10084646c:     	ldrb	w12, [x11, #0x1]
100846470:     	and	w15, w12, #0x3f
100846474:     	cmp	w13, #0xe0
100846478:     	b.lo	0x100846424 <_js_json_stringify_full+0x964>
10084647c:     	and	w14, w13, #0x1f
100846480:     	ldrb	w12, [x11, #0x2]
100846484:     	and	w12, w12, #0x3f
100846488:     	orr	w15, w12, w15, lsl #6
10084648c:     	cmp	w13, #0xf0
100846490:     	b.lo	0x1008464ac <_js_json_stringify_full+0x9ec>
100846494:     	add	x12, x11, #0x4
100846498:     	ldrb	w13, [x11, #0x3]
10084649c:     	and	w13, w13, #0x3f
1008464a0:     	orr	w13, w13, w15, lsl #6
1008464a4:     	bfi	w13, w14, #18, #3
1008464a8:     	b	0x100846430 <_js_json_stringify_full+0x970>
1008464ac:     	add	x12, x11, #0x3
1008464b0:     	orr	w13, w15, w14, lsl #12
1008464b4:     	b	0x100846430 <_js_json_stringify_full+0x970>
1008464b8:     	cbz	x23, 0x10084653c <_js_json_stringify_full+0xa7c>
1008464bc:     	mov	x0, x23
1008464c0:     	mov	w1, #0x1                ; =1
1008464c4:     	bl	0x100b5f248 <_mi_malloc_aligned>
1008464c8:     	cbz	x0, 0x100847768 <_js_json_stringify_full+0x1ca8>
1008464cc:     	mov	x25, x0
1008464d0:     	mov	x1, x22
1008464d4:     	mov	x2, x23
1008464d8:     	bl	0x100b61e6c <_writev+0x100b61e6c>
1008464dc:     	b	0x100846544 <_js_json_stringify_full+0xa84>
1008464e0:     	cbz	x24, 0x100846598 <_js_json_stringify_full+0xad8>
1008464e4:     	mov	x0, x24
1008464e8:     	mov	w1, #0x1                ; =1
1008464ec:     	bl	0x100b5f248 <_mi_malloc_aligned>
1008464f0:     	cbz	x0, 0x100847774 <_js_json_stringify_full+0x1cb4>
1008464f4:     	mov	x23, x0
1008464f8:     	mov	x1, x22
1008464fc:     	mov	x2, x24
100846500:     	bl	0x100b61e6c <_writev+0x100b61e6c>
100846504:     	b	0x1008465a0 <_js_json_stringify_full+0xae0>
100846508:     	cbz	x24, 0x10084653c <_js_json_stringify_full+0xa7c>
10084650c:     	cmp	x24, x23
100846510:     	b.hs	0x100846fe8 <_js_json_stringify_full+0x1528>
100846514:     	ldrsb	w8, [x22, x24]
100846518:     	cmn	w8, #0x40
10084651c:     	b.ge	0x100846fec <_js_json_stringify_full+0x152c>
100846520:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846524:     	add	x4, x4, #0x270
100846528:     	mov	x0, x22
10084652c:     	mov	x1, x23
100846530:     	mov	x2, #0x0                ; =0
100846534:     	mov	x3, x24
100846538:     	bl	0x100b126f8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
10084653c:     	mov	x21, #0x0               ; =0
100846540:     	mov	w25, #0x1               ; =1
100846544:     	stp	x21, x25, [sp]
100846548:     	b	0x1008465a4 <_js_json_stringify_full+0xae4>
10084654c:     	add	x14, sp, #0x70
100846550:     	mov	w16, #0x5c              ; =92
100846554:     	strb	w16, [x14, x12]
100846558:     	add	x12, x12, #0x2
10084655c:     	strb	w15, [x13, #0x1]
100846560:     	cmp	w10, #0x2
100846564:     	b.eq	0x100845cd4 <_js_json_stringify_full+0x214>
100846568:     	ldrb	w11, [x11, #0x2]
10084656c:     	sxtb	w10, w11
100846570:     	cmp	w11, #0xb
100846574:     	b.le	0x100847074 <_js_json_stringify_full+0x15b4>
100846578:     	cmp	w11, #0x21
10084657c:     	b.gt	0x1008470c0 <_js_json_stringify_full+0x1600>
100846580:     	cmp	w11, #0xc
100846584:     	b.eq	0x10084714c <_js_json_stringify_full+0x168c>
100846588:     	cmp	w11, #0xd
10084658c:     	b.ne	0x1008470d0 <_js_json_stringify_full+0x1610>
100846590:     	mov	w10, #0x72              ; =114
100846594:     	b	0x100847158 <_js_json_stringify_full+0x1698>
100846598:     	mov	x21, #0x0               ; =0
10084659c:     	mov	w23, #0x1               ; =1
1008465a0:     	stp	x21, x23, [sp]
1008465a4:     	str	x21, [sp, #0x10]
1008465a8:     	cmp	x27, #0x2
1008465ac:     	b.lo	0x1008466ec <_js_json_stringify_full+0xc2c>
1008465b0:     	and	x24, x20, #0xffff000000000000
1008465b4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008465b8:     	cmp	x24, x8
1008465bc:     	b.ne	0x1008466c8 <_js_json_stringify_full+0xc08>
1008465c0:     	and	x22, x20, #0xffffffffffff
1008465c4:     	cmp	x22, #0x100, lsl #12    ; =0x100000
1008465c8:     	b.lo	0x1008466ec <_js_json_stringify_full+0xc2c>
1008465cc:     	mov	x0, x22
1008465d0:     	bl	0x10050a640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
1008465d4:     	tbnz	w0, #0x0, 0x1008466ec <_js_json_stringify_full+0xc2c>
1008465d8:     	lsr	x8, x22, #51
1008465dc:     	cmp	x8, #0xfff
1008465e0:     	b.lo	0x1008465f8 <_js_json_stringify_full+0xb38>
1008465e4:     	mov	w8, #0x7ffc             ; =32764
1008465e8:     	cmp	x8, x22, lsr #48
1008465ec:     	b.eq	0x1008466ec <_js_json_stringify_full+0xc2c>
1008465f0:     	ands	x22, x22, #0xffffffffffff
1008465f4:     	b.eq	0x1008466ec <_js_json_stringify_full+0xc2c>
1008465f8:     	and	x8, x22, #0xfffffffffff00000
1008465fc:     	lsr	x9, x22, #47
100846600:     	cmp	x9, #0x0
100846604:     	ccmp	x8, #0x0, #0x4, eq
100846608:     	b.eq	0x1008466ec <_js_json_stringify_full+0xc2c>
10084660c:     	tst	x22, #0x3
100846610:     	ccmp	x22, #0x7, #0x0, eq
100846614:     	b.ls	0x100847388 <_js_json_stringify_full+0x18c8>
100846618:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084661c:     	ldr	x8, [x8, #0x48]
100846620:     	cmn	x8, #0x1
100846624:     	b.eq	0x1008472d8 <_js_json_stringify_full+0x1818>
100846628:     	mrs	x9, TPIDRRO_EL0
10084662c:     	and	x9, x9, #0xfffffffffffffff8
100846630:     	ldr	x0, [x9, x8, lsl #3]
100846634:     	cbz	x0, 0x1008472d8 <_js_json_stringify_full+0x1818>
100846638:     	lsr	x1, x22, #20
10084663c:     	ldr	x8, [x0, #0x10]
100846640:     	ldrb	w9, [x8]
100846644:     	cmp	w9, #0x2
100846648:     	b.ne	0x1008472f0 <_js_json_stringify_full+0x1830>
10084664c:     	ldrb	w9, [x8, #0x88]
100846650:     	tbz	w9, #0x0, 0x100846670 <_js_json_stringify_full+0xbb0>
100846654:     	ldr	x9, [x8, #0x80]
100846658:     	cmp	x9, x1
10084665c:     	b.ne	0x100846670 <_js_json_stringify_full+0xbb0>
100846660:     	ldp	x9, x10, [x8, #0x60]
100846664:     	cmp	x9, x22
100846668:     	ccmp	x10, x22, #0x0, ls
10084666c:     	b.hi	0x1008472d0 <_js_json_stringify_full+0x1810>
100846670:     	ldrb	w9, [x8, #0xb8]
100846674:     	cbz	w9, 0x100846694 <_js_json_stringify_full+0xbd4>
100846678:     	ldr	x9, [x8, #0xb0]
10084667c:     	cmp	x9, x1
100846680:     	b.ne	0x100846694 <_js_json_stringify_full+0xbd4>
100846684:     	ldp	x9, x10, [x8, #0x90]
100846688:     	cmp	x9, x22
10084668c:     	ccmp	x10, x22, #0x0, ls
100846690:     	b.hi	0x100847558 <_js_json_stringify_full+0x1a98>
100846694:     	ldrb	w9, [x8, #0xe8]
100846698:     	cbz	w9, 0x100847110 <_js_json_stringify_full+0x1650>
10084669c:     	ldr	x9, [x8, #0xe0]
1008466a0:     	cmp	x9, x1
1008466a4:     	b.ne	0x100847110 <_js_json_stringify_full+0x1650>
1008466a8:     	ldr	x9, [x8, #0xc0]
1008466ac:     	cmp	x9, x22
1008466b0:     	b.hi	0x100847110 <_js_json_stringify_full+0x1650>
1008466b4:     	ldr	x9, [x8, #0xc8]
1008466b8:     	cmp	x9, x22
1008466bc:     	b.ls	0x100847110 <_js_json_stringify_full+0x1650>
1008466c0:     	add	x9, x8, #0xc0
1008466c4:     	b	0x10084755c <_js_json_stringify_full+0x1a9c>
1008466c8:     	lsr	x8, x20, #52
1008466cc:     	cbnz	x8, 0x1008466ec <_js_json_stringify_full+0xc2c>
1008466d0:     	cbz	x20, 0x1008466ec <_js_json_stringify_full+0xc2c>
1008466d4:     	and	x8, x20, #0x7
1008466d8:     	cbnz	x8, 0x1008466ec <_js_json_stringify_full+0xc2c>
1008466dc:     	mov	x0, x20
1008466e0:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008466e4:     	mov	x22, x20
1008466e8:     	cbnz	w0, 0x1008465c4 <_js_json_stringify_full+0xb04>
1008466ec:     	mov	x24, #-0x1              ; =-1
1008466f0:     	str	x24, [sp, #0x20]
1008466f4:     	mov	w23, #0x1               ; =1
1008466f8:     	cmp	x27, #0x1
1008466fc:     	cset	w8, hi
100846700:     	tst	w8, w23
100846704:     	b.eq	0x100846778 <_js_json_stringify_full+0xcb8>
100846708:     	and	x22, x20, #0xffff000000000000
10084670c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846710:     	cmp	x22, x8
100846714:     	b.ne	0x100846750 <_js_json_stringify_full+0xc90>
100846718:     	and	x8, x20, #0xffffffffffff
10084671c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846720:     	b.lo	0x100846778 <_js_json_stringify_full+0xcb8>
100846724:     	ldr	w8, [x8, #0xc]
100846728:     	mov	w9, #0x4f53             ; =20307
10084672c:     	movk	w9, #0x434c, lsl #16
100846730:     	cmp	w8, w9
100846734:     	b.ne	0x100846778 <_js_json_stringify_full+0xcb8>
100846738:     	and	x8, x20, #0xffffffffffff
10084673c:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846740:     	cmp	x22, x9
100846744:     	csel	x28, x8, x20, eq
100846748:     	mov	w27, #0x1               ; =1
10084674c:     	b	0x10084677c <_js_json_stringify_full+0xcbc>
100846750:     	lsr	x8, x20, #52
100846754:     	cbnz	x8, 0x100846778 <_js_json_stringify_full+0xcb8>
100846758:     	mov	w27, #0x0               ; =0
10084675c:     	cbz	x20, 0x10084677c <_js_json_stringify_full+0xcbc>
100846760:     	and	x8, x20, #0x7
100846764:     	cbnz	x8, 0x10084677c <_js_json_stringify_full+0xcbc>
100846768:     	mov	x0, x20
10084676c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846770:     	mov	x8, x20
100846774:     	tbnz	w0, #0x0, 0x10084671c <_js_json_stringify_full+0xc5c>
100846778:     	mov	w27, #0x0               ; =0
10084677c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846780:     	add	x0, x0, #0xd78
100846784:     	ldr	x8, [x0]
100846788:     	blr	x8
10084678c:     	mov	x20, x0
100846790:     	ldr	w25, [x0]
100846794:     	add	w8, w25, #0x1
100846798:     	str	w8, [x0]
10084679c:     	cbz	w25, 0x10084680c <_js_json_stringify_full+0xd4c>
1008467a0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008467a4:     	add	x0, x0, #0xd00
1008467a8:     	ldr	x8, [x0]
1008467ac:     	blr	x8
1008467b0:     	ldrb	w8, [x0, #0x20]
1008467b4:     	cmp	w8, #0x1
1008467b8:     	b.ne	0x1008475c8 <_js_json_stringify_full+0x1b08>
1008467bc:     	ldr	x8, [x0]
1008467c0:     	cbnz	x8, 0x1008475d4 <_js_json_stringify_full+0x1b14>
1008467c4:     	mov	x8, #-0x1               ; =-1
1008467c8:     	str	x8, [x0]
1008467cc:     	ldr	x22, [x0, #0x18]
1008467d0:     	ldr	x8, [x0, #0x8]
1008467d4:     	cmp	x22, x8
1008467d8:     	b.eq	0x100846fbc <_js_json_stringify_full+0x14fc>
1008467dc:     	ldr	x8, [x0, #0x10]
1008467e0:     	mov	w9, #0x18               ; =24
1008467e4:     	madd	x8, x22, x9, x8
1008467e8:     	mov	w9, #0x8                ; =8
1008467ec:     	stp	xzr, x9, [x8]
1008467f0:     	str	xzr, [x8, #0x10]
1008467f4:     	add	x8, x22, #0x1
1008467f8:     	str	x8, [x0, #0x18]
1008467fc:     	ldr	x8, [x0]
100846800:     	add	x8, x8, #0x1
100846804:     	str	x8, [x0]
100846808:     	b	0x100846874 <_js_json_stringify_full+0xdb4>
10084680c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846810:     	add	x0, x0, #0xdc0
100846814:     	ldr	x8, [x0]
100846818:     	blr	x8
10084681c:     	strb	wzr, [x0]
100846820:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846824:     	add	x0, x0, #0xdf0
100846828:     	ldr	x8, [x0]
10084682c:     	blr	x8
100846830:     	strb	wzr, [x0]
100846834:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100846838:     	ldr	w22, [x8, #0x5a8]
10084683c:     	cmp	w22, #0x300
100846840:     	b.hs	0x10084700c <_js_json_stringify_full+0x154c>
100846844:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100846848:     	ldr	x8, [x8, #0x48]
10084684c:     	cmn	x8, #0x1
100846850:     	b.eq	0x100846ffc <_js_json_stringify_full+0x153c>
100846854:     	mrs	x9, TPIDRRO_EL0
100846858:     	and	x9, x9, #0xfffffffffffffff8
10084685c:     	ldr	x0, [x9, x8, lsl #3]
100846860:     	cbz	x0, 0x100846ffc <_js_json_stringify_full+0x153c>
100846864:     	add	x8, x0, x22, lsl #3
100846868:     	ldr	x0, [x8, #0x1e8]
10084686c:     	cbz	x0, 0x10084700c <_js_json_stringify_full+0x154c>
100846870:     	str	xzr, [x0]
100846874:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846878:     	add	x0, x0, #0xd30
10084687c:     	ldr	x8, [x0]
100846880:     	blr	x8
100846884:     	mov	x22, x0
100846888:     	ldrb	w8, [x0, #0x18]
10084688c:     	cmp	w8, #0x1
100846890:     	b.ne	0x10084757c <_js_json_stringify_full+0x1abc>
100846894:     	ldr	x8, [x0]
100846898:     	mov	x9, #-0x1               ; =-1
10084689c:     	str	x9, [x0]
1008468a0:     	cmn	x8, #0x2
1008468a4:     	b.eq	0x100847714 <_js_json_stringify_full+0x1c54>
1008468a8:     	cmn	x8, #0x1
1008468ac:     	b.eq	0x100846980 <_js_json_stringify_full+0xec0>
1008468b0:     	add	x9, sp, #0x38
1008468b4:     	ldur	q0, [x0, #0x8]
1008468b8:     	stur	q0, [x9, #0x8]
1008468bc:     	str	x8, [sp, #0x38]
1008468c0:     	tbz	w23, #0x0, 0x100846994 <_js_json_stringify_full+0xed4>
1008468c4:     	tbz	w27, #0x0, 0x100846a7c <_js_json_stringify_full+0xfbc>
1008468c8:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1008468cc:     	str	x0, [sp, #0x50]
1008468d0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008468d4:     	stp	x28, x8, [sp, #0x78]
1008468d8:     	mov	w8, #0x1                ; =1
1008468dc:     	str	x8, [sp, #0x70]
1008468e0:     	add	x0, sp, #0x70
1008468e4:     	bl	0x10028b520 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
1008468e8:     	mov	x21, x0
1008468ec:     	str	x0, [sp, #0x58]
1008468f0:     	mov	w0, #0x0                ; =0
1008468f4:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008468f8:     	stp	xzr, xzr, [x0]
1008468fc:     	str	wzr, [x0, #0x10]
100846900:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846904:     	bfxil	x8, x0, #0, #48
100846908:     	fmov	d0, x8
10084690c:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100846910:     	mov	x19, x0
100846914:     	adrp	x23, 0x100f7c000 <_perry_global_worker_ts__1>
100846918:     	ldr	x8, [x23, #0x48]
10084691c:     	cmn	x8, #0x1
100846920:     	b.eq	0x100846ae0 <_js_json_stringify_full+0x1020>
100846924:     	mrs	x9, TPIDRRO_EL0
100846928:     	and	x9, x9, #0xfffffffffffffff8
10084692c:     	ldr	x8, [x9, x8, lsl #3]
100846930:     	cbz	x8, 0x100846ae0 <_js_json_stringify_full+0x1020>
100846934:     	ldr	x8, [x8, #0x19e8]
100846938:     	cbz	x8, 0x100846ae0 <_js_json_stringify_full+0x1020>
10084693c:     	ldr	x9, [x8]
100846940:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846944:     	cmp	x9, x10
100846948:     	b.hs	0x10084764c <_js_json_stringify_full+0x1b8c>
10084694c:     	add	x10, x9, #0x1
100846950:     	str	x10, [x8]
100846954:     	ldr	x10, [x8, #0x18]
100846958:     	cmp	x19, x10
10084695c:     	b.hs	0x100847658 <_js_json_stringify_full+0x1b98>
100846960:     	ldr	x10, [x8, #0x10]
100846964:     	mov	w11, #0x18              ; =24
100846968:     	madd	x10, x19, x11, x10
10084696c:     	ldr	x11, [x10]
100846970:     	cbnz	x11, 0x1008476b8 <_js_json_stringify_full+0x1bf8>
100846974:     	ldr	x0, [x10, #0x8]
100846978:     	str	x9, [x8]
10084697c:     	b	0x100846ae8 <_js_json_stringify_full+0x1028>
100846980:     	mov	x8, #0x0                ; =0
100846984:     	mov	w9, #0x1                ; =1
100846988:     	stp	x9, xzr, [sp, #0x40]
10084698c:     	str	x8, [sp, #0x38]
100846990:     	tbnz	w23, #0x0, 0x1008468c4 <_js_json_stringify_full+0xe04>
100846994:     	cmp	x21, #0x0
100846998:     	cset	w6, ne
10084699c:     	ldp	x0, x1, [sp, #0x28]
1008469a0:     	ldp	x3, x4, [sp, #0x8]
1008469a4:     	add	x2, sp, #0x38
1008469a8:     	mov.16b	v0, v8
1008469ac:     	mov	x5, #0x0                ; =0
1008469b0:     	bl	0x100502e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
1008469b4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008469b8:     	add	x0, x0, #0xd90
1008469bc:     	ldr	x8, [x0]
1008469c0:     	blr	x8
1008469c4:     	ldrb	w8, [x0, #0x20]
1008469c8:     	cbnz	w8, 0x1008475e0 <_js_json_stringify_full+0x1b20>
1008469cc:     	ldr	x8, [x0]
1008469d0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1008469d4:     	cmp	x8, x9
1008469d8:     	b.hs	0x100847610 <_js_json_stringify_full+0x1b50>
1008469dc:     	ldr	x9, [x0, #0x18]
1008469e0:     	cbz	x9, 0x1008469ec <_js_json_stringify_full+0xf2c>
1008469e4:     	cbnz	x8, 0x10084761c <_js_json_stringify_full+0x1b5c>
1008469e8:     	str	xzr, [x0, #0x18]
1008469ec:     	ldp	x0, x1, [sp, #0x40]
1008469f0:     	cmp	x1, #0x5
1008469f4:     	b.hi	0x100846a5c <_js_json_stringify_full+0xf9c>
1008469f8:     	cbz	x1, 0x100846c6c <_js_json_stringify_full+0x11ac>
1008469fc:     	ldrsb	w8, [x0]
100846a00:     	tbnz	w8, #0x1f, 0x100846a5c <_js_json_stringify_full+0xf9c>
100846a04:     	cmp	x1, #0x1
100846a08:     	b.eq	0x100846a44 <_js_json_stringify_full+0xf84>
100846a0c:     	ldrsb	w8, [x0, #0x1]
100846a10:     	tbnz	w8, #0x1f, 0x100846a5c <_js_json_stringify_full+0xf9c>
100846a14:     	cmp	x1, #0x2
100846a18:     	b.eq	0x100846a44 <_js_json_stringify_full+0xf84>
100846a1c:     	ldrsb	w8, [x0, #0x2]
100846a20:     	tbnz	w8, #0x1f, 0x100846a5c <_js_json_stringify_full+0xf9c>
100846a24:     	cmp	x1, #0x3
100846a28:     	b.eq	0x100846a44 <_js_json_stringify_full+0xf84>
100846a2c:     	ldrsb	w8, [x0, #0x3]
100846a30:     	tbnz	w8, #0x1f, 0x100846a5c <_js_json_stringify_full+0xf9c>
100846a34:     	cmp	x1, #0x4
100846a38:     	b.eq	0x100846a44 <_js_json_stringify_full+0xf84>
100846a3c:     	ldrsb	w8, [x0, #0x4]
100846a40:     	tbnz	w8, #0x1f, 0x100846a5c <_js_json_stringify_full+0xf9c>
100846a44:     	cmp	x1, #0x4
100846a48:     	b.hs	0x100846dac <_js_json_stringify_full+0x12ec>
100846a4c:     	mov	x10, #0x0               ; =0
100846a50:     	mov	x9, #0x0                ; =0
100846a54:     	mov	x8, x0
100846a58:     	b	0x100846e3c <_js_json_stringify_full+0x137c>
100846a5c:     	bl	0x100329e88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846a60:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
100846a64:     	bfxil	x21, x0, #0, #48
100846a68:     	ldp	x23, x0, [sp, #0x38]
100846a6c:     	ldrb	w8, [x22, #0x18]
100846a70:     	cmp	w8, #0x1
100846a74:     	b.eq	0x100846e78 <_js_json_stringify_full+0x13b8>
100846a78:     	b	0x1008475a8 <_js_json_stringify_full+0x1ae8>
100846a7c:     	mov	w0, #0x0                ; =0
100846a80:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846a84:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846a88:     	bfxil	x8, x0, #0, #48
100846a8c:     	fmov	d1, x8
100846a90:     	stp	xzr, xzr, [x0]
100846a94:     	str	wzr, [x0, #0x10]
100846a98:     	mov.16b	v0, v8
100846a9c:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846aa0:     	mov.16b	v8, v0
100846aa4:     	fmov	x23, d8
100846aa8:     	cmp	x23, x26
100846aac:     	b.eq	0x100846cf4 <_js_json_stringify_full+0x1234>
100846ab0:     	mov	w8, #0x7ffd             ; =32765
100846ab4:     	cmp	x8, x23, lsr #48
100846ab8:     	b.ne	0x100846cc4 <_js_json_stringify_full+0x1204>
100846abc:     	and	x8, x23, #0xffffffffffff
100846ac0:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846ac4:     	b.lo	0x100846ce8 <_js_json_stringify_full+0x1228>
100846ac8:     	ldr	w8, [x8, #0xc]
100846acc:     	mov	w9, #0x4f53             ; =20307
100846ad0:     	movk	w9, #0x434c, lsl #16
100846ad4:     	cmp	w8, w9
100846ad8:     	b.ne	0x100846ce8 <_js_json_stringify_full+0x1228>
100846adc:     	b	0x100846cf4 <_js_json_stringify_full+0x1234>
100846ae0:     	mov	x0, x19
100846ae4:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846ae8:     	fmov	d1, x0
100846aec:     	mov.16b	v0, v8
100846af0:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846af4:     	mov.16b	v8, v0
100846af8:     	ldr	x8, [x23, #0x48]
100846afc:     	cmn	x8, #0x1
100846b00:     	b.eq	0x100846b64 <_js_json_stringify_full+0x10a4>
100846b04:     	mrs	x9, TPIDRRO_EL0
100846b08:     	and	x9, x9, #0xfffffffffffffff8
100846b0c:     	ldr	x8, [x9, x8, lsl #3]
100846b10:     	cbz	x8, 0x100846b64 <_js_json_stringify_full+0x10a4>
100846b14:     	ldr	x8, [x8, #0x19e8]
100846b18:     	cbz	x8, 0x100846b64 <_js_json_stringify_full+0x10a4>
100846b1c:     	ldr	x9, [x8]
100846b20:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846b24:     	cmp	x9, x10
100846b28:     	b.hs	0x10084764c <_js_json_stringify_full+0x1b8c>
100846b2c:     	add	x10, x9, #0x1
100846b30:     	str	x10, [x8]
100846b34:     	ldr	x10, [x8, #0x18]
100846b38:     	cmp	x21, x10
100846b3c:     	b.hs	0x100847658 <_js_json_stringify_full+0x1b98>
100846b40:     	ldr	x10, [x8, #0x10]
100846b44:     	mov	w11, #0x18              ; =24
100846b48:     	madd	x10, x21, x11, x10
100846b4c:     	ldr	x11, [x10]
100846b50:     	cmp	x11, #0x1
100846b54:     	b.ne	0x10084772c <_js_json_stringify_full+0x1c6c>
100846b58:     	ldr	x21, [x10, #0x8]
100846b5c:     	str	x9, [x8]
100846b60:     	b	0x100846b70 <_js_json_stringify_full+0x10b0>
100846b64:     	mov	x0, x21
100846b68:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846b6c:     	mov	x21, x0
100846b70:     	ldr	x8, [x23, #0x48]
100846b74:     	cmn	x8, #0x1
100846b78:     	b.eq	0x100846bd8 <_js_json_stringify_full+0x1118>
100846b7c:     	mrs	x9, TPIDRRO_EL0
100846b80:     	and	x9, x9, #0xfffffffffffffff8
100846b84:     	ldr	x8, [x9, x8, lsl #3]
100846b88:     	cbz	x8, 0x100846bd8 <_js_json_stringify_full+0x1118>
100846b8c:     	ldr	x8, [x8, #0x19e8]
100846b90:     	cbz	x8, 0x100846bd8 <_js_json_stringify_full+0x1118>
100846b94:     	ldr	x9, [x8]
100846b98:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846b9c:     	cmp	x9, x10
100846ba0:     	b.hs	0x10084764c <_js_json_stringify_full+0x1b8c>
100846ba4:     	add	x10, x9, #0x1
100846ba8:     	str	x10, [x8]
100846bac:     	ldr	x10, [x8, #0x18]
100846bb0:     	cmp	x19, x10
100846bb4:     	b.hs	0x100847658 <_js_json_stringify_full+0x1b98>
100846bb8:     	ldr	x10, [x8, #0x10]
100846bbc:     	mov	w11, #0x18              ; =24
100846bc0:     	madd	x10, x19, x11, x10
100846bc4:     	ldr	x11, [x10]
100846bc8:     	cbnz	x11, 0x1008476b8 <_js_json_stringify_full+0x1bf8>
100846bcc:     	ldr	x0, [x10, #0x8]
100846bd0:     	str	x9, [x8]
100846bd4:     	b	0x100846be0 <_js_json_stringify_full+0x1120>
100846bd8:     	mov	x0, x19
100846bdc:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846be0:     	fmov	d9, x0
100846be4:     	mov.16b	v0, v8
100846be8:     	bl	0x1004ff434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100846bec:     	mov.16b	v2, v0
100846bf0:     	mov	x0, x21
100846bf4:     	mov.16b	v0, v9
100846bf8:     	mov.16b	v1, v8
100846bfc:     	bl	0x1004ff714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100846c00:     	str	d0, [sp, #0x60]
100846c04:     	fmov	x19, d0
100846c08:     	cmp	x19, x26
100846c0c:     	b.ne	0x100846c74 <_js_json_stringify_full+0x11b4>
100846c10:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846c14:     	add	x0, x0, #0xd90
100846c18:     	ldr	x8, [x0]
100846c1c:     	blr	x8
100846c20:     	ldrb	w8, [x0, #0x20]
100846c24:     	cbnz	w8, 0x10084770c <_js_json_stringify_full+0x1c4c>
100846c28:     	ldr	x8, [x0]
100846c2c:     	cbnz	x8, 0x10084775c <_js_json_stringify_full+0x1c9c>
100846c30:     	str	xzr, [x0, #0x18]
100846c34:     	ldp	x21, x19, [sp, #0x38]
100846c38:     	ldrb	w8, [x22, #0x18]
100846c3c:     	cmp	w8, #0x1
100846c40:     	b.ne	0x100847690 <_js_json_stringify_full+0x1bd0>
100846c44:     	ldp	x8, x0, [x22]
100846c48:     	stp	x21, x19, [x22]
100846c4c:     	str	xzr, [x22, #0x10]
100846c50:     	sub	x8, x8, #0x1
100846c54:     	cmn	x8, #0x2
100846c58:     	b.hs	0x100846c60 <_js_json_stringify_full+0x11a0>
100846c5c:     	bl	0x100b5efc0 <_mi_free>
100846c60:     	cbz	w25, 0x100846f20 <_js_json_stringify_full+0x1460>
100846c64:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846c68:     	b	0x100846f24 <_js_json_stringify_full+0x1464>
100846c6c:     	mov	x10, #0x0               ; =0
100846c70:     	b	0x100846e5c <_js_json_stringify_full+0x139c>
100846c74:     	add	x0, sp, #0x38
100846c78:     	bl	0x100500470 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100846c7c:     	tbnz	w0, #0x0, 0x100846cb8 <_js_json_stringify_full+0x11f8>
100846c80:     	mov	x0, x19
100846c84:     	bl	0x100327dec <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100846c88:     	cmp	x0, #0x1
100846c8c:     	b.ne	0x100847720 <_js_json_stringify_full+0x1c60>
100846c90:     	add	x8, sp, #0x68
100846c94:     	add	x9, sp, #0x60
100846c98:     	stp	x1, x8, [sp, #0x68]
100846c9c:     	str	x9, [sp, #0x78]
100846ca0:     	add	x8, sp, #0x38
100846ca4:     	mov	x9, sp
100846ca8:     	stp	x8, x9, [sp, #0x80]
100846cac:     	add	x0, sp, #0x58
100846cb0:     	add	x1, sp, #0x70
100846cb4:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100846cb8:     	add	x0, sp, #0x50
100846cbc:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846cc0:     	b	0x1008469b4 <_js_json_stringify_full+0xef4>
100846cc4:     	lsr	x8, x23, #52
100846cc8:     	cbnz	x8, 0x100846ce8 <_js_json_stringify_full+0x1228>
100846ccc:     	cbz	x23, 0x100846ce8 <_js_json_stringify_full+0x1228>
100846cd0:     	and	x8, x23, #0x7
100846cd4:     	cbnz	x8, 0x100846ce8 <_js_json_stringify_full+0x1228>
100846cd8:     	mov	x0, x23
100846cdc:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846ce0:     	mov	x8, x23
100846ce4:     	tbnz	w0, #0x0, 0x100846ac0 <_js_json_stringify_full+0x1000>
100846ce8:     	mov	x0, x23
100846cec:     	bl	0x100509494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100846cf0:     	tbz	w0, #0x0, 0x100846d80 <_js_json_stringify_full+0x12c0>
100846cf4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846cf8:     	add	x0, x0, #0xd90
100846cfc:     	ldr	x8, [x0]
100846d00:     	blr	x8
100846d04:     	ldrb	w8, [x0, #0x20]
100846d08:     	cbnz	w8, 0x10084765c <_js_json_stringify_full+0x1b9c>
100846d0c:     	ldr	x8, [x0]
100846d10:     	cbnz	x8, 0x100847684 <_js_json_stringify_full+0x1bc4>
100846d14:     	str	xzr, [x0, #0x18]
100846d18:     	ldp	x21, x19, [sp, #0x38]
100846d1c:     	ldrb	w8, [x22, #0x18]
100846d20:     	cmp	w8, #0x1
100846d24:     	b.ne	0x100847638 <_js_json_stringify_full+0x1b78>
100846d28:     	ldp	x8, x0, [x22]
100846d2c:     	stp	x21, x19, [x22]
100846d30:     	str	xzr, [x22, #0x10]
100846d34:     	sub	x8, x8, #0x1
100846d38:     	cmn	x8, #0x2
100846d3c:     	b.hs	0x100846d44 <_js_json_stringify_full+0x1284>
100846d40:     	bl	0x100b5efc0 <_mi_free>
100846d44:     	cbz	w25, 0x100846d64 <_js_json_stringify_full+0x12a4>
100846d48:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846d4c:     	ldr	w8, [x20]
100846d50:     	sub	w8, w8, #0x1
100846d54:     	str	w8, [x20]
100846d58:     	cmn	x24, #0x1
100846d5c:     	b.ne	0x100846f40 <_js_json_stringify_full+0x1480>
100846d60:     	b	0x100846f7c <_js_json_stringify_full+0x14bc>
100846d64:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846d68:     	ldr	w8, [x20]
100846d6c:     	sub	w8, w8, #0x1
100846d70:     	str	w8, [x20]
100846d74:     	cmn	x24, #0x1
100846d78:     	b.ne	0x100846f40 <_js_json_stringify_full+0x1480>
100846d7c:     	b	0x100846f7c <_js_json_stringify_full+0x14bc>
100846d80:     	cmp	x19, x23
100846d84:     	b.eq	0x100846d90 <_js_json_stringify_full+0x12d0>
100846d88:     	mov.16b	v0, v8
100846d8c:     	bl	0x10050e86c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100846d90:     	cbz	x21, 0x10084701c <_js_json_stringify_full+0x155c>
100846d94:     	ldp	x1, x2, [sp, #0x8]
100846d98:     	add	x0, sp, #0x38
100846d9c:     	mov.16b	v0, v8
100846da0:     	mov	x3, #0x0                ; =0
100846da4:     	bl	0x100500f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100846da8:     	b	0x10084702c <_js_json_stringify_full+0x156c>
100846dac:     	and	x9, x1, #0x4
100846db0:     	add	x8, x0, x9
100846db4:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
100846db8:     	ldr	q0, [x10, #0xa40]
100846dbc:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3363a>
100846dc0:     	ldr	q2, [x10, #0x940]
100846dc4:     	movi.2d	v1, #0000000000000000
100846dc8:     	movi.2d	v3, #0x000000000000ff
100846dcc:     	mov	w10, #0x4               ; =4
100846dd0:     	dup.2d	v4, x10
100846dd4:     	mov	x10, x0
100846dd8:     	and	x11, x1, #0x4
100846ddc:     	movi.2d	v5, #0000000000000000
100846de0:     	ldr	s6, [x10], #0x4
100846de4:     	ushll.8h	v6, v6, #0x0
100846de8:     	ushll.4s	v6, v6, #0x0
100846dec:     	ushll2.2d	v7, v6, #0x0
100846df0:     	and.16b	v7, v7, v3
100846df4:     	ushll.2d	v6, v6, #0x0
100846df8:     	and.16b	v6, v6, v3
100846dfc:     	shl.2d	v16, v0, #0x3
100846e00:     	shl.2d	v17, v2, #0x3
100846e04:     	ushl.2d	v6, v6, v17
100846e08:     	ushl.2d	v7, v7, v16
100846e0c:     	orr.16b	v1, v7, v1
100846e10:     	orr.16b	v5, v6, v5
100846e14:     	add.2d	v0, v0, v4
100846e18:     	add.2d	v2, v2, v4
100846e1c:     	subs	x11, x11, #0x4
100846e20:     	b.ne	0x100846de0 <_js_json_stringify_full+0x1320>
100846e24:     	orr.16b	v0, v5, v1
100846e28:     	mov	d1, v0[1]
100846e2c:     	orr.8b	v0, v0, v1
100846e30:     	fmov	x10, d0
100846e34:     	cmp	x1, x9
100846e38:     	b.eq	0x100846e5c <_js_json_stringify_full+0x139c>
100846e3c:     	add	x11, x0, x1
100846e40:     	lsl	x9, x9, #3
100846e44:     	ldrb	w12, [x8], #0x1
100846e48:     	lsl	x12, x12, x9
100846e4c:     	orr	x10, x12, x10
100846e50:     	add	x9, x9, #0x8
100846e54:     	cmp	x8, x11
100846e58:     	b.ne	0x100846e44 <_js_json_stringify_full+0x1384>
100846e5c:     	orr	x8, x10, x1, lsl #40
100846e60:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846e64:     	orr	x21, x8, x9
100846e68:     	ldr	x23, [sp, #0x38]
100846e6c:     	ldrb	w8, [x22, #0x18]
100846e70:     	cmp	w8, #0x1
100846e74:     	b.ne	0x1008475a8 <_js_json_stringify_full+0x1ae8>
100846e78:     	ldp	x9, x8, [x22]
100846e7c:     	stp	x23, x0, [x22]
100846e80:     	str	xzr, [x22, #0x10]
100846e84:     	sub	x9, x9, #0x1
100846e88:     	cmn	x9, #0x2
100846e8c:     	b.hs	0x100846e98 <_js_json_stringify_full+0x13d8>
100846e90:     	mov	x0, x8
100846e94:     	bl	0x100b5efc0 <_mi_free>
100846e98:     	cbz	w25, 0x100846eb8 <_js_json_stringify_full+0x13f8>
100846e9c:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846ea0:     	ldr	w8, [x20]
100846ea4:     	sub	w8, w8, #0x1
100846ea8:     	str	w8, [x20]
100846eac:     	cmn	x24, #0x1
100846eb0:     	b.ne	0x100846ed0 <_js_json_stringify_full+0x1410>
100846eb4:     	b	0x100846f0c <_js_json_stringify_full+0x144c>
100846eb8:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846ebc:     	ldr	w8, [x20]
100846ec0:     	sub	w8, w8, #0x1
100846ec4:     	str	w8, [x20]
100846ec8:     	cmn	x24, #0x1
100846ecc:     	b.eq	0x100846f0c <_js_json_stringify_full+0x144c>
100846ed0:     	ldp	x19, x20, [sp, #0x28]
100846ed4:     	cbz	x20, 0x100846f00 <_js_json_stringify_full+0x1440>
100846ed8:     	add	x22, x19, #0x8
100846edc:     	b	0x100846eec <_js_json_stringify_full+0x142c>
100846ee0:     	add	x22, x22, #0x18
100846ee4:     	subs	x20, x20, #0x1
100846ee8:     	b.eq	0x100846f00 <_js_json_stringify_full+0x1440>
100846eec:     	ldur	x8, [x22, #-0x8]
100846ef0:     	cbz	x8, 0x100846ee0 <_js_json_stringify_full+0x1420>
100846ef4:     	ldr	x0, [x22]
100846ef8:     	bl	0x100b5efc0 <_mi_free>
100846efc:     	b	0x100846ee0 <_js_json_stringify_full+0x1420>
100846f00:     	cbz	x24, 0x100846f0c <_js_json_stringify_full+0x144c>
100846f04:     	mov	x0, x19
100846f08:     	bl	0x100b5efc0 <_mi_free>
100846f0c:     	ldr	x8, [sp]
100846f10:     	cbz	x8, 0x100846f94 <_js_json_stringify_full+0x14d4>
100846f14:     	ldr	x0, [sp, #0x8]
100846f18:     	bl	0x100b5efc0 <_mi_free>
100846f1c:     	b	0x100846f94 <_js_json_stringify_full+0x14d4>
100846f20:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846f24:     	ldr	w8, [x20]
100846f28:     	sub	w8, w8, #0x1
100846f2c:     	str	w8, [x20]
100846f30:     	add	x0, sp, #0x50
100846f34:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846f38:     	cmn	x24, #0x1
100846f3c:     	b.eq	0x100846f7c <_js_json_stringify_full+0x14bc>
100846f40:     	ldp	x19, x20, [sp, #0x28]
100846f44:     	cbz	x20, 0x100846f70 <_js_json_stringify_full+0x14b0>
100846f48:     	add	x21, x19, #0x8
100846f4c:     	b	0x100846f5c <_js_json_stringify_full+0x149c>
100846f50:     	add	x21, x21, #0x18
100846f54:     	subs	x20, x20, #0x1
100846f58:     	b.eq	0x100846f70 <_js_json_stringify_full+0x14b0>
100846f5c:     	ldur	x8, [x21, #-0x8]
100846f60:     	cbz	x8, 0x100846f50 <_js_json_stringify_full+0x1490>
100846f64:     	ldr	x0, [x21]
100846f68:     	bl	0x100b5efc0 <_mi_free>
100846f6c:     	b	0x100846f50 <_js_json_stringify_full+0x1490>
100846f70:     	cbz	x24, 0x100846f7c <_js_json_stringify_full+0x14bc>
100846f74:     	mov	x0, x19
100846f78:     	bl	0x100b5efc0 <_mi_free>
100846f7c:     	ldr	x8, [sp]
100846f80:     	cbz	x8, 0x100846f8c <_js_json_stringify_full+0x14cc>
100846f84:     	ldr	x0, [sp, #0x8]
100846f88:     	bl	0x100b5efc0 <_mi_free>
100846f8c:     	mov	x21, #0x1               ; =1
100846f90:     	movk	x21, #0x7ffc, lsl #48
100846f94:     	mov	x0, x21
100846f98:     	ldp	x29, x30, [sp, #0x100]
100846f9c:     	ldp	x20, x19, [sp, #0xf0]
100846fa0:     	ldp	x22, x21, [sp, #0xe0]
100846fa4:     	ldp	x24, x23, [sp, #0xd0]
100846fa8:     	ldp	x26, x25, [sp, #0xc0]
100846fac:     	ldp	x28, x27, [sp, #0xb0]
100846fb0:     	ldp	d9, d8, [sp, #0xa0]
100846fb4:     	add	sp, sp, #0x110
100846fb8:     	ret
100846fbc:     	mov	x26, x21
100846fc0:     	mov	x21, x28
100846fc4:     	mov	x28, x0
100846fc8:     	add	x0, x0, #0x8
100846fcc:     	bl	0x100b3bd50 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100846fd0:     	mov	x0, x28
100846fd4:     	mov	x28, x21
100846fd8:     	mov	x21, x26
100846fdc:     	mov	x26, #0x1               ; =1
100846fe0:     	movk	x26, #0x7ffc, lsl #48
100846fe4:     	b	0x1008467dc <_js_json_stringify_full+0xd1c>
100846fe8:     	b.ne	0x100846520 <_js_json_stringify_full+0xa60>
100846fec:     	tbz	x24, #0x3f, 0x100847044 <_js_json_stringify_full+0x1584>
100846ff0:     	mov	x0, #0x0                ; =0
100846ff4:     	mov	x1, x24
100846ff8:     	bl	0x100b12380 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100846ffc:     	bl	0x100b3f3fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100847000:     	add	x8, x0, x22, lsl #3
100847004:     	ldr	x0, [x8, #0x1e8]
100847008:     	cbnz	x0, 0x100846870 <_js_json_stringify_full+0xdb0>
10084700c:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100847010:     	add	x0, x0, #0x138
100847014:     	bl	0x100b3cc1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100847018:     	b	0x100846870 <_js_json_stringify_full+0xdb0>
10084701c:     	add	x1, sp, #0x38
100847020:     	mov.16b	v0, v8
100847024:     	mov	w0, #0x0                ; =0
100847028:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084702c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100847030:     	add	x0, x0, #0xdc0
100847034:     	ldr	x8, [x0]
100847038:     	blr	x8
10084703c:     	strb	wzr, [x0]
100847040:     	b	0x1008469b4 <_js_json_stringify_full+0xef4>
100847044:     	mov	x0, x24
100847048:     	mov	w1, #0x1                ; =1
10084704c:     	bl	0x100b5f248 <_mi_malloc_aligned>
100847050:     	mov	x25, x0
100847054:     	mov	w0, #0x1                ; =1
100847058:     	cbz	x25, 0x100846ff4 <_js_json_stringify_full+0x1534>
10084705c:     	mov	x0, x25
100847060:     	mov	x1, x22
100847064:     	mov	x2, x24
100847068:     	bl	0x100b61e6c <_writev+0x100b61e6c>
10084706c:     	mov	x21, x24
100847070:     	b	0x100846544 <_js_json_stringify_full+0xa84>
100847074:     	cmp	w11, #0x8
100847078:     	b.eq	0x100847144 <_js_json_stringify_full+0x1684>
10084707c:     	cmp	w11, #0x9
100847080:     	b.eq	0x100847154 <_js_json_stringify_full+0x1694>
100847084:     	cmp	w11, #0xa
100847088:     	b.ne	0x1008470d0 <_js_json_stringify_full+0x1610>
10084708c:     	mov	w10, #0x6e              ; =110
100847090:     	b	0x100847158 <_js_json_stringify_full+0x1698>
100847094:     	mov	x22, x0
100847098:     	and	x0, x19, #0xffffffffffff
10084709c:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008470a0:     	cbz	x0, 0x10084717c <_js_json_stringify_full+0x16bc>
1008470a4:     	ldr	w21, [x0]
1008470a8:     	cmp	w21, #0x4
1008470ac:     	b.hi	0x1008460a8 <_js_json_stringify_full+0x5e8>
1008470b0:     	ldr	w8, [x0, #0x4]
1008470b4:     	cmp	w21, w8
1008470b8:     	b.hi	0x1008460a8 <_js_json_stringify_full+0x5e8>
1008470bc:     	b	0x100847180 <_js_json_stringify_full+0x16c0>
1008470c0:     	cmp	w11, #0x22
1008470c4:     	b.eq	0x100847158 <_js_json_stringify_full+0x1698>
1008470c8:     	cmp	w11, #0x5c
1008470cc:     	b.eq	0x100847158 <_js_json_stringify_full+0x1698>
1008470d0:     	cmp	x12, #0x3
1008470d4:     	mov	w11, #0x20              ; =32
1008470d8:     	ccmp	w10, w11, #0x8, ls
1008470dc:     	b.lt	0x100845fe4 <_js_json_stringify_full+0x524>
1008470e0:     	add	x8, sp, #0x70
1008470e4:     	strb	w10, [x8, x12]
1008470e8:     	add	x12, x12, #0x1
1008470ec:     	b	0x100845cd4 <_js_json_stringify_full+0x214>
1008470f0:     	mov	x1, x0
1008470f4:     	and	x0, x19, #0xffffffffffff
1008470f8:     	mov	x22, x1
1008470fc:     	bl	0x1004f8e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100847100:     	cmp	x0, #0x1
100847104:     	b.ne	0x100847228 <_js_json_stringify_full+0x1768>
100847108:     	mov	x21, x1
10084710c:     	b	0x100846f94 <_js_json_stringify_full+0x14d4>
100847110:     	ldrb	w9, [x8, #0x118]
100847114:     	cbz	w9, 0x100847350 <_js_json_stringify_full+0x1890>
100847118:     	ldr	x9, [x8, #0x110]
10084711c:     	cmp	x9, x1
100847120:     	b.ne	0x100847350 <_js_json_stringify_full+0x1890>
100847124:     	ldr	x9, [x8, #0xf0]
100847128:     	cmp	x9, x22
10084712c:     	b.hi	0x100847350 <_js_json_stringify_full+0x1890>
100847130:     	ldr	x9, [x8, #0xf8]
100847134:     	cmp	x9, x22
100847138:     	b.ls	0x100847350 <_js_json_stringify_full+0x1890>
10084713c:     	add	x9, x8, #0xf0
100847140:     	b	0x10084755c <_js_json_stringify_full+0x1a9c>
100847144:     	mov	w10, #0x62              ; =98
100847148:     	b	0x100847158 <_js_json_stringify_full+0x1698>
10084714c:     	mov	w10, #0x66              ; =102
100847150:     	b	0x100847158 <_js_json_stringify_full+0x1698>
100847154:     	mov	w10, #0x74              ; =116
100847158:     	cmp	x12, #0x2
10084715c:     	b.hi	0x100845fe4 <_js_json_stringify_full+0x524>
100847160:     	add	x8, sp, #0x70
100847164:     	add	x8, x8, x12
100847168:     	add	x12, x12, #0x2
10084716c:     	mov	w11, #0x5c              ; =92
100847170:     	strb	w11, [x8]
100847174:     	strb	w10, [x8, #0x1]
100847178:     	b	0x100845cd4 <_js_json_stringify_full+0x214>
10084717c:     	mov	x21, #0x0               ; =0
100847180:     	ldr	w8, [x22, #0x4]
100847184:     	lsl	x9, x21, #3
100847188:     	add	x9, x9, #0x18
10084718c:     	cmp	x9, x8
100847190:     	b.hi	0x1008460a8 <_js_json_stringify_full+0x5e8>
100847194:     	ldr	w8, [x24, #0x4]
100847198:     	mov	w9, #-0x40000000        ; =-1073741824
10084719c:     	cmp	w8, w9
1008471a0:     	csel	w8, w8, wzr, lt
1008471a4:     	mov	x22, x0
1008471a8:     	mov	x0, x8
1008471ac:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1008471b0:     	mov	w9, #0x2                ; =2
1008471b4:     	cmp	w1, #0x2
1008471b8:     	csel	w10, w1, w9, hi
1008471bc:     	tst	w0, #0x1
1008471c0:     	csel	x8, x10, x9, ne
1008471c4:     	cmp	x21, x8
1008471c8:     	b.hi	0x1008460a8 <_js_json_stringify_full+0x5e8>
1008471cc:     	cbz	x21, 0x10084758c <_js_json_stringify_full+0x1acc>
1008471d0:     	mov	x0, x22
1008471d4:     	mov	x1, x21
1008471d8:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008471dc:     	tbz	w0, #0x0, 0x1008460a8 <_js_json_stringify_full+0x5e8>
1008471e0:     	cmp	x21, #0x1
1008471e4:     	b.eq	0x100847628 <_js_json_stringify_full+0x1b68>
1008471e8:     	cmp	x21, #0x2
1008471ec:     	b.ne	0x1008476e0 <_js_json_stringify_full+0x1c20>
1008471f0:     	mov	x22, #0x0               ; =0
1008471f4:     	add	x24, x24, #0x10
1008471f8:     	mov	w8, #0x1                ; =1
1008471fc:     	mov	x25, x8
100847200:     	ldr	x1, [x24, x22, lsl #3]
100847204:     	add	x0, sp, #0x70
100847208:     	bl	0x1004efe14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084720c:     	ldr	w8, [sp, #0x70]
100847210:     	cmn	w8, #0x1
100847214:     	b.ne	0x1008476c8 <_js_json_stringify_full+0x1c08>
100847218:     	mov	w8, #0x0                ; =0
10084721c:     	mov	w22, #0x1               ; =1
100847220:     	tbnz	w25, #0x0, 0x1008471fc <_js_json_stringify_full+0x173c>
100847224:     	b	0x1008476e0 <_js_json_stringify_full+0x1c20>
100847228:     	and	x0, x19, #0xffffffffffff
10084722c:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100847230:     	cbz	x0, 0x1008472bc <_js_json_stringify_full+0x17fc>
100847234:     	ldr	w21, [x0]
100847238:     	cbz	w21, 0x1008472bc <_js_json_stringify_full+0x17fc>
10084723c:     	cmp	w21, #0x8
100847240:     	b.hi	0x100846074 <_js_json_stringify_full+0x5b4>
100847244:     	ldr	w8, [x0, #0x4]
100847248:     	cmp	w21, w8
10084724c:     	b.hi	0x100846074 <_js_json_stringify_full+0x5b4>
100847250:     	ldr	w8, [x22, #0x4]
100847254:     	lsl	x9, x21, #3
100847258:     	add	x9, x9, #0x18
10084725c:     	cmp	x9, x8
100847260:     	b.hi	0x100846074 <_js_json_stringify_full+0x5b4>
100847264:     	ldr	w8, [x24, #0x4]
100847268:     	mov	w9, #-0x40000000        ; =-1073741824
10084726c:     	cmp	w8, w9
100847270:     	csel	w8, w8, wzr, lt
100847274:     	mov	x22, x0
100847278:     	mov	x0, x8
10084727c:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100847280:     	mov	w9, #0x2                ; =2
100847284:     	cmp	w1, #0x2
100847288:     	csel	w10, w1, w9, hi
10084728c:     	tst	w0, #0x1
100847290:     	csel	w8, w10, w9, ne
100847294:     	cmp	w21, w8
100847298:     	b.hi	0x100846074 <_js_json_stringify_full+0x5b4>
10084729c:     	mov	x0, x22
1008472a0:     	mov	x1, x21
1008472a4:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008472a8:     	cbz	w0, 0x100846074 <_js_json_stringify_full+0x5b4>
1008472ac:     	and	x0, x19, #0xffffffffffff
1008472b0:     	mov	x1, x21
1008472b4:     	bl	0x1004f7f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
1008472b8:     	b	0x1008472c4 <_js_json_stringify_full+0x1804>
1008472bc:     	and	x0, x19, #0xffffffffffff
1008472c0:     	bl	0x1004f8cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
1008472c4:     	mov	x21, x1
1008472c8:     	tbz	w0, #0x0, 0x100846074 <_js_json_stringify_full+0x5b4>
1008472cc:     	b	0x100846f94 <_js_json_stringify_full+0x14d4>
1008472d0:     	add	x9, x8, #0x60
1008472d4:     	b	0x10084755c <_js_json_stringify_full+0x1a9c>
1008472d8:     	bl	0x100b3f3fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008472dc:     	lsr	x1, x22, #20
1008472e0:     	ldr	x8, [x0, #0x10]
1008472e4:     	ldrb	w9, [x8]
1008472e8:     	cmp	w9, #0x2
1008472ec:     	b.eq	0x10084664c <_js_json_stringify_full+0xb8c>
1008472f0:     	ldr	x9, [x8, #0x8]
1008472f4:     	ldr	x10, [x8, #0x28]
1008472f8:     	sub	x9, x1, x9
1008472fc:     	cmp	x9, x10
100847300:     	b.hs	0x100847344 <_js_json_stringify_full+0x1884>
100847304:     	ldr	x10, [x8, #0x20]
100847308:     	mov	w11, #0x28              ; =40
10084730c:     	madd	x9, x9, x11, x10
100847310:     	ldr	x10, [x9]
100847314:     	ldr	x11, [x8, #0x10]
100847318:     	cmp	x10, x11
10084731c:     	b.ne	0x100847350 <_js_json_stringify_full+0x1890>
100847320:     	ldp	x10, x11, [x9, #0x8]
100847324:     	cmp	x10, x22
100847328:     	ccmp	x11, x22, #0x0, ls
10084732c:     	b.ls	0x100847350 <_js_json_stringify_full+0x1890>
100847330:     	ldr	x10, [x8, #0x30]
100847334:     	add	x10, x10, #0x1
100847338:     	str	x10, [x8, #0x30]
10084733c:     	add	x8, x9, #0x21
100847340:     	b	0x10084756c <_js_json_stringify_full+0x1aac>
100847344:     	ldr	x9, [x8, #0x58]
100847348:     	add	x9, x9, #0x1
10084734c:     	str	x9, [x8, #0x58]
100847350:     	ldr	x9, [x8, #0x38]
100847354:     	add	x9, x9, #0x1
100847358:     	str	x9, [x8, #0x38]
10084735c:     	mov	x0, x22
100847360:     	bl	0x10051e348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100847364:     	and	w8, w0, #0xff
100847368:     	cbz	w8, 0x100847388 <_js_json_stringify_full+0x18c8>
10084736c:     	ldurb	w8, [x22, #-0x8]
100847370:     	ldurb	w9, [x22, #-0x7]
100847374:     	mov	w10, #0x82              ; =130
100847378:     	and	w9, w9, w10
10084737c:     	cmp	w9, #0x2
100847380:     	ccmp	w8, #0x1, #0x0, eq
100847384:     	b.eq	0x10084741c <_js_json_stringify_full+0x195c>
100847388:     	mov	x0, x22
10084738c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847390:     	mov	x23, x0
100847394:     	cbz	x0, 0x1008473c0 <_js_json_stringify_full+0x1900>
100847398:     	ldrb	w8, [x23]
10084739c:     	cmp	w8, #0x1
1008473a0:     	b.ne	0x1008473e0 <_js_json_stringify_full+0x1920>
1008473a4:     	ldrsb	w8, [x23, #0x1]
1008473a8:     	tbnz	w8, #0x1f, 0x100847444 <_js_json_stringify_full+0x1984>
1008473ac:     	mov	x0, x23
1008473b0:     	ldp	w9, w8, [x22]
1008473b4:     	cmp	w9, w8
1008473b8:     	b.hi	0x1008474c8 <_js_json_stringify_full+0x1a08>
1008473bc:     	b	0x1008474e0 <_js_json_stringify_full+0x1a20>
1008473c0:     	mov	x0, x22
1008473c4:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008473c8:     	tbnz	w0, #0x0, 0x1008473d8 <_js_json_stringify_full+0x1918>
1008473cc:     	mov	x0, x22
1008473d0:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008473d4:     	tbz	w0, #0x0, 0x1008466ec <_js_json_stringify_full+0xc2c>
1008473d8:     	mov	x0, #0x0                ; =0
1008473dc:     	b	0x1008474b8 <_js_json_stringify_full+0x19f8>
1008473e0:     	mov	x0, x23
1008473e4:     	cmp	w8, #0x1
1008473e8:     	b.eq	0x1008474b8 <_js_json_stringify_full+0x19f8>
1008473ec:     	cmp	w8, #0x9
1008473f0:     	b.ne	0x1008466ec <_js_json_stringify_full+0xc2c>
1008473f4:     	ldr	w8, [x22, #0x4]
1008473f8:     	mov	w9, #0x5841             ; =22593
1008473fc:     	movk	w9, #0x4c5a, lsl #16
100847400:     	cmp	w8, w9
100847404:     	b.ne	0x1008466ec <_js_json_stringify_full+0xc2c>
100847408:     	mov	x0, x22
10084740c:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100847410:     	mov	x22, x0
100847414:     	cbnz	x0, 0x100847508 <_js_json_stringify_full+0x1a48>
100847418:     	b	0x1008466ec <_js_json_stringify_full+0xc2c>
10084741c:     	ldr	w8, [x22]
100847420:     	mov	w9, #0xe100             ; =57600
100847424:     	movk	w9, #0x5f5, lsl #16
100847428:     	orr	w9, w9, #0x1
10084742c:     	cmp	w8, w9
100847430:     	b.hs	0x100847388 <_js_json_stringify_full+0x18c8>
100847434:     	ldr	w9, [x22, #0x4]
100847438:     	cmp	w8, w9
10084743c:     	b.ls	0x100847508 <_js_json_stringify_full+0x1a48>
100847440:     	b	0x100847388 <_js_json_stringify_full+0x18c8>
100847444:     	ldr	x22, [x23, #0x8]
100847448:     	mov	x0, x22
10084744c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847450:     	cbz	x0, 0x1008466ec <_js_json_stringify_full+0xc2c>
100847454:     	ldrb	w8, [x0]
100847458:     	cmp	w8, #0x1
10084745c:     	b.ne	0x1008466ec <_js_json_stringify_full+0xc2c>
100847460:     	ldrsb	w8, [x0, #0x1]
100847464:     	tbz	w8, #0x1f, 0x1008473b0 <_js_json_stringify_full+0x18f0>
100847468:     	mov	w25, #0x1               ; =1
10084746c:     	ldr	x22, [x0, #0x8]
100847470:     	mov	x0, x22
100847474:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847478:     	cbz	x0, 0x1008466ec <_js_json_stringify_full+0xc2c>
10084747c:     	ldrb	w8, [x0]
100847480:     	cmp	w8, #0x1
100847484:     	b.ne	0x1008466ec <_js_json_stringify_full+0xc2c>
100847488:     	cmp	w25, #0x3f
10084748c:     	b.hi	0x1008466ec <_js_json_stringify_full+0xc2c>
100847490:     	add	w25, w25, #0x1
100847494:     	ldrsb	w8, [x0, #0x1]
100847498:     	tbnz	w8, #0x1f, 0x10084746c <_js_json_stringify_full+0x19ac>
10084749c:     	str	x22, [x23, #0x8]
1008474a0:     	ldrb	w8, [x23, #0x1]
1008474a4:     	orr	w8, w8, #0x80
1008474a8:     	strb	w8, [x23, #0x1]
1008474ac:     	ldrb	w8, [x0]
1008474b0:     	cmp	w8, #0x1
1008474b4:     	b.ne	0x1008473ec <_js_json_stringify_full+0x192c>
1008474b8:     	ldp	w9, w8, [x22]
1008474bc:     	cmp	w9, w8
1008474c0:     	b.ls	0x1008474e0 <_js_json_stringify_full+0x1a20>
1008474c4:     	cbz	x23, 0x1008474f0 <_js_json_stringify_full+0x1a30>
1008474c8:     	ldr	w9, [x0, #0x4]
1008474cc:     	ubfiz	x8, x8, #3, #32
1008474d0:     	add	x8, x8, #0x10
1008474d4:     	cmp	x8, x9
1008474d8:     	b.eq	0x100847508 <_js_json_stringify_full+0x1a48>
1008474dc:     	b	0x1008474f0 <_js_json_stringify_full+0x1a30>
1008474e0:     	mov	w8, #0xe100             ; =57600
1008474e4:     	movk	w8, #0x5f5, lsl #16
1008474e8:     	cmp	w9, w8
1008474ec:     	b.ls	0x100847508 <_js_json_stringify_full+0x1a48>
1008474f0:     	mov	x0, x22
1008474f4:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008474f8:     	tbnz	w0, #0x0, 0x100847508 <_js_json_stringify_full+0x1a48>
1008474fc:     	mov	x0, x22
100847500:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847504:     	tbz	w0, #0x0, 0x1008466ec <_js_json_stringify_full+0xc2c>
100847508:     	ldp	w8, w9, [x22]
10084750c:     	sub	w10, w9, #0x1
100847510:     	mov	w11, #0x270f            ; =9999
100847514:     	cmp	w10, w11
100847518:     	ccmp	w8, w9, #0x2, lo
10084751c:     	b.hi	0x1008466ec <_js_json_stringify_full+0xc2c>
100847520:     	and	x8, x20, #0xffffffffffff
100847524:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100847528:     	cmp	x24, x9
10084752c:     	csel	x1, x8, x20, eq
100847530:     	add	x0, sp, #0x20
100847534:     	bl	0x1004ffc78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100847538:     	ldr	x24, [sp, #0x20]
10084753c:     	cmn	x24, #0x1
100847540:     	cset	w23, eq
100847544:     	cmp	x27, #0x1
100847548:     	cset	w8, hi
10084754c:     	tst	w8, w23
100847550:     	b.ne	0x100846708 <_js_json_stringify_full+0xc48>
100847554:     	b	0x100846778 <_js_json_stringify_full+0xcb8>
100847558:     	add	x9, x8, #0x90
10084755c:     	ldr	x10, [x8, #0x30]
100847560:     	add	x10, x10, #0x1
100847564:     	str	x10, [x8, #0x30]
100847568:     	add	x8, x9, #0x19
10084756c:     	ldrb	w8, [x8]
100847570:     	cmp	w8, #0xff
100847574:     	b.ne	0x100847368 <_js_json_stringify_full+0x18a8>
100847578:     	b	0x10084735c <_js_json_stringify_full+0x189c>
10084757c:     	mov	x0, x22
100847580:     	bl	0x100b1e584 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847584:     	cbnz	x0, 0x100846894 <_js_json_stringify_full+0xdd4>
100847588:     	b	0x100847714 <_js_json_stringify_full+0x1c54>
10084758c:     	and	x0, x19, #0xffffffffffff
100847590:     	bl	0x1004f7d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847594:     	mov	w0, w0
100847598:     	mov	x21, #0x7d7b            ; =32123
10084759c:     	movk	x21, #0x200, lsl #32
1008475a0:     	movk	x21, #0x7ff9, lsl #48
1008475a4:     	b	0x1008476f8 <_js_json_stringify_full+0x1c38>
1008475a8:     	mov	x19, x0
1008475ac:     	mov	x0, x22
1008475b0:     	bl	0x100b1e584 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008475b4:     	mov	x22, x0
1008475b8:     	mov	x0, x19
1008475bc:     	cbnz	x22, 0x100846e78 <_js_json_stringify_full+0x13b8>
1008475c0:     	cbnz	x23, 0x1008476a4 <_js_json_stringify_full+0x1be4>
1008475c4:     	b	0x100847714 <_js_json_stringify_full+0x1c54>
1008475c8:     	bl	0x100b1e6e4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
1008475cc:     	cbnz	x0, 0x1008467bc <_js_json_stringify_full+0xcfc>
1008475d0:     	b	0x100847714 <_js_json_stringify_full+0x1c54>
1008475d4:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1008475d8:     	add	x0, x0, #0x440
1008475dc:     	bl	0x100b1272c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008475e0:     	cmp	w8, #0x1
1008475e4:     	b.ne	0x100847714 <_js_json_stringify_full+0x1c54>
1008475e8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008475ec:     	add	x1, x1, #0x998
1008475f0:     	mov	x19, x0
1008475f4:     	bl	0x100a2045c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008475f8:     	mov	x0, x19
1008475fc:     	strb	wzr, [x19, #0x20]
100847600:     	ldr	x8, [x19]
100847604:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847608:     	cmp	x8, x9
10084760c:     	b.lo	0x1008469dc <_js_json_stringify_full+0xf1c>
100847610:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847614:     	add	x0, x0, #0xea8
100847618:     	bl	0x100b1275c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084761c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847620:     	add	x0, x0, #0xec0
100847624:     	bl	0x100b1272c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847628:     	and	x0, x19, #0xffffffffffff
10084762c:     	bl	0x1004ef9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
100847630:     	mov	x21, x1
100847634:     	b	0x1008476f8 <_js_json_stringify_full+0x1c38>
100847638:     	mov	x0, x22
10084763c:     	bl	0x100b1e584 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847640:     	mov	x22, x0
100847644:     	cbnz	x0, 0x100846d28 <_js_json_stringify_full+0x1268>
100847648:     	b	0x1008476a0 <_js_json_stringify_full+0x1be0>
10084764c:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847650:     	add	x0, x0, #0xd70
100847654:     	bl	0x100b1275c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847658:     	bl	0x100b4b954 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084765c:     	cmp	w8, #0x2
100847660:     	b.eq	0x100847714 <_js_json_stringify_full+0x1c54>
100847664:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847668:     	add	x1, x1, #0x998
10084766c:     	mov	x19, x0
100847670:     	bl	0x100a2045c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847674:     	mov	x0, x19
100847678:     	strb	wzr, [x19, #0x20]
10084767c:     	ldr	x8, [x19]
100847680:     	cbz	x8, 0x100846d14 <_js_json_stringify_full+0x1254>
100847684:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847688:     	add	x0, x0, #0xe90
10084768c:     	bl	0x100b1272c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847690:     	mov	x0, x22
100847694:     	bl	0x100b1e584 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847698:     	mov	x22, x0
10084769c:     	cbnz	x0, 0x100846c44 <_js_json_stringify_full+0x1184>
1008476a0:     	cbz	x21, 0x100847714 <_js_json_stringify_full+0x1c54>
1008476a4:     	mov	x0, x19
1008476a8:     	bl	0x100b5efc0 <_mi_free>
1008476ac:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008476b0:     	add	x0, x0, #0xc18
1008476b4:     	bl	0x100b5861c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008476b8:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xa74>
1008476bc:     	add	x0, x0, #0x4b0
1008476c0:     	mov	w1, #0xf                ; =15
1008476c4:     	bl	0x100b4b91c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008476c8:     	and	x0, x19, #0xffffffffffff
1008476cc:     	add	x2, sp, #0x70
1008476d0:     	mov	x1, x22
1008476d4:     	bl	0x1004f01c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008476d8:     	tbnz	w0, #0x0, 0x100847108 <_js_json_stringify_full+0x1648>
1008476dc:     	mov	w21, #0x2               ; =2
1008476e0:     	and	x0, x19, #0xffffffffffff
1008476e4:     	mov	x1, x21
1008476e8:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
1008476ec:     	mov	x21, x1
1008476f0:     	mov	x26, #0x1               ; =1
1008476f4:     	movk	x26, #0x7ffc, lsl #48
1008476f8:     	tbnz	w0, #0x0, 0x100846f94 <_js_json_stringify_full+0x14d4>
1008476fc:     	mov	w21, #0x1               ; =1
100847700:     	cmp	x19, x26
100847704:     	b.eq	0x100846f8c <_js_json_stringify_full+0x14cc>
100847708:     	b	0x1008460b4 <_js_json_stringify_full+0x5f4>
10084770c:     	cmp	w8, #0x2
100847710:     	b.ne	0x10084773c <_js_json_stringify_full+0x1c7c>
100847714:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847718:     	add	x0, x0, #0xc18
10084771c:     	bl	0x100b5861c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847720:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
100847724:     	add	x0, x0, #0x800
100847728:     	bl	0x100b127f0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10084772c:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xa74>
100847730:     	add	x0, x0, #0x1e7
100847734:     	mov	w1, #0xb                ; =11
100847738:     	bl	0x100b4b91c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084773c:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847740:     	add	x1, x1, #0x998
100847744:     	mov	x19, x0
100847748:     	bl	0x100a2045c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084774c:     	mov	x0, x19
100847750:     	strb	wzr, [x19, #0x20]
100847754:     	ldr	x8, [x19]
100847758:     	cbz	x8, 0x100846c30 <_js_json_stringify_full+0x1170>
10084775c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847760:     	add	x0, x0, #0xe78
100847764:     	bl	0x100b1272c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847768:     	mov	w0, #0x1                ; =1
10084776c:     	mov	x1, x23
100847770:     	bl	0x100b12380 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847774:     	mov	w0, #0x1                ; =1
100847778:     	mov	x1, x21
10084777c:     	bl	0x100b12380 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847780:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847784:     	add	x2, x2, #0x3c8
100847788:     	mov	w0, #0x5                ; =5
10084778c:     	mov	w1, #0x5                ; =5
100847790:     	bl	0x100b1288c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
