
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/r22-shared-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845a40 <_js_json_stringify_full>:
100845a40:     	sub	sp, sp, #0x110
100845a44:     	stp	d9, d8, [sp, #0xa0]
100845a48:     	stp	x28, x27, [sp, #0xb0]
100845a4c:     	stp	x26, x25, [sp, #0xc0]
100845a50:     	stp	x24, x23, [sp, #0xd0]
100845a54:     	stp	x22, x21, [sp, #0xe0]
100845a58:     	stp	x20, x19, [sp, #0xf0]
100845a5c:     	stp	x29, x30, [sp, #0x100]
100845a60:     	add	x29, sp, #0x100
100845a64:     	mov.16b	v9, v2
100845a68:     	mov.16b	v8, v0
100845a6c:     	mov	x26, #0x1               ; =1
100845a70:     	movk	x26, #0x7ffc, lsl #48
100845a74:     	fmov	x19, d8
100845a78:     	fmov	x20, d1
100845a7c:     	fmov	x23, d9
100845a80:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845a84:     	add	x9, x23, x8
100845a88:     	add	x27, x20, x8
100845a8c:     	cmp	x9, #0x2
100845a90:     	b.hs	0x100845aac <_js_json_stringify_full+0x6c>
100845a94:     	cmp	x27, #0x2
100845a98:     	b.lo	0x100845abc <_js_json_stringify_full+0x7c>
100845a9c:     	mov	w21, #0x0               ; =0
100845aa0:     	cmp	x19, x26
100845aa4:     	b.eq	0x100846f0c <_js_json_stringify_full+0x14cc>
100845aa8:     	b	0x100846034 <_js_json_stringify_full+0x5f4>
100845aac:     	add	x8, x26, #0x2
100845ab0:     	cmp	x23, x8
100845ab4:     	ccmp	x27, #0x2, #0x2, eq
100845ab8:     	b.hs	0x100845a9c <_js_json_stringify_full+0x5c>
100845abc:     	mov	x8, #-0x2               ; =-2
100845ac0:     	movk	x8, #0x8003, lsl #48
100845ac4:     	add	x8, x19, x8
100845ac8:     	cmp	x8, #0x3
100845acc:     	b.hs	0x100845ae0 <_js_json_stringify_full+0xa0>
100845ad0:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100845ad4:     	add	x9, x9, #0x6d8
100845ad8:     	ldr	x21, [x9, x8, lsl #3]
100845adc:     	b	0x100846f14 <_js_json_stringify_full+0x14d4>
100845ae0:     	strb	wzr, [sp, #0x3c]
100845ae4:     	str	wzr, [sp, #0x38]
100845ae8:     	and	x8, x19, #0xffff000000000000
100845aec:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845af0:     	cmp	x8, x9
100845af4:     	b.eq	0x100845b68 <_js_json_stringify_full+0x128>
100845af8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845afc:     	cmp	x8, x9
100845b00:     	b.ne	0x100845f64 <_js_json_stringify_full+0x524>
100845b04:     	ubfx	x10, x19, #40, #8
100845b08:     	cbz	x10, 0x100845b58 <_js_json_stringify_full+0x118>
100845b0c:     	strb	w19, [sp, #0x38]
100845b10:     	cmp	x10, #0x1
100845b14:     	b.eq	0x100845b58 <_js_json_stringify_full+0x118>
100845b18:     	lsr	x9, x19, #8
100845b1c:     	strb	w9, [sp, #0x39]
100845b20:     	cmp	x10, #0x2
100845b24:     	b.eq	0x100845b58 <_js_json_stringify_full+0x118>
100845b28:     	lsr	x9, x19, #16
100845b2c:     	strb	w9, [sp, #0x3a]
100845b30:     	cmp	x10, #0x3
100845b34:     	b.eq	0x100845b58 <_js_json_stringify_full+0x118>
100845b38:     	lsr	x9, x19, #24
100845b3c:     	strb	w9, [sp, #0x3b]
100845b40:     	cmp	x10, #0x4
100845b44:     	b.eq	0x100845b58 <_js_json_stringify_full+0x118>
100845b48:     	lsr	x9, x19, #32
100845b4c:     	strb	w9, [sp, #0x3c]
100845b50:     	cmp	x10, #0x5
100845b54:     	b.ne	0x100847700 <_js_json_stringify_full+0x1cc0>
100845b58:     	add	x11, sp, #0x38
100845b5c:     	cmp	w10, #0x3
100845b60:     	b.ls	0x100845b80 <_js_json_stringify_full+0x140>
100845b64:     	b	0x100845f64 <_js_json_stringify_full+0x524>
100845b68:     	ands	x9, x19, #0xffffffffffff
100845b6c:     	b.eq	0x100846028 <_js_json_stringify_full+0x5e8>
100845b70:     	add	x11, x9, #0x14
100845b74:     	ldr	w10, [x9, #0x4]
100845b78:     	cmp	w10, #0x3
100845b7c:     	b.hi	0x100845f64 <_js_json_stringify_full+0x524>
100845b80:     	stur	wzr, [sp, #0x71]
100845b84:     	mov	w9, #0x22               ; =34
100845b88:     	strb	w9, [sp, #0x70]
100845b8c:     	cbz	w10, 0x100845bc4 <_js_json_stringify_full+0x184>
100845b90:     	add	x12, sp, #0x70
100845b94:     	ldrb	w13, [x11]
100845b98:     	sxtb	w15, w13
100845b9c:     	cmp	w13, #0xb
100845ba0:     	b.le	0x100845bcc <_js_json_stringify_full+0x18c>
100845ba4:     	cmp	w13, #0x21
100845ba8:     	b.gt	0x100845bec <_js_json_stringify_full+0x1ac>
100845bac:     	cmp	w13, #0xc
100845bb0:     	b.eq	0x100845c20 <_js_json_stringify_full+0x1e0>
100845bb4:     	cmp	w13, #0xd
100845bb8:     	b.ne	0x100845bfc <_js_json_stringify_full+0x1bc>
100845bbc:     	mov	w15, #0x72              ; =114
100845bc0:     	b	0x100845c2c <_js_json_stringify_full+0x1ec>
100845bc4:     	mov	w12, #0x1               ; =1
100845bc8:     	b	0x100845c54 <_js_json_stringify_full+0x214>
100845bcc:     	cmp	w13, #0x8
100845bd0:     	b.eq	0x100845c18 <_js_json_stringify_full+0x1d8>
100845bd4:     	cmp	w13, #0x9
100845bd8:     	b.eq	0x100845c28 <_js_json_stringify_full+0x1e8>
100845bdc:     	cmp	w13, #0xa
100845be0:     	b.ne	0x100845bfc <_js_json_stringify_full+0x1bc>
100845be4:     	mov	w15, #0x6e              ; =110
100845be8:     	b	0x100845c2c <_js_json_stringify_full+0x1ec>
100845bec:     	cmp	w13, #0x22
100845bf0:     	b.eq	0x100845c2c <_js_json_stringify_full+0x1ec>
100845bf4:     	cmp	w13, #0x5c
100845bf8:     	b.eq	0x100845c2c <_js_json_stringify_full+0x1ec>
100845bfc:     	cmp	w15, #0x20
100845c00:     	b.lt	0x100845f64 <_js_json_stringify_full+0x524>
100845c04:     	mov	w14, #0x0               ; =0
100845c08:     	add	x13, x12, #0x2
100845c0c:     	mov	w12, #0x2               ; =2
100845c10:     	mov	w16, #0x1               ; =1
100845c14:     	b	0x100845c44 <_js_json_stringify_full+0x204>
100845c18:     	mov	w15, #0x62              ; =98
100845c1c:     	b	0x100845c2c <_js_json_stringify_full+0x1ec>
100845c20:     	mov	w15, #0x66              ; =102
100845c24:     	b	0x100845c2c <_js_json_stringify_full+0x1ec>
100845c28:     	mov	w15, #0x74              ; =116
100845c2c:     	add	x13, x12, #0x3
100845c30:     	mov	w12, #0x5c              ; =92
100845c34:     	strb	w12, [sp, #0x71]
100845c38:     	mov	w14, #0x1               ; =1
100845c3c:     	mov	w12, #0x3               ; =3
100845c40:     	mov	w16, #0x2               ; =2
100845c44:     	add	x17, sp, #0x70
100845c48:     	strb	w15, [x17, x16]
100845c4c:     	cmp	w10, #0x1
100845c50:     	b.ne	0x100845c8c <_js_json_stringify_full+0x24c>
100845c54:     	add	x10, sp, #0x70
100845c58:     	strb	w9, [x10, x12]
100845c5c:     	add	x8, x12, #0x1
100845c60:     	cmp	x12, #0x3
100845c64:     	b.hs	0x100845c78 <_js_json_stringify_full+0x238>
100845c68:     	mov	x13, #0x0               ; =0
100845c6c:     	mov	x11, #0x0               ; =0
100845c70:     	add	x9, sp, #0x70
100845c74:     	b	0x100845ed4 <_js_json_stringify_full+0x494>
100845c78:     	cmp	x12, #0xf
100845c7c:     	b.hs	0x100845cbc <_js_json_stringify_full+0x27c>
100845c80:     	mov	x11, #0x0               ; =0
100845c84:     	mov	x13, #0x0               ; =0
100845c88:     	b	0x100845e30 <_js_json_stringify_full+0x3f0>
100845c8c:     	ldrb	w16, [x11, #0x1]
100845c90:     	sxtb	w15, w16
100845c94:     	cmp	w16, #0xb
100845c98:     	b.le	0x100845f04 <_js_json_stringify_full+0x4c4>
100845c9c:     	cmp	w16, #0x21
100845ca0:     	b.gt	0x100845f24 <_js_json_stringify_full+0x4e4>
100845ca4:     	cmp	w16, #0xc
100845ca8:     	b.eq	0x100845f54 <_js_json_stringify_full+0x514>
100845cac:     	cmp	w16, #0xd
100845cb0:     	b.ne	0x100845f34 <_js_json_stringify_full+0x4f4>
100845cb4:     	mov	w15, #0x72              ; =114
100845cb8:     	b	0x100845f60 <_js_json_stringify_full+0x520>
100845cbc:     	and	x12, x8, #0xc
100845cc0:     	and	x11, x8, #0x10
100845cc4:     	add	x13, sp, #0x70
100845cc8:     	add	x9, x13, x11
100845ccc:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845cd0:     	ldr	q0, [x14, #0x850]
100845cd4:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845cd8:     	ldr	q1, [x14, #0x860]
100845cdc:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845ce0:     	ldr	q2, [x14, #0x870]
100845ce4:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845ce8:     	ldr	q3, [x14, #0x880]
100845cec:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845cf0:     	ldr	q4, [x14, #0x890]
100845cf4:     	movi.2d	v5, #0000000000000000
100845cf8:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845cfc:     	ldr	q6, [x14, #0x8a0]
100845d00:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100845d04:     	ldr	q7, [x14, #0x9c0]
100845d08:     	mov	w14, #0x10              ; =16
100845d0c:     	movi.2d	v16, #0000000000000000
100845d10:     	dup.2d	v17, x14
100845d14:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x336ba>
100845d18:     	ldr	q19, [x14, #0x8c0]
100845d1c:     	and	x14, x8, #0x10
100845d20:     	movi.2d	v20, #0000000000000000
100845d24:     	movi.2d	v18, #0000000000000000
100845d28:     	movi.2d	v23, #0000000000000000
100845d2c:     	movi.2d	v21, #0000000000000000
100845d30:     	movi.2d	v24, #0000000000000000
100845d34:     	movi.2d	v22, #0000000000000000
100845d38:     	ldr	q25, [x13], #0x10
100845d3c:     	ushll.8h	v26, v25, #0x0
100845d40:     	ushll2.4s	v27, v26, #0x0
100845d44:     	ushll2.2d	v28, v27, #0x0
100845d48:     	ushll2.8h	v25, v25, #0x0
100845d4c:     	ushll.4s	v29, v25, #0x0
100845d50:     	ushll2.2d	v30, v29, #0x0
100845d54:     	ushll.2d	v29, v29, #0x0
100845d58:     	ushll.2d	v27, v27, #0x0
100845d5c:     	ushll.4s	v26, v26, #0x0
100845d60:     	ushll2.2d	v31, v26, #0x0
100845d64:     	ushll2.4s	v25, v25, #0x0
100845d68:     	ushll.2d	v8, v25, #0x0
100845d6c:     	ushll.2d	v26, v26, #0x0
100845d70:     	ushll2.2d	v25, v25, #0x0
100845d74:     	shl.2d	v9, v0, #0x3
100845d78:     	ushl.2d	v25, v25, v9
100845d7c:     	shl.2d	v9, v19, #0x3
100845d80:     	ushl.2d	v26, v26, v9
100845d84:     	shl.2d	v9, v1, #0x3
100845d88:     	ushl.2d	v8, v8, v9
100845d8c:     	shl.2d	v9, v7, #0x3
100845d90:     	ushl.2d	v31, v31, v9
100845d94:     	shl.2d	v9, v6, #0x3
100845d98:     	ushl.2d	v27, v27, v9
100845d9c:     	shl.2d	v9, v3, #0x3
100845da0:     	ushl.2d	v29, v29, v9
100845da4:     	shl.2d	v9, v2, #0x3
100845da8:     	ushl.2d	v30, v30, v9
100845dac:     	shl.2d	v9, v4, #0x3
100845db0:     	ushl.2d	v28, v28, v9
100845db4:     	orr.16b	v18, v28, v18
100845db8:     	orr.16b	v21, v30, v21
100845dbc:     	orr.16b	v23, v29, v23
100845dc0:     	orr.16b	v20, v27, v20
100845dc4:     	orr.16b	v5, v31, v5
100845dc8:     	orr.16b	v24, v8, v24
100845dcc:     	orr.16b	v16, v26, v16
100845dd0:     	orr.16b	v22, v25, v22
100845dd4:     	add.2d	v6, v6, v17
100845dd8:     	add.2d	v7, v7, v17
100845ddc:     	add.2d	v19, v19, v17
100845de0:     	add.2d	v4, v4, v17
100845de4:     	add.2d	v3, v3, v17
100845de8:     	add.2d	v2, v2, v17
100845dec:     	add.2d	v1, v1, v17
100845df0:     	add.2d	v0, v0, v17
100845df4:     	subs	x14, x14, #0x10
100845df8:     	b.ne	0x100845d38 <_js_json_stringify_full+0x2f8>
100845dfc:     	orr.16b	v0, v16, v23
100845e00:     	orr.16b	v1, v20, v24
100845e04:     	orr.16b	v0, v0, v1
100845e08:     	orr.16b	v1, v5, v21
100845e0c:     	orr.16b	v2, v18, v22
100845e10:     	orr.16b	v1, v1, v2
100845e14:     	orr.16b	v0, v0, v1
100845e18:     	mov	d1, v0[1]
100845e1c:     	orr.8b	v0, v0, v1
100845e20:     	fmov	x13, d0
100845e24:     	cmp	x8, x11
100845e28:     	b.eq	0x100845ef4 <_js_json_stringify_full+0x4b4>
100845e2c:     	cbz	x12, 0x100845ed4 <_js_json_stringify_full+0x494>
100845e30:     	mov	x14, x11
100845e34:     	and	x11, x8, #0x1c
100845e38:     	add	x15, sp, #0x70
100845e3c:     	add	x9, x15, x11
100845e40:     	fmov	d0, x13
100845e44:     	movi.2d	v1, #0000000000000000
100845e48:     	dup.2d	v3, x14
100845e4c:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100845e50:     	ldr	q2, [x12, #0x9c0]
100845e54:     	orr.16b	v2, v3, v2
100845e58:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x336ba>
100845e5c:     	ldr	q4, [x12, #0x8c0]
100845e60:     	orr.16b	v3, v3, v4
100845e64:     	sub	x12, x14, x11
100845e68:     	add	x13, x15, x14
100845e6c:     	movi.2d	v4, #0x000000000000ff
100845e70:     	mov	w14, #0x4               ; =4
100845e74:     	dup.2d	v5, x14
100845e78:     	ldr	s6, [x13], #0x4
100845e7c:     	ushll.8h	v6, v6, #0x0
100845e80:     	ushll.4s	v6, v6, #0x0
100845e84:     	ushll2.2d	v7, v6, #0x0
100845e88:     	and.16b	v7, v7, v4
100845e8c:     	ushll.2d	v6, v6, #0x0
100845e90:     	and.16b	v6, v6, v4
100845e94:     	shl.2d	v16, v2, #0x3
100845e98:     	shl.2d	v17, v3, #0x3
100845e9c:     	ushl.2d	v6, v6, v17
100845ea0:     	ushl.2d	v7, v7, v16
100845ea4:     	orr.16b	v1, v7, v1
100845ea8:     	orr.16b	v0, v6, v0
100845eac:     	add.2d	v2, v2, v5
100845eb0:     	add.2d	v3, v3, v5
100845eb4:     	adds	x12, x12, #0x4
100845eb8:     	b.ne	0x100845e78 <_js_json_stringify_full+0x438>
100845ebc:     	orr.16b	v0, v0, v1
100845ec0:     	mov	d1, v0[1]
100845ec4:     	orr.8b	v0, v0, v1
100845ec8:     	fmov	x13, d0
100845ecc:     	cmp	x8, x11
100845ed0:     	b.eq	0x100845ef4 <_js_json_stringify_full+0x4b4>
100845ed4:     	add	x10, x10, x8
100845ed8:     	lsl	x11, x11, #3
100845edc:     	ldrb	w12, [x9], #0x1
100845ee0:     	lsl	x12, x12, x11
100845ee4:     	orr	x13, x12, x13
100845ee8:     	add	x11, x11, #0x8
100845eec:     	cmp	x9, x10
100845ef0:     	b.ne	0x100845edc <_js_json_stringify_full+0x49c>
100845ef4:     	orr	x8, x13, x8, lsl #40
100845ef8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845efc:     	orr	x21, x8, x9
100845f00:     	b	0x100846f14 <_js_json_stringify_full+0x14d4>
100845f04:     	cmp	w16, #0x8
100845f08:     	b.eq	0x100845f4c <_js_json_stringify_full+0x50c>
100845f0c:     	cmp	w16, #0x9
100845f10:     	b.eq	0x100845f5c <_js_json_stringify_full+0x51c>
100845f14:     	cmp	w16, #0xa
100845f18:     	b.ne	0x100845f34 <_js_json_stringify_full+0x4f4>
100845f1c:     	mov	w15, #0x6e              ; =110
100845f20:     	b	0x100845f60 <_js_json_stringify_full+0x520>
100845f24:     	cmp	w16, #0x22
100845f28:     	b.eq	0x100845f60 <_js_json_stringify_full+0x520>
100845f2c:     	cmp	w16, #0x5c
100845f30:     	b.eq	0x100845f60 <_js_json_stringify_full+0x520>
100845f34:     	cmp	w15, #0x20
100845f38:     	b.lt	0x100845f64 <_js_json_stringify_full+0x524>
100845f3c:     	add	x13, sp, #0x70
100845f40:     	strb	w15, [x13, x12]
100845f44:     	add	x12, x12, #0x1
100845f48:     	b	0x1008464e0 <_js_json_stringify_full+0xaa0>
100845f4c:     	mov	w15, #0x62              ; =98
100845f50:     	b	0x100845f60 <_js_json_stringify_full+0x520>
100845f54:     	mov	w15, #0x66              ; =102
100845f58:     	b	0x100845f60 <_js_json_stringify_full+0x520>
100845f5c:     	mov	w15, #0x74              ; =116
100845f60:     	tbz	w14, #0x0, 0x1008464cc <_js_json_stringify_full+0xa8c>
100845f64:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100845f68:     	cmp	x8, x9
100845f6c:     	b.eq	0x100845fb4 <_js_json_stringify_full+0x574>
100845f70:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845f74:     	cmp	x8, x9
100845f78:     	b.ne	0x100846028 <_js_json_stringify_full+0x5e8>
100845f7c:     	and	x8, x19, #0xffffffffffff
100845f80:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100845f84:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100845f88:     	movk	x10, #0xffef, lsl #16
100845f8c:     	cmp	x9, x10
100845f90:     	b.hi	0x100846028 <_js_json_stringify_full+0x5e8>
100845f94:     	ldr	w8, [x8, #0x4]
100845f98:     	cmp	w8, #0x40
100845f9c:     	b.lo	0x100846028 <_js_json_stringify_full+0x5e8>
100845fa0:     	and	x0, x19, #0xffffffffffff
100845fa4:     	bl	0x1004f2ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845fa8:     	cmp	x0, #0x1
100845fac:     	b.ne	0x100846028 <_js_json_stringify_full+0x5e8>
100845fb0:     	b	0x100846168 <_js_json_stringify_full+0x728>
100845fb4:     	and	x24, x19, #0xffffffffffff
100845fb8:     	and	x0, x19, #0xffffffffffff
100845fbc:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100845fc0:     	cbz	x0, 0x100845ff4 <_js_json_stringify_full+0x5b4>
100845fc4:     	ldrb	w8, [x0]
100845fc8:     	cmp	w8, #0x2
100845fcc:     	b.ne	0x100845ff4 <_js_json_stringify_full+0x5b4>
100845fd0:     	ldrsb	w8, [x0, #0x1]
100845fd4:     	tbnz	w8, #0x1f, 0x100845ff4 <_js_json_stringify_full+0x5b4>
100845fd8:     	ldrh	w8, [x0, #0x2]
100845fdc:     	tbnz	w8, #0xb, 0x100845ff4 <_js_json_stringify_full+0x5b4>
100845fe0:     	ldr	w8, [x0, #0x4]
100845fe4:     	cmp	w8, #0x18
100845fe8:     	b.lo	0x100845ff4 <_js_json_stringify_full+0x5b4>
100845fec:     	ldr	w8, [x24]
100845ff0:     	cbz	w8, 0x100847070 <_js_json_stringify_full+0x1630>
100845ff4:     	and	x0, x19, #0xffffffffffff
100845ff8:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100845ffc:     	cbz	x0, 0x100846028 <_js_json_stringify_full+0x5e8>
100846000:     	ldrb	w8, [x0]
100846004:     	cmp	w8, #0x2
100846008:     	b.ne	0x100846028 <_js_json_stringify_full+0x5e8>
10084600c:     	ldrh	w8, [x0, #0x2]
100846010:     	tbnz	w8, #0xb, 0x100846028 <_js_json_stringify_full+0x5e8>
100846014:     	ldr	w8, [x0, #0x4]
100846018:     	cmp	w8, #0x18
10084601c:     	b.lo	0x100846028 <_js_json_stringify_full+0x5e8>
100846020:     	ldr	w8, [x24]
100846024:     	cbz	w8, 0x100847014 <_js_json_stringify_full+0x15d4>
100846028:     	mov	w21, #0x1               ; =1
10084602c:     	cmp	x19, x26
100846030:     	b.eq	0x100846f0c <_js_json_stringify_full+0x14cc>
100846034:     	and	x22, x19, #0xffff000000000000
100846038:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084603c:     	cmp	x22, x8
100846040:     	b.ne	0x100846078 <_js_json_stringify_full+0x638>
100846044:     	and	x8, x19, #0xffffffffffff
100846048:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084604c:     	b.lo	0x100846064 <_js_json_stringify_full+0x624>
100846050:     	ldr	w8, [x8, #0xc]
100846054:     	mov	w9, #0x4f53             ; =20307
100846058:     	movk	w9, #0x434c, lsl #16
10084605c:     	cmp	w8, w9
100846060:     	b.eq	0x100846f0c <_js_json_stringify_full+0x14cc>
100846064:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846068:     	cmp	x22, x8
10084606c:     	b.ne	0x1008460a4 <_js_json_stringify_full+0x664>
100846070:     	and	x0, x19, #0xffffffffffff
100846074:     	b	0x1008460cc <_js_json_stringify_full+0x68c>
100846078:     	lsr	x8, x19, #52
10084607c:     	cbnz	x8, 0x100846154 <_js_json_stringify_full+0x714>
100846080:     	and	x8, x19, #0x7
100846084:     	cbz	x19, 0x1008460b0 <_js_json_stringify_full+0x670>
100846088:     	cbnz	x8, 0x1008460b0 <_js_json_stringify_full+0x670>
10084608c:     	mov	x0, x19
100846090:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846094:     	mov	x8, x19
100846098:     	tbnz	w0, #0x0, 0x100846048 <_js_json_stringify_full+0x608>
10084609c:     	mov	x8, #0x0                ; =0
1008460a0:     	b	0x1008460b0 <_js_json_stringify_full+0x670>
1008460a4:     	lsr	x8, x19, #52
1008460a8:     	cbnz	x8, 0x100846154 <_js_json_stringify_full+0x714>
1008460ac:     	and	x8, x19, #0x7
1008460b0:     	cbz	x19, 0x100846154 <_js_json_stringify_full+0x714>
1008460b4:     	cbnz	x8, 0x100846154 <_js_json_stringify_full+0x714>
1008460b8:     	mov	x0, x19
1008460bc:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008460c0:     	mov	x8, x0
1008460c4:     	mov	x0, x19
1008460c8:     	tbz	w8, #0x0, 0x100846154 <_js_json_stringify_full+0x714>
1008460cc:     	cmp	x0, #0x100, lsl #12     ; =0x100000
1008460d0:     	b.lo	0x100846154 <_js_json_stringify_full+0x714>
1008460d4:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1008460d8:     	add	x8, x8, #0xfb0
1008460dc:     	ldaprb	w8, [x8]
1008460e0:     	cbz	w8, 0x100846154 <_js_json_stringify_full+0x714>
1008460e4:     	lsr	x8, x0, #3
1008460e8:     	mov	x9, #0x7c15             ; =31765
1008460ec:     	movk	x9, #0x7f4a, lsl #16
1008460f0:     	movk	x9, #0x79b9, lsl #32
1008460f4:     	movk	x9, #0x9e37, lsl #48
1008460f8:     	mul	x8, x8, x9
1008460fc:     	lsr	x10, x8, #54
100846100:     	lsr	x11, x8, #60
100846104:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100846108:     	add	x9, x9, #0xf30
10084610c:     	add	x11, x9, x11, lsl #3
100846110:     	ldapr	x11, [x11]
100846114:     	lsr	x10, x11, x10
100846118:     	tbz	w10, #0x0, 0x100846154 <_js_json_stringify_full+0x714>
10084611c:     	lsr	x10, x8, #44
100846120:     	ubfx	x11, x8, #50, #4
100846124:     	add	x11, x9, x11, lsl #3
100846128:     	ldapr	x11, [x11]
10084612c:     	lsr	x10, x11, x10
100846130:     	tbz	w10, #0x0, 0x100846154 <_js_json_stringify_full+0x714>
100846134:     	lsr	x10, x8, #34
100846138:     	ubfx	x8, x8, #40, #4
10084613c:     	add	x8, x9, x8, lsl #3
100846140:     	ldapr	x8, [x8]
100846144:     	lsr	x8, x8, x10
100846148:     	tbz	w8, #0x0, 0x100846154 <_js_json_stringify_full+0x714>
10084614c:     	bl	0x10034ca6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100846150:     	tbnz	w0, #0x0, 0x100846f0c <_js_json_stringify_full+0x14cc>
100846154:     	tbz	w21, #0x0, 0x100846174 <_js_json_stringify_full+0x734>
100846158:     	mov.16b	v0, v8
10084615c:     	bl	0x1004eddbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100846160:     	cmp	x0, #0x1
100846164:     	b.ne	0x100846174 <_js_json_stringify_full+0x734>
100846168:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
10084616c:     	bfxil	x21, x1, #0, #48
100846170:     	b	0x100846f14 <_js_json_stringify_full+0x14d4>
100846174:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846178:     	cmp	x22, x8
10084617c:     	b.ne	0x1008461cc <_js_json_stringify_full+0x78c>
100846180:     	ands	x21, x19, #0xffffffffffff
100846184:     	b.eq	0x1008461cc <_js_json_stringify_full+0x78c>
100846188:     	mov	x0, x21
10084618c:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846190:     	cbz	w0, 0x1008461cc <_js_json_stringify_full+0x78c>
100846194:     	ldurb	w8, [x21, #-0x8]
100846198:     	cmp	w8, #0x9
10084619c:     	b.ne	0x1008461cc <_js_json_stringify_full+0x78c>
1008461a0:     	ldr	w8, [x21, #0x4]
1008461a4:     	mov	w9, #0x5841             ; =22593
1008461a8:     	movk	w9, #0x4c5a, lsl #16
1008461ac:     	cmp	w8, w9
1008461b0:     	b.ne	0x1008461cc <_js_json_stringify_full+0x78c>
1008461b4:     	mov	x0, x21
1008461b8:     	bl	0x10068829c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008461bc:     	cbz	x0, 0x1008461cc <_js_json_stringify_full+0x78c>
1008461c0:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1008461c4:     	bfxil	x19, x0, #0, #48
1008461c8:     	fmov	d8, x19
1008461cc:     	mov	w8, #0x7ffd             ; =32765
1008461d0:     	cmp	x8, x23, lsr #48
1008461d4:     	b.ne	0x1008461e8 <_js_json_stringify_full+0x7a8>
1008461d8:     	and	x1, x23, #0xffffffffffff
1008461dc:     	cmp	x1, #0x100, lsl #12     ; =0x100000
1008461e0:     	b.hs	0x1008461fc <_js_json_stringify_full+0x7bc>
1008461e4:     	b	0x100846250 <_js_json_stringify_full+0x810>
1008461e8:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
1008461ec:     	mov	x9, #0xfffffff00000     ; =281474975662080
1008461f0:     	mov	x1, x23
1008461f4:     	cmp	x8, x9
1008461f8:     	b.hs	0x100846250 <_js_json_stringify_full+0x810>
1008461fc:     	lsr	x8, x1, #47
100846200:     	cbnz	x8, 0x100846250 <_js_json_stringify_full+0x810>
100846204:     	add	x0, sp, #0x70
100846208:     	bl	0x10076e0ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084620c:     	ldr	w8, [sp, #0x70]
100846210:     	tbz	w8, #0x0, 0x100846250 <_js_json_stringify_full+0x810>
100846214:     	ldr	w8, [sp, #0x78]
100846218:     	mov	w9, #-0xff30            ; =-65328
10084621c:     	cmp	w8, w9
100846220:     	b.eq	0x100846244 <_js_json_stringify_full+0x804>
100846224:     	mov	w9, #-0xff2f            ; =-65327
100846228:     	cmp	w8, w9
10084622c:     	b.ne	0x100846250 <_js_json_stringify_full+0x810>
100846230:     	mov.16b	v0, v9
100846234:     	bl	0x10084837c <_js_jsvalue_to_string>
100846238:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084623c:     	bfxil	x23, x0, #0, #48
100846240:     	b	0x100846250 <_js_json_stringify_full+0x810>
100846244:     	mov.16b	v0, v9
100846248:     	bl	0x10086f920 <_js_number_coerce>
10084624c:     	fmov	x23, d0
100846250:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100846254:     	add	x8, x23, x8
100846258:     	cmp	x8, #0x3
10084625c:     	b.hs	0x100846274 <_js_json_stringify_full+0x834>
100846260:     	mov	x21, #0x0               ; =0
100846264:     	mov	w8, #0x1                ; =1
100846268:     	stp	xzr, x8, [sp]
10084626c:     	str	xzr, [sp, #0x10]
100846270:     	b	0x100846528 <_js_json_stringify_full+0xae8>
100846274:     	and	x8, x23, #0xffff000000000000
100846278:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084627c:     	cmp	x8, x9
100846280:     	b.eq	0x1008462a4 <_js_json_stringify_full+0x864>
100846284:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846288:     	cmp	x8, x9
10084628c:     	b.ne	0x100846330 <_js_json_stringify_full+0x8f0>
100846290:     	and	x8, x23, #0xffffffffffff
100846294:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846298:     	b.hs	0x100846378 <_js_json_stringify_full+0x938>
10084629c:     	mov	x9, #0x0                ; =0
1008462a0:     	b	0x100846380 <_js_json_stringify_full+0x940>
1008462a4:     	strb	wzr, [sp, #0x3c]
1008462a8:     	str	wzr, [sp, #0x38]
1008462ac:     	ubfx	x1, x23, #40, #8
1008462b0:     	cbz	x1, 0x100846300 <_js_json_stringify_full+0x8c0>
1008462b4:     	strb	w23, [sp, #0x38]
1008462b8:     	cmp	x1, #0x1
1008462bc:     	b.eq	0x100846300 <_js_json_stringify_full+0x8c0>
1008462c0:     	lsr	x8, x23, #8
1008462c4:     	strb	w8, [sp, #0x39]
1008462c8:     	cmp	x1, #0x2
1008462cc:     	b.eq	0x100846300 <_js_json_stringify_full+0x8c0>
1008462d0:     	lsr	x8, x23, #16
1008462d4:     	strb	w8, [sp, #0x3a]
1008462d8:     	cmp	x1, #0x3
1008462dc:     	b.eq	0x100846300 <_js_json_stringify_full+0x8c0>
1008462e0:     	lsr	x8, x23, #24
1008462e4:     	strb	w8, [sp, #0x3b]
1008462e8:     	cmp	x1, #0x4
1008462ec:     	b.eq	0x100846300 <_js_json_stringify_full+0x8c0>
1008462f0:     	lsr	x8, x23, #32
1008462f4:     	strb	w8, [sp, #0x3c]
1008462f8:     	cmp	x1, #0x5
1008462fc:     	b.ne	0x100847700 <_js_json_stringify_full+0x1cc0>
100846300:     	add	x8, sp, #0x70
100846304:     	add	x0, sp, #0x38
100846308:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084630c:     	ldr	w8, [sp, #0x70]
100846310:     	ldp	x9, x21, [sp, #0x78]
100846314:     	cmp	w8, #0x0
100846318:     	csinc	x22, x9, xzr, eq
10084631c:     	csel	x24, xzr, x21, ne
100846320:     	tbz	x24, #0x3f, 0x100846460 <_js_json_stringify_full+0xa20>
100846324:     	mov	x0, #0x0                ; =0
100846328:     	mov	x1, x21
10084632c:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100846330:     	add	x8, x26, #0x3
100846334:     	cmp	x23, x8
100846338:     	b.eq	0x100846260 <_js_json_stringify_full+0x820>
10084633c:     	fmov	d0, x23
100846340:     	fcvtzu	x8, d0
100846344:     	mov	w9, #0xa                ; =10
100846348:     	cmp	x8, #0xa
10084634c:     	csel	x3, x8, x9, lo
100846350:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x1af4>
100846354:     	add	x1, x1, #0x69c
100846358:     	add	x0, sp, #0x70
10084635c:     	mov	w2, #0x1                ; =1
100846360:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100846364:     	ldr	x21, [sp, #0x80]
100846368:     	str	x21, [sp, #0x10]
10084636c:     	ldr	q0, [sp, #0x70]
100846370:     	str	q0, [sp]
100846374:     	b	0x100846528 <_js_json_stringify_full+0xae8>
100846378:     	ldr	w21, [x8, #0x4]
10084637c:     	add	x9, x8, #0x14
100846380:     	mov	x14, #0x0               ; =0
100846384:     	mov	x8, #0x0                ; =0
100846388:     	cmp	x9, #0x0
10084638c:     	csel	x23, xzr, x21, eq
100846390:     	csinc	x22, x9, xzr, ne
100846394:     	add	x9, x22, x23
100846398:     	mov	w10, #0x1               ; =1
10084639c:     	mov	x11, x22
1008463a0:     	b	0x1008463d0 <_js_json_stringify_full+0x990>
1008463a4:     	add	x12, x11, #0x2
1008463a8:     	bfi	w15, w13, #6, #5
1008463ac:     	mov	x13, x15
1008463b0:     	sub	x11, x24, x11
1008463b4:     	add	x14, x11, x12
1008463b8:     	cmp	w13, #0x10, lsl #12     ; =0x10000
1008463bc:     	cinc	x11, x10, hs
1008463c0:     	add	x8, x11, x8
1008463c4:     	mov	x11, x12
1008463c8:     	cmp	x8, #0xa
1008463cc:     	b.hi	0x100846488 <_js_json_stringify_full+0xa48>
1008463d0:     	cmp	x11, x9
1008463d4:     	b.eq	0x100846438 <_js_json_stringify_full+0x9f8>
1008463d8:     	mov	x24, x14
1008463dc:     	mov	x12, x11
1008463e0:     	ldrsb	w14, [x12], #0x1
1008463e4:     	and	w13, w14, #0xff
1008463e8:     	tbz	w14, #0x1f, 0x1008463b0 <_js_json_stringify_full+0x970>
1008463ec:     	ldrb	w12, [x11, #0x1]
1008463f0:     	and	w15, w12, #0x3f
1008463f4:     	cmp	w13, #0xe0
1008463f8:     	b.lo	0x1008463a4 <_js_json_stringify_full+0x964>
1008463fc:     	and	w14, w13, #0x1f
100846400:     	ldrb	w12, [x11, #0x2]
100846404:     	and	w12, w12, #0x3f
100846408:     	orr	w15, w12, w15, lsl #6
10084640c:     	cmp	w13, #0xf0
100846410:     	b.lo	0x10084642c <_js_json_stringify_full+0x9ec>
100846414:     	add	x12, x11, #0x4
100846418:     	ldrb	w13, [x11, #0x3]
10084641c:     	and	w13, w13, #0x3f
100846420:     	orr	w13, w13, w15, lsl #6
100846424:     	bfi	w13, w14, #18, #3
100846428:     	b	0x1008463b0 <_js_json_stringify_full+0x970>
10084642c:     	add	x12, x11, #0x3
100846430:     	orr	w13, w15, w14, lsl #12
100846434:     	b	0x1008463b0 <_js_json_stringify_full+0x970>
100846438:     	cbz	x23, 0x1008464bc <_js_json_stringify_full+0xa7c>
10084643c:     	mov	x0, x23
100846440:     	mov	w1, #0x1                ; =1
100846444:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
100846448:     	cbz	x0, 0x1008476e8 <_js_json_stringify_full+0x1ca8>
10084644c:     	mov	x25, x0
100846450:     	mov	x1, x22
100846454:     	mov	x2, x23
100846458:     	bl	0x100b61dec <_writev+0x100b61dec>
10084645c:     	b	0x1008464c4 <_js_json_stringify_full+0xa84>
100846460:     	cbz	x24, 0x100846518 <_js_json_stringify_full+0xad8>
100846464:     	mov	x0, x24
100846468:     	mov	w1, #0x1                ; =1
10084646c:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
100846470:     	cbz	x0, 0x1008476f4 <_js_json_stringify_full+0x1cb4>
100846474:     	mov	x23, x0
100846478:     	mov	x1, x22
10084647c:     	mov	x2, x24
100846480:     	bl	0x100b61dec <_writev+0x100b61dec>
100846484:     	b	0x100846520 <_js_json_stringify_full+0xae0>
100846488:     	cbz	x24, 0x1008464bc <_js_json_stringify_full+0xa7c>
10084648c:     	cmp	x24, x23
100846490:     	b.hs	0x100846f68 <_js_json_stringify_full+0x1528>
100846494:     	ldrsb	w8, [x22, x24]
100846498:     	cmn	w8, #0x40
10084649c:     	b.ge	0x100846f6c <_js_json_stringify_full+0x152c>
1008464a0:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008464a4:     	add	x4, x4, #0x270
1008464a8:     	mov	x0, x22
1008464ac:     	mov	x1, x23
1008464b0:     	mov	x2, #0x0                ; =0
1008464b4:     	mov	x3, x24
1008464b8:     	bl	0x100b12678 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
1008464bc:     	mov	x21, #0x0               ; =0
1008464c0:     	mov	w25, #0x1               ; =1
1008464c4:     	stp	x21, x25, [sp]
1008464c8:     	b	0x100846524 <_js_json_stringify_full+0xae4>
1008464cc:     	add	x14, sp, #0x70
1008464d0:     	mov	w16, #0x5c              ; =92
1008464d4:     	strb	w16, [x14, x12]
1008464d8:     	add	x12, x12, #0x2
1008464dc:     	strb	w15, [x13, #0x1]
1008464e0:     	cmp	w10, #0x2
1008464e4:     	b.eq	0x100845c54 <_js_json_stringify_full+0x214>
1008464e8:     	ldrb	w11, [x11, #0x2]
1008464ec:     	sxtb	w10, w11
1008464f0:     	cmp	w11, #0xb
1008464f4:     	b.le	0x100846ff4 <_js_json_stringify_full+0x15b4>
1008464f8:     	cmp	w11, #0x21
1008464fc:     	b.gt	0x100847040 <_js_json_stringify_full+0x1600>
100846500:     	cmp	w11, #0xc
100846504:     	b.eq	0x1008470cc <_js_json_stringify_full+0x168c>
100846508:     	cmp	w11, #0xd
10084650c:     	b.ne	0x100847050 <_js_json_stringify_full+0x1610>
100846510:     	mov	w10, #0x72              ; =114
100846514:     	b	0x1008470d8 <_js_json_stringify_full+0x1698>
100846518:     	mov	x21, #0x0               ; =0
10084651c:     	mov	w23, #0x1               ; =1
100846520:     	stp	x21, x23, [sp]
100846524:     	str	x21, [sp, #0x10]
100846528:     	cmp	x27, #0x2
10084652c:     	b.lo	0x10084666c <_js_json_stringify_full+0xc2c>
100846530:     	and	x24, x20, #0xffff000000000000
100846534:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846538:     	cmp	x24, x8
10084653c:     	b.ne	0x100846648 <_js_json_stringify_full+0xc08>
100846540:     	and	x22, x20, #0xffffffffffff
100846544:     	cmp	x22, #0x100, lsl #12    ; =0x100000
100846548:     	b.lo	0x10084666c <_js_json_stringify_full+0xc2c>
10084654c:     	mov	x0, x22
100846550:     	bl	0x10050a680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100846554:     	tbnz	w0, #0x0, 0x10084666c <_js_json_stringify_full+0xc2c>
100846558:     	lsr	x8, x22, #51
10084655c:     	cmp	x8, #0xfff
100846560:     	b.lo	0x100846578 <_js_json_stringify_full+0xb38>
100846564:     	mov	w8, #0x7ffc             ; =32764
100846568:     	cmp	x8, x22, lsr #48
10084656c:     	b.eq	0x10084666c <_js_json_stringify_full+0xc2c>
100846570:     	ands	x22, x22, #0xffffffffffff
100846574:     	b.eq	0x10084666c <_js_json_stringify_full+0xc2c>
100846578:     	and	x8, x22, #0xfffffffffff00000
10084657c:     	lsr	x9, x22, #47
100846580:     	cmp	x9, #0x0
100846584:     	ccmp	x8, #0x0, #0x4, eq
100846588:     	b.eq	0x10084666c <_js_json_stringify_full+0xc2c>
10084658c:     	tst	x22, #0x3
100846590:     	ccmp	x22, #0x7, #0x0, eq
100846594:     	b.ls	0x100847308 <_js_json_stringify_full+0x18c8>
100846598:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084659c:     	ldr	x8, [x8, #0x48]
1008465a0:     	cmn	x8, #0x1
1008465a4:     	b.eq	0x100847258 <_js_json_stringify_full+0x1818>
1008465a8:     	mrs	x9, TPIDRRO_EL0
1008465ac:     	and	x9, x9, #0xfffffffffffffff8
1008465b0:     	ldr	x0, [x9, x8, lsl #3]
1008465b4:     	cbz	x0, 0x100847258 <_js_json_stringify_full+0x1818>
1008465b8:     	lsr	x1, x22, #20
1008465bc:     	ldr	x8, [x0, #0x10]
1008465c0:     	ldrb	w9, [x8]
1008465c4:     	cmp	w9, #0x2
1008465c8:     	b.ne	0x100847270 <_js_json_stringify_full+0x1830>
1008465cc:     	ldrb	w9, [x8, #0x88]
1008465d0:     	tbz	w9, #0x0, 0x1008465f0 <_js_json_stringify_full+0xbb0>
1008465d4:     	ldr	x9, [x8, #0x80]
1008465d8:     	cmp	x9, x1
1008465dc:     	b.ne	0x1008465f0 <_js_json_stringify_full+0xbb0>
1008465e0:     	ldp	x9, x10, [x8, #0x60]
1008465e4:     	cmp	x9, x22
1008465e8:     	ccmp	x10, x22, #0x0, ls
1008465ec:     	b.hi	0x100847250 <_js_json_stringify_full+0x1810>
1008465f0:     	ldrb	w9, [x8, #0xb8]
1008465f4:     	cbz	w9, 0x100846614 <_js_json_stringify_full+0xbd4>
1008465f8:     	ldr	x9, [x8, #0xb0]
1008465fc:     	cmp	x9, x1
100846600:     	b.ne	0x100846614 <_js_json_stringify_full+0xbd4>
100846604:     	ldp	x9, x10, [x8, #0x90]
100846608:     	cmp	x9, x22
10084660c:     	ccmp	x10, x22, #0x0, ls
100846610:     	b.hi	0x1008474d8 <_js_json_stringify_full+0x1a98>
100846614:     	ldrb	w9, [x8, #0xe8]
100846618:     	cbz	w9, 0x100847090 <_js_json_stringify_full+0x1650>
10084661c:     	ldr	x9, [x8, #0xe0]
100846620:     	cmp	x9, x1
100846624:     	b.ne	0x100847090 <_js_json_stringify_full+0x1650>
100846628:     	ldr	x9, [x8, #0xc0]
10084662c:     	cmp	x9, x22
100846630:     	b.hi	0x100847090 <_js_json_stringify_full+0x1650>
100846634:     	ldr	x9, [x8, #0xc8]
100846638:     	cmp	x9, x22
10084663c:     	b.ls	0x100847090 <_js_json_stringify_full+0x1650>
100846640:     	add	x9, x8, #0xc0
100846644:     	b	0x1008474dc <_js_json_stringify_full+0x1a9c>
100846648:     	lsr	x8, x20, #52
10084664c:     	cbnz	x8, 0x10084666c <_js_json_stringify_full+0xc2c>
100846650:     	cbz	x20, 0x10084666c <_js_json_stringify_full+0xc2c>
100846654:     	and	x8, x20, #0x7
100846658:     	cbnz	x8, 0x10084666c <_js_json_stringify_full+0xc2c>
10084665c:     	mov	x0, x20
100846660:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846664:     	mov	x22, x20
100846668:     	cbnz	w0, 0x100846544 <_js_json_stringify_full+0xb04>
10084666c:     	mov	x24, #-0x1              ; =-1
100846670:     	str	x24, [sp, #0x20]
100846674:     	mov	w23, #0x1               ; =1
100846678:     	cmp	x27, #0x1
10084667c:     	cset	w8, hi
100846680:     	tst	w8, w23
100846684:     	b.eq	0x1008466f8 <_js_json_stringify_full+0xcb8>
100846688:     	and	x22, x20, #0xffff000000000000
10084668c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846690:     	cmp	x22, x8
100846694:     	b.ne	0x1008466d0 <_js_json_stringify_full+0xc90>
100846698:     	and	x8, x20, #0xffffffffffff
10084669c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008466a0:     	b.lo	0x1008466f8 <_js_json_stringify_full+0xcb8>
1008466a4:     	ldr	w8, [x8, #0xc]
1008466a8:     	mov	w9, #0x4f53             ; =20307
1008466ac:     	movk	w9, #0x434c, lsl #16
1008466b0:     	cmp	w8, w9
1008466b4:     	b.ne	0x1008466f8 <_js_json_stringify_full+0xcb8>
1008466b8:     	and	x8, x20, #0xffffffffffff
1008466bc:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008466c0:     	cmp	x22, x9
1008466c4:     	csel	x28, x8, x20, eq
1008466c8:     	mov	w27, #0x1               ; =1
1008466cc:     	b	0x1008466fc <_js_json_stringify_full+0xcbc>
1008466d0:     	lsr	x8, x20, #52
1008466d4:     	cbnz	x8, 0x1008466f8 <_js_json_stringify_full+0xcb8>
1008466d8:     	mov	w27, #0x0               ; =0
1008466dc:     	cbz	x20, 0x1008466fc <_js_json_stringify_full+0xcbc>
1008466e0:     	and	x8, x20, #0x7
1008466e4:     	cbnz	x8, 0x1008466fc <_js_json_stringify_full+0xcbc>
1008466e8:     	mov	x0, x20
1008466ec:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008466f0:     	mov	x8, x20
1008466f4:     	tbnz	w0, #0x0, 0x10084669c <_js_json_stringify_full+0xc5c>
1008466f8:     	mov	w27, #0x0               ; =0
1008466fc:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846700:     	add	x0, x0, #0xd78
100846704:     	ldr	x8, [x0]
100846708:     	blr	x8
10084670c:     	mov	x20, x0
100846710:     	ldr	w25, [x0]
100846714:     	add	w8, w25, #0x1
100846718:     	str	w8, [x0]
10084671c:     	cbz	w25, 0x10084678c <_js_json_stringify_full+0xd4c>
100846720:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846724:     	add	x0, x0, #0xd00
100846728:     	ldr	x8, [x0]
10084672c:     	blr	x8
100846730:     	ldrb	w8, [x0, #0x20]
100846734:     	cmp	w8, #0x1
100846738:     	b.ne	0x100847548 <_js_json_stringify_full+0x1b08>
10084673c:     	ldr	x8, [x0]
100846740:     	cbnz	x8, 0x100847554 <_js_json_stringify_full+0x1b14>
100846744:     	mov	x8, #-0x1               ; =-1
100846748:     	str	x8, [x0]
10084674c:     	ldr	x22, [x0, #0x18]
100846750:     	ldr	x8, [x0, #0x8]
100846754:     	cmp	x22, x8
100846758:     	b.eq	0x100846f3c <_js_json_stringify_full+0x14fc>
10084675c:     	ldr	x8, [x0, #0x10]
100846760:     	mov	w9, #0x18               ; =24
100846764:     	madd	x8, x22, x9, x8
100846768:     	mov	w9, #0x8                ; =8
10084676c:     	stp	xzr, x9, [x8]
100846770:     	str	xzr, [x8, #0x10]
100846774:     	add	x8, x22, #0x1
100846778:     	str	x8, [x0, #0x18]
10084677c:     	ldr	x8, [x0]
100846780:     	add	x8, x8, #0x1
100846784:     	str	x8, [x0]
100846788:     	b	0x1008467f4 <_js_json_stringify_full+0xdb4>
10084678c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846790:     	add	x0, x0, #0xdc0
100846794:     	ldr	x8, [x0]
100846798:     	blr	x8
10084679c:     	strb	wzr, [x0]
1008467a0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008467a4:     	add	x0, x0, #0xdf0
1008467a8:     	ldr	x8, [x0]
1008467ac:     	blr	x8
1008467b0:     	strb	wzr, [x0]
1008467b4:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008467b8:     	ldr	w22, [x8, #0x5a8]
1008467bc:     	cmp	w22, #0x300
1008467c0:     	b.hs	0x100846f8c <_js_json_stringify_full+0x154c>
1008467c4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1008467c8:     	ldr	x8, [x8, #0x48]
1008467cc:     	cmn	x8, #0x1
1008467d0:     	b.eq	0x100846f7c <_js_json_stringify_full+0x153c>
1008467d4:     	mrs	x9, TPIDRRO_EL0
1008467d8:     	and	x9, x9, #0xfffffffffffffff8
1008467dc:     	ldr	x0, [x9, x8, lsl #3]
1008467e0:     	cbz	x0, 0x100846f7c <_js_json_stringify_full+0x153c>
1008467e4:     	add	x8, x0, x22, lsl #3
1008467e8:     	ldr	x0, [x8, #0x1e8]
1008467ec:     	cbz	x0, 0x100846f8c <_js_json_stringify_full+0x154c>
1008467f0:     	str	xzr, [x0]
1008467f4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008467f8:     	add	x0, x0, #0xd30
1008467fc:     	ldr	x8, [x0]
100846800:     	blr	x8
100846804:     	mov	x22, x0
100846808:     	ldrb	w8, [x0, #0x18]
10084680c:     	cmp	w8, #0x1
100846810:     	b.ne	0x1008474fc <_js_json_stringify_full+0x1abc>
100846814:     	ldr	x8, [x0]
100846818:     	mov	x9, #-0x1               ; =-1
10084681c:     	str	x9, [x0]
100846820:     	cmn	x8, #0x2
100846824:     	b.eq	0x100847694 <_js_json_stringify_full+0x1c54>
100846828:     	cmn	x8, #0x1
10084682c:     	b.eq	0x100846900 <_js_json_stringify_full+0xec0>
100846830:     	add	x9, sp, #0x38
100846834:     	ldur	q0, [x0, #0x8]
100846838:     	stur	q0, [x9, #0x8]
10084683c:     	str	x8, [sp, #0x38]
100846840:     	tbz	w23, #0x0, 0x100846914 <_js_json_stringify_full+0xed4>
100846844:     	tbz	w27, #0x0, 0x1008469fc <_js_json_stringify_full+0xfbc>
100846848:     	bl	0x10028b458 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10084684c:     	str	x0, [sp, #0x50]
100846850:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846854:     	stp	x28, x8, [sp, #0x78]
100846858:     	mov	w8, #0x1                ; =1
10084685c:     	str	x8, [sp, #0x70]
100846860:     	add	x0, sp, #0x70
100846864:     	bl	0x10028b560 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100846868:     	mov	x21, x0
10084686c:     	str	x0, [sp, #0x58]
100846870:     	mov	w0, #0x0                ; =0
100846874:     	bl	0x10034b1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846878:     	stp	xzr, xzr, [x0]
10084687c:     	str	wzr, [x0, #0x10]
100846880:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846884:     	bfxil	x8, x0, #0, #48
100846888:     	fmov	d0, x8
10084688c:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100846890:     	mov	x19, x0
100846894:     	adrp	x23, 0x100f7c000 <_perry_global_worker_ts__1>
100846898:     	ldr	x8, [x23, #0x48]
10084689c:     	cmn	x8, #0x1
1008468a0:     	b.eq	0x100846a60 <_js_json_stringify_full+0x1020>
1008468a4:     	mrs	x9, TPIDRRO_EL0
1008468a8:     	and	x9, x9, #0xfffffffffffffff8
1008468ac:     	ldr	x8, [x9, x8, lsl #3]
1008468b0:     	cbz	x8, 0x100846a60 <_js_json_stringify_full+0x1020>
1008468b4:     	ldr	x8, [x8, #0x19e8]
1008468b8:     	cbz	x8, 0x100846a60 <_js_json_stringify_full+0x1020>
1008468bc:     	ldr	x9, [x8]
1008468c0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1008468c4:     	cmp	x9, x10
1008468c8:     	b.hs	0x1008475cc <_js_json_stringify_full+0x1b8c>
1008468cc:     	add	x10, x9, #0x1
1008468d0:     	str	x10, [x8]
1008468d4:     	ldr	x10, [x8, #0x18]
1008468d8:     	cmp	x19, x10
1008468dc:     	b.hs	0x1008475d8 <_js_json_stringify_full+0x1b98>
1008468e0:     	ldr	x10, [x8, #0x10]
1008468e4:     	mov	w11, #0x18              ; =24
1008468e8:     	madd	x10, x19, x11, x10
1008468ec:     	ldr	x11, [x10]
1008468f0:     	cbnz	x11, 0x100847638 <_js_json_stringify_full+0x1bf8>
1008468f4:     	ldr	x0, [x10, #0x8]
1008468f8:     	str	x9, [x8]
1008468fc:     	b	0x100846a68 <_js_json_stringify_full+0x1028>
100846900:     	mov	x8, #0x0                ; =0
100846904:     	mov	w9, #0x1                ; =1
100846908:     	stp	x9, xzr, [sp, #0x40]
10084690c:     	str	x8, [sp, #0x38]
100846910:     	tbnz	w23, #0x0, 0x100846844 <_js_json_stringify_full+0xe04>
100846914:     	cmp	x21, #0x0
100846918:     	cset	w6, ne
10084691c:     	ldp	x0, x1, [sp, #0x28]
100846920:     	ldp	x3, x4, [sp, #0x8]
100846924:     	add	x2, sp, #0x38
100846928:     	mov.16b	v0, v8
10084692c:     	mov	x5, #0x0                ; =0
100846930:     	bl	0x100502ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100846934:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846938:     	add	x0, x0, #0xd90
10084693c:     	ldr	x8, [x0]
100846940:     	blr	x8
100846944:     	ldrb	w8, [x0, #0x20]
100846948:     	cbnz	w8, 0x100847560 <_js_json_stringify_full+0x1b20>
10084694c:     	ldr	x8, [x0]
100846950:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100846954:     	cmp	x8, x9
100846958:     	b.hs	0x100847590 <_js_json_stringify_full+0x1b50>
10084695c:     	ldr	x9, [x0, #0x18]
100846960:     	cbz	x9, 0x10084696c <_js_json_stringify_full+0xf2c>
100846964:     	cbnz	x8, 0x10084759c <_js_json_stringify_full+0x1b5c>
100846968:     	str	xzr, [x0, #0x18]
10084696c:     	ldp	x0, x1, [sp, #0x40]
100846970:     	cmp	x1, #0x5
100846974:     	b.hi	0x1008469dc <_js_json_stringify_full+0xf9c>
100846978:     	cbz	x1, 0x100846bec <_js_json_stringify_full+0x11ac>
10084697c:     	ldrsb	w8, [x0]
100846980:     	tbnz	w8, #0x1f, 0x1008469dc <_js_json_stringify_full+0xf9c>
100846984:     	cmp	x1, #0x1
100846988:     	b.eq	0x1008469c4 <_js_json_stringify_full+0xf84>
10084698c:     	ldrsb	w8, [x0, #0x1]
100846990:     	tbnz	w8, #0x1f, 0x1008469dc <_js_json_stringify_full+0xf9c>
100846994:     	cmp	x1, #0x2
100846998:     	b.eq	0x1008469c4 <_js_json_stringify_full+0xf84>
10084699c:     	ldrsb	w8, [x0, #0x2]
1008469a0:     	tbnz	w8, #0x1f, 0x1008469dc <_js_json_stringify_full+0xf9c>
1008469a4:     	cmp	x1, #0x3
1008469a8:     	b.eq	0x1008469c4 <_js_json_stringify_full+0xf84>
1008469ac:     	ldrsb	w8, [x0, #0x3]
1008469b0:     	tbnz	w8, #0x1f, 0x1008469dc <_js_json_stringify_full+0xf9c>
1008469b4:     	cmp	x1, #0x4
1008469b8:     	b.eq	0x1008469c4 <_js_json_stringify_full+0xf84>
1008469bc:     	ldrsb	w8, [x0, #0x4]
1008469c0:     	tbnz	w8, #0x1f, 0x1008469dc <_js_json_stringify_full+0xf9c>
1008469c4:     	cmp	x1, #0x4
1008469c8:     	b.hs	0x100846d2c <_js_json_stringify_full+0x12ec>
1008469cc:     	mov	x10, #0x0               ; =0
1008469d0:     	mov	x9, #0x0                ; =0
1008469d4:     	mov	x8, x0
1008469d8:     	b	0x100846dbc <_js_json_stringify_full+0x137c>
1008469dc:     	bl	0x100329ec8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
1008469e0:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
1008469e4:     	bfxil	x21, x0, #0, #48
1008469e8:     	ldp	x23, x0, [sp, #0x38]
1008469ec:     	ldrb	w8, [x22, #0x18]
1008469f0:     	cmp	w8, #0x1
1008469f4:     	b.eq	0x100846df8 <_js_json_stringify_full+0x13b8>
1008469f8:     	b	0x100847528 <_js_json_stringify_full+0x1ae8>
1008469fc:     	mov	w0, #0x0                ; =0
100846a00:     	bl	0x10034b1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846a04:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846a08:     	bfxil	x8, x0, #0, #48
100846a0c:     	fmov	d1, x8
100846a10:     	stp	xzr, xzr, [x0]
100846a14:     	str	wzr, [x0, #0x10]
100846a18:     	mov.16b	v0, v8
100846a1c:     	bl	0x1004ff93c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846a20:     	mov.16b	v8, v0
100846a24:     	fmov	x23, d8
100846a28:     	cmp	x23, x26
100846a2c:     	b.eq	0x100846c74 <_js_json_stringify_full+0x1234>
100846a30:     	mov	w8, #0x7ffd             ; =32765
100846a34:     	cmp	x8, x23, lsr #48
100846a38:     	b.ne	0x100846c44 <_js_json_stringify_full+0x1204>
100846a3c:     	and	x8, x23, #0xffffffffffff
100846a40:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846a44:     	b.lo	0x100846c68 <_js_json_stringify_full+0x1228>
100846a48:     	ldr	w8, [x8, #0xc]
100846a4c:     	mov	w9, #0x4f53             ; =20307
100846a50:     	movk	w9, #0x434c, lsl #16
100846a54:     	cmp	w8, w9
100846a58:     	b.ne	0x100846c68 <_js_json_stringify_full+0x1228>
100846a5c:     	b	0x100846c74 <_js_json_stringify_full+0x1234>
100846a60:     	mov	x0, x19
100846a64:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846a68:     	fmov	d1, x0
100846a6c:     	mov.16b	v0, v8
100846a70:     	bl	0x1004ff93c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846a74:     	mov.16b	v8, v0
100846a78:     	ldr	x8, [x23, #0x48]
100846a7c:     	cmn	x8, #0x1
100846a80:     	b.eq	0x100846ae4 <_js_json_stringify_full+0x10a4>
100846a84:     	mrs	x9, TPIDRRO_EL0
100846a88:     	and	x9, x9, #0xfffffffffffffff8
100846a8c:     	ldr	x8, [x9, x8, lsl #3]
100846a90:     	cbz	x8, 0x100846ae4 <_js_json_stringify_full+0x10a4>
100846a94:     	ldr	x8, [x8, #0x19e8]
100846a98:     	cbz	x8, 0x100846ae4 <_js_json_stringify_full+0x10a4>
100846a9c:     	ldr	x9, [x8]
100846aa0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846aa4:     	cmp	x9, x10
100846aa8:     	b.hs	0x1008475cc <_js_json_stringify_full+0x1b8c>
100846aac:     	add	x10, x9, #0x1
100846ab0:     	str	x10, [x8]
100846ab4:     	ldr	x10, [x8, #0x18]
100846ab8:     	cmp	x21, x10
100846abc:     	b.hs	0x1008475d8 <_js_json_stringify_full+0x1b98>
100846ac0:     	ldr	x10, [x8, #0x10]
100846ac4:     	mov	w11, #0x18              ; =24
100846ac8:     	madd	x10, x21, x11, x10
100846acc:     	ldr	x11, [x10]
100846ad0:     	cmp	x11, #0x1
100846ad4:     	b.ne	0x1008476ac <_js_json_stringify_full+0x1c6c>
100846ad8:     	ldr	x21, [x10, #0x8]
100846adc:     	str	x9, [x8]
100846ae0:     	b	0x100846af0 <_js_json_stringify_full+0x10b0>
100846ae4:     	mov	x0, x21
100846ae8:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846aec:     	mov	x21, x0
100846af0:     	ldr	x8, [x23, #0x48]
100846af4:     	cmn	x8, #0x1
100846af8:     	b.eq	0x100846b58 <_js_json_stringify_full+0x1118>
100846afc:     	mrs	x9, TPIDRRO_EL0
100846b00:     	and	x9, x9, #0xfffffffffffffff8
100846b04:     	ldr	x8, [x9, x8, lsl #3]
100846b08:     	cbz	x8, 0x100846b58 <_js_json_stringify_full+0x1118>
100846b0c:     	ldr	x8, [x8, #0x19e8]
100846b10:     	cbz	x8, 0x100846b58 <_js_json_stringify_full+0x1118>
100846b14:     	ldr	x9, [x8]
100846b18:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846b1c:     	cmp	x9, x10
100846b20:     	b.hs	0x1008475cc <_js_json_stringify_full+0x1b8c>
100846b24:     	add	x10, x9, #0x1
100846b28:     	str	x10, [x8]
100846b2c:     	ldr	x10, [x8, #0x18]
100846b30:     	cmp	x19, x10
100846b34:     	b.hs	0x1008475d8 <_js_json_stringify_full+0x1b98>
100846b38:     	ldr	x10, [x8, #0x10]
100846b3c:     	mov	w11, #0x18              ; =24
100846b40:     	madd	x10, x19, x11, x10
100846b44:     	ldr	x11, [x10]
100846b48:     	cbnz	x11, 0x100847638 <_js_json_stringify_full+0x1bf8>
100846b4c:     	ldr	x0, [x10, #0x8]
100846b50:     	str	x9, [x8]
100846b54:     	b	0x100846b60 <_js_json_stringify_full+0x1120>
100846b58:     	mov	x0, x19
100846b5c:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846b60:     	fmov	d9, x0
100846b64:     	mov.16b	v0, v8
100846b68:     	bl	0x1004ff474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100846b6c:     	mov.16b	v2, v0
100846b70:     	mov	x0, x21
100846b74:     	mov.16b	v0, v9
100846b78:     	mov.16b	v1, v8
100846b7c:     	bl	0x1004ff754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100846b80:     	str	d0, [sp, #0x60]
100846b84:     	fmov	x19, d0
100846b88:     	cmp	x19, x26
100846b8c:     	b.ne	0x100846bf4 <_js_json_stringify_full+0x11b4>
100846b90:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846b94:     	add	x0, x0, #0xd90
100846b98:     	ldr	x8, [x0]
100846b9c:     	blr	x8
100846ba0:     	ldrb	w8, [x0, #0x20]
100846ba4:     	cbnz	w8, 0x10084768c <_js_json_stringify_full+0x1c4c>
100846ba8:     	ldr	x8, [x0]
100846bac:     	cbnz	x8, 0x1008476dc <_js_json_stringify_full+0x1c9c>
100846bb0:     	str	xzr, [x0, #0x18]
100846bb4:     	ldp	x21, x19, [sp, #0x38]
100846bb8:     	ldrb	w8, [x22, #0x18]
100846bbc:     	cmp	w8, #0x1
100846bc0:     	b.ne	0x100847610 <_js_json_stringify_full+0x1bd0>
100846bc4:     	ldp	x8, x0, [x22]
100846bc8:     	stp	x21, x19, [x22]
100846bcc:     	str	xzr, [x22, #0x10]
100846bd0:     	sub	x8, x8, #0x1
100846bd4:     	cmn	x8, #0x2
100846bd8:     	b.hs	0x100846be0 <_js_json_stringify_full+0x11a0>
100846bdc:     	bl	0x100b5ef40 <_mi_free>
100846be0:     	cbz	w25, 0x100846ea0 <_js_json_stringify_full+0x1460>
100846be4:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846be8:     	b	0x100846ea4 <_js_json_stringify_full+0x1464>
100846bec:     	mov	x10, #0x0               ; =0
100846bf0:     	b	0x100846ddc <_js_json_stringify_full+0x139c>
100846bf4:     	add	x0, sp, #0x38
100846bf8:     	bl	0x1005004b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100846bfc:     	tbnz	w0, #0x0, 0x100846c38 <_js_json_stringify_full+0x11f8>
100846c00:     	mov	x0, x19
100846c04:     	bl	0x100327e2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100846c08:     	cmp	x0, #0x1
100846c0c:     	b.ne	0x1008476a0 <_js_json_stringify_full+0x1c60>
100846c10:     	add	x8, sp, #0x68
100846c14:     	add	x9, sp, #0x60
100846c18:     	stp	x1, x8, [sp, #0x68]
100846c1c:     	str	x9, [sp, #0x78]
100846c20:     	add	x8, sp, #0x38
100846c24:     	mov	x9, sp
100846c28:     	stp	x8, x9, [sp, #0x80]
100846c2c:     	add	x0, sp, #0x58
100846c30:     	add	x1, sp, #0x70
100846c34:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100846c38:     	add	x0, sp, #0x50
100846c3c:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846c40:     	b	0x100846934 <_js_json_stringify_full+0xef4>
100846c44:     	lsr	x8, x23, #52
100846c48:     	cbnz	x8, 0x100846c68 <_js_json_stringify_full+0x1228>
100846c4c:     	cbz	x23, 0x100846c68 <_js_json_stringify_full+0x1228>
100846c50:     	and	x8, x23, #0x7
100846c54:     	cbnz	x8, 0x100846c68 <_js_json_stringify_full+0x1228>
100846c58:     	mov	x0, x23
100846c5c:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846c60:     	mov	x8, x23
100846c64:     	tbnz	w0, #0x0, 0x100846a40 <_js_json_stringify_full+0x1000>
100846c68:     	mov	x0, x23
100846c6c:     	bl	0x1005094d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100846c70:     	tbz	w0, #0x0, 0x100846d00 <_js_json_stringify_full+0x12c0>
100846c74:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846c78:     	add	x0, x0, #0xd90
100846c7c:     	ldr	x8, [x0]
100846c80:     	blr	x8
100846c84:     	ldrb	w8, [x0, #0x20]
100846c88:     	cbnz	w8, 0x1008475dc <_js_json_stringify_full+0x1b9c>
100846c8c:     	ldr	x8, [x0]
100846c90:     	cbnz	x8, 0x100847604 <_js_json_stringify_full+0x1bc4>
100846c94:     	str	xzr, [x0, #0x18]
100846c98:     	ldp	x21, x19, [sp, #0x38]
100846c9c:     	ldrb	w8, [x22, #0x18]
100846ca0:     	cmp	w8, #0x1
100846ca4:     	b.ne	0x1008475b8 <_js_json_stringify_full+0x1b78>
100846ca8:     	ldp	x8, x0, [x22]
100846cac:     	stp	x21, x19, [x22]
100846cb0:     	str	xzr, [x22, #0x10]
100846cb4:     	sub	x8, x8, #0x1
100846cb8:     	cmn	x8, #0x2
100846cbc:     	b.hs	0x100846cc4 <_js_json_stringify_full+0x1284>
100846cc0:     	bl	0x100b5ef40 <_mi_free>
100846cc4:     	cbz	w25, 0x100846ce4 <_js_json_stringify_full+0x12a4>
100846cc8:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846ccc:     	ldr	w8, [x20]
100846cd0:     	sub	w8, w8, #0x1
100846cd4:     	str	w8, [x20]
100846cd8:     	cmn	x24, #0x1
100846cdc:     	b.ne	0x100846ec0 <_js_json_stringify_full+0x1480>
100846ce0:     	b	0x100846efc <_js_json_stringify_full+0x14bc>
100846ce4:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846ce8:     	ldr	w8, [x20]
100846cec:     	sub	w8, w8, #0x1
100846cf0:     	str	w8, [x20]
100846cf4:     	cmn	x24, #0x1
100846cf8:     	b.ne	0x100846ec0 <_js_json_stringify_full+0x1480>
100846cfc:     	b	0x100846efc <_js_json_stringify_full+0x14bc>
100846d00:     	cmp	x19, x23
100846d04:     	b.eq	0x100846d10 <_js_json_stringify_full+0x12d0>
100846d08:     	mov.16b	v0, v8
100846d0c:     	bl	0x10050e8ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100846d10:     	cbz	x21, 0x100846f9c <_js_json_stringify_full+0x155c>
100846d14:     	ldp	x1, x2, [sp, #0x8]
100846d18:     	add	x0, sp, #0x38
100846d1c:     	mov.16b	v0, v8
100846d20:     	mov	x3, #0x0                ; =0
100846d24:     	bl	0x100500fa0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100846d28:     	b	0x100846fac <_js_json_stringify_full+0x156c>
100846d2c:     	and	x9, x1, #0x4
100846d30:     	add	x8, x0, x9
100846d34:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100846d38:     	ldr	q0, [x10, #0x9c0]
100846d3c:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x336ba>
100846d40:     	ldr	q2, [x10, #0x8c0]
100846d44:     	movi.2d	v1, #0000000000000000
100846d48:     	movi.2d	v3, #0x000000000000ff
100846d4c:     	mov	w10, #0x4               ; =4
100846d50:     	dup.2d	v4, x10
100846d54:     	mov	x10, x0
100846d58:     	and	x11, x1, #0x4
100846d5c:     	movi.2d	v5, #0000000000000000
100846d60:     	ldr	s6, [x10], #0x4
100846d64:     	ushll.8h	v6, v6, #0x0
100846d68:     	ushll.4s	v6, v6, #0x0
100846d6c:     	ushll2.2d	v7, v6, #0x0
100846d70:     	and.16b	v7, v7, v3
100846d74:     	ushll.2d	v6, v6, #0x0
100846d78:     	and.16b	v6, v6, v3
100846d7c:     	shl.2d	v16, v0, #0x3
100846d80:     	shl.2d	v17, v2, #0x3
100846d84:     	ushl.2d	v6, v6, v17
100846d88:     	ushl.2d	v7, v7, v16
100846d8c:     	orr.16b	v1, v7, v1
100846d90:     	orr.16b	v5, v6, v5
100846d94:     	add.2d	v0, v0, v4
100846d98:     	add.2d	v2, v2, v4
100846d9c:     	subs	x11, x11, #0x4
100846da0:     	b.ne	0x100846d60 <_js_json_stringify_full+0x1320>
100846da4:     	orr.16b	v0, v5, v1
100846da8:     	mov	d1, v0[1]
100846dac:     	orr.8b	v0, v0, v1
100846db0:     	fmov	x10, d0
100846db4:     	cmp	x1, x9
100846db8:     	b.eq	0x100846ddc <_js_json_stringify_full+0x139c>
100846dbc:     	add	x11, x0, x1
100846dc0:     	lsl	x9, x9, #3
100846dc4:     	ldrb	w12, [x8], #0x1
100846dc8:     	lsl	x12, x12, x9
100846dcc:     	orr	x10, x12, x10
100846dd0:     	add	x9, x9, #0x8
100846dd4:     	cmp	x8, x11
100846dd8:     	b.ne	0x100846dc4 <_js_json_stringify_full+0x1384>
100846ddc:     	orr	x8, x10, x1, lsl #40
100846de0:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846de4:     	orr	x21, x8, x9
100846de8:     	ldr	x23, [sp, #0x38]
100846dec:     	ldrb	w8, [x22, #0x18]
100846df0:     	cmp	w8, #0x1
100846df4:     	b.ne	0x100847528 <_js_json_stringify_full+0x1ae8>
100846df8:     	ldp	x9, x8, [x22]
100846dfc:     	stp	x23, x0, [x22]
100846e00:     	str	xzr, [x22, #0x10]
100846e04:     	sub	x9, x9, #0x1
100846e08:     	cmn	x9, #0x2
100846e0c:     	b.hs	0x100846e18 <_js_json_stringify_full+0x13d8>
100846e10:     	mov	x0, x8
100846e14:     	bl	0x100b5ef40 <_mi_free>
100846e18:     	cbz	w25, 0x100846e38 <_js_json_stringify_full+0x13f8>
100846e1c:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846e20:     	ldr	w8, [x20]
100846e24:     	sub	w8, w8, #0x1
100846e28:     	str	w8, [x20]
100846e2c:     	cmn	x24, #0x1
100846e30:     	b.ne	0x100846e50 <_js_json_stringify_full+0x1410>
100846e34:     	b	0x100846e8c <_js_json_stringify_full+0x144c>
100846e38:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846e3c:     	ldr	w8, [x20]
100846e40:     	sub	w8, w8, #0x1
100846e44:     	str	w8, [x20]
100846e48:     	cmn	x24, #0x1
100846e4c:     	b.eq	0x100846e8c <_js_json_stringify_full+0x144c>
100846e50:     	ldp	x19, x20, [sp, #0x28]
100846e54:     	cbz	x20, 0x100846e80 <_js_json_stringify_full+0x1440>
100846e58:     	add	x22, x19, #0x8
100846e5c:     	b	0x100846e6c <_js_json_stringify_full+0x142c>
100846e60:     	add	x22, x22, #0x18
100846e64:     	subs	x20, x20, #0x1
100846e68:     	b.eq	0x100846e80 <_js_json_stringify_full+0x1440>
100846e6c:     	ldur	x8, [x22, #-0x8]
100846e70:     	cbz	x8, 0x100846e60 <_js_json_stringify_full+0x1420>
100846e74:     	ldr	x0, [x22]
100846e78:     	bl	0x100b5ef40 <_mi_free>
100846e7c:     	b	0x100846e60 <_js_json_stringify_full+0x1420>
100846e80:     	cbz	x24, 0x100846e8c <_js_json_stringify_full+0x144c>
100846e84:     	mov	x0, x19
100846e88:     	bl	0x100b5ef40 <_mi_free>
100846e8c:     	ldr	x8, [sp]
100846e90:     	cbz	x8, 0x100846f14 <_js_json_stringify_full+0x14d4>
100846e94:     	ldr	x0, [sp, #0x8]
100846e98:     	bl	0x100b5ef40 <_mi_free>
100846e9c:     	b	0x100846f14 <_js_json_stringify_full+0x14d4>
100846ea0:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846ea4:     	ldr	w8, [x20]
100846ea8:     	sub	w8, w8, #0x1
100846eac:     	str	w8, [x20]
100846eb0:     	add	x0, sp, #0x50
100846eb4:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846eb8:     	cmn	x24, #0x1
100846ebc:     	b.eq	0x100846efc <_js_json_stringify_full+0x14bc>
100846ec0:     	ldp	x19, x20, [sp, #0x28]
100846ec4:     	cbz	x20, 0x100846ef0 <_js_json_stringify_full+0x14b0>
100846ec8:     	add	x21, x19, #0x8
100846ecc:     	b	0x100846edc <_js_json_stringify_full+0x149c>
100846ed0:     	add	x21, x21, #0x18
100846ed4:     	subs	x20, x20, #0x1
100846ed8:     	b.eq	0x100846ef0 <_js_json_stringify_full+0x14b0>
100846edc:     	ldur	x8, [x21, #-0x8]
100846ee0:     	cbz	x8, 0x100846ed0 <_js_json_stringify_full+0x1490>
100846ee4:     	ldr	x0, [x21]
100846ee8:     	bl	0x100b5ef40 <_mi_free>
100846eec:     	b	0x100846ed0 <_js_json_stringify_full+0x1490>
100846ef0:     	cbz	x24, 0x100846efc <_js_json_stringify_full+0x14bc>
100846ef4:     	mov	x0, x19
100846ef8:     	bl	0x100b5ef40 <_mi_free>
100846efc:     	ldr	x8, [sp]
100846f00:     	cbz	x8, 0x100846f0c <_js_json_stringify_full+0x14cc>
100846f04:     	ldr	x0, [sp, #0x8]
100846f08:     	bl	0x100b5ef40 <_mi_free>
100846f0c:     	mov	x21, #0x1               ; =1
100846f10:     	movk	x21, #0x7ffc, lsl #48
100846f14:     	mov	x0, x21
100846f18:     	ldp	x29, x30, [sp, #0x100]
100846f1c:     	ldp	x20, x19, [sp, #0xf0]
100846f20:     	ldp	x22, x21, [sp, #0xe0]
100846f24:     	ldp	x24, x23, [sp, #0xd0]
100846f28:     	ldp	x26, x25, [sp, #0xc0]
100846f2c:     	ldp	x28, x27, [sp, #0xb0]
100846f30:     	ldp	d9, d8, [sp, #0xa0]
100846f34:     	add	sp, sp, #0x110
100846f38:     	ret
100846f3c:     	mov	x26, x21
100846f40:     	mov	x21, x28
100846f44:     	mov	x28, x0
100846f48:     	add	x0, x0, #0x8
100846f4c:     	bl	0x100b3bcd0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100846f50:     	mov	x0, x28
100846f54:     	mov	x28, x21
100846f58:     	mov	x21, x26
100846f5c:     	mov	x26, #0x1               ; =1
100846f60:     	movk	x26, #0x7ffc, lsl #48
100846f64:     	b	0x10084675c <_js_json_stringify_full+0xd1c>
100846f68:     	b.ne	0x1008464a0 <_js_json_stringify_full+0xa60>
100846f6c:     	tbz	x24, #0x3f, 0x100846fc4 <_js_json_stringify_full+0x1584>
100846f70:     	mov	x0, #0x0                ; =0
100846f74:     	mov	x1, x24
100846f78:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100846f7c:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100846f80:     	add	x8, x0, x22, lsl #3
100846f84:     	ldr	x0, [x8, #0x1e8]
100846f88:     	cbnz	x0, 0x1008467f0 <_js_json_stringify_full+0xdb0>
100846f8c:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846f90:     	add	x0, x0, #0x138
100846f94:     	bl	0x100b3cb9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100846f98:     	b	0x1008467f0 <_js_json_stringify_full+0xdb0>
100846f9c:     	add	x1, sp, #0x38
100846fa0:     	mov.16b	v0, v8
100846fa4:     	mov	w0, #0x0                ; =0
100846fa8:     	bl	0x1005095ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100846fac:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846fb0:     	add	x0, x0, #0xdc0
100846fb4:     	ldr	x8, [x0]
100846fb8:     	blr	x8
100846fbc:     	strb	wzr, [x0]
100846fc0:     	b	0x100846934 <_js_json_stringify_full+0xef4>
100846fc4:     	mov	x0, x24
100846fc8:     	mov	w1, #0x1                ; =1
100846fcc:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
100846fd0:     	mov	x25, x0
100846fd4:     	mov	w0, #0x1                ; =1
100846fd8:     	cbz	x25, 0x100846f74 <_js_json_stringify_full+0x1534>
100846fdc:     	mov	x0, x25
100846fe0:     	mov	x1, x22
100846fe4:     	mov	x2, x24
100846fe8:     	bl	0x100b61dec <_writev+0x100b61dec>
100846fec:     	mov	x21, x24
100846ff0:     	b	0x1008464c4 <_js_json_stringify_full+0xa84>
100846ff4:     	cmp	w11, #0x8
100846ff8:     	b.eq	0x1008470c4 <_js_json_stringify_full+0x1684>
100846ffc:     	cmp	w11, #0x9
100847000:     	b.eq	0x1008470d4 <_js_json_stringify_full+0x1694>
100847004:     	cmp	w11, #0xa
100847008:     	b.ne	0x100847050 <_js_json_stringify_full+0x1610>
10084700c:     	mov	w10, #0x6e              ; =110
100847010:     	b	0x1008470d8 <_js_json_stringify_full+0x1698>
100847014:     	mov	x22, x0
100847018:     	and	x0, x19, #0xffffffffffff
10084701c:     	bl	0x100347c80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100847020:     	cbz	x0, 0x1008470fc <_js_json_stringify_full+0x16bc>
100847024:     	ldr	w21, [x0]
100847028:     	cmp	w21, #0x4
10084702c:     	b.hi	0x100846028 <_js_json_stringify_full+0x5e8>
100847030:     	ldr	w8, [x0, #0x4]
100847034:     	cmp	w21, w8
100847038:     	b.hi	0x100846028 <_js_json_stringify_full+0x5e8>
10084703c:     	b	0x100847100 <_js_json_stringify_full+0x16c0>
100847040:     	cmp	w11, #0x22
100847044:     	b.eq	0x1008470d8 <_js_json_stringify_full+0x1698>
100847048:     	cmp	w11, #0x5c
10084704c:     	b.eq	0x1008470d8 <_js_json_stringify_full+0x1698>
100847050:     	cmp	x12, #0x3
100847054:     	mov	w11, #0x20              ; =32
100847058:     	ccmp	w10, w11, #0x8, ls
10084705c:     	b.lt	0x100845f64 <_js_json_stringify_full+0x524>
100847060:     	add	x8, sp, #0x70
100847064:     	strb	w10, [x8, x12]
100847068:     	add	x12, x12, #0x1
10084706c:     	b	0x100845c54 <_js_json_stringify_full+0x214>
100847070:     	mov	x1, x0
100847074:     	and	x0, x19, #0xffffffffffff
100847078:     	mov	x22, x1
10084707c:     	bl	0x1004f8e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100847080:     	cmp	x0, #0x1
100847084:     	b.ne	0x1008471a8 <_js_json_stringify_full+0x1768>
100847088:     	mov	x21, x1
10084708c:     	b	0x100846f14 <_js_json_stringify_full+0x14d4>
100847090:     	ldrb	w9, [x8, #0x118]
100847094:     	cbz	w9, 0x1008472d0 <_js_json_stringify_full+0x1890>
100847098:     	ldr	x9, [x8, #0x110]
10084709c:     	cmp	x9, x1
1008470a0:     	b.ne	0x1008472d0 <_js_json_stringify_full+0x1890>
1008470a4:     	ldr	x9, [x8, #0xf0]
1008470a8:     	cmp	x9, x22
1008470ac:     	b.hi	0x1008472d0 <_js_json_stringify_full+0x1890>
1008470b0:     	ldr	x9, [x8, #0xf8]
1008470b4:     	cmp	x9, x22
1008470b8:     	b.ls	0x1008472d0 <_js_json_stringify_full+0x1890>
1008470bc:     	add	x9, x8, #0xf0
1008470c0:     	b	0x1008474dc <_js_json_stringify_full+0x1a9c>
1008470c4:     	mov	w10, #0x62              ; =98
1008470c8:     	b	0x1008470d8 <_js_json_stringify_full+0x1698>
1008470cc:     	mov	w10, #0x66              ; =102
1008470d0:     	b	0x1008470d8 <_js_json_stringify_full+0x1698>
1008470d4:     	mov	w10, #0x74              ; =116
1008470d8:     	cmp	x12, #0x2
1008470dc:     	b.hi	0x100845f64 <_js_json_stringify_full+0x524>
1008470e0:     	add	x8, sp, #0x70
1008470e4:     	add	x8, x8, x12
1008470e8:     	add	x12, x12, #0x2
1008470ec:     	mov	w11, #0x5c              ; =92
1008470f0:     	strb	w11, [x8]
1008470f4:     	strb	w10, [x8, #0x1]
1008470f8:     	b	0x100845c54 <_js_json_stringify_full+0x214>
1008470fc:     	mov	x21, #0x0               ; =0
100847100:     	ldr	w8, [x22, #0x4]
100847104:     	lsl	x9, x21, #3
100847108:     	add	x9, x9, #0x18
10084710c:     	cmp	x9, x8
100847110:     	b.hi	0x100846028 <_js_json_stringify_full+0x5e8>
100847114:     	ldr	w8, [x24, #0x4]
100847118:     	mov	w9, #-0x40000000        ; =-1073741824
10084711c:     	cmp	w8, w9
100847120:     	csel	w8, w8, wzr, lt
100847124:     	mov	x22, x0
100847128:     	mov	x0, x8
10084712c:     	bl	0x1005e5724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100847130:     	mov	w9, #0x2                ; =2
100847134:     	cmp	w1, #0x2
100847138:     	csel	w10, w1, w9, hi
10084713c:     	tst	w0, #0x1
100847140:     	csel	x8, x10, x9, ne
100847144:     	cmp	x21, x8
100847148:     	b.hi	0x100846028 <_js_json_stringify_full+0x5e8>
10084714c:     	cbz	x21, 0x10084750c <_js_json_stringify_full+0x1acc>
100847150:     	mov	x0, x22
100847154:     	mov	x1, x21
100847158:     	bl	0x1004efe00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084715c:     	tbz	w0, #0x0, 0x100846028 <_js_json_stringify_full+0x5e8>
100847160:     	cmp	x21, #0x1
100847164:     	b.eq	0x1008475a8 <_js_json_stringify_full+0x1b68>
100847168:     	cmp	x21, #0x2
10084716c:     	b.ne	0x100847660 <_js_json_stringify_full+0x1c20>
100847170:     	mov	x22, #0x0               ; =0
100847174:     	add	x24, x24, #0x10
100847178:     	mov	w8, #0x1                ; =1
10084717c:     	mov	x25, x8
100847180:     	ldr	x1, [x24, x22, lsl #3]
100847184:     	add	x0, sp, #0x70
100847188:     	bl	0x1004efe54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084718c:     	ldr	w8, [sp, #0x70]
100847190:     	cmn	w8, #0x1
100847194:     	b.ne	0x100847648 <_js_json_stringify_full+0x1c08>
100847198:     	mov	w8, #0x0                ; =0
10084719c:     	mov	w22, #0x1               ; =1
1008471a0:     	tbnz	w25, #0x0, 0x10084717c <_js_json_stringify_full+0x173c>
1008471a4:     	b	0x100847660 <_js_json_stringify_full+0x1c20>
1008471a8:     	and	x0, x19, #0xffffffffffff
1008471ac:     	bl	0x100347c80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008471b0:     	cbz	x0, 0x10084723c <_js_json_stringify_full+0x17fc>
1008471b4:     	ldr	w21, [x0]
1008471b8:     	cbz	w21, 0x10084723c <_js_json_stringify_full+0x17fc>
1008471bc:     	cmp	w21, #0x8
1008471c0:     	b.hi	0x100845ff4 <_js_json_stringify_full+0x5b4>
1008471c4:     	ldr	w8, [x0, #0x4]
1008471c8:     	cmp	w21, w8
1008471cc:     	b.hi	0x100845ff4 <_js_json_stringify_full+0x5b4>
1008471d0:     	ldr	w8, [x22, #0x4]
1008471d4:     	lsl	x9, x21, #3
1008471d8:     	add	x9, x9, #0x18
1008471dc:     	cmp	x9, x8
1008471e0:     	b.hi	0x100845ff4 <_js_json_stringify_full+0x5b4>
1008471e4:     	ldr	w8, [x24, #0x4]
1008471e8:     	mov	w9, #-0x40000000        ; =-1073741824
1008471ec:     	cmp	w8, w9
1008471f0:     	csel	w8, w8, wzr, lt
1008471f4:     	mov	x22, x0
1008471f8:     	mov	x0, x8
1008471fc:     	bl	0x1005e5724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100847200:     	mov	w9, #0x2                ; =2
100847204:     	cmp	w1, #0x2
100847208:     	csel	w10, w1, w9, hi
10084720c:     	tst	w0, #0x1
100847210:     	csel	w8, w10, w9, ne
100847214:     	cmp	w21, w8
100847218:     	b.hi	0x100845ff4 <_js_json_stringify_full+0x5b4>
10084721c:     	mov	x0, x22
100847220:     	mov	x1, x21
100847224:     	bl	0x1004efe00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100847228:     	cbz	w0, 0x100845ff4 <_js_json_stringify_full+0x5b4>
10084722c:     	and	x0, x19, #0xffffffffffff
100847230:     	mov	x1, x21
100847234:     	bl	0x1004f7f80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100847238:     	b	0x100847244 <_js_json_stringify_full+0x1804>
10084723c:     	and	x0, x19, #0xffffffffffff
100847240:     	bl	0x1004f8d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100847244:     	mov	x21, x1
100847248:     	tbz	w0, #0x0, 0x100845ff4 <_js_json_stringify_full+0x5b4>
10084724c:     	b	0x100846f14 <_js_json_stringify_full+0x14d4>
100847250:     	add	x9, x8, #0x60
100847254:     	b	0x1008474dc <_js_json_stringify_full+0x1a9c>
100847258:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084725c:     	lsr	x1, x22, #20
100847260:     	ldr	x8, [x0, #0x10]
100847264:     	ldrb	w9, [x8]
100847268:     	cmp	w9, #0x2
10084726c:     	b.eq	0x1008465cc <_js_json_stringify_full+0xb8c>
100847270:     	ldr	x9, [x8, #0x8]
100847274:     	ldr	x10, [x8, #0x28]
100847278:     	sub	x9, x1, x9
10084727c:     	cmp	x9, x10
100847280:     	b.hs	0x1008472c4 <_js_json_stringify_full+0x1884>
100847284:     	ldr	x10, [x8, #0x20]
100847288:     	mov	w11, #0x28              ; =40
10084728c:     	madd	x9, x9, x11, x10
100847290:     	ldr	x10, [x9]
100847294:     	ldr	x11, [x8, #0x10]
100847298:     	cmp	x10, x11
10084729c:     	b.ne	0x1008472d0 <_js_json_stringify_full+0x1890>
1008472a0:     	ldp	x10, x11, [x9, #0x8]
1008472a4:     	cmp	x10, x22
1008472a8:     	ccmp	x11, x22, #0x0, ls
1008472ac:     	b.ls	0x1008472d0 <_js_json_stringify_full+0x1890>
1008472b0:     	ldr	x10, [x8, #0x30]
1008472b4:     	add	x10, x10, #0x1
1008472b8:     	str	x10, [x8, #0x30]
1008472bc:     	add	x8, x9, #0x21
1008472c0:     	b	0x1008474ec <_js_json_stringify_full+0x1aac>
1008472c4:     	ldr	x9, [x8, #0x58]
1008472c8:     	add	x9, x9, #0x1
1008472cc:     	str	x9, [x8, #0x58]
1008472d0:     	ldr	x9, [x8, #0x38]
1008472d4:     	add	x9, x9, #0x1
1008472d8:     	str	x9, [x8, #0x38]
1008472dc:     	mov	x0, x22
1008472e0:     	bl	0x10051e388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1008472e4:     	and	w8, w0, #0xff
1008472e8:     	cbz	w8, 0x100847308 <_js_json_stringify_full+0x18c8>
1008472ec:     	ldurb	w8, [x22, #-0x8]
1008472f0:     	ldurb	w9, [x22, #-0x7]
1008472f4:     	mov	w10, #0x82              ; =130
1008472f8:     	and	w9, w9, w10
1008472fc:     	cmp	w9, #0x2
100847300:     	ccmp	w8, #0x1, #0x0, eq
100847304:     	b.eq	0x10084739c <_js_json_stringify_full+0x195c>
100847308:     	mov	x0, x22
10084730c:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847310:     	mov	x23, x0
100847314:     	cbz	x0, 0x100847340 <_js_json_stringify_full+0x1900>
100847318:     	ldrb	w8, [x23]
10084731c:     	cmp	w8, #0x1
100847320:     	b.ne	0x100847360 <_js_json_stringify_full+0x1920>
100847324:     	ldrsb	w8, [x23, #0x1]
100847328:     	tbnz	w8, #0x1f, 0x1008473c4 <_js_json_stringify_full+0x1984>
10084732c:     	mov	x0, x23
100847330:     	ldp	w9, w8, [x22]
100847334:     	cmp	w9, w8
100847338:     	b.hi	0x100847448 <_js_json_stringify_full+0x1a08>
10084733c:     	b	0x100847460 <_js_json_stringify_full+0x1a20>
100847340:     	mov	x0, x22
100847344:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847348:     	tbnz	w0, #0x0, 0x100847358 <_js_json_stringify_full+0x1918>
10084734c:     	mov	x0, x22
100847350:     	bl	0x1002a3f88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847354:     	tbz	w0, #0x0, 0x10084666c <_js_json_stringify_full+0xc2c>
100847358:     	mov	x0, #0x0                ; =0
10084735c:     	b	0x100847438 <_js_json_stringify_full+0x19f8>
100847360:     	mov	x0, x23
100847364:     	cmp	w8, #0x1
100847368:     	b.eq	0x100847438 <_js_json_stringify_full+0x19f8>
10084736c:     	cmp	w8, #0x9
100847370:     	b.ne	0x10084666c <_js_json_stringify_full+0xc2c>
100847374:     	ldr	w8, [x22, #0x4]
100847378:     	mov	w9, #0x5841             ; =22593
10084737c:     	movk	w9, #0x4c5a, lsl #16
100847380:     	cmp	w8, w9
100847384:     	b.ne	0x10084666c <_js_json_stringify_full+0xc2c>
100847388:     	mov	x0, x22
10084738c:     	bl	0x100375e8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100847390:     	mov	x22, x0
100847394:     	cbnz	x0, 0x100847488 <_js_json_stringify_full+0x1a48>
100847398:     	b	0x10084666c <_js_json_stringify_full+0xc2c>
10084739c:     	ldr	w8, [x22]
1008473a0:     	mov	w9, #0xe100             ; =57600
1008473a4:     	movk	w9, #0x5f5, lsl #16
1008473a8:     	orr	w9, w9, #0x1
1008473ac:     	cmp	w8, w9
1008473b0:     	b.hs	0x100847308 <_js_json_stringify_full+0x18c8>
1008473b4:     	ldr	w9, [x22, #0x4]
1008473b8:     	cmp	w8, w9
1008473bc:     	b.ls	0x100847488 <_js_json_stringify_full+0x1a48>
1008473c0:     	b	0x100847308 <_js_json_stringify_full+0x18c8>
1008473c4:     	ldr	x22, [x23, #0x8]
1008473c8:     	mov	x0, x22
1008473cc:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008473d0:     	cbz	x0, 0x10084666c <_js_json_stringify_full+0xc2c>
1008473d4:     	ldrb	w8, [x0]
1008473d8:     	cmp	w8, #0x1
1008473dc:     	b.ne	0x10084666c <_js_json_stringify_full+0xc2c>
1008473e0:     	ldrsb	w8, [x0, #0x1]
1008473e4:     	tbz	w8, #0x1f, 0x100847330 <_js_json_stringify_full+0x18f0>
1008473e8:     	mov	w25, #0x1               ; =1
1008473ec:     	ldr	x22, [x0, #0x8]
1008473f0:     	mov	x0, x22
1008473f4:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008473f8:     	cbz	x0, 0x10084666c <_js_json_stringify_full+0xc2c>
1008473fc:     	ldrb	w8, [x0]
100847400:     	cmp	w8, #0x1
100847404:     	b.ne	0x10084666c <_js_json_stringify_full+0xc2c>
100847408:     	cmp	w25, #0x3f
10084740c:     	b.hi	0x10084666c <_js_json_stringify_full+0xc2c>
100847410:     	add	w25, w25, #0x1
100847414:     	ldrsb	w8, [x0, #0x1]
100847418:     	tbnz	w8, #0x1f, 0x1008473ec <_js_json_stringify_full+0x19ac>
10084741c:     	str	x22, [x23, #0x8]
100847420:     	ldrb	w8, [x23, #0x1]
100847424:     	orr	w8, w8, #0x80
100847428:     	strb	w8, [x23, #0x1]
10084742c:     	ldrb	w8, [x0]
100847430:     	cmp	w8, #0x1
100847434:     	b.ne	0x10084736c <_js_json_stringify_full+0x192c>
100847438:     	ldp	w9, w8, [x22]
10084743c:     	cmp	w9, w8
100847440:     	b.ls	0x100847460 <_js_json_stringify_full+0x1a20>
100847444:     	cbz	x23, 0x100847470 <_js_json_stringify_full+0x1a30>
100847448:     	ldr	w9, [x0, #0x4]
10084744c:     	ubfiz	x8, x8, #3, #32
100847450:     	add	x8, x8, #0x10
100847454:     	cmp	x8, x9
100847458:     	b.eq	0x100847488 <_js_json_stringify_full+0x1a48>
10084745c:     	b	0x100847470 <_js_json_stringify_full+0x1a30>
100847460:     	mov	w8, #0xe100             ; =57600
100847464:     	movk	w8, #0x5f5, lsl #16
100847468:     	cmp	w9, w8
10084746c:     	b.ls	0x100847488 <_js_json_stringify_full+0x1a48>
100847470:     	mov	x0, x22
100847474:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847478:     	tbnz	w0, #0x0, 0x100847488 <_js_json_stringify_full+0x1a48>
10084747c:     	mov	x0, x22
100847480:     	bl	0x1002a3f88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847484:     	tbz	w0, #0x0, 0x10084666c <_js_json_stringify_full+0xc2c>
100847488:     	ldp	w8, w9, [x22]
10084748c:     	sub	w10, w9, #0x1
100847490:     	mov	w11, #0x270f            ; =9999
100847494:     	cmp	w10, w11
100847498:     	ccmp	w8, w9, #0x2, lo
10084749c:     	b.hi	0x10084666c <_js_json_stringify_full+0xc2c>
1008474a0:     	and	x8, x20, #0xffffffffffff
1008474a4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008474a8:     	cmp	x24, x9
1008474ac:     	csel	x1, x8, x20, eq
1008474b0:     	add	x0, sp, #0x20
1008474b4:     	bl	0x1004ffcb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
1008474b8:     	ldr	x24, [sp, #0x20]
1008474bc:     	cmn	x24, #0x1
1008474c0:     	cset	w23, eq
1008474c4:     	cmp	x27, #0x1
1008474c8:     	cset	w8, hi
1008474cc:     	tst	w8, w23
1008474d0:     	b.ne	0x100846688 <_js_json_stringify_full+0xc48>
1008474d4:     	b	0x1008466f8 <_js_json_stringify_full+0xcb8>
1008474d8:     	add	x9, x8, #0x90
1008474dc:     	ldr	x10, [x8, #0x30]
1008474e0:     	add	x10, x10, #0x1
1008474e4:     	str	x10, [x8, #0x30]
1008474e8:     	add	x8, x9, #0x19
1008474ec:     	ldrb	w8, [x8]
1008474f0:     	cmp	w8, #0xff
1008474f4:     	b.ne	0x1008472e8 <_js_json_stringify_full+0x18a8>
1008474f8:     	b	0x1008472dc <_js_json_stringify_full+0x189c>
1008474fc:     	mov	x0, x22
100847500:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847504:     	cbnz	x0, 0x100846814 <_js_json_stringify_full+0xdd4>
100847508:     	b	0x100847694 <_js_json_stringify_full+0x1c54>
10084750c:     	and	x0, x19, #0xffffffffffff
100847510:     	bl	0x1004f7db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847514:     	mov	w0, w0
100847518:     	mov	x21, #0x7d7b            ; =32123
10084751c:     	movk	x21, #0x200, lsl #32
100847520:     	movk	x21, #0x7ff9, lsl #48
100847524:     	b	0x100847678 <_js_json_stringify_full+0x1c38>
100847528:     	mov	x19, x0
10084752c:     	mov	x0, x22
100847530:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847534:     	mov	x22, x0
100847538:     	mov	x0, x19
10084753c:     	cbnz	x22, 0x100846df8 <_js_json_stringify_full+0x13b8>
100847540:     	cbnz	x23, 0x100847624 <_js_json_stringify_full+0x1be4>
100847544:     	b	0x100847694 <_js_json_stringify_full+0x1c54>
100847548:     	bl	0x100b1e664 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084754c:     	cbnz	x0, 0x10084673c <_js_json_stringify_full+0xcfc>
100847550:     	b	0x100847694 <_js_json_stringify_full+0x1c54>
100847554:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100847558:     	add	x0, x0, #0x440
10084755c:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847560:     	cmp	w8, #0x1
100847564:     	b.ne	0x100847694 <_js_json_stringify_full+0x1c54>
100847568:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
10084756c:     	add	x1, x1, #0x998
100847570:     	mov	x19, x0
100847574:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847578:     	mov	x0, x19
10084757c:     	strb	wzr, [x19, #0x20]
100847580:     	ldr	x8, [x19]
100847584:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847588:     	cmp	x8, x9
10084758c:     	b.lo	0x10084695c <_js_json_stringify_full+0xf1c>
100847590:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847594:     	add	x0, x0, #0xea8
100847598:     	bl	0x100b126dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084759c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008475a0:     	add	x0, x0, #0xec0
1008475a4:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008475a8:     	and	x0, x19, #0xffffffffffff
1008475ac:     	bl	0x1004efa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008475b0:     	mov	x21, x1
1008475b4:     	b	0x100847678 <_js_json_stringify_full+0x1c38>
1008475b8:     	mov	x0, x22
1008475bc:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008475c0:     	mov	x22, x0
1008475c4:     	cbnz	x0, 0x100846ca8 <_js_json_stringify_full+0x1268>
1008475c8:     	b	0x100847620 <_js_json_stringify_full+0x1be0>
1008475cc:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
1008475d0:     	add	x0, x0, #0xd70
1008475d4:     	bl	0x100b126dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008475d8:     	bl	0x100b4b8d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
1008475dc:     	cmp	w8, #0x2
1008475e0:     	b.eq	0x100847694 <_js_json_stringify_full+0x1c54>
1008475e4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008475e8:     	add	x1, x1, #0x998
1008475ec:     	mov	x19, x0
1008475f0:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008475f4:     	mov	x0, x19
1008475f8:     	strb	wzr, [x19, #0x20]
1008475fc:     	ldr	x8, [x19]
100847600:     	cbz	x8, 0x100846c94 <_js_json_stringify_full+0x1254>
100847604:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847608:     	add	x0, x0, #0xe90
10084760c:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847610:     	mov	x0, x22
100847614:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847618:     	mov	x22, x0
10084761c:     	cbnz	x0, 0x100846bc4 <_js_json_stringify_full+0x1184>
100847620:     	cbz	x21, 0x100847694 <_js_json_stringify_full+0x1c54>
100847624:     	mov	x0, x19
100847628:     	bl	0x100b5ef40 <_mi_free>
10084762c:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847630:     	add	x0, x0, #0xc18
100847634:     	bl	0x100b5859c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847638:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xaf4>
10084763c:     	add	x0, x0, #0x430
100847640:     	mov	w1, #0xf                ; =15
100847644:     	bl	0x100b4b89c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847648:     	and	x0, x19, #0xffffffffffff
10084764c:     	add	x2, sp, #0x70
100847650:     	mov	x1, x22
100847654:     	bl	0x1004f0200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100847658:     	tbnz	w0, #0x0, 0x100847088 <_js_json_stringify_full+0x1648>
10084765c:     	mov	w21, #0x2               ; =2
100847660:     	and	x0, x19, #0xffffffffffff
100847664:     	mov	x1, x21
100847668:     	bl	0x1004ee880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084766c:     	mov	x21, x1
100847670:     	mov	x26, #0x1               ; =1
100847674:     	movk	x26, #0x7ffc, lsl #48
100847678:     	tbnz	w0, #0x0, 0x100846f14 <_js_json_stringify_full+0x14d4>
10084767c:     	mov	w21, #0x1               ; =1
100847680:     	cmp	x19, x26
100847684:     	b.eq	0x100846f0c <_js_json_stringify_full+0x14cc>
100847688:     	b	0x100846034 <_js_json_stringify_full+0x5f4>
10084768c:     	cmp	w8, #0x2
100847690:     	b.ne	0x1008476bc <_js_json_stringify_full+0x1c7c>
100847694:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847698:     	add	x0, x0, #0xc18
10084769c:     	bl	0x100b5859c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008476a0:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
1008476a4:     	add	x0, x0, #0x800
1008476a8:     	bl	0x100b12770 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1008476ac:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xaf4>
1008476b0:     	add	x0, x0, #0x167
1008476b4:     	mov	w1, #0xb                ; =11
1008476b8:     	bl	0x100b4b89c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008476bc:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008476c0:     	add	x1, x1, #0x998
1008476c4:     	mov	x19, x0
1008476c8:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008476cc:     	mov	x0, x19
1008476d0:     	strb	wzr, [x19, #0x20]
1008476d4:     	ldr	x8, [x19]
1008476d8:     	cbz	x8, 0x100846bb0 <_js_json_stringify_full+0x1170>
1008476dc:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008476e0:     	add	x0, x0, #0xe78
1008476e4:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008476e8:     	mov	w0, #0x1                ; =1
1008476ec:     	mov	x1, x23
1008476f0:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008476f4:     	mov	w0, #0x1                ; =1
1008476f8:     	mov	x1, x21
1008476fc:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847700:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847704:     	add	x2, x2, #0x3c8
100847708:     	mov	w0, #0x5                ; =5
10084770c:     	mov	w1, #0x5                ; =5
100847710:     	bl	0x100b1280c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
