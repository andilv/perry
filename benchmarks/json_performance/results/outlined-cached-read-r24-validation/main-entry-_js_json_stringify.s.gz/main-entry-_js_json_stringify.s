
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-cached-read-r24/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084526c <_js_json_stringify>:
10084526c:     	sub	sp, sp, #0x80
100845270:     	stp	d9, d8, [sp, #0x20]
100845274:     	stp	x26, x25, [sp, #0x30]
100845278:     	stp	x24, x23, [sp, #0x40]
10084527c:     	stp	x22, x21, [sp, #0x50]
100845280:     	stp	x20, x19, [sp, #0x60]
100845284:     	stp	x29, x30, [sp, #0x70]
100845288:     	add	x29, sp, #0x70
10084528c:     	mov	x21, x0
100845290:     	mov.16b	v8, v0
100845294:     	fmov	x19, d8
100845298:     	and	x20, x19, #0xffff000000000000
10084529c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008452a0:     	cmp	x20, x8
1008452a4:     	b.ne	0x1008452cc <_js_json_stringify+0x60>
1008452a8:     	and	x0, x19, #0xffffffffffff
1008452ac:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1008452b0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1008452b4:     	movk	x9, #0xffef, lsl #16
1008452b8:     	cmp	x8, x9
1008452bc:     	b.hi	0x1008452cc <_js_json_stringify+0x60>
1008452c0:     	ldr	w8, [x0, #0x4]
1008452c4:     	cmp	w8, #0x40
1008452c8:     	b.hs	0x10084533c <_js_json_stringify+0xd0>
1008452cc:     	mov.16b	v0, v8
1008452d0:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008452d4:     	tbz	w0, #0x0, 0x1008452e0 <_js_json_stringify+0x74>
1008452d8:     	mov	x23, x1
1008452dc:     	b	0x100845850 <_js_json_stringify+0x5e4>
1008452e0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008452e4:     	cmp	x20, x8
1008452e8:     	b.ne	0x100845350 <_js_json_stringify+0xe4>
1008452ec:     	ands	x19, x19, #0xffffffffffff
1008452f0:     	b.eq	0x100845350 <_js_json_stringify+0xe4>
1008452f4:     	mov	x0, x19
1008452f8:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008452fc:     	cbz	w0, 0x100845350 <_js_json_stringify+0xe4>
100845300:     	ldurb	w8, [x19, #-0x8]
100845304:     	cmp	w8, #0x9
100845308:     	b.ne	0x100845350 <_js_json_stringify+0xe4>
10084530c:     	ldr	w8, [x19, #0x4]
100845310:     	mov	w9, #0x5841             ; =22593
100845314:     	movk	w9, #0x4c5a, lsl #16
100845318:     	cmp	w8, w9
10084531c:     	b.ne	0x100845350 <_js_json_stringify+0xe4>
100845320:     	mov	x0, x19
100845324:     	bl	0x10068825c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100845328:     	cbz	x0, 0x100845350 <_js_json_stringify+0xe4>
10084532c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845330:     	bfxil	x8, x0, #0, #48
100845334:     	fmov	d8, x8
100845338:     	b	0x100845350 <_js_json_stringify+0xe4>
10084533c:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845340:     	tbnz	w0, #0x0, 0x1008452d8 <_js_json_stringify+0x6c>
100845344:     	mov.16b	v0, v8
100845348:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084534c:     	tbnz	w0, #0x0, 0x1008452d8 <_js_json_stringify+0x6c>
100845350:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845354:     	add	x0, x0, #0xd78
100845358:     	ldr	x8, [x0]
10084535c:     	blr	x8
100845360:     	mov	x19, x0
100845364:     	ldr	w26, [x0]
100845368:     	add	w8, w26, #0x1
10084536c:     	str	w8, [x0]
100845370:     	cbz	w26, 0x1008453e0 <_js_json_stringify+0x174>
100845374:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845378:     	add	x0, x0, #0xd00
10084537c:     	ldr	x8, [x0]
100845380:     	blr	x8
100845384:     	ldrb	w8, [x0, #0x20]
100845388:     	cmp	w8, #0x1
10084538c:     	b.ne	0x100845944 <_js_json_stringify+0x6d8>
100845390:     	ldr	x8, [x0]
100845394:     	cbnz	x8, 0x100845950 <_js_json_stringify+0x6e4>
100845398:     	mov	x8, #-0x1               ; =-1
10084539c:     	str	x8, [x0]
1008453a0:     	ldr	x20, [x0, #0x18]
1008453a4:     	ldr	x8, [x0, #0x8]
1008453a8:     	cmp	x20, x8
1008453ac:     	b.eq	0x100845874 <_js_json_stringify+0x608>
1008453b0:     	ldr	x8, [x0, #0x10]
1008453b4:     	mov	w9, #0x18               ; =24
1008453b8:     	madd	x8, x20, x9, x8
1008453bc:     	mov	w9, #0x8                ; =8
1008453c0:     	stp	xzr, x9, [x8]
1008453c4:     	str	xzr, [x8, #0x10]
1008453c8:     	add	x8, x20, #0x1
1008453cc:     	str	x8, [x0, #0x18]
1008453d0:     	ldr	x8, [x0]
1008453d4:     	add	x8, x8, #0x1
1008453d8:     	str	x8, [x0]
1008453dc:     	b	0x10084546c <_js_json_stringify+0x200>
1008453e0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008453e4:     	add	x0, x0, #0xdc0
1008453e8:     	ldr	x8, [x0]
1008453ec:     	blr	x8
1008453f0:     	strb	wzr, [x0]
1008453f4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008453f8:     	add	x0, x0, #0xdf0
1008453fc:     	ldr	x8, [x0]
100845400:     	blr	x8
100845404:     	strb	wzr, [x0]
100845408:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10084540c:     	ldr	w20, [x8, #0x5a8]
100845410:     	cmp	w20, #0x300
100845414:     	b.hs	0x1008458d0 <_js_json_stringify+0x664>
100845418:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084541c:     	ldr	x8, [x8, #0x48]
100845420:     	cmn	x8, #0x1
100845424:     	b.eq	0x1008458c0 <_js_json_stringify+0x654>
100845428:     	mrs	x9, TPIDRRO_EL0
10084542c:     	and	x9, x9, #0xfffffffffffffff8
100845430:     	ldr	x0, [x9, x8, lsl #3]
100845434:     	cbz	x0, 0x1008458c0 <_js_json_stringify+0x654>
100845438:     	add	x8, x0, x20, lsl #3
10084543c:     	ldr	x0, [x8, #0x1e8]
100845440:     	cbz	x0, 0x1008458d0 <_js_json_stringify+0x664>
100845444:     	str	xzr, [x0]
100845448:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084544c:     	add	x0, x0, #0xd90
100845450:     	ldr	x8, [x0]
100845454:     	blr	x8
100845458:     	ldrb	w8, [x0, #0x20]
10084545c:     	cbnz	w8, 0x10084595c <_js_json_stringify+0x6f0>
100845460:     	ldr	x8, [x0]
100845464:     	cbnz	x8, 0x100845984 <_js_json_stringify+0x718>
100845468:     	str	xzr, [x0, #0x18]
10084546c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845470:     	add	x0, x0, #0xd30
100845474:     	ldr	x8, [x0]
100845478:     	blr	x8
10084547c:     	mov	x20, x0
100845480:     	ldrb	w8, [x0, #0x18]
100845484:     	cmp	w8, #0x1
100845488:     	b.ne	0x1008458e0 <_js_json_stringify+0x674>
10084548c:     	ldr	x8, [x0]
100845490:     	mov	x9, #-0x1               ; =-1
100845494:     	str	x9, [x0]
100845498:     	cmn	x8, #0x2
10084549c:     	b.eq	0x100845990 <_js_json_stringify+0x724>
1008454a0:     	cmn	x8, #0x1
1008454a4:     	b.eq	0x1008454b8 <_js_json_stringify+0x24c>
1008454a8:     	add	x9, sp, #0x8
1008454ac:     	ldur	q0, [x0, #0x8]
1008454b0:     	stur	q0, [x9, #0x8]
1008454b4:     	b	0x1008454c4 <_js_json_stringify+0x258>
1008454b8:     	mov	x8, #0x0                ; =0
1008454bc:     	mov	w9, #0x1                ; =1
1008454c0:     	stp	x9, xzr, [sp, #0x10]
1008454c4:     	str	x8, [sp, #0x8]
1008454c8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008454cc:     	add	x0, x0, #0xd18
1008454d0:     	ldr	x8, [x0]
1008454d4:     	blr	x8
1008454d8:     	ldrb	w8, [x0, #0x20]
1008454dc:     	cbnz	w8, 0x100845910 <_js_json_stringify+0x6a4>
1008454e0:     	ldr	x8, [x0]
1008454e4:     	cbnz	x8, 0x100845938 <_js_json_stringify+0x6cc>
1008454e8:     	str	xzr, [x0, #0x18]
1008454ec:     	add	x1, sp, #0x8
1008454f0:     	mov.16b	v0, v8
1008454f4:     	mov	x0, x21
1008454f8:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008454fc:     	ldp	x21, x22, [sp, #0x10]
100845500:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100845504:     	b.hs	0x1008455c4 <_js_json_stringify+0x358>
100845508:     	cmp	x22, #0x40
10084550c:     	b.hs	0x100845688 <_js_json_stringify+0x41c>
100845510:     	ands	x9, x22, #0x38
100845514:     	b.eq	0x100845538 <_js_json_stringify+0x2cc>
100845518:     	and	x8, x22, #0x38
10084551c:     	neg	x8, x8
100845520:     	mov	x10, x21
100845524:     	ldr	x11, [x10], #0x8
100845528:     	tst	x11, #0x8080808080808080
10084552c:     	b.ne	0x1008455ac <_js_json_stringify+0x340>
100845530:     	adds	x8, x8, #0x8
100845534:     	b.ne	0x100845524 <_js_json_stringify+0x2b8>
100845538:     	and	x8, x22, #0x7
10084553c:     	cbz	x8, 0x10084570c <_js_json_stringify+0x4a0>
100845540:     	add	x9, x21, x9
100845544:     	ldrsb	w10, [x9]
100845548:     	tbnz	w10, #0x1f, 0x1008455ac <_js_json_stringify+0x340>
10084554c:     	cmp	x8, #0x1
100845550:     	b.eq	0x10084570c <_js_json_stringify+0x4a0>
100845554:     	ldrsb	w10, [x9, #0x1]
100845558:     	tbnz	w10, #0x1f, 0x1008455ac <_js_json_stringify+0x340>
10084555c:     	cmp	x8, #0x2
100845560:     	b.eq	0x10084570c <_js_json_stringify+0x4a0>
100845564:     	ldrsb	w10, [x9, #0x2]
100845568:     	tbnz	w10, #0x1f, 0x1008455ac <_js_json_stringify+0x340>
10084556c:     	cmp	x8, #0x3
100845570:     	b.eq	0x10084570c <_js_json_stringify+0x4a0>
100845574:     	ldrsb	w10, [x9, #0x3]
100845578:     	tbnz	w10, #0x1f, 0x1008455ac <_js_json_stringify+0x340>
10084557c:     	cmp	x8, #0x4
100845580:     	b.eq	0x10084570c <_js_json_stringify+0x4a0>
100845584:     	ldrsb	w10, [x9, #0x4]
100845588:     	tbnz	w10, #0x1f, 0x1008455ac <_js_json_stringify+0x340>
10084558c:     	cmp	x8, #0x5
100845590:     	b.eq	0x10084570c <_js_json_stringify+0x4a0>
100845594:     	ldrsb	w10, [x9, #0x5]
100845598:     	tbnz	w10, #0x1f, 0x1008455ac <_js_json_stringify+0x340>
10084559c:     	cmp	x8, #0x6
1008455a0:     	b.eq	0x10084570c <_js_json_stringify+0x4a0>
1008455a4:     	ldrsb	w8, [x9, #0x6]
1008455a8:     	tbz	w8, #0x1f, 0x10084570c <_js_json_stringify+0x4a0>
1008455ac:     	mov	x0, x21
1008455b0:     	mov	x1, x22
1008455b4:     	mov	x2, x22
1008455b8:     	bl	0x1008dccc0 <_js_string_from_bytes_with_capacity>
1008455bc:     	mov	x23, x0
1008455c0:     	b	0x100845808 <_js_json_stringify+0x59c>
1008455c4:     	and	x8, x22, #0x7fffffffffffffc0
1008455c8:     	add	x8, x21, x8
1008455cc:     	mov	x9, x21
1008455d0:     	ldp	q0, q1, [x9]
1008455d4:     	ldp	q2, q3, [x9, #0x20]
1008455d8:     	orr.16b	v0, v1, v0
1008455dc:     	orr.16b	v1, v2, v3
1008455e0:     	orr.16b	v0, v0, v1
1008455e4:     	umaxv.16b	b0, v0
1008455e8:     	fmov	w10, s0
1008455ec:     	tbnz	w10, #0x7, 0x10084564c <_js_json_stringify+0x3e0>
1008455f0:     	add	x9, x9, #0x40
1008455f4:     	cmp	x9, x8
1008455f8:     	b.ne	0x1008455d0 <_js_json_stringify+0x364>
1008455fc:     	ands	x9, x22, #0x30
100845600:     	b.eq	0x100845624 <_js_json_stringify+0x3b8>
100845604:     	mov	x10, x9
100845608:     	mov	x11, x8
10084560c:     	ldr	q0, [x11], #0x10
100845610:     	umaxv.16b	b0, v0
100845614:     	fmov	w12, s0
100845618:     	tbnz	w12, #0x7, 0x10084564c <_js_json_stringify+0x3e0>
10084561c:     	subs	x10, x10, #0x10
100845620:     	b.ne	0x10084560c <_js_json_stringify+0x3a0>
100845624:     	and	x10, x22, #0xf
100845628:     	cbz	x10, 0x100845644 <_js_json_stringify+0x3d8>
10084562c:     	add	x8, x8, x9
100845630:     	ldrsb	w9, [x8]
100845634:     	tbnz	w9, #0x1f, 0x10084564c <_js_json_stringify+0x3e0>
100845638:     	add	x8, x8, #0x1
10084563c:     	subs	x10, x10, #0x1
100845640:     	b.ne	0x100845630 <_js_json_stringify+0x3c4>
100845644:     	mov	w24, w22
100845648:     	b	0x100845680 <_js_json_stringify+0x414>
10084564c:     	mov	w24, w22
100845650:     	cbz	x24, 0x100845680 <_js_json_stringify+0x414>
100845654:     	mov	x8, x21
100845658:     	ands	x9, x22, #0x3
10084565c:     	b.eq	0x100845678 <_js_json_stringify+0x40c>
100845660:     	mov	x8, x21
100845664:     	ldrsb	w10, [x8]
100845668:     	tbnz	w10, #0x1f, 0x100845770 <_js_json_stringify+0x504>
10084566c:     	add	x8, x8, #0x1
100845670:     	subs	x9, x9, #0x1
100845674:     	b.ne	0x100845664 <_js_json_stringify+0x3f8>
100845678:     	cmp	x24, #0x4
10084567c:     	b.hs	0x10084573c <_js_json_stringify+0x4d0>
100845680:     	mov	x25, x22
100845684:     	b	0x100845780 <_js_json_stringify+0x514>
100845688:     	and	x8, x22, #0x7fffffffffffffc0
10084568c:     	and	x8, x8, #0xffffffff0007ffff
100845690:     	add	x8, x21, x8
100845694:     	mov	x9, x21
100845698:     	ldp	q0, q1, [x9]
10084569c:     	ldp	q2, q3, [x9, #0x20]
1008456a0:     	orr.16b	v0, v1, v0
1008456a4:     	orr.16b	v1, v2, v3
1008456a8:     	orr.16b	v0, v0, v1
1008456ac:     	umaxv.16b	b0, v0
1008456b0:     	fmov	w10, s0
1008456b4:     	tbnz	w10, #0x7, 0x1008455ac <_js_json_stringify+0x340>
1008456b8:     	add	x9, x9, #0x40
1008456bc:     	cmp	x9, x8
1008456c0:     	b.ne	0x100845698 <_js_json_stringify+0x42c>
1008456c4:     	ands	x9, x22, #0x30
1008456c8:     	b.eq	0x1008456ec <_js_json_stringify+0x480>
1008456cc:     	mov	x10, x9
1008456d0:     	mov	x11, x8
1008456d4:     	ldr	q0, [x11], #0x10
1008456d8:     	umaxv.16b	b0, v0
1008456dc:     	fmov	w12, s0
1008456e0:     	tbnz	w12, #0x7, 0x1008455ac <_js_json_stringify+0x340>
1008456e4:     	subs	x10, x10, #0x10
1008456e8:     	b.ne	0x1008456d4 <_js_json_stringify+0x468>
1008456ec:     	and	x10, x22, #0xf
1008456f0:     	cbz	x10, 0x10084570c <_js_json_stringify+0x4a0>
1008456f4:     	add	x8, x8, x9
1008456f8:     	ldrsb	w9, [x8]
1008456fc:     	tbnz	w9, #0x1f, 0x1008455ac <_js_json_stringify+0x340>
100845700:     	add	x8, x8, #0x1
100845704:     	subs	x10, x10, #0x1
100845708:     	b.ne	0x1008456f8 <_js_json_stringify+0x48c>
10084570c:     	mov	x0, x22
100845710:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845714:     	mov	x23, x0
100845718:     	stp	w22, w22, [x0]
10084571c:     	stp	wzr, wzr, [x0, #0xc]
100845720:     	str	w22, [x0, #0x8]
100845724:     	cbz	w22, 0x100845808 <_js_json_stringify+0x59c>
100845728:     	and	x2, x22, #0x7ffff
10084572c:     	mov	x0, x1
100845730:     	mov	x1, x21
100845734:     	bl	0x100b61d6c <_writev+0x100b61d6c>
100845738:     	b	0x100845808 <_js_json_stringify+0x59c>
10084573c:     	add	x9, x21, x24
100845740:     	ldrsb	w10, [x8]
100845744:     	tbnz	w10, #0x1f, 0x100845770 <_js_json_stringify+0x504>
100845748:     	ldrsb	w10, [x8, #0x1]
10084574c:     	tbnz	w10, #0x1f, 0x100845770 <_js_json_stringify+0x504>
100845750:     	ldrsb	w10, [x8, #0x2]
100845754:     	tbnz	w10, #0x1f, 0x100845770 <_js_json_stringify+0x504>
100845758:     	ldrsb	w10, [x8, #0x3]
10084575c:     	tbnz	w10, #0x1f, 0x100845770 <_js_json_stringify+0x504>
100845760:     	add	x8, x8, #0x4
100845764:     	cmp	x8, x9
100845768:     	b.ne	0x100845740 <_js_json_stringify+0x4d4>
10084576c:     	b	0x100845680 <_js_json_stringify+0x414>
100845770:     	mov	w1, w22
100845774:     	mov	x0, x21
100845778:     	bl	0x1005ea920 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10084577c:     	mov	x25, x0
100845780:     	bl	0x1004eff00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100845784:     	add	x0, x24, #0x14
100845788:     	mov	w1, #0x3                ; =3
10084578c:     	bl	0x100458380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100845790:     	mov	x23, x0
100845794:     	stp	w25, w22, [x0]
100845798:     	stp	wzr, wzr, [x0, #0xc]
10084579c:     	str	w22, [x0, #0x8]
1008457a0:     	add	x0, x0, #0x14
1008457a4:     	mov	x1, x21
1008457a8:     	mov	x2, x24
1008457ac:     	bl	0x100b61d6c <_writev+0x100b61d6c>
1008457b0:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008457b4:     	ldr	w21, [x8, #0x590]
1008457b8:     	cmp	w21, #0x300
1008457bc:     	b.hs	0x100845898 <_js_json_stringify+0x62c>
1008457c0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1008457c4:     	ldr	x8, [x8, #0x48]
1008457c8:     	cmn	x8, #0x1
1008457cc:     	b.eq	0x100845888 <_js_json_stringify+0x61c>
1008457d0:     	mrs	x9, TPIDRRO_EL0
1008457d4:     	and	x9, x9, #0xfffffffffffffff8
1008457d8:     	ldr	x0, [x9, x8, lsl #3]
1008457dc:     	cbz	x0, 0x100845888 <_js_json_stringify+0x61c>
1008457e0:     	add	x8, x0, x21, lsl #3
1008457e4:     	ldr	x0, [x8, #0x1e8]
1008457e8:     	cbz	x0, 0x100845898 <_js_json_stringify+0x62c>
1008457ec:     	ldr	x8, [x0]
1008457f0:     	adds	x8, x8, x24
1008457f4:     	csinv	x8, x8, xzr, lo
1008457f8:     	str	x8, [x0]
1008457fc:     	lsr	x8, x8, #25
100845800:     	cbz	x8, 0x100845808 <_js_json_stringify+0x59c>
100845804:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845808:     	ldp	x22, x21, [sp, #0x8]
10084580c:     	ldrb	w8, [x20, #0x18]
100845810:     	cmp	w8, #0x1
100845814:     	b.ne	0x1008458f0 <_js_json_stringify+0x684>
100845818:     	ldp	x8, x0, [x20]
10084581c:     	stp	x22, x21, [x20]
100845820:     	str	xzr, [x20, #0x10]
100845824:     	sub	x8, x8, #0x1
100845828:     	cmn	x8, #0x2
10084582c:     	b.hs	0x100845834 <_js_json_stringify+0x5c8>
100845830:     	bl	0x100b5eec0 <_mi_free>
100845834:     	cbz	w26, 0x100845840 <_js_json_stringify+0x5d4>
100845838:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084583c:     	b	0x100845844 <_js_json_stringify+0x5d8>
100845840:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845844:     	ldr	w8, [x19]
100845848:     	sub	w8, w8, #0x1
10084584c:     	str	w8, [x19]
100845850:     	mov	x0, x23
100845854:     	ldp	x29, x30, [sp, #0x70]
100845858:     	ldp	x20, x19, [sp, #0x60]
10084585c:     	ldp	x22, x21, [sp, #0x50]
100845860:     	ldp	x24, x23, [sp, #0x40]
100845864:     	ldp	x26, x25, [sp, #0x30]
100845868:     	ldp	d9, d8, [sp, #0x20]
10084586c:     	add	sp, sp, #0x80
100845870:     	ret
100845874:     	mov	x22, x0
100845878:     	add	x0, x0, #0x8
10084587c:     	bl	0x100b3bc50 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845880:     	mov	x0, x22
100845884:     	b	0x1008453b0 <_js_json_stringify+0x144>
100845888:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084588c:     	add	x8, x0, x21, lsl #3
100845890:     	ldr	x0, [x8, #0x1e8]
100845894:     	cbnz	x0, 0x1008457ec <_js_json_stringify+0x580>
100845898:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084589c:     	add	x0, x0, #0x78
1008458a0:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008458a4:     	ldr	x8, [x0]
1008458a8:     	adds	x8, x8, x24
1008458ac:     	csinv	x8, x8, xzr, lo
1008458b0:     	str	x8, [x0]
1008458b4:     	lsr	x8, x8, #25
1008458b8:     	cbnz	x8, 0x100845804 <_js_json_stringify+0x598>
1008458bc:     	b	0x100845808 <_js_json_stringify+0x59c>
1008458c0:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008458c4:     	add	x8, x0, x20, lsl #3
1008458c8:     	ldr	x0, [x8, #0x1e8]
1008458cc:     	cbnz	x0, 0x100845444 <_js_json_stringify+0x1d8>
1008458d0:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008458d4:     	add	x0, x0, #0x138
1008458d8:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008458dc:     	b	0x100845444 <_js_json_stringify+0x1d8>
1008458e0:     	mov	x0, x20
1008458e4:     	bl	0x100b1e484 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008458e8:     	cbnz	x0, 0x10084548c <_js_json_stringify+0x220>
1008458ec:     	b	0x100845990 <_js_json_stringify+0x724>
1008458f0:     	mov	x0, x20
1008458f4:     	bl	0x100b1e484 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008458f8:     	mov	x20, x0
1008458fc:     	cbnz	x0, 0x100845818 <_js_json_stringify+0x5ac>
100845900:     	cbz	x22, 0x100845990 <_js_json_stringify+0x724>
100845904:     	mov	x0, x21
100845908:     	bl	0x100b5eec0 <_mi_free>
10084590c:     	b	0x100845990 <_js_json_stringify+0x724>
100845910:     	cmp	w8, #0x2
100845914:     	b.eq	0x100845990 <_js_json_stringify+0x724>
100845918:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
10084591c:     	add	x1, x1, #0xff8
100845920:     	mov	x22, x0
100845924:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845928:     	mov	x0, x22
10084592c:     	strb	wzr, [x22, #0x20]
100845930:     	ldr	x8, [x22]
100845934:     	cbz	x8, 0x1008454e8 <_js_json_stringify+0x27c>
100845938:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084593c:     	add	x0, x0, #0xdb8
100845940:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845944:     	bl	0x100b1e5e4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100845948:     	cbnz	x0, 0x100845390 <_js_json_stringify+0x124>
10084594c:     	b	0x100845990 <_js_json_stringify+0x724>
100845950:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100845954:     	add	x0, x0, #0x440
100845958:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084595c:     	cmp	w8, #0x1
100845960:     	b.ne	0x100845990 <_js_json_stringify+0x724>
100845964:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845968:     	add	x1, x1, #0x998
10084596c:     	mov	x20, x0
100845970:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845974:     	mov	x0, x20
100845978:     	strb	wzr, [x20, #0x20]
10084597c:     	ldr	x8, [x20]
100845980:     	cbz	x8, 0x100845468 <_js_json_stringify+0x1fc>
100845984:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845988:     	add	x0, x0, #0xd88
10084598c:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845990:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845994:     	add	x0, x0, #0xc18
100845998:     	bl	0x100b5851c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
