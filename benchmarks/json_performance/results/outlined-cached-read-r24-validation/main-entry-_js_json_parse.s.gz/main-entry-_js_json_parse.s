
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-cached-read-r24/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844554 <_js_json_parse>:
100844554:     	stp	x29, x30, [sp, #-0x10]!
100844558:     	mov	x29, sp
10084455c:     	cbz	x0, 0x1008445b4 <_js_json_parse+0x60>
100844560:     	ldr	w1, [x0, #0x4]
100844564:     	cmp	w1, #0x2
100844568:     	b.eq	0x100844578 <_js_json_parse+0x24>
10084456c:     	cbz	w1, 0x1008445b4 <_js_json_parse+0x60>
100844570:     	ldrb	w8, [x0, #0x14]
100844574:     	b	0x100844598 <_js_json_parse+0x44>
100844578:     	ldrb	w8, [x0, #0x14]
10084457c:     	cmp	w8, #0x7b
100844580:     	b.ne	0x100844598 <_js_json_parse+0x44>
100844584:     	ldrb	w8, [x0, #0x15]
100844588:     	cmp	w8, #0x7d
10084458c:     	b.ne	0x1008445a4 <_js_json_parse+0x50>
100844590:     	ldp	x29, x30, [sp], #0x10
100844594:     	b	0x1004ec900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100844598:     	orr	w8, w8, #0x20
10084459c:     	cmp	w8, #0x7b
1008445a0:     	b.ne	0x1008445ac <_js_json_parse+0x58>
1008445a4:     	ldp	x29, x30, [sp], #0x10
1008445a8:     	b	0x100505d78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008445ac:     	ldp	x29, x30, [sp], #0x10
1008445b0:     	b	0x1005083f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008445b4:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6fdc>
1008445b8:     	add	x0, x0, #0x501
1008445bc:     	mov	w1, #0x1c               ; =28
1008445c0:     	bl	0x100508828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
