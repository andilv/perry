
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-cached-read-r24/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008459c0 <_js_json_stringify_full>:
1008459c0:     	sub	sp, sp, #0x110
1008459c4:     	stp	d9, d8, [sp, #0xa0]
1008459c8:     	stp	x28, x27, [sp, #0xb0]
1008459cc:     	stp	x26, x25, [sp, #0xc0]
1008459d0:     	stp	x24, x23, [sp, #0xd0]
1008459d4:     	stp	x22, x21, [sp, #0xe0]
1008459d8:     	stp	x20, x19, [sp, #0xf0]
1008459dc:     	stp	x29, x30, [sp, #0x100]
1008459e0:     	add	x29, sp, #0x100
1008459e4:     	mov.16b	v9, v2
1008459e8:     	mov.16b	v8, v0
1008459ec:     	mov	x26, #0x1               ; =1
1008459f0:     	movk	x26, #0x7ffc, lsl #48
1008459f4:     	fmov	x19, d8
1008459f8:     	fmov	x20, d1
1008459fc:     	fmov	x23, d9
100845a00:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845a04:     	add	x9, x23, x8
100845a08:     	add	x27, x20, x8
100845a0c:     	cmp	x9, #0x2
100845a10:     	b.hs	0x100845a2c <_js_json_stringify_full+0x6c>
100845a14:     	cmp	x27, #0x2
100845a18:     	b.lo	0x100845a3c <_js_json_stringify_full+0x7c>
100845a1c:     	mov	w21, #0x0               ; =0
100845a20:     	cmp	x19, x26
100845a24:     	b.eq	0x100846e8c <_js_json_stringify_full+0x14cc>
100845a28:     	b	0x100845fb4 <_js_json_stringify_full+0x5f4>
100845a2c:     	add	x8, x26, #0x2
100845a30:     	cmp	x23, x8
100845a34:     	ccmp	x27, #0x2, #0x2, eq
100845a38:     	b.hs	0x100845a1c <_js_json_stringify_full+0x5c>
100845a3c:     	mov	x8, #-0x2               ; =-2
100845a40:     	movk	x8, #0x8003, lsl #48
100845a44:     	add	x8, x19, x8
100845a48:     	cmp	x8, #0x3
100845a4c:     	b.hs	0x100845a60 <_js_json_stringify_full+0xa0>
100845a50:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
100845a54:     	add	x9, x9, #0x658
100845a58:     	ldr	x21, [x9, x8, lsl #3]
100845a5c:     	b	0x100846e94 <_js_json_stringify_full+0x14d4>
100845a60:     	strb	wzr, [sp, #0x3c]
100845a64:     	str	wzr, [sp, #0x38]
100845a68:     	and	x8, x19, #0xffff000000000000
100845a6c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845a70:     	cmp	x8, x9
100845a74:     	b.eq	0x100845ae8 <_js_json_stringify_full+0x128>
100845a78:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845a7c:     	cmp	x8, x9
100845a80:     	b.ne	0x100845ee4 <_js_json_stringify_full+0x524>
100845a84:     	ubfx	x10, x19, #40, #8
100845a88:     	cbz	x10, 0x100845ad8 <_js_json_stringify_full+0x118>
100845a8c:     	strb	w19, [sp, #0x38]
100845a90:     	cmp	x10, #0x1
100845a94:     	b.eq	0x100845ad8 <_js_json_stringify_full+0x118>
100845a98:     	lsr	x9, x19, #8
100845a9c:     	strb	w9, [sp, #0x39]
100845aa0:     	cmp	x10, #0x2
100845aa4:     	b.eq	0x100845ad8 <_js_json_stringify_full+0x118>
100845aa8:     	lsr	x9, x19, #16
100845aac:     	strb	w9, [sp, #0x3a]
100845ab0:     	cmp	x10, #0x3
100845ab4:     	b.eq	0x100845ad8 <_js_json_stringify_full+0x118>
100845ab8:     	lsr	x9, x19, #24
100845abc:     	strb	w9, [sp, #0x3b]
100845ac0:     	cmp	x10, #0x4
100845ac4:     	b.eq	0x100845ad8 <_js_json_stringify_full+0x118>
100845ac8:     	lsr	x9, x19, #32
100845acc:     	strb	w9, [sp, #0x3c]
100845ad0:     	cmp	x10, #0x5
100845ad4:     	b.ne	0x100847680 <_js_json_stringify_full+0x1cc0>
100845ad8:     	add	x11, sp, #0x38
100845adc:     	cmp	w10, #0x3
100845ae0:     	b.ls	0x100845b00 <_js_json_stringify_full+0x140>
100845ae4:     	b	0x100845ee4 <_js_json_stringify_full+0x524>
100845ae8:     	ands	x9, x19, #0xffffffffffff
100845aec:     	b.eq	0x100845fa8 <_js_json_stringify_full+0x5e8>
100845af0:     	add	x11, x9, #0x14
100845af4:     	ldr	w10, [x9, #0x4]
100845af8:     	cmp	w10, #0x3
100845afc:     	b.hi	0x100845ee4 <_js_json_stringify_full+0x524>
100845b00:     	stur	wzr, [sp, #0x71]
100845b04:     	mov	w9, #0x22               ; =34
100845b08:     	strb	w9, [sp, #0x70]
100845b0c:     	cbz	w10, 0x100845b44 <_js_json_stringify_full+0x184>
100845b10:     	add	x12, sp, #0x70
100845b14:     	ldrb	w13, [x11]
100845b18:     	sxtb	w15, w13
100845b1c:     	cmp	w13, #0xb
100845b20:     	b.le	0x100845b4c <_js_json_stringify_full+0x18c>
100845b24:     	cmp	w13, #0x21
100845b28:     	b.gt	0x100845b6c <_js_json_stringify_full+0x1ac>
100845b2c:     	cmp	w13, #0xc
100845b30:     	b.eq	0x100845ba0 <_js_json_stringify_full+0x1e0>
100845b34:     	cmp	w13, #0xd
100845b38:     	b.ne	0x100845b7c <_js_json_stringify_full+0x1bc>
100845b3c:     	mov	w15, #0x72              ; =114
100845b40:     	b	0x100845bac <_js_json_stringify_full+0x1ec>
100845b44:     	mov	w12, #0x1               ; =1
100845b48:     	b	0x100845bd4 <_js_json_stringify_full+0x214>
100845b4c:     	cmp	w13, #0x8
100845b50:     	b.eq	0x100845b98 <_js_json_stringify_full+0x1d8>
100845b54:     	cmp	w13, #0x9
100845b58:     	b.eq	0x100845ba8 <_js_json_stringify_full+0x1e8>
100845b5c:     	cmp	w13, #0xa
100845b60:     	b.ne	0x100845b7c <_js_json_stringify_full+0x1bc>
100845b64:     	mov	w15, #0x6e              ; =110
100845b68:     	b	0x100845bac <_js_json_stringify_full+0x1ec>
100845b6c:     	cmp	w13, #0x22
100845b70:     	b.eq	0x100845bac <_js_json_stringify_full+0x1ec>
100845b74:     	cmp	w13, #0x5c
100845b78:     	b.eq	0x100845bac <_js_json_stringify_full+0x1ec>
100845b7c:     	cmp	w15, #0x20
100845b80:     	b.lt	0x100845ee4 <_js_json_stringify_full+0x524>
100845b84:     	mov	w14, #0x0               ; =0
100845b88:     	add	x13, x12, #0x2
100845b8c:     	mov	w12, #0x2               ; =2
100845b90:     	mov	w16, #0x1               ; =1
100845b94:     	b	0x100845bc4 <_js_json_stringify_full+0x204>
100845b98:     	mov	w15, #0x62              ; =98
100845b9c:     	b	0x100845bac <_js_json_stringify_full+0x1ec>
100845ba0:     	mov	w15, #0x66              ; =102
100845ba4:     	b	0x100845bac <_js_json_stringify_full+0x1ec>
100845ba8:     	mov	w15, #0x74              ; =116
100845bac:     	add	x13, x12, #0x3
100845bb0:     	mov	w12, #0x5c              ; =92
100845bb4:     	strb	w12, [sp, #0x71]
100845bb8:     	mov	w14, #0x1               ; =1
100845bbc:     	mov	w12, #0x3               ; =3
100845bc0:     	mov	w16, #0x2               ; =2
100845bc4:     	add	x17, sp, #0x70
100845bc8:     	strb	w15, [x17, x16]
100845bcc:     	cmp	w10, #0x1
100845bd0:     	b.ne	0x100845c0c <_js_json_stringify_full+0x24c>
100845bd4:     	add	x10, sp, #0x70
100845bd8:     	strb	w9, [x10, x12]
100845bdc:     	add	x8, x12, #0x1
100845be0:     	cmp	x12, #0x3
100845be4:     	b.hs	0x100845bf8 <_js_json_stringify_full+0x238>
100845be8:     	mov	x13, #0x0               ; =0
100845bec:     	mov	x11, #0x0               ; =0
100845bf0:     	add	x9, sp, #0x70
100845bf4:     	b	0x100845e54 <_js_json_stringify_full+0x494>
100845bf8:     	cmp	x12, #0xf
100845bfc:     	b.hs	0x100845c3c <_js_json_stringify_full+0x27c>
100845c00:     	mov	x11, #0x0               ; =0
100845c04:     	mov	x13, #0x0               ; =0
100845c08:     	b	0x100845db0 <_js_json_stringify_full+0x3f0>
100845c0c:     	ldrb	w16, [x11, #0x1]
100845c10:     	sxtb	w15, w16
100845c14:     	cmp	w16, #0xb
100845c18:     	b.le	0x100845e84 <_js_json_stringify_full+0x4c4>
100845c1c:     	cmp	w16, #0x21
100845c20:     	b.gt	0x100845ea4 <_js_json_stringify_full+0x4e4>
100845c24:     	cmp	w16, #0xc
100845c28:     	b.eq	0x100845ed4 <_js_json_stringify_full+0x514>
100845c2c:     	cmp	w16, #0xd
100845c30:     	b.ne	0x100845eb4 <_js_json_stringify_full+0x4f4>
100845c34:     	mov	w15, #0x72              ; =114
100845c38:     	b	0x100845ee0 <_js_json_stringify_full+0x520>
100845c3c:     	and	x12, x8, #0xc
100845c40:     	and	x11, x8, #0x10
100845c44:     	add	x13, sp, #0x70
100845c48:     	add	x9, x13, x11
100845c4c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5f30>
100845c50:     	ldr	q0, [x14, #0x7d0]
100845c54:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5f30>
100845c58:     	ldr	q1, [x14, #0x7e0]
100845c5c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5f30>
100845c60:     	ldr	q2, [x14, #0x7f0]
100845c64:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5f30>
100845c68:     	ldr	q3, [x14, #0x800]
100845c6c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5f30>
100845c70:     	ldr	q4, [x14, #0x810]
100845c74:     	movi.2d	v5, #0000000000000000
100845c78:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5f30>
100845c7c:     	ldr	q6, [x14, #0x820]
100845c80:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
100845c84:     	ldr	q7, [x14, #0x940]
100845c88:     	mov	w14, #0x10              ; =16
100845c8c:     	movi.2d	v16, #0000000000000000
100845c90:     	dup.2d	v17, x14
100845c94:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3373a>
100845c98:     	ldr	q19, [x14, #0x840]
100845c9c:     	and	x14, x8, #0x10
100845ca0:     	movi.2d	v20, #0000000000000000
100845ca4:     	movi.2d	v18, #0000000000000000
100845ca8:     	movi.2d	v23, #0000000000000000
100845cac:     	movi.2d	v21, #0000000000000000
100845cb0:     	movi.2d	v24, #0000000000000000
100845cb4:     	movi.2d	v22, #0000000000000000
100845cb8:     	ldr	q25, [x13], #0x10
100845cbc:     	ushll.8h	v26, v25, #0x0
100845cc0:     	ushll2.4s	v27, v26, #0x0
100845cc4:     	ushll2.2d	v28, v27, #0x0
100845cc8:     	ushll2.8h	v25, v25, #0x0
100845ccc:     	ushll.4s	v29, v25, #0x0
100845cd0:     	ushll2.2d	v30, v29, #0x0
100845cd4:     	ushll.2d	v29, v29, #0x0
100845cd8:     	ushll.2d	v27, v27, #0x0
100845cdc:     	ushll.4s	v26, v26, #0x0
100845ce0:     	ushll2.2d	v31, v26, #0x0
100845ce4:     	ushll2.4s	v25, v25, #0x0
100845ce8:     	ushll.2d	v8, v25, #0x0
100845cec:     	ushll.2d	v26, v26, #0x0
100845cf0:     	ushll2.2d	v25, v25, #0x0
100845cf4:     	shl.2d	v9, v0, #0x3
100845cf8:     	ushl.2d	v25, v25, v9
100845cfc:     	shl.2d	v9, v19, #0x3
100845d00:     	ushl.2d	v26, v26, v9
100845d04:     	shl.2d	v9, v1, #0x3
100845d08:     	ushl.2d	v8, v8, v9
100845d0c:     	shl.2d	v9, v7, #0x3
100845d10:     	ushl.2d	v31, v31, v9
100845d14:     	shl.2d	v9, v6, #0x3
100845d18:     	ushl.2d	v27, v27, v9
100845d1c:     	shl.2d	v9, v3, #0x3
100845d20:     	ushl.2d	v29, v29, v9
100845d24:     	shl.2d	v9, v2, #0x3
100845d28:     	ushl.2d	v30, v30, v9
100845d2c:     	shl.2d	v9, v4, #0x3
100845d30:     	ushl.2d	v28, v28, v9
100845d34:     	orr.16b	v18, v28, v18
100845d38:     	orr.16b	v21, v30, v21
100845d3c:     	orr.16b	v23, v29, v23
100845d40:     	orr.16b	v20, v27, v20
100845d44:     	orr.16b	v5, v31, v5
100845d48:     	orr.16b	v24, v8, v24
100845d4c:     	orr.16b	v16, v26, v16
100845d50:     	orr.16b	v22, v25, v22
100845d54:     	add.2d	v6, v6, v17
100845d58:     	add.2d	v7, v7, v17
100845d5c:     	add.2d	v19, v19, v17
100845d60:     	add.2d	v4, v4, v17
100845d64:     	add.2d	v3, v3, v17
100845d68:     	add.2d	v2, v2, v17
100845d6c:     	add.2d	v1, v1, v17
100845d70:     	add.2d	v0, v0, v17
100845d74:     	subs	x14, x14, #0x10
100845d78:     	b.ne	0x100845cb8 <_js_json_stringify_full+0x2f8>
100845d7c:     	orr.16b	v0, v16, v23
100845d80:     	orr.16b	v1, v20, v24
100845d84:     	orr.16b	v0, v0, v1
100845d88:     	orr.16b	v1, v5, v21
100845d8c:     	orr.16b	v2, v18, v22
100845d90:     	orr.16b	v1, v1, v2
100845d94:     	orr.16b	v0, v0, v1
100845d98:     	mov	d1, v0[1]
100845d9c:     	orr.8b	v0, v0, v1
100845da0:     	fmov	x13, d0
100845da4:     	cmp	x8, x11
100845da8:     	b.eq	0x100845e74 <_js_json_stringify_full+0x4b4>
100845dac:     	cbz	x12, 0x100845e54 <_js_json_stringify_full+0x494>
100845db0:     	mov	x14, x11
100845db4:     	and	x11, x8, #0x1c
100845db8:     	add	x15, sp, #0x70
100845dbc:     	add	x9, x15, x11
100845dc0:     	fmov	d0, x13
100845dc4:     	movi.2d	v1, #0000000000000000
100845dc8:     	dup.2d	v3, x14
100845dcc:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
100845dd0:     	ldr	q2, [x12, #0x940]
100845dd4:     	orr.16b	v2, v3, v2
100845dd8:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3373a>
100845ddc:     	ldr	q4, [x12, #0x840]
100845de0:     	orr.16b	v3, v3, v4
100845de4:     	sub	x12, x14, x11
100845de8:     	add	x13, x15, x14
100845dec:     	movi.2d	v4, #0x000000000000ff
100845df0:     	mov	w14, #0x4               ; =4
100845df4:     	dup.2d	v5, x14
100845df8:     	ldr	s6, [x13], #0x4
100845dfc:     	ushll.8h	v6, v6, #0x0
100845e00:     	ushll.4s	v6, v6, #0x0
100845e04:     	ushll2.2d	v7, v6, #0x0
100845e08:     	and.16b	v7, v7, v4
100845e0c:     	ushll.2d	v6, v6, #0x0
100845e10:     	and.16b	v6, v6, v4
100845e14:     	shl.2d	v16, v2, #0x3
100845e18:     	shl.2d	v17, v3, #0x3
100845e1c:     	ushl.2d	v6, v6, v17
100845e20:     	ushl.2d	v7, v7, v16
100845e24:     	orr.16b	v1, v7, v1
100845e28:     	orr.16b	v0, v6, v0
100845e2c:     	add.2d	v2, v2, v5
100845e30:     	add.2d	v3, v3, v5
100845e34:     	adds	x12, x12, #0x4
100845e38:     	b.ne	0x100845df8 <_js_json_stringify_full+0x438>
100845e3c:     	orr.16b	v0, v0, v1
100845e40:     	mov	d1, v0[1]
100845e44:     	orr.8b	v0, v0, v1
100845e48:     	fmov	x13, d0
100845e4c:     	cmp	x8, x11
100845e50:     	b.eq	0x100845e74 <_js_json_stringify_full+0x4b4>
100845e54:     	add	x10, x10, x8
100845e58:     	lsl	x11, x11, #3
100845e5c:     	ldrb	w12, [x9], #0x1
100845e60:     	lsl	x12, x12, x11
100845e64:     	orr	x13, x12, x13
100845e68:     	add	x11, x11, #0x8
100845e6c:     	cmp	x9, x10
100845e70:     	b.ne	0x100845e5c <_js_json_stringify_full+0x49c>
100845e74:     	orr	x8, x13, x8, lsl #40
100845e78:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845e7c:     	orr	x21, x8, x9
100845e80:     	b	0x100846e94 <_js_json_stringify_full+0x14d4>
100845e84:     	cmp	w16, #0x8
100845e88:     	b.eq	0x100845ecc <_js_json_stringify_full+0x50c>
100845e8c:     	cmp	w16, #0x9
100845e90:     	b.eq	0x100845edc <_js_json_stringify_full+0x51c>
100845e94:     	cmp	w16, #0xa
100845e98:     	b.ne	0x100845eb4 <_js_json_stringify_full+0x4f4>
100845e9c:     	mov	w15, #0x6e              ; =110
100845ea0:     	b	0x100845ee0 <_js_json_stringify_full+0x520>
100845ea4:     	cmp	w16, #0x22
100845ea8:     	b.eq	0x100845ee0 <_js_json_stringify_full+0x520>
100845eac:     	cmp	w16, #0x5c
100845eb0:     	b.eq	0x100845ee0 <_js_json_stringify_full+0x520>
100845eb4:     	cmp	w15, #0x20
100845eb8:     	b.lt	0x100845ee4 <_js_json_stringify_full+0x524>
100845ebc:     	add	x13, sp, #0x70
100845ec0:     	strb	w15, [x13, x12]
100845ec4:     	add	x12, x12, #0x1
100845ec8:     	b	0x100846460 <_js_json_stringify_full+0xaa0>
100845ecc:     	mov	w15, #0x62              ; =98
100845ed0:     	b	0x100845ee0 <_js_json_stringify_full+0x520>
100845ed4:     	mov	w15, #0x66              ; =102
100845ed8:     	b	0x100845ee0 <_js_json_stringify_full+0x520>
100845edc:     	mov	w15, #0x74              ; =116
100845ee0:     	tbz	w14, #0x0, 0x10084644c <_js_json_stringify_full+0xa8c>
100845ee4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100845ee8:     	cmp	x8, x9
100845eec:     	b.eq	0x100845f34 <_js_json_stringify_full+0x574>
100845ef0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845ef4:     	cmp	x8, x9
100845ef8:     	b.ne	0x100845fa8 <_js_json_stringify_full+0x5e8>
100845efc:     	and	x8, x19, #0xffffffffffff
100845f00:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100845f04:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100845f08:     	movk	x10, #0xffef, lsl #16
100845f0c:     	cmp	x9, x10
100845f10:     	b.hi	0x100845fa8 <_js_json_stringify_full+0x5e8>
100845f14:     	ldr	w8, [x8, #0x4]
100845f18:     	cmp	w8, #0x40
100845f1c:     	b.lo	0x100845fa8 <_js_json_stringify_full+0x5e8>
100845f20:     	and	x0, x19, #0xffffffffffff
100845f24:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845f28:     	cmp	x0, #0x1
100845f2c:     	b.ne	0x100845fa8 <_js_json_stringify_full+0x5e8>
100845f30:     	b	0x1008460e8 <_js_json_stringify_full+0x728>
100845f34:     	and	x24, x19, #0xffffffffffff
100845f38:     	and	x0, x19, #0xffffffffffff
100845f3c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100845f40:     	cbz	x0, 0x100845f74 <_js_json_stringify_full+0x5b4>
100845f44:     	ldrb	w8, [x0]
100845f48:     	cmp	w8, #0x2
100845f4c:     	b.ne	0x100845f74 <_js_json_stringify_full+0x5b4>
100845f50:     	ldrsb	w8, [x0, #0x1]
100845f54:     	tbnz	w8, #0x1f, 0x100845f74 <_js_json_stringify_full+0x5b4>
100845f58:     	ldrh	w8, [x0, #0x2]
100845f5c:     	tbnz	w8, #0xb, 0x100845f74 <_js_json_stringify_full+0x5b4>
100845f60:     	ldr	w8, [x0, #0x4]
100845f64:     	cmp	w8, #0x18
100845f68:     	b.lo	0x100845f74 <_js_json_stringify_full+0x5b4>
100845f6c:     	ldr	w8, [x24]
100845f70:     	cbz	w8, 0x100846ff0 <_js_json_stringify_full+0x1630>
100845f74:     	and	x0, x19, #0xffffffffffff
100845f78:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100845f7c:     	cbz	x0, 0x100845fa8 <_js_json_stringify_full+0x5e8>
100845f80:     	ldrb	w8, [x0]
100845f84:     	cmp	w8, #0x2
100845f88:     	b.ne	0x100845fa8 <_js_json_stringify_full+0x5e8>
100845f8c:     	ldrh	w8, [x0, #0x2]
100845f90:     	tbnz	w8, #0xb, 0x100845fa8 <_js_json_stringify_full+0x5e8>
100845f94:     	ldr	w8, [x0, #0x4]
100845f98:     	cmp	w8, #0x18
100845f9c:     	b.lo	0x100845fa8 <_js_json_stringify_full+0x5e8>
100845fa0:     	ldr	w8, [x24]
100845fa4:     	cbz	w8, 0x100846f94 <_js_json_stringify_full+0x15d4>
100845fa8:     	mov	w21, #0x1               ; =1
100845fac:     	cmp	x19, x26
100845fb0:     	b.eq	0x100846e8c <_js_json_stringify_full+0x14cc>
100845fb4:     	and	x22, x19, #0xffff000000000000
100845fb8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845fbc:     	cmp	x22, x8
100845fc0:     	b.ne	0x100845ff8 <_js_json_stringify_full+0x638>
100845fc4:     	and	x8, x19, #0xffffffffffff
100845fc8:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100845fcc:     	b.lo	0x100845fe4 <_js_json_stringify_full+0x624>
100845fd0:     	ldr	w8, [x8, #0xc]
100845fd4:     	mov	w9, #0x4f53             ; =20307
100845fd8:     	movk	w9, #0x434c, lsl #16
100845fdc:     	cmp	w8, w9
100845fe0:     	b.eq	0x100846e8c <_js_json_stringify_full+0x14cc>
100845fe4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845fe8:     	cmp	x22, x8
100845fec:     	b.ne	0x100846024 <_js_json_stringify_full+0x664>
100845ff0:     	and	x0, x19, #0xffffffffffff
100845ff4:     	b	0x10084604c <_js_json_stringify_full+0x68c>
100845ff8:     	lsr	x8, x19, #52
100845ffc:     	cbnz	x8, 0x1008460d4 <_js_json_stringify_full+0x714>
100846000:     	and	x8, x19, #0x7
100846004:     	cbz	x19, 0x100846030 <_js_json_stringify_full+0x670>
100846008:     	cbnz	x8, 0x100846030 <_js_json_stringify_full+0x670>
10084600c:     	mov	x0, x19
100846010:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846014:     	mov	x8, x19
100846018:     	tbnz	w0, #0x0, 0x100845fc8 <_js_json_stringify_full+0x608>
10084601c:     	mov	x8, #0x0                ; =0
100846020:     	b	0x100846030 <_js_json_stringify_full+0x670>
100846024:     	lsr	x8, x19, #52
100846028:     	cbnz	x8, 0x1008460d4 <_js_json_stringify_full+0x714>
10084602c:     	and	x8, x19, #0x7
100846030:     	cbz	x19, 0x1008460d4 <_js_json_stringify_full+0x714>
100846034:     	cbnz	x8, 0x1008460d4 <_js_json_stringify_full+0x714>
100846038:     	mov	x0, x19
10084603c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846040:     	mov	x8, x0
100846044:     	mov	x0, x19
100846048:     	tbz	w8, #0x0, 0x1008460d4 <_js_json_stringify_full+0x714>
10084604c:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846050:     	b.lo	0x1008460d4 <_js_json_stringify_full+0x714>
100846054:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100846058:     	add	x8, x8, #0xfb0
10084605c:     	ldaprb	w8, [x8]
100846060:     	cbz	w8, 0x1008460d4 <_js_json_stringify_full+0x714>
100846064:     	lsr	x8, x0, #3
100846068:     	mov	x9, #0x7c15             ; =31765
10084606c:     	movk	x9, #0x7f4a, lsl #16
100846070:     	movk	x9, #0x79b9, lsl #32
100846074:     	movk	x9, #0x9e37, lsl #48
100846078:     	mul	x8, x8, x9
10084607c:     	lsr	x10, x8, #54
100846080:     	lsr	x11, x8, #60
100846084:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100846088:     	add	x9, x9, #0xf30
10084608c:     	add	x11, x9, x11, lsl #3
100846090:     	ldapr	x11, [x11]
100846094:     	lsr	x10, x11, x10
100846098:     	tbz	w10, #0x0, 0x1008460d4 <_js_json_stringify_full+0x714>
10084609c:     	lsr	x10, x8, #44
1008460a0:     	ubfx	x11, x8, #50, #4
1008460a4:     	add	x11, x9, x11, lsl #3
1008460a8:     	ldapr	x11, [x11]
1008460ac:     	lsr	x10, x11, x10
1008460b0:     	tbz	w10, #0x0, 0x1008460d4 <_js_json_stringify_full+0x714>
1008460b4:     	lsr	x10, x8, #34
1008460b8:     	ubfx	x8, x8, #40, #4
1008460bc:     	add	x8, x9, x8, lsl #3
1008460c0:     	ldapr	x8, [x8]
1008460c4:     	lsr	x8, x8, x10
1008460c8:     	tbz	w8, #0x0, 0x1008460d4 <_js_json_stringify_full+0x714>
1008460cc:     	bl	0x10034ca2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
1008460d0:     	tbnz	w0, #0x0, 0x100846e8c <_js_json_stringify_full+0x14cc>
1008460d4:     	tbz	w21, #0x0, 0x1008460f4 <_js_json_stringify_full+0x734>
1008460d8:     	mov.16b	v0, v8
1008460dc:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008460e0:     	cmp	x0, #0x1
1008460e4:     	b.ne	0x1008460f4 <_js_json_stringify_full+0x734>
1008460e8:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
1008460ec:     	bfxil	x21, x1, #0, #48
1008460f0:     	b	0x100846e94 <_js_json_stringify_full+0x14d4>
1008460f4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008460f8:     	cmp	x22, x8
1008460fc:     	b.ne	0x10084614c <_js_json_stringify_full+0x78c>
100846100:     	ands	x21, x19, #0xffffffffffff
100846104:     	b.eq	0x10084614c <_js_json_stringify_full+0x78c>
100846108:     	mov	x0, x21
10084610c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846110:     	cbz	w0, 0x10084614c <_js_json_stringify_full+0x78c>
100846114:     	ldurb	w8, [x21, #-0x8]
100846118:     	cmp	w8, #0x9
10084611c:     	b.ne	0x10084614c <_js_json_stringify_full+0x78c>
100846120:     	ldr	w8, [x21, #0x4]
100846124:     	mov	w9, #0x5841             ; =22593
100846128:     	movk	w9, #0x4c5a, lsl #16
10084612c:     	cmp	w8, w9
100846130:     	b.ne	0x10084614c <_js_json_stringify_full+0x78c>
100846134:     	mov	x0, x21
100846138:     	bl	0x10068825c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084613c:     	cbz	x0, 0x10084614c <_js_json_stringify_full+0x78c>
100846140:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100846144:     	bfxil	x19, x0, #0, #48
100846148:     	fmov	d8, x19
10084614c:     	mov	w8, #0x7ffd             ; =32765
100846150:     	cmp	x8, x23, lsr #48
100846154:     	b.ne	0x100846168 <_js_json_stringify_full+0x7a8>
100846158:     	and	x1, x23, #0xffffffffffff
10084615c:     	cmp	x1, #0x100, lsl #12     ; =0x100000
100846160:     	b.hs	0x10084617c <_js_json_stringify_full+0x7bc>
100846164:     	b	0x1008461d0 <_js_json_stringify_full+0x810>
100846168:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084616c:     	mov	x9, #0xfffffff00000     ; =281474975662080
100846170:     	mov	x1, x23
100846174:     	cmp	x8, x9
100846178:     	b.hs	0x1008461d0 <_js_json_stringify_full+0x810>
10084617c:     	lsr	x8, x1, #47
100846180:     	cbnz	x8, 0x1008461d0 <_js_json_stringify_full+0x810>
100846184:     	add	x0, sp, #0x70
100846188:     	bl	0x10076e06c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084618c:     	ldr	w8, [sp, #0x70]
100846190:     	tbz	w8, #0x0, 0x1008461d0 <_js_json_stringify_full+0x810>
100846194:     	ldr	w8, [sp, #0x78]
100846198:     	mov	w9, #-0xff30            ; =-65328
10084619c:     	cmp	w8, w9
1008461a0:     	b.eq	0x1008461c4 <_js_json_stringify_full+0x804>
1008461a4:     	mov	w9, #-0xff2f            ; =-65327
1008461a8:     	cmp	w8, w9
1008461ac:     	b.ne	0x1008461d0 <_js_json_stringify_full+0x810>
1008461b0:     	mov.16b	v0, v9
1008461b4:     	bl	0x1008482fc <_js_jsvalue_to_string>
1008461b8:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1008461bc:     	bfxil	x23, x0, #0, #48
1008461c0:     	b	0x1008461d0 <_js_json_stringify_full+0x810>
1008461c4:     	mov.16b	v0, v9
1008461c8:     	bl	0x10086f8a0 <_js_number_coerce>
1008461cc:     	fmov	x23, d0
1008461d0:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008461d4:     	add	x8, x23, x8
1008461d8:     	cmp	x8, #0x3
1008461dc:     	b.hs	0x1008461f4 <_js_json_stringify_full+0x834>
1008461e0:     	mov	x21, #0x0               ; =0
1008461e4:     	mov	w8, #0x1                ; =1
1008461e8:     	stp	xzr, x8, [sp]
1008461ec:     	str	xzr, [sp, #0x10]
1008461f0:     	b	0x1008464a8 <_js_json_stringify_full+0xae8>
1008461f4:     	and	x8, x23, #0xffff000000000000
1008461f8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008461fc:     	cmp	x8, x9
100846200:     	b.eq	0x100846224 <_js_json_stringify_full+0x864>
100846204:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846208:     	cmp	x8, x9
10084620c:     	b.ne	0x1008462b0 <_js_json_stringify_full+0x8f0>
100846210:     	and	x8, x23, #0xffffffffffff
100846214:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846218:     	b.hs	0x1008462f8 <_js_json_stringify_full+0x938>
10084621c:     	mov	x9, #0x0                ; =0
100846220:     	b	0x100846300 <_js_json_stringify_full+0x940>
100846224:     	strb	wzr, [sp, #0x3c]
100846228:     	str	wzr, [sp, #0x38]
10084622c:     	ubfx	x1, x23, #40, #8
100846230:     	cbz	x1, 0x100846280 <_js_json_stringify_full+0x8c0>
100846234:     	strb	w23, [sp, #0x38]
100846238:     	cmp	x1, #0x1
10084623c:     	b.eq	0x100846280 <_js_json_stringify_full+0x8c0>
100846240:     	lsr	x8, x23, #8
100846244:     	strb	w8, [sp, #0x39]
100846248:     	cmp	x1, #0x2
10084624c:     	b.eq	0x100846280 <_js_json_stringify_full+0x8c0>
100846250:     	lsr	x8, x23, #16
100846254:     	strb	w8, [sp, #0x3a]
100846258:     	cmp	x1, #0x3
10084625c:     	b.eq	0x100846280 <_js_json_stringify_full+0x8c0>
100846260:     	lsr	x8, x23, #24
100846264:     	strb	w8, [sp, #0x3b]
100846268:     	cmp	x1, #0x4
10084626c:     	b.eq	0x100846280 <_js_json_stringify_full+0x8c0>
100846270:     	lsr	x8, x23, #32
100846274:     	strb	w8, [sp, #0x3c]
100846278:     	cmp	x1, #0x5
10084627c:     	b.ne	0x100847680 <_js_json_stringify_full+0x1cc0>
100846280:     	add	x8, sp, #0x70
100846284:     	add	x0, sp, #0x38
100846288:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084628c:     	ldr	w8, [sp, #0x70]
100846290:     	ldp	x9, x21, [sp, #0x78]
100846294:     	cmp	w8, #0x0
100846298:     	csinc	x22, x9, xzr, eq
10084629c:     	csel	x24, xzr, x21, ne
1008462a0:     	tbz	x24, #0x3f, 0x1008463e0 <_js_json_stringify_full+0xa20>
1008462a4:     	mov	x0, #0x0                ; =0
1008462a8:     	mov	x1, x21
1008462ac:     	bl	0x100b12280 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008462b0:     	add	x8, x26, #0x3
1008462b4:     	cmp	x23, x8
1008462b8:     	b.eq	0x1008461e0 <_js_json_stringify_full+0x820>
1008462bc:     	fmov	d0, x23
1008462c0:     	fcvtzu	x8, d0
1008462c4:     	mov	w9, #0xa                ; =10
1008462c8:     	cmp	x8, #0xa
1008462cc:     	csel	x3, x8, x9, lo
1008462d0:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x1b74>
1008462d4:     	add	x1, x1, #0x61c
1008462d8:     	add	x0, sp, #0x70
1008462dc:     	mov	w2, #0x1                ; =1
1008462e0:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
1008462e4:     	ldr	x21, [sp, #0x80]
1008462e8:     	str	x21, [sp, #0x10]
1008462ec:     	ldr	q0, [sp, #0x70]
1008462f0:     	str	q0, [sp]
1008462f4:     	b	0x1008464a8 <_js_json_stringify_full+0xae8>
1008462f8:     	ldr	w21, [x8, #0x4]
1008462fc:     	add	x9, x8, #0x14
100846300:     	mov	x14, #0x0               ; =0
100846304:     	mov	x8, #0x0                ; =0
100846308:     	cmp	x9, #0x0
10084630c:     	csel	x23, xzr, x21, eq
100846310:     	csinc	x22, x9, xzr, ne
100846314:     	add	x9, x22, x23
100846318:     	mov	w10, #0x1               ; =1
10084631c:     	mov	x11, x22
100846320:     	b	0x100846350 <_js_json_stringify_full+0x990>
100846324:     	add	x12, x11, #0x2
100846328:     	bfi	w15, w13, #6, #5
10084632c:     	mov	x13, x15
100846330:     	sub	x11, x24, x11
100846334:     	add	x14, x11, x12
100846338:     	cmp	w13, #0x10, lsl #12     ; =0x10000
10084633c:     	cinc	x11, x10, hs
100846340:     	add	x8, x11, x8
100846344:     	mov	x11, x12
100846348:     	cmp	x8, #0xa
10084634c:     	b.hi	0x100846408 <_js_json_stringify_full+0xa48>
100846350:     	cmp	x11, x9
100846354:     	b.eq	0x1008463b8 <_js_json_stringify_full+0x9f8>
100846358:     	mov	x24, x14
10084635c:     	mov	x12, x11
100846360:     	ldrsb	w14, [x12], #0x1
100846364:     	and	w13, w14, #0xff
100846368:     	tbz	w14, #0x1f, 0x100846330 <_js_json_stringify_full+0x970>
10084636c:     	ldrb	w12, [x11, #0x1]
100846370:     	and	w15, w12, #0x3f
100846374:     	cmp	w13, #0xe0
100846378:     	b.lo	0x100846324 <_js_json_stringify_full+0x964>
10084637c:     	and	w14, w13, #0x1f
100846380:     	ldrb	w12, [x11, #0x2]
100846384:     	and	w12, w12, #0x3f
100846388:     	orr	w15, w12, w15, lsl #6
10084638c:     	cmp	w13, #0xf0
100846390:     	b.lo	0x1008463ac <_js_json_stringify_full+0x9ec>
100846394:     	add	x12, x11, #0x4
100846398:     	ldrb	w13, [x11, #0x3]
10084639c:     	and	w13, w13, #0x3f
1008463a0:     	orr	w13, w13, w15, lsl #6
1008463a4:     	bfi	w13, w14, #18, #3
1008463a8:     	b	0x100846330 <_js_json_stringify_full+0x970>
1008463ac:     	add	x12, x11, #0x3
1008463b0:     	orr	w13, w15, w14, lsl #12
1008463b4:     	b	0x100846330 <_js_json_stringify_full+0x970>
1008463b8:     	cbz	x23, 0x10084643c <_js_json_stringify_full+0xa7c>
1008463bc:     	mov	x0, x23
1008463c0:     	mov	w1, #0x1                ; =1
1008463c4:     	bl	0x100b5f148 <_mi_malloc_aligned>
1008463c8:     	cbz	x0, 0x100847668 <_js_json_stringify_full+0x1ca8>
1008463cc:     	mov	x25, x0
1008463d0:     	mov	x1, x22
1008463d4:     	mov	x2, x23
1008463d8:     	bl	0x100b61d6c <_writev+0x100b61d6c>
1008463dc:     	b	0x100846444 <_js_json_stringify_full+0xa84>
1008463e0:     	cbz	x24, 0x100846498 <_js_json_stringify_full+0xad8>
1008463e4:     	mov	x0, x24
1008463e8:     	mov	w1, #0x1                ; =1
1008463ec:     	bl	0x100b5f148 <_mi_malloc_aligned>
1008463f0:     	cbz	x0, 0x100847674 <_js_json_stringify_full+0x1cb4>
1008463f4:     	mov	x23, x0
1008463f8:     	mov	x1, x22
1008463fc:     	mov	x2, x24
100846400:     	bl	0x100b61d6c <_writev+0x100b61d6c>
100846404:     	b	0x1008464a0 <_js_json_stringify_full+0xae0>
100846408:     	cbz	x24, 0x10084643c <_js_json_stringify_full+0xa7c>
10084640c:     	cmp	x24, x23
100846410:     	b.hs	0x100846ee8 <_js_json_stringify_full+0x1528>
100846414:     	ldrsb	w8, [x22, x24]
100846418:     	cmn	w8, #0x40
10084641c:     	b.ge	0x100846eec <_js_json_stringify_full+0x152c>
100846420:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846424:     	add	x4, x4, #0x270
100846428:     	mov	x0, x22
10084642c:     	mov	x1, x23
100846430:     	mov	x2, #0x0                ; =0
100846434:     	mov	x3, x24
100846438:     	bl	0x100b125f8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
10084643c:     	mov	x21, #0x0               ; =0
100846440:     	mov	w25, #0x1               ; =1
100846444:     	stp	x21, x25, [sp]
100846448:     	b	0x1008464a4 <_js_json_stringify_full+0xae4>
10084644c:     	add	x14, sp, #0x70
100846450:     	mov	w16, #0x5c              ; =92
100846454:     	strb	w16, [x14, x12]
100846458:     	add	x12, x12, #0x2
10084645c:     	strb	w15, [x13, #0x1]
100846460:     	cmp	w10, #0x2
100846464:     	b.eq	0x100845bd4 <_js_json_stringify_full+0x214>
100846468:     	ldrb	w11, [x11, #0x2]
10084646c:     	sxtb	w10, w11
100846470:     	cmp	w11, #0xb
100846474:     	b.le	0x100846f74 <_js_json_stringify_full+0x15b4>
100846478:     	cmp	w11, #0x21
10084647c:     	b.gt	0x100846fc0 <_js_json_stringify_full+0x1600>
100846480:     	cmp	w11, #0xc
100846484:     	b.eq	0x10084704c <_js_json_stringify_full+0x168c>
100846488:     	cmp	w11, #0xd
10084648c:     	b.ne	0x100846fd0 <_js_json_stringify_full+0x1610>
100846490:     	mov	w10, #0x72              ; =114
100846494:     	b	0x100847058 <_js_json_stringify_full+0x1698>
100846498:     	mov	x21, #0x0               ; =0
10084649c:     	mov	w23, #0x1               ; =1
1008464a0:     	stp	x21, x23, [sp]
1008464a4:     	str	x21, [sp, #0x10]
1008464a8:     	cmp	x27, #0x2
1008464ac:     	b.lo	0x1008465ec <_js_json_stringify_full+0xc2c>
1008464b0:     	and	x24, x20, #0xffff000000000000
1008464b4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008464b8:     	cmp	x24, x8
1008464bc:     	b.ne	0x1008465c8 <_js_json_stringify_full+0xc08>
1008464c0:     	and	x22, x20, #0xffffffffffff
1008464c4:     	cmp	x22, #0x100, lsl #12    ; =0x100000
1008464c8:     	b.lo	0x1008465ec <_js_json_stringify_full+0xc2c>
1008464cc:     	mov	x0, x22
1008464d0:     	bl	0x10050a640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
1008464d4:     	tbnz	w0, #0x0, 0x1008465ec <_js_json_stringify_full+0xc2c>
1008464d8:     	lsr	x8, x22, #51
1008464dc:     	cmp	x8, #0xfff
1008464e0:     	b.lo	0x1008464f8 <_js_json_stringify_full+0xb38>
1008464e4:     	mov	w8, #0x7ffc             ; =32764
1008464e8:     	cmp	x8, x22, lsr #48
1008464ec:     	b.eq	0x1008465ec <_js_json_stringify_full+0xc2c>
1008464f0:     	ands	x22, x22, #0xffffffffffff
1008464f4:     	b.eq	0x1008465ec <_js_json_stringify_full+0xc2c>
1008464f8:     	and	x8, x22, #0xfffffffffff00000
1008464fc:     	lsr	x9, x22, #47
100846500:     	cmp	x9, #0x0
100846504:     	ccmp	x8, #0x0, #0x4, eq
100846508:     	b.eq	0x1008465ec <_js_json_stringify_full+0xc2c>
10084650c:     	tst	x22, #0x3
100846510:     	ccmp	x22, #0x7, #0x0, eq
100846514:     	b.ls	0x100847288 <_js_json_stringify_full+0x18c8>
100846518:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084651c:     	ldr	x8, [x8, #0x48]
100846520:     	cmn	x8, #0x1
100846524:     	b.eq	0x1008471d8 <_js_json_stringify_full+0x1818>
100846528:     	mrs	x9, TPIDRRO_EL0
10084652c:     	and	x9, x9, #0xfffffffffffffff8
100846530:     	ldr	x0, [x9, x8, lsl #3]
100846534:     	cbz	x0, 0x1008471d8 <_js_json_stringify_full+0x1818>
100846538:     	lsr	x1, x22, #20
10084653c:     	ldr	x8, [x0, #0x10]
100846540:     	ldrb	w9, [x8]
100846544:     	cmp	w9, #0x2
100846548:     	b.ne	0x1008471f0 <_js_json_stringify_full+0x1830>
10084654c:     	ldrb	w9, [x8, #0x88]
100846550:     	tbz	w9, #0x0, 0x100846570 <_js_json_stringify_full+0xbb0>
100846554:     	ldr	x9, [x8, #0x80]
100846558:     	cmp	x9, x1
10084655c:     	b.ne	0x100846570 <_js_json_stringify_full+0xbb0>
100846560:     	ldp	x9, x10, [x8, #0x60]
100846564:     	cmp	x9, x22
100846568:     	ccmp	x10, x22, #0x0, ls
10084656c:     	b.hi	0x1008471d0 <_js_json_stringify_full+0x1810>
100846570:     	ldrb	w9, [x8, #0xb8]
100846574:     	cbz	w9, 0x100846594 <_js_json_stringify_full+0xbd4>
100846578:     	ldr	x9, [x8, #0xb0]
10084657c:     	cmp	x9, x1
100846580:     	b.ne	0x100846594 <_js_json_stringify_full+0xbd4>
100846584:     	ldp	x9, x10, [x8, #0x90]
100846588:     	cmp	x9, x22
10084658c:     	ccmp	x10, x22, #0x0, ls
100846590:     	b.hi	0x100847458 <_js_json_stringify_full+0x1a98>
100846594:     	ldrb	w9, [x8, #0xe8]
100846598:     	cbz	w9, 0x100847010 <_js_json_stringify_full+0x1650>
10084659c:     	ldr	x9, [x8, #0xe0]
1008465a0:     	cmp	x9, x1
1008465a4:     	b.ne	0x100847010 <_js_json_stringify_full+0x1650>
1008465a8:     	ldr	x9, [x8, #0xc0]
1008465ac:     	cmp	x9, x22
1008465b0:     	b.hi	0x100847010 <_js_json_stringify_full+0x1650>
1008465b4:     	ldr	x9, [x8, #0xc8]
1008465b8:     	cmp	x9, x22
1008465bc:     	b.ls	0x100847010 <_js_json_stringify_full+0x1650>
1008465c0:     	add	x9, x8, #0xc0
1008465c4:     	b	0x10084745c <_js_json_stringify_full+0x1a9c>
1008465c8:     	lsr	x8, x20, #52
1008465cc:     	cbnz	x8, 0x1008465ec <_js_json_stringify_full+0xc2c>
1008465d0:     	cbz	x20, 0x1008465ec <_js_json_stringify_full+0xc2c>
1008465d4:     	and	x8, x20, #0x7
1008465d8:     	cbnz	x8, 0x1008465ec <_js_json_stringify_full+0xc2c>
1008465dc:     	mov	x0, x20
1008465e0:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008465e4:     	mov	x22, x20
1008465e8:     	cbnz	w0, 0x1008464c4 <_js_json_stringify_full+0xb04>
1008465ec:     	mov	x24, #-0x1              ; =-1
1008465f0:     	str	x24, [sp, #0x20]
1008465f4:     	mov	w23, #0x1               ; =1
1008465f8:     	cmp	x27, #0x1
1008465fc:     	cset	w8, hi
100846600:     	tst	w8, w23
100846604:     	b.eq	0x100846678 <_js_json_stringify_full+0xcb8>
100846608:     	and	x22, x20, #0xffff000000000000
10084660c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846610:     	cmp	x22, x8
100846614:     	b.ne	0x100846650 <_js_json_stringify_full+0xc90>
100846618:     	and	x8, x20, #0xffffffffffff
10084661c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846620:     	b.lo	0x100846678 <_js_json_stringify_full+0xcb8>
100846624:     	ldr	w8, [x8, #0xc]
100846628:     	mov	w9, #0x4f53             ; =20307
10084662c:     	movk	w9, #0x434c, lsl #16
100846630:     	cmp	w8, w9
100846634:     	b.ne	0x100846678 <_js_json_stringify_full+0xcb8>
100846638:     	and	x8, x20, #0xffffffffffff
10084663c:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846640:     	cmp	x22, x9
100846644:     	csel	x28, x8, x20, eq
100846648:     	mov	w27, #0x1               ; =1
10084664c:     	b	0x10084667c <_js_json_stringify_full+0xcbc>
100846650:     	lsr	x8, x20, #52
100846654:     	cbnz	x8, 0x100846678 <_js_json_stringify_full+0xcb8>
100846658:     	mov	w27, #0x0               ; =0
10084665c:     	cbz	x20, 0x10084667c <_js_json_stringify_full+0xcbc>
100846660:     	and	x8, x20, #0x7
100846664:     	cbnz	x8, 0x10084667c <_js_json_stringify_full+0xcbc>
100846668:     	mov	x0, x20
10084666c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846670:     	mov	x8, x20
100846674:     	tbnz	w0, #0x0, 0x10084661c <_js_json_stringify_full+0xc5c>
100846678:     	mov	w27, #0x0               ; =0
10084667c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846680:     	add	x0, x0, #0xd78
100846684:     	ldr	x8, [x0]
100846688:     	blr	x8
10084668c:     	mov	x20, x0
100846690:     	ldr	w25, [x0]
100846694:     	add	w8, w25, #0x1
100846698:     	str	w8, [x0]
10084669c:     	cbz	w25, 0x10084670c <_js_json_stringify_full+0xd4c>
1008466a0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008466a4:     	add	x0, x0, #0xd00
1008466a8:     	ldr	x8, [x0]
1008466ac:     	blr	x8
1008466b0:     	ldrb	w8, [x0, #0x20]
1008466b4:     	cmp	w8, #0x1
1008466b8:     	b.ne	0x1008474c8 <_js_json_stringify_full+0x1b08>
1008466bc:     	ldr	x8, [x0]
1008466c0:     	cbnz	x8, 0x1008474d4 <_js_json_stringify_full+0x1b14>
1008466c4:     	mov	x8, #-0x1               ; =-1
1008466c8:     	str	x8, [x0]
1008466cc:     	ldr	x22, [x0, #0x18]
1008466d0:     	ldr	x8, [x0, #0x8]
1008466d4:     	cmp	x22, x8
1008466d8:     	b.eq	0x100846ebc <_js_json_stringify_full+0x14fc>
1008466dc:     	ldr	x8, [x0, #0x10]
1008466e0:     	mov	w9, #0x18               ; =24
1008466e4:     	madd	x8, x22, x9, x8
1008466e8:     	mov	w9, #0x8                ; =8
1008466ec:     	stp	xzr, x9, [x8]
1008466f0:     	str	xzr, [x8, #0x10]
1008466f4:     	add	x8, x22, #0x1
1008466f8:     	str	x8, [x0, #0x18]
1008466fc:     	ldr	x8, [x0]
100846700:     	add	x8, x8, #0x1
100846704:     	str	x8, [x0]
100846708:     	b	0x100846774 <_js_json_stringify_full+0xdb4>
10084670c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846710:     	add	x0, x0, #0xdc0
100846714:     	ldr	x8, [x0]
100846718:     	blr	x8
10084671c:     	strb	wzr, [x0]
100846720:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846724:     	add	x0, x0, #0xdf0
100846728:     	ldr	x8, [x0]
10084672c:     	blr	x8
100846730:     	strb	wzr, [x0]
100846734:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100846738:     	ldr	w22, [x8, #0x5a8]
10084673c:     	cmp	w22, #0x300
100846740:     	b.hs	0x100846f0c <_js_json_stringify_full+0x154c>
100846744:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100846748:     	ldr	x8, [x8, #0x48]
10084674c:     	cmn	x8, #0x1
100846750:     	b.eq	0x100846efc <_js_json_stringify_full+0x153c>
100846754:     	mrs	x9, TPIDRRO_EL0
100846758:     	and	x9, x9, #0xfffffffffffffff8
10084675c:     	ldr	x0, [x9, x8, lsl #3]
100846760:     	cbz	x0, 0x100846efc <_js_json_stringify_full+0x153c>
100846764:     	add	x8, x0, x22, lsl #3
100846768:     	ldr	x0, [x8, #0x1e8]
10084676c:     	cbz	x0, 0x100846f0c <_js_json_stringify_full+0x154c>
100846770:     	str	xzr, [x0]
100846774:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846778:     	add	x0, x0, #0xd30
10084677c:     	ldr	x8, [x0]
100846780:     	blr	x8
100846784:     	mov	x22, x0
100846788:     	ldrb	w8, [x0, #0x18]
10084678c:     	cmp	w8, #0x1
100846790:     	b.ne	0x10084747c <_js_json_stringify_full+0x1abc>
100846794:     	ldr	x8, [x0]
100846798:     	mov	x9, #-0x1               ; =-1
10084679c:     	str	x9, [x0]
1008467a0:     	cmn	x8, #0x2
1008467a4:     	b.eq	0x100847614 <_js_json_stringify_full+0x1c54>
1008467a8:     	cmn	x8, #0x1
1008467ac:     	b.eq	0x100846880 <_js_json_stringify_full+0xec0>
1008467b0:     	add	x9, sp, #0x38
1008467b4:     	ldur	q0, [x0, #0x8]
1008467b8:     	stur	q0, [x9, #0x8]
1008467bc:     	str	x8, [sp, #0x38]
1008467c0:     	tbz	w23, #0x0, 0x100846894 <_js_json_stringify_full+0xed4>
1008467c4:     	tbz	w27, #0x0, 0x10084697c <_js_json_stringify_full+0xfbc>
1008467c8:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1008467cc:     	str	x0, [sp, #0x50]
1008467d0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008467d4:     	stp	x28, x8, [sp, #0x78]
1008467d8:     	mov	w8, #0x1                ; =1
1008467dc:     	str	x8, [sp, #0x70]
1008467e0:     	add	x0, sp, #0x70
1008467e4:     	bl	0x10028b520 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
1008467e8:     	mov	x21, x0
1008467ec:     	str	x0, [sp, #0x58]
1008467f0:     	mov	w0, #0x0                ; =0
1008467f4:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008467f8:     	stp	xzr, xzr, [x0]
1008467fc:     	str	wzr, [x0, #0x10]
100846800:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846804:     	bfxil	x8, x0, #0, #48
100846808:     	fmov	d0, x8
10084680c:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100846810:     	mov	x19, x0
100846814:     	adrp	x23, 0x100f7c000 <_perry_global_worker_ts__1>
100846818:     	ldr	x8, [x23, #0x48]
10084681c:     	cmn	x8, #0x1
100846820:     	b.eq	0x1008469e0 <_js_json_stringify_full+0x1020>
100846824:     	mrs	x9, TPIDRRO_EL0
100846828:     	and	x9, x9, #0xfffffffffffffff8
10084682c:     	ldr	x8, [x9, x8, lsl #3]
100846830:     	cbz	x8, 0x1008469e0 <_js_json_stringify_full+0x1020>
100846834:     	ldr	x8, [x8, #0x19e8]
100846838:     	cbz	x8, 0x1008469e0 <_js_json_stringify_full+0x1020>
10084683c:     	ldr	x9, [x8]
100846840:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846844:     	cmp	x9, x10
100846848:     	b.hs	0x10084754c <_js_json_stringify_full+0x1b8c>
10084684c:     	add	x10, x9, #0x1
100846850:     	str	x10, [x8]
100846854:     	ldr	x10, [x8, #0x18]
100846858:     	cmp	x19, x10
10084685c:     	b.hs	0x100847558 <_js_json_stringify_full+0x1b98>
100846860:     	ldr	x10, [x8, #0x10]
100846864:     	mov	w11, #0x18              ; =24
100846868:     	madd	x10, x19, x11, x10
10084686c:     	ldr	x11, [x10]
100846870:     	cbnz	x11, 0x1008475b8 <_js_json_stringify_full+0x1bf8>
100846874:     	ldr	x0, [x10, #0x8]
100846878:     	str	x9, [x8]
10084687c:     	b	0x1008469e8 <_js_json_stringify_full+0x1028>
100846880:     	mov	x8, #0x0                ; =0
100846884:     	mov	w9, #0x1                ; =1
100846888:     	stp	x9, xzr, [sp, #0x40]
10084688c:     	str	x8, [sp, #0x38]
100846890:     	tbnz	w23, #0x0, 0x1008467c4 <_js_json_stringify_full+0xe04>
100846894:     	cmp	x21, #0x0
100846898:     	cset	w6, ne
10084689c:     	ldp	x0, x1, [sp, #0x28]
1008468a0:     	ldp	x3, x4, [sp, #0x8]
1008468a4:     	add	x2, sp, #0x38
1008468a8:     	mov.16b	v0, v8
1008468ac:     	mov	x5, #0x0                ; =0
1008468b0:     	bl	0x100502e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
1008468b4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008468b8:     	add	x0, x0, #0xd90
1008468bc:     	ldr	x8, [x0]
1008468c0:     	blr	x8
1008468c4:     	ldrb	w8, [x0, #0x20]
1008468c8:     	cbnz	w8, 0x1008474e0 <_js_json_stringify_full+0x1b20>
1008468cc:     	ldr	x8, [x0]
1008468d0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1008468d4:     	cmp	x8, x9
1008468d8:     	b.hs	0x100847510 <_js_json_stringify_full+0x1b50>
1008468dc:     	ldr	x9, [x0, #0x18]
1008468e0:     	cbz	x9, 0x1008468ec <_js_json_stringify_full+0xf2c>
1008468e4:     	cbnz	x8, 0x10084751c <_js_json_stringify_full+0x1b5c>
1008468e8:     	str	xzr, [x0, #0x18]
1008468ec:     	ldp	x0, x1, [sp, #0x40]
1008468f0:     	cmp	x1, #0x5
1008468f4:     	b.hi	0x10084695c <_js_json_stringify_full+0xf9c>
1008468f8:     	cbz	x1, 0x100846b6c <_js_json_stringify_full+0x11ac>
1008468fc:     	ldrsb	w8, [x0]
100846900:     	tbnz	w8, #0x1f, 0x10084695c <_js_json_stringify_full+0xf9c>
100846904:     	cmp	x1, #0x1
100846908:     	b.eq	0x100846944 <_js_json_stringify_full+0xf84>
10084690c:     	ldrsb	w8, [x0, #0x1]
100846910:     	tbnz	w8, #0x1f, 0x10084695c <_js_json_stringify_full+0xf9c>
100846914:     	cmp	x1, #0x2
100846918:     	b.eq	0x100846944 <_js_json_stringify_full+0xf84>
10084691c:     	ldrsb	w8, [x0, #0x2]
100846920:     	tbnz	w8, #0x1f, 0x10084695c <_js_json_stringify_full+0xf9c>
100846924:     	cmp	x1, #0x3
100846928:     	b.eq	0x100846944 <_js_json_stringify_full+0xf84>
10084692c:     	ldrsb	w8, [x0, #0x3]
100846930:     	tbnz	w8, #0x1f, 0x10084695c <_js_json_stringify_full+0xf9c>
100846934:     	cmp	x1, #0x4
100846938:     	b.eq	0x100846944 <_js_json_stringify_full+0xf84>
10084693c:     	ldrsb	w8, [x0, #0x4]
100846940:     	tbnz	w8, #0x1f, 0x10084695c <_js_json_stringify_full+0xf9c>
100846944:     	cmp	x1, #0x4
100846948:     	b.hs	0x100846cac <_js_json_stringify_full+0x12ec>
10084694c:     	mov	x10, #0x0               ; =0
100846950:     	mov	x9, #0x0                ; =0
100846954:     	mov	x8, x0
100846958:     	b	0x100846d3c <_js_json_stringify_full+0x137c>
10084695c:     	bl	0x100329e88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846960:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
100846964:     	bfxil	x21, x0, #0, #48
100846968:     	ldp	x23, x0, [sp, #0x38]
10084696c:     	ldrb	w8, [x22, #0x18]
100846970:     	cmp	w8, #0x1
100846974:     	b.eq	0x100846d78 <_js_json_stringify_full+0x13b8>
100846978:     	b	0x1008474a8 <_js_json_stringify_full+0x1ae8>
10084697c:     	mov	w0, #0x0                ; =0
100846980:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846984:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846988:     	bfxil	x8, x0, #0, #48
10084698c:     	fmov	d1, x8
100846990:     	stp	xzr, xzr, [x0]
100846994:     	str	wzr, [x0, #0x10]
100846998:     	mov.16b	v0, v8
10084699c:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
1008469a0:     	mov.16b	v8, v0
1008469a4:     	fmov	x23, d8
1008469a8:     	cmp	x23, x26
1008469ac:     	b.eq	0x100846bf4 <_js_json_stringify_full+0x1234>
1008469b0:     	mov	w8, #0x7ffd             ; =32765
1008469b4:     	cmp	x8, x23, lsr #48
1008469b8:     	b.ne	0x100846bc4 <_js_json_stringify_full+0x1204>
1008469bc:     	and	x8, x23, #0xffffffffffff
1008469c0:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008469c4:     	b.lo	0x100846be8 <_js_json_stringify_full+0x1228>
1008469c8:     	ldr	w8, [x8, #0xc]
1008469cc:     	mov	w9, #0x4f53             ; =20307
1008469d0:     	movk	w9, #0x434c, lsl #16
1008469d4:     	cmp	w8, w9
1008469d8:     	b.ne	0x100846be8 <_js_json_stringify_full+0x1228>
1008469dc:     	b	0x100846bf4 <_js_json_stringify_full+0x1234>
1008469e0:     	mov	x0, x19
1008469e4:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
1008469e8:     	fmov	d1, x0
1008469ec:     	mov.16b	v0, v8
1008469f0:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
1008469f4:     	mov.16b	v8, v0
1008469f8:     	ldr	x8, [x23, #0x48]
1008469fc:     	cmn	x8, #0x1
100846a00:     	b.eq	0x100846a64 <_js_json_stringify_full+0x10a4>
100846a04:     	mrs	x9, TPIDRRO_EL0
100846a08:     	and	x9, x9, #0xfffffffffffffff8
100846a0c:     	ldr	x8, [x9, x8, lsl #3]
100846a10:     	cbz	x8, 0x100846a64 <_js_json_stringify_full+0x10a4>
100846a14:     	ldr	x8, [x8, #0x19e8]
100846a18:     	cbz	x8, 0x100846a64 <_js_json_stringify_full+0x10a4>
100846a1c:     	ldr	x9, [x8]
100846a20:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846a24:     	cmp	x9, x10
100846a28:     	b.hs	0x10084754c <_js_json_stringify_full+0x1b8c>
100846a2c:     	add	x10, x9, #0x1
100846a30:     	str	x10, [x8]
100846a34:     	ldr	x10, [x8, #0x18]
100846a38:     	cmp	x21, x10
100846a3c:     	b.hs	0x100847558 <_js_json_stringify_full+0x1b98>
100846a40:     	ldr	x10, [x8, #0x10]
100846a44:     	mov	w11, #0x18              ; =24
100846a48:     	madd	x10, x21, x11, x10
100846a4c:     	ldr	x11, [x10]
100846a50:     	cmp	x11, #0x1
100846a54:     	b.ne	0x10084762c <_js_json_stringify_full+0x1c6c>
100846a58:     	ldr	x21, [x10, #0x8]
100846a5c:     	str	x9, [x8]
100846a60:     	b	0x100846a70 <_js_json_stringify_full+0x10b0>
100846a64:     	mov	x0, x21
100846a68:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846a6c:     	mov	x21, x0
100846a70:     	ldr	x8, [x23, #0x48]
100846a74:     	cmn	x8, #0x1
100846a78:     	b.eq	0x100846ad8 <_js_json_stringify_full+0x1118>
100846a7c:     	mrs	x9, TPIDRRO_EL0
100846a80:     	and	x9, x9, #0xfffffffffffffff8
100846a84:     	ldr	x8, [x9, x8, lsl #3]
100846a88:     	cbz	x8, 0x100846ad8 <_js_json_stringify_full+0x1118>
100846a8c:     	ldr	x8, [x8, #0x19e8]
100846a90:     	cbz	x8, 0x100846ad8 <_js_json_stringify_full+0x1118>
100846a94:     	ldr	x9, [x8]
100846a98:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846a9c:     	cmp	x9, x10
100846aa0:     	b.hs	0x10084754c <_js_json_stringify_full+0x1b8c>
100846aa4:     	add	x10, x9, #0x1
100846aa8:     	str	x10, [x8]
100846aac:     	ldr	x10, [x8, #0x18]
100846ab0:     	cmp	x19, x10
100846ab4:     	b.hs	0x100847558 <_js_json_stringify_full+0x1b98>
100846ab8:     	ldr	x10, [x8, #0x10]
100846abc:     	mov	w11, #0x18              ; =24
100846ac0:     	madd	x10, x19, x11, x10
100846ac4:     	ldr	x11, [x10]
100846ac8:     	cbnz	x11, 0x1008475b8 <_js_json_stringify_full+0x1bf8>
100846acc:     	ldr	x0, [x10, #0x8]
100846ad0:     	str	x9, [x8]
100846ad4:     	b	0x100846ae0 <_js_json_stringify_full+0x1120>
100846ad8:     	mov	x0, x19
100846adc:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846ae0:     	fmov	d9, x0
100846ae4:     	mov.16b	v0, v8
100846ae8:     	bl	0x1004ff434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100846aec:     	mov.16b	v2, v0
100846af0:     	mov	x0, x21
100846af4:     	mov.16b	v0, v9
100846af8:     	mov.16b	v1, v8
100846afc:     	bl	0x1004ff714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100846b00:     	str	d0, [sp, #0x60]
100846b04:     	fmov	x19, d0
100846b08:     	cmp	x19, x26
100846b0c:     	b.ne	0x100846b74 <_js_json_stringify_full+0x11b4>
100846b10:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846b14:     	add	x0, x0, #0xd90
100846b18:     	ldr	x8, [x0]
100846b1c:     	blr	x8
100846b20:     	ldrb	w8, [x0, #0x20]
100846b24:     	cbnz	w8, 0x10084760c <_js_json_stringify_full+0x1c4c>
100846b28:     	ldr	x8, [x0]
100846b2c:     	cbnz	x8, 0x10084765c <_js_json_stringify_full+0x1c9c>
100846b30:     	str	xzr, [x0, #0x18]
100846b34:     	ldp	x21, x19, [sp, #0x38]
100846b38:     	ldrb	w8, [x22, #0x18]
100846b3c:     	cmp	w8, #0x1
100846b40:     	b.ne	0x100847590 <_js_json_stringify_full+0x1bd0>
100846b44:     	ldp	x8, x0, [x22]
100846b48:     	stp	x21, x19, [x22]
100846b4c:     	str	xzr, [x22, #0x10]
100846b50:     	sub	x8, x8, #0x1
100846b54:     	cmn	x8, #0x2
100846b58:     	b.hs	0x100846b60 <_js_json_stringify_full+0x11a0>
100846b5c:     	bl	0x100b5eec0 <_mi_free>
100846b60:     	cbz	w25, 0x100846e20 <_js_json_stringify_full+0x1460>
100846b64:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846b68:     	b	0x100846e24 <_js_json_stringify_full+0x1464>
100846b6c:     	mov	x10, #0x0               ; =0
100846b70:     	b	0x100846d5c <_js_json_stringify_full+0x139c>
100846b74:     	add	x0, sp, #0x38
100846b78:     	bl	0x100500470 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100846b7c:     	tbnz	w0, #0x0, 0x100846bb8 <_js_json_stringify_full+0x11f8>
100846b80:     	mov	x0, x19
100846b84:     	bl	0x100327dec <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100846b88:     	cmp	x0, #0x1
100846b8c:     	b.ne	0x100847620 <_js_json_stringify_full+0x1c60>
100846b90:     	add	x8, sp, #0x68
100846b94:     	add	x9, sp, #0x60
100846b98:     	stp	x1, x8, [sp, #0x68]
100846b9c:     	str	x9, [sp, #0x78]
100846ba0:     	add	x8, sp, #0x38
100846ba4:     	mov	x9, sp
100846ba8:     	stp	x8, x9, [sp, #0x80]
100846bac:     	add	x0, sp, #0x58
100846bb0:     	add	x1, sp, #0x70
100846bb4:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100846bb8:     	add	x0, sp, #0x50
100846bbc:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846bc0:     	b	0x1008468b4 <_js_json_stringify_full+0xef4>
100846bc4:     	lsr	x8, x23, #52
100846bc8:     	cbnz	x8, 0x100846be8 <_js_json_stringify_full+0x1228>
100846bcc:     	cbz	x23, 0x100846be8 <_js_json_stringify_full+0x1228>
100846bd0:     	and	x8, x23, #0x7
100846bd4:     	cbnz	x8, 0x100846be8 <_js_json_stringify_full+0x1228>
100846bd8:     	mov	x0, x23
100846bdc:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846be0:     	mov	x8, x23
100846be4:     	tbnz	w0, #0x0, 0x1008469c0 <_js_json_stringify_full+0x1000>
100846be8:     	mov	x0, x23
100846bec:     	bl	0x100509494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100846bf0:     	tbz	w0, #0x0, 0x100846c80 <_js_json_stringify_full+0x12c0>
100846bf4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846bf8:     	add	x0, x0, #0xd90
100846bfc:     	ldr	x8, [x0]
100846c00:     	blr	x8
100846c04:     	ldrb	w8, [x0, #0x20]
100846c08:     	cbnz	w8, 0x10084755c <_js_json_stringify_full+0x1b9c>
100846c0c:     	ldr	x8, [x0]
100846c10:     	cbnz	x8, 0x100847584 <_js_json_stringify_full+0x1bc4>
100846c14:     	str	xzr, [x0, #0x18]
100846c18:     	ldp	x21, x19, [sp, #0x38]
100846c1c:     	ldrb	w8, [x22, #0x18]
100846c20:     	cmp	w8, #0x1
100846c24:     	b.ne	0x100847538 <_js_json_stringify_full+0x1b78>
100846c28:     	ldp	x8, x0, [x22]
100846c2c:     	stp	x21, x19, [x22]
100846c30:     	str	xzr, [x22, #0x10]
100846c34:     	sub	x8, x8, #0x1
100846c38:     	cmn	x8, #0x2
100846c3c:     	b.hs	0x100846c44 <_js_json_stringify_full+0x1284>
100846c40:     	bl	0x100b5eec0 <_mi_free>
100846c44:     	cbz	w25, 0x100846c64 <_js_json_stringify_full+0x12a4>
100846c48:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846c4c:     	ldr	w8, [x20]
100846c50:     	sub	w8, w8, #0x1
100846c54:     	str	w8, [x20]
100846c58:     	cmn	x24, #0x1
100846c5c:     	b.ne	0x100846e40 <_js_json_stringify_full+0x1480>
100846c60:     	b	0x100846e7c <_js_json_stringify_full+0x14bc>
100846c64:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846c68:     	ldr	w8, [x20]
100846c6c:     	sub	w8, w8, #0x1
100846c70:     	str	w8, [x20]
100846c74:     	cmn	x24, #0x1
100846c78:     	b.ne	0x100846e40 <_js_json_stringify_full+0x1480>
100846c7c:     	b	0x100846e7c <_js_json_stringify_full+0x14bc>
100846c80:     	cmp	x19, x23
100846c84:     	b.eq	0x100846c90 <_js_json_stringify_full+0x12d0>
100846c88:     	mov.16b	v0, v8
100846c8c:     	bl	0x10050e86c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100846c90:     	cbz	x21, 0x100846f1c <_js_json_stringify_full+0x155c>
100846c94:     	ldp	x1, x2, [sp, #0x8]
100846c98:     	add	x0, sp, #0x38
100846c9c:     	mov.16b	v0, v8
100846ca0:     	mov	x3, #0x0                ; =0
100846ca4:     	bl	0x100500f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100846ca8:     	b	0x100846f2c <_js_json_stringify_full+0x156c>
100846cac:     	and	x9, x1, #0x4
100846cb0:     	add	x8, x0, x9
100846cb4:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
100846cb8:     	ldr	q0, [x10, #0x940]
100846cbc:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3373a>
100846cc0:     	ldr	q2, [x10, #0x840]
100846cc4:     	movi.2d	v1, #0000000000000000
100846cc8:     	movi.2d	v3, #0x000000000000ff
100846ccc:     	mov	w10, #0x4               ; =4
100846cd0:     	dup.2d	v4, x10
100846cd4:     	mov	x10, x0
100846cd8:     	and	x11, x1, #0x4
100846cdc:     	movi.2d	v5, #0000000000000000
100846ce0:     	ldr	s6, [x10], #0x4
100846ce4:     	ushll.8h	v6, v6, #0x0
100846ce8:     	ushll.4s	v6, v6, #0x0
100846cec:     	ushll2.2d	v7, v6, #0x0
100846cf0:     	and.16b	v7, v7, v3
100846cf4:     	ushll.2d	v6, v6, #0x0
100846cf8:     	and.16b	v6, v6, v3
100846cfc:     	shl.2d	v16, v0, #0x3
100846d00:     	shl.2d	v17, v2, #0x3
100846d04:     	ushl.2d	v6, v6, v17
100846d08:     	ushl.2d	v7, v7, v16
100846d0c:     	orr.16b	v1, v7, v1
100846d10:     	orr.16b	v5, v6, v5
100846d14:     	add.2d	v0, v0, v4
100846d18:     	add.2d	v2, v2, v4
100846d1c:     	subs	x11, x11, #0x4
100846d20:     	b.ne	0x100846ce0 <_js_json_stringify_full+0x1320>
100846d24:     	orr.16b	v0, v5, v1
100846d28:     	mov	d1, v0[1]
100846d2c:     	orr.8b	v0, v0, v1
100846d30:     	fmov	x10, d0
100846d34:     	cmp	x1, x9
100846d38:     	b.eq	0x100846d5c <_js_json_stringify_full+0x139c>
100846d3c:     	add	x11, x0, x1
100846d40:     	lsl	x9, x9, #3
100846d44:     	ldrb	w12, [x8], #0x1
100846d48:     	lsl	x12, x12, x9
100846d4c:     	orr	x10, x12, x10
100846d50:     	add	x9, x9, #0x8
100846d54:     	cmp	x8, x11
100846d58:     	b.ne	0x100846d44 <_js_json_stringify_full+0x1384>
100846d5c:     	orr	x8, x10, x1, lsl #40
100846d60:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846d64:     	orr	x21, x8, x9
100846d68:     	ldr	x23, [sp, #0x38]
100846d6c:     	ldrb	w8, [x22, #0x18]
100846d70:     	cmp	w8, #0x1
100846d74:     	b.ne	0x1008474a8 <_js_json_stringify_full+0x1ae8>
100846d78:     	ldp	x9, x8, [x22]
100846d7c:     	stp	x23, x0, [x22]
100846d80:     	str	xzr, [x22, #0x10]
100846d84:     	sub	x9, x9, #0x1
100846d88:     	cmn	x9, #0x2
100846d8c:     	b.hs	0x100846d98 <_js_json_stringify_full+0x13d8>
100846d90:     	mov	x0, x8
100846d94:     	bl	0x100b5eec0 <_mi_free>
100846d98:     	cbz	w25, 0x100846db8 <_js_json_stringify_full+0x13f8>
100846d9c:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846da0:     	ldr	w8, [x20]
100846da4:     	sub	w8, w8, #0x1
100846da8:     	str	w8, [x20]
100846dac:     	cmn	x24, #0x1
100846db0:     	b.ne	0x100846dd0 <_js_json_stringify_full+0x1410>
100846db4:     	b	0x100846e0c <_js_json_stringify_full+0x144c>
100846db8:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846dbc:     	ldr	w8, [x20]
100846dc0:     	sub	w8, w8, #0x1
100846dc4:     	str	w8, [x20]
100846dc8:     	cmn	x24, #0x1
100846dcc:     	b.eq	0x100846e0c <_js_json_stringify_full+0x144c>
100846dd0:     	ldp	x19, x20, [sp, #0x28]
100846dd4:     	cbz	x20, 0x100846e00 <_js_json_stringify_full+0x1440>
100846dd8:     	add	x22, x19, #0x8
100846ddc:     	b	0x100846dec <_js_json_stringify_full+0x142c>
100846de0:     	add	x22, x22, #0x18
100846de4:     	subs	x20, x20, #0x1
100846de8:     	b.eq	0x100846e00 <_js_json_stringify_full+0x1440>
100846dec:     	ldur	x8, [x22, #-0x8]
100846df0:     	cbz	x8, 0x100846de0 <_js_json_stringify_full+0x1420>
100846df4:     	ldr	x0, [x22]
100846df8:     	bl	0x100b5eec0 <_mi_free>
100846dfc:     	b	0x100846de0 <_js_json_stringify_full+0x1420>
100846e00:     	cbz	x24, 0x100846e0c <_js_json_stringify_full+0x144c>
100846e04:     	mov	x0, x19
100846e08:     	bl	0x100b5eec0 <_mi_free>
100846e0c:     	ldr	x8, [sp]
100846e10:     	cbz	x8, 0x100846e94 <_js_json_stringify_full+0x14d4>
100846e14:     	ldr	x0, [sp, #0x8]
100846e18:     	bl	0x100b5eec0 <_mi_free>
100846e1c:     	b	0x100846e94 <_js_json_stringify_full+0x14d4>
100846e20:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846e24:     	ldr	w8, [x20]
100846e28:     	sub	w8, w8, #0x1
100846e2c:     	str	w8, [x20]
100846e30:     	add	x0, sp, #0x50
100846e34:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846e38:     	cmn	x24, #0x1
100846e3c:     	b.eq	0x100846e7c <_js_json_stringify_full+0x14bc>
100846e40:     	ldp	x19, x20, [sp, #0x28]
100846e44:     	cbz	x20, 0x100846e70 <_js_json_stringify_full+0x14b0>
100846e48:     	add	x21, x19, #0x8
100846e4c:     	b	0x100846e5c <_js_json_stringify_full+0x149c>
100846e50:     	add	x21, x21, #0x18
100846e54:     	subs	x20, x20, #0x1
100846e58:     	b.eq	0x100846e70 <_js_json_stringify_full+0x14b0>
100846e5c:     	ldur	x8, [x21, #-0x8]
100846e60:     	cbz	x8, 0x100846e50 <_js_json_stringify_full+0x1490>
100846e64:     	ldr	x0, [x21]
100846e68:     	bl	0x100b5eec0 <_mi_free>
100846e6c:     	b	0x100846e50 <_js_json_stringify_full+0x1490>
100846e70:     	cbz	x24, 0x100846e7c <_js_json_stringify_full+0x14bc>
100846e74:     	mov	x0, x19
100846e78:     	bl	0x100b5eec0 <_mi_free>
100846e7c:     	ldr	x8, [sp]
100846e80:     	cbz	x8, 0x100846e8c <_js_json_stringify_full+0x14cc>
100846e84:     	ldr	x0, [sp, #0x8]
100846e88:     	bl	0x100b5eec0 <_mi_free>
100846e8c:     	mov	x21, #0x1               ; =1
100846e90:     	movk	x21, #0x7ffc, lsl #48
100846e94:     	mov	x0, x21
100846e98:     	ldp	x29, x30, [sp, #0x100]
100846e9c:     	ldp	x20, x19, [sp, #0xf0]
100846ea0:     	ldp	x22, x21, [sp, #0xe0]
100846ea4:     	ldp	x24, x23, [sp, #0xd0]
100846ea8:     	ldp	x26, x25, [sp, #0xc0]
100846eac:     	ldp	x28, x27, [sp, #0xb0]
100846eb0:     	ldp	d9, d8, [sp, #0xa0]
100846eb4:     	add	sp, sp, #0x110
100846eb8:     	ret
100846ebc:     	mov	x26, x21
100846ec0:     	mov	x21, x28
100846ec4:     	mov	x28, x0
100846ec8:     	add	x0, x0, #0x8
100846ecc:     	bl	0x100b3bc50 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100846ed0:     	mov	x0, x28
100846ed4:     	mov	x28, x21
100846ed8:     	mov	x21, x26
100846edc:     	mov	x26, #0x1               ; =1
100846ee0:     	movk	x26, #0x7ffc, lsl #48
100846ee4:     	b	0x1008466dc <_js_json_stringify_full+0xd1c>
100846ee8:     	b.ne	0x100846420 <_js_json_stringify_full+0xa60>
100846eec:     	tbz	x24, #0x3f, 0x100846f44 <_js_json_stringify_full+0x1584>
100846ef0:     	mov	x0, #0x0                ; =0
100846ef4:     	mov	x1, x24
100846ef8:     	bl	0x100b12280 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100846efc:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100846f00:     	add	x8, x0, x22, lsl #3
100846f04:     	ldr	x0, [x8, #0x1e8]
100846f08:     	cbnz	x0, 0x100846770 <_js_json_stringify_full+0xdb0>
100846f0c:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846f10:     	add	x0, x0, #0x138
100846f14:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100846f18:     	b	0x100846770 <_js_json_stringify_full+0xdb0>
100846f1c:     	add	x1, sp, #0x38
100846f20:     	mov.16b	v0, v8
100846f24:     	mov	w0, #0x0                ; =0
100846f28:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100846f2c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846f30:     	add	x0, x0, #0xdc0
100846f34:     	ldr	x8, [x0]
100846f38:     	blr	x8
100846f3c:     	strb	wzr, [x0]
100846f40:     	b	0x1008468b4 <_js_json_stringify_full+0xef4>
100846f44:     	mov	x0, x24
100846f48:     	mov	w1, #0x1                ; =1
100846f4c:     	bl	0x100b5f148 <_mi_malloc_aligned>
100846f50:     	mov	x25, x0
100846f54:     	mov	w0, #0x1                ; =1
100846f58:     	cbz	x25, 0x100846ef4 <_js_json_stringify_full+0x1534>
100846f5c:     	mov	x0, x25
100846f60:     	mov	x1, x22
100846f64:     	mov	x2, x24
100846f68:     	bl	0x100b61d6c <_writev+0x100b61d6c>
100846f6c:     	mov	x21, x24
100846f70:     	b	0x100846444 <_js_json_stringify_full+0xa84>
100846f74:     	cmp	w11, #0x8
100846f78:     	b.eq	0x100847044 <_js_json_stringify_full+0x1684>
100846f7c:     	cmp	w11, #0x9
100846f80:     	b.eq	0x100847054 <_js_json_stringify_full+0x1694>
100846f84:     	cmp	w11, #0xa
100846f88:     	b.ne	0x100846fd0 <_js_json_stringify_full+0x1610>
100846f8c:     	mov	w10, #0x6e              ; =110
100846f90:     	b	0x100847058 <_js_json_stringify_full+0x1698>
100846f94:     	mov	x22, x0
100846f98:     	and	x0, x19, #0xffffffffffff
100846f9c:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100846fa0:     	cbz	x0, 0x10084707c <_js_json_stringify_full+0x16bc>
100846fa4:     	ldr	w21, [x0]
100846fa8:     	cmp	w21, #0x4
100846fac:     	b.hi	0x100845fa8 <_js_json_stringify_full+0x5e8>
100846fb0:     	ldr	w8, [x0, #0x4]
100846fb4:     	cmp	w21, w8
100846fb8:     	b.hi	0x100845fa8 <_js_json_stringify_full+0x5e8>
100846fbc:     	b	0x100847080 <_js_json_stringify_full+0x16c0>
100846fc0:     	cmp	w11, #0x22
100846fc4:     	b.eq	0x100847058 <_js_json_stringify_full+0x1698>
100846fc8:     	cmp	w11, #0x5c
100846fcc:     	b.eq	0x100847058 <_js_json_stringify_full+0x1698>
100846fd0:     	cmp	x12, #0x3
100846fd4:     	mov	w11, #0x20              ; =32
100846fd8:     	ccmp	w10, w11, #0x8, ls
100846fdc:     	b.lt	0x100845ee4 <_js_json_stringify_full+0x524>
100846fe0:     	add	x8, sp, #0x70
100846fe4:     	strb	w10, [x8, x12]
100846fe8:     	add	x12, x12, #0x1
100846fec:     	b	0x100845bd4 <_js_json_stringify_full+0x214>
100846ff0:     	mov	x1, x0
100846ff4:     	and	x0, x19, #0xffffffffffff
100846ff8:     	mov	x22, x1
100846ffc:     	bl	0x1004f8e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100847000:     	cmp	x0, #0x1
100847004:     	b.ne	0x100847128 <_js_json_stringify_full+0x1768>
100847008:     	mov	x21, x1
10084700c:     	b	0x100846e94 <_js_json_stringify_full+0x14d4>
100847010:     	ldrb	w9, [x8, #0x118]
100847014:     	cbz	w9, 0x100847250 <_js_json_stringify_full+0x1890>
100847018:     	ldr	x9, [x8, #0x110]
10084701c:     	cmp	x9, x1
100847020:     	b.ne	0x100847250 <_js_json_stringify_full+0x1890>
100847024:     	ldr	x9, [x8, #0xf0]
100847028:     	cmp	x9, x22
10084702c:     	b.hi	0x100847250 <_js_json_stringify_full+0x1890>
100847030:     	ldr	x9, [x8, #0xf8]
100847034:     	cmp	x9, x22
100847038:     	b.ls	0x100847250 <_js_json_stringify_full+0x1890>
10084703c:     	add	x9, x8, #0xf0
100847040:     	b	0x10084745c <_js_json_stringify_full+0x1a9c>
100847044:     	mov	w10, #0x62              ; =98
100847048:     	b	0x100847058 <_js_json_stringify_full+0x1698>
10084704c:     	mov	w10, #0x66              ; =102
100847050:     	b	0x100847058 <_js_json_stringify_full+0x1698>
100847054:     	mov	w10, #0x74              ; =116
100847058:     	cmp	x12, #0x2
10084705c:     	b.hi	0x100845ee4 <_js_json_stringify_full+0x524>
100847060:     	add	x8, sp, #0x70
100847064:     	add	x8, x8, x12
100847068:     	add	x12, x12, #0x2
10084706c:     	mov	w11, #0x5c              ; =92
100847070:     	strb	w11, [x8]
100847074:     	strb	w10, [x8, #0x1]
100847078:     	b	0x100845bd4 <_js_json_stringify_full+0x214>
10084707c:     	mov	x21, #0x0               ; =0
100847080:     	ldr	w8, [x22, #0x4]
100847084:     	lsl	x9, x21, #3
100847088:     	add	x9, x9, #0x18
10084708c:     	cmp	x9, x8
100847090:     	b.hi	0x100845fa8 <_js_json_stringify_full+0x5e8>
100847094:     	ldr	w8, [x24, #0x4]
100847098:     	mov	w9, #-0x40000000        ; =-1073741824
10084709c:     	cmp	w8, w9
1008470a0:     	csel	w8, w8, wzr, lt
1008470a4:     	mov	x22, x0
1008470a8:     	mov	x0, x8
1008470ac:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1008470b0:     	mov	w9, #0x2                ; =2
1008470b4:     	cmp	w1, #0x2
1008470b8:     	csel	w10, w1, w9, hi
1008470bc:     	tst	w0, #0x1
1008470c0:     	csel	x8, x10, x9, ne
1008470c4:     	cmp	x21, x8
1008470c8:     	b.hi	0x100845fa8 <_js_json_stringify_full+0x5e8>
1008470cc:     	cbz	x21, 0x10084748c <_js_json_stringify_full+0x1acc>
1008470d0:     	mov	x0, x22
1008470d4:     	mov	x1, x21
1008470d8:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008470dc:     	tbz	w0, #0x0, 0x100845fa8 <_js_json_stringify_full+0x5e8>
1008470e0:     	cmp	x21, #0x1
1008470e4:     	b.eq	0x100847528 <_js_json_stringify_full+0x1b68>
1008470e8:     	cmp	x21, #0x2
1008470ec:     	b.ne	0x1008475e0 <_js_json_stringify_full+0x1c20>
1008470f0:     	mov	x22, #0x0               ; =0
1008470f4:     	add	x24, x24, #0x10
1008470f8:     	mov	w8, #0x1                ; =1
1008470fc:     	mov	x25, x8
100847100:     	ldr	x1, [x24, x22, lsl #3]
100847104:     	add	x0, sp, #0x70
100847108:     	bl	0x1004efe14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084710c:     	ldr	w8, [sp, #0x70]
100847110:     	cmn	w8, #0x1
100847114:     	b.ne	0x1008475c8 <_js_json_stringify_full+0x1c08>
100847118:     	mov	w8, #0x0                ; =0
10084711c:     	mov	w22, #0x1               ; =1
100847120:     	tbnz	w25, #0x0, 0x1008470fc <_js_json_stringify_full+0x173c>
100847124:     	b	0x1008475e0 <_js_json_stringify_full+0x1c20>
100847128:     	and	x0, x19, #0xffffffffffff
10084712c:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100847130:     	cbz	x0, 0x1008471bc <_js_json_stringify_full+0x17fc>
100847134:     	ldr	w21, [x0]
100847138:     	cbz	w21, 0x1008471bc <_js_json_stringify_full+0x17fc>
10084713c:     	cmp	w21, #0x8
100847140:     	b.hi	0x100845f74 <_js_json_stringify_full+0x5b4>
100847144:     	ldr	w8, [x0, #0x4]
100847148:     	cmp	w21, w8
10084714c:     	b.hi	0x100845f74 <_js_json_stringify_full+0x5b4>
100847150:     	ldr	w8, [x22, #0x4]
100847154:     	lsl	x9, x21, #3
100847158:     	add	x9, x9, #0x18
10084715c:     	cmp	x9, x8
100847160:     	b.hi	0x100845f74 <_js_json_stringify_full+0x5b4>
100847164:     	ldr	w8, [x24, #0x4]
100847168:     	mov	w9, #-0x40000000        ; =-1073741824
10084716c:     	cmp	w8, w9
100847170:     	csel	w8, w8, wzr, lt
100847174:     	mov	x22, x0
100847178:     	mov	x0, x8
10084717c:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100847180:     	mov	w9, #0x2                ; =2
100847184:     	cmp	w1, #0x2
100847188:     	csel	w10, w1, w9, hi
10084718c:     	tst	w0, #0x1
100847190:     	csel	w8, w10, w9, ne
100847194:     	cmp	w21, w8
100847198:     	b.hi	0x100845f74 <_js_json_stringify_full+0x5b4>
10084719c:     	mov	x0, x22
1008471a0:     	mov	x1, x21
1008471a4:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008471a8:     	cbz	w0, 0x100845f74 <_js_json_stringify_full+0x5b4>
1008471ac:     	and	x0, x19, #0xffffffffffff
1008471b0:     	mov	x1, x21
1008471b4:     	bl	0x1004f7f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
1008471b8:     	b	0x1008471c4 <_js_json_stringify_full+0x1804>
1008471bc:     	and	x0, x19, #0xffffffffffff
1008471c0:     	bl	0x1004f8cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
1008471c4:     	mov	x21, x1
1008471c8:     	tbz	w0, #0x0, 0x100845f74 <_js_json_stringify_full+0x5b4>
1008471cc:     	b	0x100846e94 <_js_json_stringify_full+0x14d4>
1008471d0:     	add	x9, x8, #0x60
1008471d4:     	b	0x10084745c <_js_json_stringify_full+0x1a9c>
1008471d8:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008471dc:     	lsr	x1, x22, #20
1008471e0:     	ldr	x8, [x0, #0x10]
1008471e4:     	ldrb	w9, [x8]
1008471e8:     	cmp	w9, #0x2
1008471ec:     	b.eq	0x10084654c <_js_json_stringify_full+0xb8c>
1008471f0:     	ldr	x9, [x8, #0x8]
1008471f4:     	ldr	x10, [x8, #0x28]
1008471f8:     	sub	x9, x1, x9
1008471fc:     	cmp	x9, x10
100847200:     	b.hs	0x100847244 <_js_json_stringify_full+0x1884>
100847204:     	ldr	x10, [x8, #0x20]
100847208:     	mov	w11, #0x28              ; =40
10084720c:     	madd	x9, x9, x11, x10
100847210:     	ldr	x10, [x9]
100847214:     	ldr	x11, [x8, #0x10]
100847218:     	cmp	x10, x11
10084721c:     	b.ne	0x100847250 <_js_json_stringify_full+0x1890>
100847220:     	ldp	x10, x11, [x9, #0x8]
100847224:     	cmp	x10, x22
100847228:     	ccmp	x11, x22, #0x0, ls
10084722c:     	b.ls	0x100847250 <_js_json_stringify_full+0x1890>
100847230:     	ldr	x10, [x8, #0x30]
100847234:     	add	x10, x10, #0x1
100847238:     	str	x10, [x8, #0x30]
10084723c:     	add	x8, x9, #0x21
100847240:     	b	0x10084746c <_js_json_stringify_full+0x1aac>
100847244:     	ldr	x9, [x8, #0x58]
100847248:     	add	x9, x9, #0x1
10084724c:     	str	x9, [x8, #0x58]
100847250:     	ldr	x9, [x8, #0x38]
100847254:     	add	x9, x9, #0x1
100847258:     	str	x9, [x8, #0x38]
10084725c:     	mov	x0, x22
100847260:     	bl	0x10051e348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100847264:     	and	w8, w0, #0xff
100847268:     	cbz	w8, 0x100847288 <_js_json_stringify_full+0x18c8>
10084726c:     	ldurb	w8, [x22, #-0x8]
100847270:     	ldurb	w9, [x22, #-0x7]
100847274:     	mov	w10, #0x82              ; =130
100847278:     	and	w9, w9, w10
10084727c:     	cmp	w9, #0x2
100847280:     	ccmp	w8, #0x1, #0x0, eq
100847284:     	b.eq	0x10084731c <_js_json_stringify_full+0x195c>
100847288:     	mov	x0, x22
10084728c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847290:     	mov	x23, x0
100847294:     	cbz	x0, 0x1008472c0 <_js_json_stringify_full+0x1900>
100847298:     	ldrb	w8, [x23]
10084729c:     	cmp	w8, #0x1
1008472a0:     	b.ne	0x1008472e0 <_js_json_stringify_full+0x1920>
1008472a4:     	ldrsb	w8, [x23, #0x1]
1008472a8:     	tbnz	w8, #0x1f, 0x100847344 <_js_json_stringify_full+0x1984>
1008472ac:     	mov	x0, x23
1008472b0:     	ldp	w9, w8, [x22]
1008472b4:     	cmp	w9, w8
1008472b8:     	b.hi	0x1008473c8 <_js_json_stringify_full+0x1a08>
1008472bc:     	b	0x1008473e0 <_js_json_stringify_full+0x1a20>
1008472c0:     	mov	x0, x22
1008472c4:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008472c8:     	tbnz	w0, #0x0, 0x1008472d8 <_js_json_stringify_full+0x1918>
1008472cc:     	mov	x0, x22
1008472d0:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008472d4:     	tbz	w0, #0x0, 0x1008465ec <_js_json_stringify_full+0xc2c>
1008472d8:     	mov	x0, #0x0                ; =0
1008472dc:     	b	0x1008473b8 <_js_json_stringify_full+0x19f8>
1008472e0:     	mov	x0, x23
1008472e4:     	cmp	w8, #0x1
1008472e8:     	b.eq	0x1008473b8 <_js_json_stringify_full+0x19f8>
1008472ec:     	cmp	w8, #0x9
1008472f0:     	b.ne	0x1008465ec <_js_json_stringify_full+0xc2c>
1008472f4:     	ldr	w8, [x22, #0x4]
1008472f8:     	mov	w9, #0x5841             ; =22593
1008472fc:     	movk	w9, #0x4c5a, lsl #16
100847300:     	cmp	w8, w9
100847304:     	b.ne	0x1008465ec <_js_json_stringify_full+0xc2c>
100847308:     	mov	x0, x22
10084730c:     	bl	0x1003759b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100847310:     	mov	x22, x0
100847314:     	cbnz	x0, 0x100847408 <_js_json_stringify_full+0x1a48>
100847318:     	b	0x1008465ec <_js_json_stringify_full+0xc2c>
10084731c:     	ldr	w8, [x22]
100847320:     	mov	w9, #0xe100             ; =57600
100847324:     	movk	w9, #0x5f5, lsl #16
100847328:     	orr	w9, w9, #0x1
10084732c:     	cmp	w8, w9
100847330:     	b.hs	0x100847288 <_js_json_stringify_full+0x18c8>
100847334:     	ldr	w9, [x22, #0x4]
100847338:     	cmp	w8, w9
10084733c:     	b.ls	0x100847408 <_js_json_stringify_full+0x1a48>
100847340:     	b	0x100847288 <_js_json_stringify_full+0x18c8>
100847344:     	ldr	x22, [x23, #0x8]
100847348:     	mov	x0, x22
10084734c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847350:     	cbz	x0, 0x1008465ec <_js_json_stringify_full+0xc2c>
100847354:     	ldrb	w8, [x0]
100847358:     	cmp	w8, #0x1
10084735c:     	b.ne	0x1008465ec <_js_json_stringify_full+0xc2c>
100847360:     	ldrsb	w8, [x0, #0x1]
100847364:     	tbz	w8, #0x1f, 0x1008472b0 <_js_json_stringify_full+0x18f0>
100847368:     	mov	w25, #0x1               ; =1
10084736c:     	ldr	x22, [x0, #0x8]
100847370:     	mov	x0, x22
100847374:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847378:     	cbz	x0, 0x1008465ec <_js_json_stringify_full+0xc2c>
10084737c:     	ldrb	w8, [x0]
100847380:     	cmp	w8, #0x1
100847384:     	b.ne	0x1008465ec <_js_json_stringify_full+0xc2c>
100847388:     	cmp	w25, #0x3f
10084738c:     	b.hi	0x1008465ec <_js_json_stringify_full+0xc2c>
100847390:     	add	w25, w25, #0x1
100847394:     	ldrsb	w8, [x0, #0x1]
100847398:     	tbnz	w8, #0x1f, 0x10084736c <_js_json_stringify_full+0x19ac>
10084739c:     	str	x22, [x23, #0x8]
1008473a0:     	ldrb	w8, [x23, #0x1]
1008473a4:     	orr	w8, w8, #0x80
1008473a8:     	strb	w8, [x23, #0x1]
1008473ac:     	ldrb	w8, [x0]
1008473b0:     	cmp	w8, #0x1
1008473b4:     	b.ne	0x1008472ec <_js_json_stringify_full+0x192c>
1008473b8:     	ldp	w9, w8, [x22]
1008473bc:     	cmp	w9, w8
1008473c0:     	b.ls	0x1008473e0 <_js_json_stringify_full+0x1a20>
1008473c4:     	cbz	x23, 0x1008473f0 <_js_json_stringify_full+0x1a30>
1008473c8:     	ldr	w9, [x0, #0x4]
1008473cc:     	ubfiz	x8, x8, #3, #32
1008473d0:     	add	x8, x8, #0x10
1008473d4:     	cmp	x8, x9
1008473d8:     	b.eq	0x100847408 <_js_json_stringify_full+0x1a48>
1008473dc:     	b	0x1008473f0 <_js_json_stringify_full+0x1a30>
1008473e0:     	mov	w8, #0xe100             ; =57600
1008473e4:     	movk	w8, #0x5f5, lsl #16
1008473e8:     	cmp	w9, w8
1008473ec:     	b.ls	0x100847408 <_js_json_stringify_full+0x1a48>
1008473f0:     	mov	x0, x22
1008473f4:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008473f8:     	tbnz	w0, #0x0, 0x100847408 <_js_json_stringify_full+0x1a48>
1008473fc:     	mov	x0, x22
100847400:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847404:     	tbz	w0, #0x0, 0x1008465ec <_js_json_stringify_full+0xc2c>
100847408:     	ldp	w8, w9, [x22]
10084740c:     	sub	w10, w9, #0x1
100847410:     	mov	w11, #0x270f            ; =9999
100847414:     	cmp	w10, w11
100847418:     	ccmp	w8, w9, #0x2, lo
10084741c:     	b.hi	0x1008465ec <_js_json_stringify_full+0xc2c>
100847420:     	and	x8, x20, #0xffffffffffff
100847424:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100847428:     	cmp	x24, x9
10084742c:     	csel	x1, x8, x20, eq
100847430:     	add	x0, sp, #0x20
100847434:     	bl	0x1004ffc78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100847438:     	ldr	x24, [sp, #0x20]
10084743c:     	cmn	x24, #0x1
100847440:     	cset	w23, eq
100847444:     	cmp	x27, #0x1
100847448:     	cset	w8, hi
10084744c:     	tst	w8, w23
100847450:     	b.ne	0x100846608 <_js_json_stringify_full+0xc48>
100847454:     	b	0x100846678 <_js_json_stringify_full+0xcb8>
100847458:     	add	x9, x8, #0x90
10084745c:     	ldr	x10, [x8, #0x30]
100847460:     	add	x10, x10, #0x1
100847464:     	str	x10, [x8, #0x30]
100847468:     	add	x8, x9, #0x19
10084746c:     	ldrb	w8, [x8]
100847470:     	cmp	w8, #0xff
100847474:     	b.ne	0x100847268 <_js_json_stringify_full+0x18a8>
100847478:     	b	0x10084725c <_js_json_stringify_full+0x189c>
10084747c:     	mov	x0, x22
100847480:     	bl	0x100b1e484 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847484:     	cbnz	x0, 0x100846794 <_js_json_stringify_full+0xdd4>
100847488:     	b	0x100847614 <_js_json_stringify_full+0x1c54>
10084748c:     	and	x0, x19, #0xffffffffffff
100847490:     	bl	0x1004f7d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847494:     	mov	w0, w0
100847498:     	mov	x21, #0x7d7b            ; =32123
10084749c:     	movk	x21, #0x200, lsl #32
1008474a0:     	movk	x21, #0x7ff9, lsl #48
1008474a4:     	b	0x1008475f8 <_js_json_stringify_full+0x1c38>
1008474a8:     	mov	x19, x0
1008474ac:     	mov	x0, x22
1008474b0:     	bl	0x100b1e484 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008474b4:     	mov	x22, x0
1008474b8:     	mov	x0, x19
1008474bc:     	cbnz	x22, 0x100846d78 <_js_json_stringify_full+0x13b8>
1008474c0:     	cbnz	x23, 0x1008475a4 <_js_json_stringify_full+0x1be4>
1008474c4:     	b	0x100847614 <_js_json_stringify_full+0x1c54>
1008474c8:     	bl	0x100b1e5e4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
1008474cc:     	cbnz	x0, 0x1008466bc <_js_json_stringify_full+0xcfc>
1008474d0:     	b	0x100847614 <_js_json_stringify_full+0x1c54>
1008474d4:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1008474d8:     	add	x0, x0, #0x440
1008474dc:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008474e0:     	cmp	w8, #0x1
1008474e4:     	b.ne	0x100847614 <_js_json_stringify_full+0x1c54>
1008474e8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008474ec:     	add	x1, x1, #0x998
1008474f0:     	mov	x19, x0
1008474f4:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008474f8:     	mov	x0, x19
1008474fc:     	strb	wzr, [x19, #0x20]
100847500:     	ldr	x8, [x19]
100847504:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847508:     	cmp	x8, x9
10084750c:     	b.lo	0x1008468dc <_js_json_stringify_full+0xf1c>
100847510:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847514:     	add	x0, x0, #0xea8
100847518:     	bl	0x100b1265c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084751c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847520:     	add	x0, x0, #0xec0
100847524:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847528:     	and	x0, x19, #0xffffffffffff
10084752c:     	bl	0x1004ef9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
100847530:     	mov	x21, x1
100847534:     	b	0x1008475f8 <_js_json_stringify_full+0x1c38>
100847538:     	mov	x0, x22
10084753c:     	bl	0x100b1e484 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847540:     	mov	x22, x0
100847544:     	cbnz	x0, 0x100846c28 <_js_json_stringify_full+0x1268>
100847548:     	b	0x1008475a0 <_js_json_stringify_full+0x1be0>
10084754c:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847550:     	add	x0, x0, #0xd70
100847554:     	bl	0x100b1265c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847558:     	bl	0x100b4b854 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084755c:     	cmp	w8, #0x2
100847560:     	b.eq	0x100847614 <_js_json_stringify_full+0x1c54>
100847564:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847568:     	add	x1, x1, #0x998
10084756c:     	mov	x19, x0
100847570:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847574:     	mov	x0, x19
100847578:     	strb	wzr, [x19, #0x20]
10084757c:     	ldr	x8, [x19]
100847580:     	cbz	x8, 0x100846c14 <_js_json_stringify_full+0x1254>
100847584:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847588:     	add	x0, x0, #0xe90
10084758c:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847590:     	mov	x0, x22
100847594:     	bl	0x100b1e484 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847598:     	mov	x22, x0
10084759c:     	cbnz	x0, 0x100846b44 <_js_json_stringify_full+0x1184>
1008475a0:     	cbz	x21, 0x100847614 <_js_json_stringify_full+0x1c54>
1008475a4:     	mov	x0, x19
1008475a8:     	bl	0x100b5eec0 <_mi_free>
1008475ac:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008475b0:     	add	x0, x0, #0xc18
1008475b4:     	bl	0x100b5851c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008475b8:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xb74>
1008475bc:     	add	x0, x0, #0x3b0
1008475c0:     	mov	w1, #0xf                ; =15
1008475c4:     	bl	0x100b4b81c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008475c8:     	and	x0, x19, #0xffffffffffff
1008475cc:     	add	x2, sp, #0x70
1008475d0:     	mov	x1, x22
1008475d4:     	bl	0x1004f01c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008475d8:     	tbnz	w0, #0x0, 0x100847008 <_js_json_stringify_full+0x1648>
1008475dc:     	mov	w21, #0x2               ; =2
1008475e0:     	and	x0, x19, #0xffffffffffff
1008475e4:     	mov	x1, x21
1008475e8:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
1008475ec:     	mov	x21, x1
1008475f0:     	mov	x26, #0x1               ; =1
1008475f4:     	movk	x26, #0x7ffc, lsl #48
1008475f8:     	tbnz	w0, #0x0, 0x100846e94 <_js_json_stringify_full+0x14d4>
1008475fc:     	mov	w21, #0x1               ; =1
100847600:     	cmp	x19, x26
100847604:     	b.eq	0x100846e8c <_js_json_stringify_full+0x14cc>
100847608:     	b	0x100845fb4 <_js_json_stringify_full+0x5f4>
10084760c:     	cmp	w8, #0x2
100847610:     	b.ne	0x10084763c <_js_json_stringify_full+0x1c7c>
100847614:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847618:     	add	x0, x0, #0xc18
10084761c:     	bl	0x100b5851c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847620:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
100847624:     	add	x0, x0, #0x800
100847628:     	bl	0x100b126f0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10084762c:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xb74>
100847630:     	add	x0, x0, #0xe7
100847634:     	mov	w1, #0xb                ; =11
100847638:     	bl	0x100b4b81c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084763c:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847640:     	add	x1, x1, #0x998
100847644:     	mov	x19, x0
100847648:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084764c:     	mov	x0, x19
100847650:     	strb	wzr, [x19, #0x20]
100847654:     	ldr	x8, [x19]
100847658:     	cbz	x8, 0x100846b30 <_js_json_stringify_full+0x1170>
10084765c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847660:     	add	x0, x0, #0xe78
100847664:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847668:     	mov	w0, #0x1                ; =1
10084766c:     	mov	x1, x23
100847670:     	bl	0x100b12280 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847674:     	mov	w0, #0x1                ; =1
100847678:     	mov	x1, x21
10084767c:     	bl	0x100b12280 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847680:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847684:     	add	x2, x2, #0x3c8
100847688:     	mov	w0, #0x5                ; =5
10084768c:     	mov	w1, #0x5                ; =5
100847690:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
