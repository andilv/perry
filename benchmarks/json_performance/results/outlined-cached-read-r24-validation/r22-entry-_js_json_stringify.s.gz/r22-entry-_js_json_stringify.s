
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/r22-shared-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008452ec <_js_json_stringify>:
1008452ec:     	sub	sp, sp, #0x80
1008452f0:     	stp	d9, d8, [sp, #0x20]
1008452f4:     	stp	x26, x25, [sp, #0x30]
1008452f8:     	stp	x24, x23, [sp, #0x40]
1008452fc:     	stp	x22, x21, [sp, #0x50]
100845300:     	stp	x20, x19, [sp, #0x60]
100845304:     	stp	x29, x30, [sp, #0x70]
100845308:     	add	x29, sp, #0x70
10084530c:     	mov	x21, x0
100845310:     	mov.16b	v8, v0
100845314:     	fmov	x19, d8
100845318:     	and	x20, x19, #0xffff000000000000
10084531c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100845320:     	cmp	x20, x8
100845324:     	b.ne	0x10084534c <_js_json_stringify+0x60>
100845328:     	and	x0, x19, #0xffffffffffff
10084532c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100845330:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100845334:     	movk	x9, #0xffef, lsl #16
100845338:     	cmp	x8, x9
10084533c:     	b.hi	0x10084534c <_js_json_stringify+0x60>
100845340:     	ldr	w8, [x0, #0x4]
100845344:     	cmp	w8, #0x40
100845348:     	b.hs	0x1008453bc <_js_json_stringify+0xd0>
10084534c:     	mov.16b	v0, v8
100845350:     	bl	0x1004eddbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100845354:     	tbz	w0, #0x0, 0x100845360 <_js_json_stringify+0x74>
100845358:     	mov	x23, x1
10084535c:     	b	0x1008458d0 <_js_json_stringify+0x5e4>
100845360:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845364:     	cmp	x20, x8
100845368:     	b.ne	0x1008453d0 <_js_json_stringify+0xe4>
10084536c:     	ands	x19, x19, #0xffffffffffff
100845370:     	b.eq	0x1008453d0 <_js_json_stringify+0xe4>
100845374:     	mov	x0, x19
100845378:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084537c:     	cbz	w0, 0x1008453d0 <_js_json_stringify+0xe4>
100845380:     	ldurb	w8, [x19, #-0x8]
100845384:     	cmp	w8, #0x9
100845388:     	b.ne	0x1008453d0 <_js_json_stringify+0xe4>
10084538c:     	ldr	w8, [x19, #0x4]
100845390:     	mov	w9, #0x5841             ; =22593
100845394:     	movk	w9, #0x4c5a, lsl #16
100845398:     	cmp	w8, w9
10084539c:     	b.ne	0x1008453d0 <_js_json_stringify+0xe4>
1008453a0:     	mov	x0, x19
1008453a4:     	bl	0x10068829c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008453a8:     	cbz	x0, 0x1008453d0 <_js_json_stringify+0xe4>
1008453ac:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008453b0:     	bfxil	x8, x0, #0, #48
1008453b4:     	fmov	d8, x8
1008453b8:     	b	0x1008453d0 <_js_json_stringify+0xe4>
1008453bc:     	bl	0x1004f2ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
1008453c0:     	tbnz	w0, #0x0, 0x100845358 <_js_json_stringify+0x6c>
1008453c4:     	mov.16b	v0, v8
1008453c8:     	bl	0x1004eddbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008453cc:     	tbnz	w0, #0x0, 0x100845358 <_js_json_stringify+0x6c>
1008453d0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008453d4:     	add	x0, x0, #0xd78
1008453d8:     	ldr	x8, [x0]
1008453dc:     	blr	x8
1008453e0:     	mov	x19, x0
1008453e4:     	ldr	w26, [x0]
1008453e8:     	add	w8, w26, #0x1
1008453ec:     	str	w8, [x0]
1008453f0:     	cbz	w26, 0x100845460 <_js_json_stringify+0x174>
1008453f4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008453f8:     	add	x0, x0, #0xd00
1008453fc:     	ldr	x8, [x0]
100845400:     	blr	x8
100845404:     	ldrb	w8, [x0, #0x20]
100845408:     	cmp	w8, #0x1
10084540c:     	b.ne	0x1008459c4 <_js_json_stringify+0x6d8>
100845410:     	ldr	x8, [x0]
100845414:     	cbnz	x8, 0x1008459d0 <_js_json_stringify+0x6e4>
100845418:     	mov	x8, #-0x1               ; =-1
10084541c:     	str	x8, [x0]
100845420:     	ldr	x20, [x0, #0x18]
100845424:     	ldr	x8, [x0, #0x8]
100845428:     	cmp	x20, x8
10084542c:     	b.eq	0x1008458f4 <_js_json_stringify+0x608>
100845430:     	ldr	x8, [x0, #0x10]
100845434:     	mov	w9, #0x18               ; =24
100845438:     	madd	x8, x20, x9, x8
10084543c:     	mov	w9, #0x8                ; =8
100845440:     	stp	xzr, x9, [x8]
100845444:     	str	xzr, [x8, #0x10]
100845448:     	add	x8, x20, #0x1
10084544c:     	str	x8, [x0, #0x18]
100845450:     	ldr	x8, [x0]
100845454:     	add	x8, x8, #0x1
100845458:     	str	x8, [x0]
10084545c:     	b	0x1008454ec <_js_json_stringify+0x200>
100845460:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845464:     	add	x0, x0, #0xdc0
100845468:     	ldr	x8, [x0]
10084546c:     	blr	x8
100845470:     	strb	wzr, [x0]
100845474:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845478:     	add	x0, x0, #0xdf0
10084547c:     	ldr	x8, [x0]
100845480:     	blr	x8
100845484:     	strb	wzr, [x0]
100845488:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10084548c:     	ldr	w20, [x8, #0x5a8]
100845490:     	cmp	w20, #0x300
100845494:     	b.hs	0x100845950 <_js_json_stringify+0x664>
100845498:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084549c:     	ldr	x8, [x8, #0x48]
1008454a0:     	cmn	x8, #0x1
1008454a4:     	b.eq	0x100845940 <_js_json_stringify+0x654>
1008454a8:     	mrs	x9, TPIDRRO_EL0
1008454ac:     	and	x9, x9, #0xfffffffffffffff8
1008454b0:     	ldr	x0, [x9, x8, lsl #3]
1008454b4:     	cbz	x0, 0x100845940 <_js_json_stringify+0x654>
1008454b8:     	add	x8, x0, x20, lsl #3
1008454bc:     	ldr	x0, [x8, #0x1e8]
1008454c0:     	cbz	x0, 0x100845950 <_js_json_stringify+0x664>
1008454c4:     	str	xzr, [x0]
1008454c8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008454cc:     	add	x0, x0, #0xd90
1008454d0:     	ldr	x8, [x0]
1008454d4:     	blr	x8
1008454d8:     	ldrb	w8, [x0, #0x20]
1008454dc:     	cbnz	w8, 0x1008459dc <_js_json_stringify+0x6f0>
1008454e0:     	ldr	x8, [x0]
1008454e4:     	cbnz	x8, 0x100845a04 <_js_json_stringify+0x718>
1008454e8:     	str	xzr, [x0, #0x18]
1008454ec:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008454f0:     	add	x0, x0, #0xd30
1008454f4:     	ldr	x8, [x0]
1008454f8:     	blr	x8
1008454fc:     	mov	x20, x0
100845500:     	ldrb	w8, [x0, #0x18]
100845504:     	cmp	w8, #0x1
100845508:     	b.ne	0x100845960 <_js_json_stringify+0x674>
10084550c:     	ldr	x8, [x0]
100845510:     	mov	x9, #-0x1               ; =-1
100845514:     	str	x9, [x0]
100845518:     	cmn	x8, #0x2
10084551c:     	b.eq	0x100845a10 <_js_json_stringify+0x724>
100845520:     	cmn	x8, #0x1
100845524:     	b.eq	0x100845538 <_js_json_stringify+0x24c>
100845528:     	add	x9, sp, #0x8
10084552c:     	ldur	q0, [x0, #0x8]
100845530:     	stur	q0, [x9, #0x8]
100845534:     	b	0x100845544 <_js_json_stringify+0x258>
100845538:     	mov	x8, #0x0                ; =0
10084553c:     	mov	w9, #0x1                ; =1
100845540:     	stp	x9, xzr, [sp, #0x10]
100845544:     	str	x8, [sp, #0x8]
100845548:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084554c:     	add	x0, x0, #0xd18
100845550:     	ldr	x8, [x0]
100845554:     	blr	x8
100845558:     	ldrb	w8, [x0, #0x20]
10084555c:     	cbnz	w8, 0x100845990 <_js_json_stringify+0x6a4>
100845560:     	ldr	x8, [x0]
100845564:     	cbnz	x8, 0x1008459b8 <_js_json_stringify+0x6cc>
100845568:     	str	xzr, [x0, #0x18]
10084556c:     	add	x1, sp, #0x8
100845570:     	mov.16b	v0, v8
100845574:     	mov	x0, x21
100845578:     	bl	0x1005095ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084557c:     	ldp	x21, x22, [sp, #0x10]
100845580:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100845584:     	b.hs	0x100845644 <_js_json_stringify+0x358>
100845588:     	cmp	x22, #0x40
10084558c:     	b.hs	0x100845708 <_js_json_stringify+0x41c>
100845590:     	ands	x9, x22, #0x38
100845594:     	b.eq	0x1008455b8 <_js_json_stringify+0x2cc>
100845598:     	and	x8, x22, #0x38
10084559c:     	neg	x8, x8
1008455a0:     	mov	x10, x21
1008455a4:     	ldr	x11, [x10], #0x8
1008455a8:     	tst	x11, #0x8080808080808080
1008455ac:     	b.ne	0x10084562c <_js_json_stringify+0x340>
1008455b0:     	adds	x8, x8, #0x8
1008455b4:     	b.ne	0x1008455a4 <_js_json_stringify+0x2b8>
1008455b8:     	and	x8, x22, #0x7
1008455bc:     	cbz	x8, 0x10084578c <_js_json_stringify+0x4a0>
1008455c0:     	add	x9, x21, x9
1008455c4:     	ldrsb	w10, [x9]
1008455c8:     	tbnz	w10, #0x1f, 0x10084562c <_js_json_stringify+0x340>
1008455cc:     	cmp	x8, #0x1
1008455d0:     	b.eq	0x10084578c <_js_json_stringify+0x4a0>
1008455d4:     	ldrsb	w10, [x9, #0x1]
1008455d8:     	tbnz	w10, #0x1f, 0x10084562c <_js_json_stringify+0x340>
1008455dc:     	cmp	x8, #0x2
1008455e0:     	b.eq	0x10084578c <_js_json_stringify+0x4a0>
1008455e4:     	ldrsb	w10, [x9, #0x2]
1008455e8:     	tbnz	w10, #0x1f, 0x10084562c <_js_json_stringify+0x340>
1008455ec:     	cmp	x8, #0x3
1008455f0:     	b.eq	0x10084578c <_js_json_stringify+0x4a0>
1008455f4:     	ldrsb	w10, [x9, #0x3]
1008455f8:     	tbnz	w10, #0x1f, 0x10084562c <_js_json_stringify+0x340>
1008455fc:     	cmp	x8, #0x4
100845600:     	b.eq	0x10084578c <_js_json_stringify+0x4a0>
100845604:     	ldrsb	w10, [x9, #0x4]
100845608:     	tbnz	w10, #0x1f, 0x10084562c <_js_json_stringify+0x340>
10084560c:     	cmp	x8, #0x5
100845610:     	b.eq	0x10084578c <_js_json_stringify+0x4a0>
100845614:     	ldrsb	w10, [x9, #0x5]
100845618:     	tbnz	w10, #0x1f, 0x10084562c <_js_json_stringify+0x340>
10084561c:     	cmp	x8, #0x6
100845620:     	b.eq	0x10084578c <_js_json_stringify+0x4a0>
100845624:     	ldrsb	w8, [x9, #0x6]
100845628:     	tbz	w8, #0x1f, 0x10084578c <_js_json_stringify+0x4a0>
10084562c:     	mov	x0, x21
100845630:     	mov	x1, x22
100845634:     	mov	x2, x22
100845638:     	bl	0x1008dcd40 <_js_string_from_bytes_with_capacity>
10084563c:     	mov	x23, x0
100845640:     	b	0x100845888 <_js_json_stringify+0x59c>
100845644:     	and	x8, x22, #0x7fffffffffffffc0
100845648:     	add	x8, x21, x8
10084564c:     	mov	x9, x21
100845650:     	ldp	q0, q1, [x9]
100845654:     	ldp	q2, q3, [x9, #0x20]
100845658:     	orr.16b	v0, v1, v0
10084565c:     	orr.16b	v1, v2, v3
100845660:     	orr.16b	v0, v0, v1
100845664:     	umaxv.16b	b0, v0
100845668:     	fmov	w10, s0
10084566c:     	tbnz	w10, #0x7, 0x1008456cc <_js_json_stringify+0x3e0>
100845670:     	add	x9, x9, #0x40
100845674:     	cmp	x9, x8
100845678:     	b.ne	0x100845650 <_js_json_stringify+0x364>
10084567c:     	ands	x9, x22, #0x30
100845680:     	b.eq	0x1008456a4 <_js_json_stringify+0x3b8>
100845684:     	mov	x10, x9
100845688:     	mov	x11, x8
10084568c:     	ldr	q0, [x11], #0x10
100845690:     	umaxv.16b	b0, v0
100845694:     	fmov	w12, s0
100845698:     	tbnz	w12, #0x7, 0x1008456cc <_js_json_stringify+0x3e0>
10084569c:     	subs	x10, x10, #0x10
1008456a0:     	b.ne	0x10084568c <_js_json_stringify+0x3a0>
1008456a4:     	and	x10, x22, #0xf
1008456a8:     	cbz	x10, 0x1008456c4 <_js_json_stringify+0x3d8>
1008456ac:     	add	x8, x8, x9
1008456b0:     	ldrsb	w9, [x8]
1008456b4:     	tbnz	w9, #0x1f, 0x1008456cc <_js_json_stringify+0x3e0>
1008456b8:     	add	x8, x8, #0x1
1008456bc:     	subs	x10, x10, #0x1
1008456c0:     	b.ne	0x1008456b0 <_js_json_stringify+0x3c4>
1008456c4:     	mov	w24, w22
1008456c8:     	b	0x100845700 <_js_json_stringify+0x414>
1008456cc:     	mov	w24, w22
1008456d0:     	cbz	x24, 0x100845700 <_js_json_stringify+0x414>
1008456d4:     	mov	x8, x21
1008456d8:     	ands	x9, x22, #0x3
1008456dc:     	b.eq	0x1008456f8 <_js_json_stringify+0x40c>
1008456e0:     	mov	x8, x21
1008456e4:     	ldrsb	w10, [x8]
1008456e8:     	tbnz	w10, #0x1f, 0x1008457f0 <_js_json_stringify+0x504>
1008456ec:     	add	x8, x8, #0x1
1008456f0:     	subs	x9, x9, #0x1
1008456f4:     	b.ne	0x1008456e4 <_js_json_stringify+0x3f8>
1008456f8:     	cmp	x24, #0x4
1008456fc:     	b.hs	0x1008457bc <_js_json_stringify+0x4d0>
100845700:     	mov	x25, x22
100845704:     	b	0x100845800 <_js_json_stringify+0x514>
100845708:     	and	x8, x22, #0x7fffffffffffffc0
10084570c:     	and	x8, x8, #0xffffffff0007ffff
100845710:     	add	x8, x21, x8
100845714:     	mov	x9, x21
100845718:     	ldp	q0, q1, [x9]
10084571c:     	ldp	q2, q3, [x9, #0x20]
100845720:     	orr.16b	v0, v1, v0
100845724:     	orr.16b	v1, v2, v3
100845728:     	orr.16b	v0, v0, v1
10084572c:     	umaxv.16b	b0, v0
100845730:     	fmov	w10, s0
100845734:     	tbnz	w10, #0x7, 0x10084562c <_js_json_stringify+0x340>
100845738:     	add	x9, x9, #0x40
10084573c:     	cmp	x9, x8
100845740:     	b.ne	0x100845718 <_js_json_stringify+0x42c>
100845744:     	ands	x9, x22, #0x30
100845748:     	b.eq	0x10084576c <_js_json_stringify+0x480>
10084574c:     	mov	x10, x9
100845750:     	mov	x11, x8
100845754:     	ldr	q0, [x11], #0x10
100845758:     	umaxv.16b	b0, v0
10084575c:     	fmov	w12, s0
100845760:     	tbnz	w12, #0x7, 0x10084562c <_js_json_stringify+0x340>
100845764:     	subs	x10, x10, #0x10
100845768:     	b.ne	0x100845754 <_js_json_stringify+0x468>
10084576c:     	and	x10, x22, #0xf
100845770:     	cbz	x10, 0x10084578c <_js_json_stringify+0x4a0>
100845774:     	add	x8, x8, x9
100845778:     	ldrsb	w9, [x8]
10084577c:     	tbnz	w9, #0x1f, 0x10084562c <_js_json_stringify+0x340>
100845780:     	add	x8, x8, #0x1
100845784:     	subs	x10, x10, #0x1
100845788:     	b.ne	0x100845778 <_js_json_stringify+0x48c>
10084578c:     	mov	x0, x22
100845790:     	bl	0x10034b1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845794:     	mov	x23, x0
100845798:     	stp	w22, w22, [x0]
10084579c:     	stp	wzr, wzr, [x0, #0xc]
1008457a0:     	str	w22, [x0, #0x8]
1008457a4:     	cbz	w22, 0x100845888 <_js_json_stringify+0x59c>
1008457a8:     	and	x2, x22, #0x7ffff
1008457ac:     	mov	x0, x1
1008457b0:     	mov	x1, x21
1008457b4:     	bl	0x100b61dec <_writev+0x100b61dec>
1008457b8:     	b	0x100845888 <_js_json_stringify+0x59c>
1008457bc:     	add	x9, x21, x24
1008457c0:     	ldrsb	w10, [x8]
1008457c4:     	tbnz	w10, #0x1f, 0x1008457f0 <_js_json_stringify+0x504>
1008457c8:     	ldrsb	w10, [x8, #0x1]
1008457cc:     	tbnz	w10, #0x1f, 0x1008457f0 <_js_json_stringify+0x504>
1008457d0:     	ldrsb	w10, [x8, #0x2]
1008457d4:     	tbnz	w10, #0x1f, 0x1008457f0 <_js_json_stringify+0x504>
1008457d8:     	ldrsb	w10, [x8, #0x3]
1008457dc:     	tbnz	w10, #0x1f, 0x1008457f0 <_js_json_stringify+0x504>
1008457e0:     	add	x8, x8, #0x4
1008457e4:     	cmp	x8, x9
1008457e8:     	b.ne	0x1008457c0 <_js_json_stringify+0x4d4>
1008457ec:     	b	0x100845700 <_js_json_stringify+0x414>
1008457f0:     	mov	w1, w22
1008457f4:     	mov	x0, x21
1008457f8:     	bl	0x1005ea960 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1008457fc:     	mov	x25, x0
100845800:     	bl	0x1004eff40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100845804:     	add	x0, x24, #0x14
100845808:     	mov	w1, #0x3                ; =3
10084580c:     	bl	0x1004583c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100845810:     	mov	x23, x0
100845814:     	stp	w25, w22, [x0]
100845818:     	stp	wzr, wzr, [x0, #0xc]
10084581c:     	str	w22, [x0, #0x8]
100845820:     	add	x0, x0, #0x14
100845824:     	mov	x1, x21
100845828:     	mov	x2, x24
10084582c:     	bl	0x100b61dec <_writev+0x100b61dec>
100845830:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100845834:     	ldr	w21, [x8, #0x590]
100845838:     	cmp	w21, #0x300
10084583c:     	b.hs	0x100845918 <_js_json_stringify+0x62c>
100845840:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100845844:     	ldr	x8, [x8, #0x48]
100845848:     	cmn	x8, #0x1
10084584c:     	b.eq	0x100845908 <_js_json_stringify+0x61c>
100845850:     	mrs	x9, TPIDRRO_EL0
100845854:     	and	x9, x9, #0xfffffffffffffff8
100845858:     	ldr	x0, [x9, x8, lsl #3]
10084585c:     	cbz	x0, 0x100845908 <_js_json_stringify+0x61c>
100845860:     	add	x8, x0, x21, lsl #3
100845864:     	ldr	x0, [x8, #0x1e8]
100845868:     	cbz	x0, 0x100845918 <_js_json_stringify+0x62c>
10084586c:     	ldr	x8, [x0]
100845870:     	adds	x8, x8, x24
100845874:     	csinv	x8, x8, xzr, lo
100845878:     	str	x8, [x0]
10084587c:     	lsr	x8, x8, #25
100845880:     	cbz	x8, 0x100845888 <_js_json_stringify+0x59c>
100845884:     	bl	0x10045f2f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845888:     	ldp	x22, x21, [sp, #0x8]
10084588c:     	ldrb	w8, [x20, #0x18]
100845890:     	cmp	w8, #0x1
100845894:     	b.ne	0x100845970 <_js_json_stringify+0x684>
100845898:     	ldp	x8, x0, [x20]
10084589c:     	stp	x22, x21, [x20]
1008458a0:     	str	xzr, [x20, #0x10]
1008458a4:     	sub	x8, x8, #0x1
1008458a8:     	cmn	x8, #0x2
1008458ac:     	b.hs	0x1008458b4 <_js_json_stringify+0x5c8>
1008458b0:     	bl	0x100b5ef40 <_mi_free>
1008458b4:     	cbz	w26, 0x1008458c0 <_js_json_stringify+0x5d4>
1008458b8:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008458bc:     	b	0x1008458c4 <_js_json_stringify+0x5d8>
1008458c0:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008458c4:     	ldr	w8, [x19]
1008458c8:     	sub	w8, w8, #0x1
1008458cc:     	str	w8, [x19]
1008458d0:     	mov	x0, x23
1008458d4:     	ldp	x29, x30, [sp, #0x70]
1008458d8:     	ldp	x20, x19, [sp, #0x60]
1008458dc:     	ldp	x22, x21, [sp, #0x50]
1008458e0:     	ldp	x24, x23, [sp, #0x40]
1008458e4:     	ldp	x26, x25, [sp, #0x30]
1008458e8:     	ldp	d9, d8, [sp, #0x20]
1008458ec:     	add	sp, sp, #0x80
1008458f0:     	ret
1008458f4:     	mov	x22, x0
1008458f8:     	add	x0, x0, #0x8
1008458fc:     	bl	0x100b3bcd0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845900:     	mov	x0, x22
100845904:     	b	0x100845430 <_js_json_stringify+0x144>
100845908:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084590c:     	add	x8, x0, x21, lsl #3
100845910:     	ldr	x0, [x8, #0x1e8]
100845914:     	cbnz	x0, 0x10084586c <_js_json_stringify+0x580>
100845918:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084591c:     	add	x0, x0, #0x78
100845920:     	bl	0x100b3cb9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845924:     	ldr	x8, [x0]
100845928:     	adds	x8, x8, x24
10084592c:     	csinv	x8, x8, xzr, lo
100845930:     	str	x8, [x0]
100845934:     	lsr	x8, x8, #25
100845938:     	cbnz	x8, 0x100845884 <_js_json_stringify+0x598>
10084593c:     	b	0x100845888 <_js_json_stringify+0x59c>
100845940:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845944:     	add	x8, x0, x20, lsl #3
100845948:     	ldr	x0, [x8, #0x1e8]
10084594c:     	cbnz	x0, 0x1008454c4 <_js_json_stringify+0x1d8>
100845950:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845954:     	add	x0, x0, #0x138
100845958:     	bl	0x100b3cb9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084595c:     	b	0x1008454c4 <_js_json_stringify+0x1d8>
100845960:     	mov	x0, x20
100845964:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845968:     	cbnz	x0, 0x10084550c <_js_json_stringify+0x220>
10084596c:     	b	0x100845a10 <_js_json_stringify+0x724>
100845970:     	mov	x0, x20
100845974:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845978:     	mov	x20, x0
10084597c:     	cbnz	x0, 0x100845898 <_js_json_stringify+0x5ac>
100845980:     	cbz	x22, 0x100845a10 <_js_json_stringify+0x724>
100845984:     	mov	x0, x21
100845988:     	bl	0x100b5ef40 <_mi_free>
10084598c:     	b	0x100845a10 <_js_json_stringify+0x724>
100845990:     	cmp	w8, #0x2
100845994:     	b.eq	0x100845a10 <_js_json_stringify+0x724>
100845998:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
10084599c:     	add	x1, x1, #0xff8
1008459a0:     	mov	x22, x0
1008459a4:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008459a8:     	mov	x0, x22
1008459ac:     	strb	wzr, [x22, #0x20]
1008459b0:     	ldr	x8, [x22]
1008459b4:     	cbz	x8, 0x100845568 <_js_json_stringify+0x27c>
1008459b8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008459bc:     	add	x0, x0, #0xdb8
1008459c0:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008459c4:     	bl	0x100b1e664 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
1008459c8:     	cbnz	x0, 0x100845410 <_js_json_stringify+0x124>
1008459cc:     	b	0x100845a10 <_js_json_stringify+0x724>
1008459d0:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1008459d4:     	add	x0, x0, #0x440
1008459d8:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008459dc:     	cmp	w8, #0x1
1008459e0:     	b.ne	0x100845a10 <_js_json_stringify+0x724>
1008459e4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008459e8:     	add	x1, x1, #0x998
1008459ec:     	mov	x20, x0
1008459f0:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008459f4:     	mov	x0, x20
1008459f8:     	strb	wzr, [x20, #0x20]
1008459fc:     	ldr	x8, [x20]
100845a00:     	cbz	x8, 0x1008454e8 <_js_json_stringify+0x1fc>
100845a04:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845a08:     	add	x0, x0, #0xd88
100845a0c:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845a10:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845a14:     	add	x0, x0, #0xc18
100845a18:     	bl	0x100b5859c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
