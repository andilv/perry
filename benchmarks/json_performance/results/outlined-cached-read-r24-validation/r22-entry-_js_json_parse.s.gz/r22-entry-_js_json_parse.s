
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/r22-shared-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008445d4 <_js_json_parse>:
1008445d4:     	stp	x29, x30, [sp, #-0x10]!
1008445d8:     	mov	x29, sp
1008445dc:     	cbz	x0, 0x100844634 <_js_json_parse+0x60>
1008445e0:     	ldr	w1, [x0, #0x4]
1008445e4:     	cmp	w1, #0x2
1008445e8:     	b.eq	0x1008445f8 <_js_json_parse+0x24>
1008445ec:     	cbz	w1, 0x100844634 <_js_json_parse+0x60>
1008445f0:     	ldrb	w8, [x0, #0x14]
1008445f4:     	b	0x100844618 <_js_json_parse+0x44>
1008445f8:     	ldrb	w8, [x0, #0x14]
1008445fc:     	cmp	w8, #0x7b
100844600:     	b.ne	0x100844618 <_js_json_parse+0x44>
100844604:     	ldrb	w8, [x0, #0x15]
100844608:     	cmp	w8, #0x7d
10084460c:     	b.ne	0x100844624 <_js_json_parse+0x50>
100844610:     	ldp	x29, x30, [sp], #0x10
100844614:     	b	0x1004ec940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100844618:     	orr	w8, w8, #0x20
10084461c:     	cmp	w8, #0x7b
100844620:     	b.ne	0x10084462c <_js_json_parse+0x58>
100844624:     	ldp	x29, x30, [sp], #0x10
100844628:     	b	0x100505db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10084462c:     	ldp	x29, x30, [sp], #0x10
100844630:     	b	0x100508434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100844634:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6f5c>
100844638:     	add	x0, x0, #0x581
10084463c:     	mov	w1, #0x1c               ; =28
100844640:     	bl	0x100508868 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
